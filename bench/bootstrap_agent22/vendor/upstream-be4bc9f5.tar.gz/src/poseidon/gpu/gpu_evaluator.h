#pragma once

#include "poseidon/gpu/gpu_ciphertext.h"
#include "poseidon/gpu/gpu_double_hoist.h"
#include "poseidon/gpu/gpu_plaintext.h"
#include "poseidon/gpu/gpu_key.h"
#include "poseidon/gpu/gpu_linear_transform.h"
#include "poseidon/gpu/gpu_parameter.h"

#include "poseidon/gpu/gpu_elementwise_handler.h"
#include "poseidon/gpu/gpu_keyswitch_handler.h"
#include "poseidon/gpu/gpu_ntt_handler.h"
#include "poseidon/gpu/gpu_modswitch_handler.h"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace poseidon
{
namespace gpu
{

enum class GpuEvalModPolynomialBasis : std::uint8_t
{
    Monomial = 0,
    Chebyshev = 1,
};

struct GpuEvalModPolynomialTerm
{
    std::uint32_t degree = 0;
    GpuPlaintextData coefficient_plaintext;
};

/**
 * @brief One setup-time scheduled ciphertext-basis operation for EvalMod.
 *
 * For the monomial basis this computes X^output = X^left * X^right.
 * For the Chebyshev basis this computes
 * T_output = 2*T_left*T_right - T_correction. A zero correction degree means
 * subtracting the pre-uploaded plaintext constant one.
 *
 * Steps must be topologically sorted by CPU setup. The GPU runtime never
 * recursively discovers powers or branches on polynomial coefficients.
 */
struct GpuEvalModBasisStep
{
    std::uint32_t output_degree = 0;
    std::uint32_t left_degree = 0;
    std::uint32_t right_degree = 0;
    std::uint32_t correction_degree = 0;
    double pre_rescale_scale = 0.0;
    double output_scale = 0.0;
    std::uint32_t rescale_count = 1;

    bool align_left_operand = false;
    GpuPlaintextData operand_alignment_plaintext;
    double operand_alignment_pre_rescale_scale = 0.0;
    double operand_alignment_output_scale = 0.0;
    std::uint32_t operand_alignment_rescale_count = 1;
    GpuPlaintextData correction_alignment_plaintext;
    double correction_alignment_pre_rescale_scale = 0.0;
    std::uint32_t correction_alignment_rescale_count = 1;

    /*
     * Chebyshev only. For correction_degree==0 this is the constant one at
     * output_scale. Otherwise it is a plaintext one whose scale converts the
     * correction basis to output_scale without changing its decoded value.
     */
    GpuPlaintextData correction_plaintext;
};

/**
 * @brief One low-degree leaf of the setup-time polynomial split tree.
 */
struct GpuEvalModPolynomialBlock
{
    std::vector<GpuEvalModPolynomialTerm> terms;
    std::uint32_t rescale_count = 1;
    double output_scale = 0.0;
    std::size_t output_q_count = 0;
};

/**
 * @brief Fixed Q*T_k+R combine node used by the EvalMod BSGS tree.
 */
struct GpuEvalModPolynomialCombineStep
{
    std::uint32_t output_node = 0;
    std::uint32_t quotient_node = 0;
    std::uint32_t remainder_node = 0;
    std::uint32_t basis_degree = 0;
    double output_scale = 0.0;
    std::size_t output_q_count = 0;
    std::uint32_t quotient_rescale_count = 0;
    double quotient_output_scale = 0.0;
    std::uint32_t remainder_rescale_count = 0;
    double product_scale = 0.0;
    std::size_t product_q_count = 0;
    GpuPlaintextData product_scale_plaintext;
    double product_aligned_scale = 0.0;
    GpuPlaintextData remainder_scale_plaintext;
    double remainder_aligned_scale = 0.0;
};

/**
 * @brief Build the fixed EvalMod basis DAG during untimed CPU setup.
 *
 * requested_degrees normally contains the non-zero degrees of the uploaded
 * polynomial terms. The returned steps are topologically sorted and contain
 * no run-time level/scale decisions.
 */
std::vector<GpuEvalModBasisStep> make_gpu_eval_mod_basis_plan(
    GpuEvalModPolynomialBasis basis,
    const std::vector<std::uint32_t> &requested_degrees,
    std::uint32_t preferred_giant_stride = 0);

/**
 * @brief GPU-resident bootstrapping constants and precomputed objects.
 *
 * Matrix/plaintext/key generation stays on the CPU side. This structure only
 * stores objects that have already been uploaded to GPU memory and scalar
 * parameters needed by the GPU bootstrapping scheduler.
 */
class GpuEvaluator;

struct GpuBootstrapData
{
    std::size_t allocated_bytes() const;
    GpuLinearTransformMode linear_transform_mode =
        GpuLinearTransformMode::ClassicBsgs;
    bool allow_environment_linear_transform_override = true;
    bool slot_to_coeff_first = false;
    // Set only by a profile whose Boot ends in a real projection of
    // f(real) + i*f(imag) with a real-coefficient EvalMod polynomial: both
    // branches hold real slots, so the projection keeps exactly f(real) and
    // POSEIDON_OPT_BOOT_REAL_ONLY may skip the imaginary branch.
    bool real_evalmod_projection_safe = false;
    std::size_t input_q_count = 0;
    double input_scale = 0.0;
    double output_scale_multiplier = 1.0;

    parms_id_type q0_parms_id{};
    double q0_over_message_ratio = 0.0;

    double raised_scale_override = 0.0;
    std::uint64_t post_raise_integer_multiplier = 1;
    double post_raise_scale_multiplier = 1.0;
    GpuPlaintextData post_raise_plaintext;

    /* Logical CKKS scale restored after EvalMod and before SlotToCoeff. */
    double slot_to_coeff_input_scale = 0.0;

    struct EvalModData
    {
        /* Physical scale supplied by dynamic C2S; target_scale remains min_scale. */
        double input_scale = 0.0;
        double target_scale = 0.0;
        double output_scale = 0.0;
        parms_id_type output_parms_id{};
        std::size_t output_q_count = 0;
        GpuPlaintextData input_offset_plaintext;

        /*
         * Preferred high-precision EvalMod plan.
         *
         * Each term is already encoded/uploaded by CPU setup at the exact
         * parms_id and plaintext scale needed by the corresponding GPU basis
         * ciphertext. Runtime GPU EvalMod only generates ciphertext bases,
         * multiply_plain's these constants, and performs level-aligned sums.
         * Non-constant terms should be ordered by nondecreasing q_count so the
         * accumulator reaches its final level without repeated down-switches.
         */
        GpuEvalModPolynomialBasis polynomial_basis =
            GpuEvalModPolynomialBasis::Monomial;
        std::uint32_t polynomial_degree = 0;
        std::uint32_t polynomial_log_split = 0;
        bool polynomial_flat_bsgs = false;
        bool polynomial_degree_bound_virtual = false;
        std::size_t polynomial_root_anchor_q_count = 0;
        std::vector<GpuEvalModBasisStep> basis_steps;
        std::vector<GpuEvalModPolynomialTerm> polynomial_terms;

        /*
         * Number of physical Q primes removed by one logical EvalMod
         * rescale. A value of two lets 29/30-bit GPU primes implement an
         * approximately 58/60-bit CKKS working scale. Runtime executes this
         * fixed setup-time plan with the exact two-prime rescale_x2 path.
         */
        std::uint32_t logical_rescale_count = 1;
        bool dynamic_rescale = false;
        double dynamic_min_scale = 0.0;

        /*
         * Fixed number of physical primes removed after a polynomial leaf
         * sum. The optimized plan accumulates all leaf terms first and then
         * performs one logical rescale; the legacy plan rescales every term.
         */
        std::uint32_t polynomial_rescale_count = 1;
        /* Setup-time exact final drop count; zero means no final rescale. */
        std::uint32_t polynomial_final_rescale_count = 0;
        double polynomial_output_scale = 0.0;
        bool rescale_polynomial_terms_individually = false;

        /*
         * Preferred BSGS/recurse-equivalent schedule for the 59-degree path.
         * Leaf blocks and combine steps are fully generated during CPU setup.
         * Node ids [0, polynomial_blocks.size()) name leaf outputs; combine
         * steps append/overwrite only the explicitly declared output nodes.
         */
        std::vector<GpuEvalModPolynomialBlock> polynomial_blocks;
        std::vector<GpuEvalModPolynomialCombineStep> polynomial_combine_steps;
        std::uint32_t polynomial_result_node = 0;

        /*
         * Plaintext constants used by GPU Chebyshev basis generation.
         *
         * For T_{2k}=2*T_k^2-1 and T_{a+b}=2*T_a*T_b-T_|a-b|,
         * the degree-zero term requires a plaintext 1 encoded at the generated
         * basis ciphertext parms_id. CPU setup should upload one plaintext for
         * every EvalMod basis level that may be produced.
         */
        std::vector<GpuPlaintextData> chebyshev_one_plaintexts;

        /*
         * Legacy EvalMod polynomial coefficients uploaded as plaintexts.
         *
         * CPU setup may generate/encode these constants, but the polynomial
         * evaluation itself is executed by GpuEvaluator::eval_mod_high_precision.
         * New setup code should prefer polynomial_terms above. This field is
         * kept only for compatibility with old bootstrapping tests.
         */
        std::vector<GpuPlaintextData> polynomial_coefficients;

        /*
         * Double-angle additive constants, one per iteration, already encoded
         * and uploaded to GPU memory.
         */
        std::vector<GpuPlaintextData> double_angle_constants;
        std::vector<std::uint32_t> double_angle_rescale_counts;

        /* Q prefixes whose zero-copy relinearization-key views are used. */
        std::vector<std::size_t> required_relin_q_counts;
    };

    EvalModData eval_mod;

    /*
     * Backward-compatible flat fields for early bootstrap tests/setup code.
     * Prefer eval_mod.* for new call sites.
     */
    double eval_mod_target_scale = 1.0;
    GpuPlaintextData eval_mod_input_offset_plaintext;
    std::vector<GpuPlaintextData> eval_mod_polynomial_plaintexts;
    std::vector<GpuPlaintextData> double_angle_plaintexts;

    GpuLinearMatrixGroup coeff_to_slot_matrix;
    GpuLinearMatrixGroup slot_to_coeff_matrix;
    GpuLinearMatrixGroupQP coeff_to_slot_matrix_qp;
    GpuLinearMatrixGroupQP slot_to_coeff_matrix_qp;
    /* Double-hoist only: [layer][giant group] views of the QP matrices above,
     * for the bsgs_group step of an expanded Boot. */
    std::vector<std::vector<GpuMatrixPlainQP>> coeff_to_slot_groups_qp;
    std::vector<std::vector<GpuMatrixPlainQP>> slot_to_coeff_groups_qp;
    GpuPlaintextData minus_i_plaintext;
    GpuPlaintextData plus_i_plaintext;

    /* Final reconstruction used by the production CPU Bootstrapper. */
    bool project_real = false;
    std::uint32_t output_ratio = 1;
    double slot_to_coeff_output_scale = 0.0;

    /*
     * Sparse-secret encapsulation (Bossuat et al.; Cerium's toEphemeral): at
     * q0 the ModRaise input is switched from the dense secret to a sparse
     * ephemeral one, so the ModRaise overflow I stays within a small K and
     * EvalMod can use a low-degree polynomial; right after ModRaise it is
     * switched back to the dense secret. Both are single-key KSwitch keys
     * (key index 0). Absent keys mean no encapsulation.
     */
    std::shared_ptr<const GpuEvaluationKeyData> sparse_switch_to_ephemeral;
    std::shared_ptr<const GpuEvaluationKeyData> sparse_switch_to_dense;
    /*
     * Optional small-modulus runtime for the dense -> ephemeral switch. Its
     * context keeps only the q0 primes and a few special primes, and
     * sparse_switch_to_ephemeral is then generated on that modulus alone, so
     * the dense secret is never published under the h-sparse ephemeral
     * secret at the full Q*P modulus. The owner keeps the context, GPU tables
     * and evaluator alive; the evaluator pointer is null when unused.
     */
    const GpuEvaluator *sparse_low_evaluator = nullptr;
    std::shared_ptr<const void> sparse_low_owner;

    /*
     * When non-zero, the EvalMod outputs are mod-switched down to this Q
     * count before SlotToCoeff, so a profile whose EvalMod consumes fewer
     * levels keeps the output level its OperatorSpec declares and runs
     * SlotToCoeff on fewer limbs.
     */
    std::size_t slot_to_coeff_input_q_count = 0;
    parms_id_type slot_to_coeff_input_parms_id{};
};

/**
 * @brief Reusable ciphertext storage for the GPU bootstrapping scheduler.
 *
 * The fields are intentionally explicit so the full bootstrap path can reuse
 * storage across calls without changing the component/limb/coeff layout used
 * by the existing GPU primitives.
 */
struct GpuBootstrapWorkspace
{
    // Launch independent work from the small input before the primary prefix.
    // It must be joined by parallel_eval_mod before bootstrap returns.
    std::function<void(const GpuCiphertextData &)> begin_parallel_bootstrap;
    // Optional application scheduler for the independent EvalMod branches.
    // It evaluates `imag`, invokes `evaluate_real` exactly once, and returns
    // the imaginary result on the caller's device before returning.
    std::function<void(const GpuCiphertextData &imag,
        const std::function<void()> &evaluate_real, GpuCiphertextData &result)>
        parallel_eval_mod;
    GpuCiphertextData modraise_input;
    GpuCiphertextData raised;
    GpuCiphertextData raised_scaled;

    GpuCiphertextData coeff_to_slot_real;
    GpuCiphertextData coeff_to_slot_imag;

    GpuCiphertextData eval_mod_real;
    GpuCiphertextData eval_mod_imag;

    GpuCiphertextData scratch0;
    GpuCiphertextData scratch1;
    GpuCiphertextData scratch2;
    GpuCiphertextData scratch3;
    GpuCiphertextData scratch4;
    GpuCiphertextData scratch5;

    std::vector<GpuCiphertextData> eval_mod_basis;
    std::vector<GpuCiphertextData> eval_mod_nodes;

    GpuDoubleHoistWorkspace coeff_to_slot_double_hoist;
    GpuDoubleHoistWorkspace slot_to_coeff_double_hoist;

    struct EvalModStageTiming
    {
        double input_preparation_ms{0.0};
        double basis_generation_ms{0.0};
        double leaf_evaluation_ms{0.0};
        double bsgs_combine_ms{0.0};
        double double_angle_ms{0.0};
        double output_alignment_ms{0.0};
        double total_ms{0.0};
    };

    struct EvalModMultiplyTiming
    {
        std::string label;
        std::size_t q_count{0};
        std::size_t decomposition_count{0};
        bool is_square{false};
        double gpu_ms{0.0};
    };

    // CUDA-event profiling is opt-in and is disabled for normal timed calls.
    // A caller can profile one EvalMod invocation without introducing event
    // synchronization into the production bootstrap path.
    bool capture_eval_mod_stage_timing{false};
    EvalModStageTiming eval_mod_stage_timing;
    std::vector<EvalModMultiplyTiming> eval_mod_multiply_timings;

    // Optional correctness-only snapshots. They remain disabled in timed and
    // production bootstrap calls, so the hot path pays no copy or storage cost.
    bool capture_eval_mod_trace{false};
    GpuCiphertextData eval_mod_trace_offset_input;
    GpuCiphertextData eval_mod_trace_polynomial_output;
    std::vector<GpuCiphertextData> eval_mod_trace_double_angle_square_outputs;
    std::vector<GpuCiphertextData> eval_mod_trace_double_angle_relin_outputs;
    std::vector<GpuCiphertextData> eval_mod_trace_double_angle_rescaled_square_outputs;
    std::vector<GpuCiphertextData> eval_mod_trace_polynomial_leaf_outputs;
    std::vector<GpuCiphertextData> eval_mod_trace_polynomial_combine_outputs;
    std::vector<GpuCiphertextData> eval_mod_trace_double_angle_outputs;
};

/**
 * @brief Top-level GPU evaluator.
 *
 * This class is the highest-level GPU homomorphic operation interface.
 *
 * It plays a role similar to Cheddar's Context operation entry, but uses
 * Poseidon-style naming and Poseidon-style component vectors.
 *
 * Responsibilities:
 * - check FHE semantic validity;
 * - prepare destination metadata;
 * - prepare destination storage;
 * - create views;
 * - select the proper handler.
 *
 * It does not directly launch CUDA kernels.
 * Kernel launch planning belongs to handler classes.
 */
struct GpuRotateWorkspace
{
    GpuCiphertextData permutation;
    GpuDoubleHoistWorkspace pre_rotated;
    std::shared_ptr<void> key_switch;
};

/**
 * @brief The HYBRID decomposition/ModUp of one source ciphertext's c1, kept
 * for later rotations of the same source (runtime hoisting). The caller names
 * the source with a tag that it never reuses for different data; zero means
 * empty. Only inverse-pre-rotated Galois keys rotate from a hoisted source.
 */
struct GpuRotationHoistCache
{
    std::uintptr_t source_tag = 0;
    std::shared_ptr<const void> source_owner;
    GpuHoistedDecomposition decomposition;
    std::size_t hits = 0;
    std::size_t misses = 0;
};

class GpuEvaluator
{
public:
    explicit GpuEvaluator(const GpuParameterData &params);

    struct RetainedWorkspaceBytes
    {
        std::size_t rescale;
        std::size_t relinearize;
    };

    // Query between executions, when this evaluator is not allocating scratch.
    RetainedWorkspaceBytes retained_workspace_bytes(
        const rmm::mr::device_memory_resource *resource = nullptr) const
    {
        return {modswitch_handler_.retained_workspace_bytes(resource),
                keyswitch_handler_.retained_workspace_bytes(resource)};
    }

    void add(
        const GpuCiphertextData &left_ciphertext,
        const GpuCiphertextData &right_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    void sub(
        const GpuCiphertextData &left_ciphertext,
        const GpuCiphertextData &right_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    void negate(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    void add_plain(
        const GpuCiphertextData &source_ciphertext,
        const GpuPlaintextData &source_plaintext,
        GpuCiphertextData &destination_ciphertext) const;

    void sub_plain(
        const GpuCiphertextData &source_ciphertext,
        const GpuPlaintextData &source_plaintext,
        GpuCiphertextData &destination_ciphertext) const;

    void add_plain_inplace(GpuCiphertextData &ciphertext,
                           const GpuPlaintextData &plaintext) const;
    void sub_plain_inplace(GpuCiphertextData &ciphertext,
                           const GpuPlaintextData &plaintext) const;

    void multiply_plain(
        const GpuCiphertextData &source_ciphertext,
        const GpuPlaintextData &source_plaintext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Multiply a read-only ciphertext Q prefix by a target-level plaintext.
     *
     * source_ciphertext may reside at a higher q-only level than the plaintext.
     * Its trailing q limbs remain owned and unchanged but are hidden from the
     * kernel view. No prefix materialization copy is issued.
     */
    void multiply_plain_q_prefix(
        const GpuCiphertextData &source_ciphertext,
        const GpuPlaintextData &source_plaintext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * Sum one to four plaintext products at the plaintexts' common Q level.
     * Reads const ciphertext Q prefixes and preserves every term. Product
     * scales must already agree (apart from floating metadata roundoff).
     * No rescale, modulus conversion, or coefficient approximation is done.
     * With accumulate=true, add into an already aligned two-component
     * destination in place; its scale metadata is preserved.
     */
    void multiply_plain_sum_q_prefix(
        const std::vector<const GpuCiphertextData *> &ciphertexts,
        const std::vector<const GpuPlaintextData *> &plaintexts,
        GpuCiphertextData &destination_ciphertext,
        bool accumulate = false) const;

    /** Exact 2*source - plaintext, or 2*source - correction*plaintext.
     * Source and plaintext are at the output Q level; an optional correction
     * is read through a const Q prefix. The encoded plaintext is not changed.
     * All inputs are immutable, output aliasing is safe, and no rescale occurs.
     */
    void double_sub_plain_q_prefix(
        const GpuCiphertextData &source,
        const GpuPlaintextData &plaintext,
        GpuCiphertextData &destination,
        const GpuCiphertextData *correction = nullptr) const;

    void multiply_double_sub_plain_q_prefix(
        const GpuCiphertextData &left_ciphertext,
        const GpuCiphertextData &right_ciphertext,
        const GpuPlaintextData &plaintext,
        GpuCiphertextData &destination,
        const GpuCiphertextData *correction = nullptr) const;

    void multiply_add_q_prefix(
        const GpuCiphertextData &left_ciphertext,
        const GpuCiphertextData &right_ciphertext,
        const GpuCiphertextData &addend_ciphertext,
        GpuCiphertextData &destination_ciphertext,
        parms_id_type target_parms_id) const;

    void multiply_plain_accumulate(
        const GpuCiphertextData &source_ciphertext,
        const GpuPlaintextData &source_plaintext,
        GpuCiphertextData &destination_ciphertext) const;

    void ntt_fwd(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    void ntt_inv(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    void multiply(
        const GpuCiphertextData &left_ciphertext,
        const GpuCiphertextData &right_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Multiply read-only q-only prefixes at target_parms_id.
     *
     * Either input may reside above the target level. The operation creates
     * temporary const views with shortened logical limb counts, leaving both
     * owners unchanged and avoiding ModDrop prefix copies.
     */
    void multiply_q_prefix(
        const GpuCiphertextData &left_ciphertext,
        const GpuCiphertextData &right_ciphertext,
        GpuCiphertextData &destination_ciphertext,
        parms_id_type target_parms_id) const;

    void square(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    void rescale(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Drop two physical q primes with one centered base conversion.
     *
     * The result is exactly equivalent to two consecutive ordinary rescales.
     * The optimized implementation currently batches c0 and c1.
     */
    void rescale_x2(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Execute a fixed number of CKKS rescale operations.
     *
     * The entire dropped q suffix is processed by one exact centered BConv.
     * Counts one and two retain their specialized fast paths when available.
     */
    void rescale_many(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext,
        std::uint32_t rescale_count) const;

    void rescale_many_pair(
        const GpuCiphertextData &source0,
        const GpuCiphertextData &source1,
        GpuCiphertextData &destination0,
        GpuCiphertextData &destination1,
        std::uint32_t rescale_count) const;

    void rescale_dynamic(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext,
        double min_scale) const;

    void drop_modulus(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext,
        parms_id_type target_parms_id) const;

    /**
     * @brief Logically discard an owned ciphertext's trailing q limbs.
     *
     * This is the consuming/last-use counterpart of drop_modulus(). It keeps
     * the existing device allocation and component offsets, but shortens each
     * component's visible q prefix. No CUDA work or device copy is issued.
     * The caller must own the ciphertext exclusively because the discarded
     * suffix is no longer addressable through its metadata.
     */
    void drop_modulus_inplace(
        GpuCiphertextData &ciphertext,
        parms_id_type target_parms_id) const;

    /**
     * @brief Multiply every ciphertext component by one integer scalar modulo q.
     *
     * This is primarily used by bootstrap scale matching before ModRaise.
     */
    void multiply_scalar(
        const GpuCiphertextData &source_ciphertext,
        std::uint64_t scalar,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief CKKS bootstrap ModRaise.
     *
     * Mirrors EvaluatorCkksBase::raise_modulus for the bootstrap path:
     * source is transformed to coefficient domain if needed, converted from
     * its current q-only prefix level to the first q-only Q level, then
     * transformed back to NTT form.
     */
    void raise_modulus(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Prepare a CKKS ciphertext for bootstrap ModRaise.
     *
     * Drops to one q modulus above q0, multiplies by the integer nearest to
     * q0_over_message_ratio * q_last / input_scale, then rescales once to q0.
     * Multiplication precedes Rescale to preserve the input precision. The
     * actual resulting scale is retained; it approximates the target with
     * relative error at most 0.5 / the unrounded multiplier.
     * Requires one q above q0 and a multiplier in [1, 2^53].
     *
     * The result is still q-only and in the same NTT form as the input.
     * This function intentionally does not perform Q0 -> QL basis extension.
     */
    void bootstrap_prepare_modraise_input(
        const GpuCiphertextData &source_ciphertext,
        GpuCiphertextData &destination_ciphertext,
        parms_id_type q0_parms_id,
        double q0_over_message_ratio) const;

    /**
     * @brief Relinearize ciphertext.
     *
     * Dispatches size-3 CKKS ciphertexts to the HYBRID key-switch handler and
     * writes a size-2 ciphertext in NTT form.
     */
    void relinearize(
        const GpuCiphertextData &source_ciphertext,
        const GpuRelinKeysData &relin_keys,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * Try the opt-in, shared-key batch2 HYBRID pipeline.
     *
     * Returns false without changing either destination when disabled or when
     * the input layout is unsupported. On success each result is exactly the
     * corresponding scalar relinearize result. Outputs must be distinct, but
     * may alias either input; both inputs are consumed before outputs move.
     */
    bool try_relinearize_pair(
        const GpuCiphertextData &source0,
        const GpuCiphertextData &source1,
        const GpuRelinKeysData &relin_keys,
        GpuCiphertextData &destination0,
        GpuCiphertextData &destination1) const;

    bool try_relinearize_rescale_pair(
        const GpuCiphertextData &source0,
        const GpuCiphertextData &source1,
        const GpuRelinKeysData &relin_keys,
        std::uint32_t drop_count,
        PairRelinPostOp post_op,
        const GpuPlaintextData *plain,
        const GpuCiphertextData *extra0,
        const GpuCiphertextData *extra1,
        GpuCiphertextData &destination0,
        GpuCiphertextData &destination1) const;

    bool try_relinearize_rescale_single(
        const GpuCiphertextData &source,
        const GpuRelinKeysData &relin_keys,
        std::uint32_t drop_count,
        PairRelinPostOp post_op,
        const GpuPlaintextData *plain,
        const GpuCiphertextData *extra,
        GpuCiphertextData &destination) const;

    /**
     * @brief Relinearize and drop two q primes in one HYBRID finalize path.
     *
     * This is equivalent to relinearize(source) followed by rescale_x2, but
     * avoids materializing the full same-level size-2 ciphertext.
     */
    void relinearize_rescale_x1_hybrid(
        const GpuCiphertextData &source_ciphertext,
        const GpuRelinKeysData &relin_keys,
        GpuCiphertextData &destination_ciphertext,
        bool double_moddown = false) const;

    void relinearize_rescale_x2_hybrid(
        const GpuCiphertextData &source_ciphertext,
        const GpuRelinKeysData &relin_keys,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Rotate ciphertext.
     *
     * First CKKS implementation:
     * - apply NTT-domain Galois permutation to c0/c1;
     * - key-switch the permuted c1 with the uploaded Galois key;
     * - currently requires the direct Galois key for the requested step.
     */
    void rotate(
        const GpuCiphertextData &source_ciphertext,
        int step,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * As rotate(), reusing @p hoist_cache's decomposition when it holds
     * @p source_tag (and refilling it otherwise). Keys that are not
     * inverse-pre-rotated ignore the cache.
     */
    void rotate(
        const GpuCiphertextData &source_ciphertext,
        int step,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination_ciphertext,
        GpuRotationHoistCache *hoist_cache,
        std::uintptr_t source_tag) const;

    void rotate_inplace(GpuCiphertextData &ciphertext, int step,
                        const GpuGaloisKeysData &galois_keys,
                        GpuRotateWorkspace &workspace) const;
    /** As above; a pre-rotated rotation reads @p hoist_cache when it holds @p source_tag. */
    void rotate_inplace(GpuCiphertextData &ciphertext, int step,
                        const GpuGaloisKeysData &galois_keys,
                        GpuRotateWorkspace &workspace,
                        const GpuRotationHoistCache *hoist_cache,
                        std::uintptr_t source_tag) const;

    /**
     * @brief Switch a size-2 ciphertext to another secret with a single
     * KSwitch key (key index 0), at the ciphertext's own level.
     */
    void switch_key(
        const GpuCiphertextData &source_ciphertext,
        const GpuEvaluationKeyData &switch_key,
        GpuCiphertextData &destination_ciphertext) const;
    /**
     * @brief Rotate one ciphertext by several direct steps with one shared
     * HYBRID decomposition/ModUp of c1.
     *
     * Every step must be nonzero and have a direct Galois key. Results retain
     * the input level and scale in the same order as @p steps.
     */
    void rotate_many_hoisted(
        const GpuCiphertextData &source_ciphertext,
        const std::vector<int> &steps,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        std::vector<GpuCiphertextData> &destination_ciphertexts) const;

    void rotate_many_hoisted_sum_with_identity(
        const GpuCiphertextData &source_ciphertext,
        const std::vector<int> &steps,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    void rotate_same_step_batch(
        const std::vector<const GpuCiphertextData *> &sources,
        int step,
        const GpuGaloisKeysData &galois_keys,
        std::vector<GpuCiphertextData> &destinations,
        const std::vector<const GpuCiphertextData *> *add_sources = nullptr) const;

    void rotate_distinct_steps_batch(
        const std::vector<const GpuCiphertextData *> &sources,
        const std::vector<int> &steps,
        const GpuGaloisKeysData &galois_keys,
        std::vector<GpuCiphertextData> &destinations) const;

    void rotate_distinct_steps_sum(
        const std::vector<const GpuCiphertextData *> &sources,
        const std::vector<int> &steps,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination) const;

    /**
     * @brief Conjugate ciphertext.
     *
     * First CKKS implementation:
     * - apply NTT-domain conjugation Galois permutation to c0/c1;
     * - key-switch the permuted c1 with the uploaded conjugation key.
     */
    void conjugate(
        const GpuCiphertextData &source_ciphertext,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination_ciphertext) const;

    void conjugate_pre_rotated(
        const GpuCiphertextData &source_ciphertext,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext,
        const GpuCiphertextData *add_source = nullptr) const;

    bool try_conjugate_pre_rotated_c2s_split(
        const GpuCiphertextData &dft_result,
        const GpuPlaintextData &minus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &result_real,
        GpuCiphertextData &result_imag) const;

    /**
     * @brief Multiply by one pre-uploaded diagonal plaintext matrix using BSGS.
     *
     * This mirrors the current GPU bootstrap test reference while using
     * GPU rotate/multiply_plain/add/rescale primitives. Delayed/dynamic
     * rescale is intentionally not used in this temporary bootstrapping path.
     */
    void multiply_by_diag_matrix_bsgs(
        const GpuCiphertextData &source_ciphertext,
        const GpuMatrixPlain &matrix,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination_ciphertext) const;

    void multiply_by_diag_matrix_bsgs(
        const GpuCiphertextData &source_ciphertext,
        const GpuMatrixPlain &matrix,
        const GpuGaloisKeysData &galois_keys,
        std::uint32_t rescale_count,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * Execute the explicit loose-coupled BSGS graph.  Every baby rotation,
     * plaintext product, giant-group reduction, giant rotation, and final
     * reduction is separated by an ordinary Q-basis ciphertext boundary.
     * This reference executor is single-device; make_gpu_loose_bsgs_plan()
     * exposes the same graph for later multi-GPU lowering.
     */
    void multiply_by_diag_matrix_bsgs_loose(
        const GpuCiphertextData &source_ciphertext,
        const GpuMatrixPlain &matrix,
        const GpuGaloisKeysData &galois_keys,
        std::uint32_t rescale_count,
        GpuCiphertextData &destination_ciphertext) const;

    void multiply_by_diag_matrix_bsgs_double_hoist(
        const GpuCiphertextData &source_ciphertext,
        const GpuMatrixPlainQP &matrix,
        const GpuGaloisKeysData &galois_keys,
        std::uint32_t rescale_count,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Apply a pre-uploaded DFT linear matrix group.
     */
    void dft(
        const GpuCiphertextData &source_ciphertext,
        const GpuLinearMatrixGroup &matrix_group,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination_ciphertext) const;

    void dft_loose(
        const GpuCiphertextData &source_ciphertext,
        const GpuLinearMatrixGroup &matrix_group,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &destination_ciphertext) const;

    void dft_double_hoist(
        const GpuCiphertextData &source_ciphertext,
        const GpuLinearMatrixGroupQP &matrix_group,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief CKKS CoeffToSlot with CPU-precomputed matrices already on GPU.
     *
     * minus_i_plaintext must be the CPU-encoded plaintext for complex(0, -1)
     * at the DFT output parms_id and scale 1.0, uploaded to GPU outside the
     * timed GPU path.
     */
    void coeff_to_slot(
        const GpuCiphertextData &source_ciphertext,
        const GpuLinearMatrixGroup &matrix_group,
        const GpuPlaintextData &minus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &result_real,
        GpuCiphertextData &result_imag) const;

    void coeff_to_slot_loose(
        const GpuCiphertextData &source_ciphertext,
        const GpuLinearMatrixGroup &matrix_group,
        const GpuPlaintextData &minus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &result_real,
        GpuCiphertextData &result_imag) const;

    void coeff_to_slot_double_hoist(
        const GpuCiphertextData &source_ciphertext,
        const GpuLinearMatrixGroupQP &matrix_group,
        const GpuPlaintextData &minus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &result_real,
        GpuCiphertextData &result_imag,
        bool compute_imag = true) const;

    /**
     * @brief CKKS SlotToCoeff with CPU-precomputed inverse DFT matrices already on GPU.
     *
     * plus_i_plaintext must be the CPU-encoded plaintext for complex(0, 1)
     * at the input imag ciphertext parms_id and scale 1.0, uploaded to GPU
     * outside the timed GPU path.
     */
    void slot_to_coeff(
        const GpuCiphertextData &source_real,
        const GpuCiphertextData &source_imag,
        const GpuLinearMatrixGroup &matrix_group,
        const GpuPlaintextData &plus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &result) const;

    void slot_to_coeff_loose(
        const GpuCiphertextData &source_real,
        const GpuCiphertextData &source_imag,
        const GpuLinearMatrixGroup &matrix_group,
        const GpuPlaintextData &plus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuCiphertextData &result) const;

    void slot_to_coeff_double_hoist(
        const GpuCiphertextData &source_real,
        const GpuCiphertextData &source_imag,
        const GpuLinearMatrixGroupQP &matrix_group,
        const GpuPlaintextData &plus_i_plaintext,
        const GpuGaloisKeysData &galois_keys,
        GpuDoubleHoistWorkspace &workspace,
        GpuCiphertextData &result) const;

    /**
     * @brief CKKS bootstrapping scheduler using GPU-resident precomputed data.
     *
     * This stitches together the already implemented GPU stages:
     * prepare/ModRaise -> CoeffToSlot -> EvalMod -> SlotToCoeff.
     * EvalMod uses the setup-time static GPU plan stored in GpuBootstrapData.
     */
    void bootstrap(
        const GpuCiphertextData &source_ciphertext,
        const GpuBootstrapData &bootstrap_data,
        const GpuRelinKeysData &relin_keys,
        const GpuGaloisKeysData &galois_keys,
        GpuBootstrapWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /*
     * The steps of bootstrap(), one call each, for a Boot the compiler
     * expanded (RuntimePlan V6 boot_step). Each reproduces the corresponding
     * part of bootstrap() on the same profile data; with eval_mod_high_precision
     * and the ordinary rotate/add/sub/multiply_scalar/rescale_many they compose
     * to it.
     */

    /** ModRaise: prepare, raise to the full Q and apply raised_scale_override. */
    void bootstrap_raise(
        const GpuCiphertextData &source_ciphertext,
        const GpuBootstrapData &bootstrap_data,
        GpuBootstrapWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /** One CoeffToSlot or SlotToCoeff layer with its rescale, in the profile's linear mode. */
    void bootstrap_linear_layer(
        const GpuCiphertextData &source_ciphertext,
        const GpuBootstrapData &bootstrap_data,
        bool coeff_to_slot,
        std::size_t layer,
        const GpuGaloisKeysData &galois_keys,
        GpuBootstrapWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * One giant group of a double-hoist layer: the group's hoisted baby
     * rotations, its plaintext products accumulated in QP, one ModDown and the
     * giant rotation. Not rescaled: the layer's rescale follows the sum of
     * its groups.
     */
    void bootstrap_bsgs_group(
        const GpuCiphertextData &source_ciphertext,
        const GpuBootstrapData &bootstrap_data,
        bool coeff_to_slot,
        std::size_t layer,
        std::size_t group,
        const GpuGaloisKeysData &galois_keys,
        GpuBootstrapWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /** Conjugation with the profile's keys, pre-rotated when they are. */
    void bootstrap_conjugate(
        const GpuCiphertextData &source_ciphertext,
        const GpuGaloisKeysData &galois_keys,
        GpuBootstrapWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

    /** A copy of the ciphertext whose scale metadata is `scale`. */
    void bootstrap_set_scale(
        const GpuCiphertextData &source_ciphertext,
        double scale,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * multiply_plain with the Q prefix of the plaintext. A double-hoist
     * profile keeps its diagonals as exact [Q|P] plaintexts; their Q part is
     * the ordinary diagonal, so no second copy is needed.
     */
    void multiply_plain_q_view(
        const GpuCiphertextData &source_ciphertext,
        const GpuPlaintextData &source_plaintext,
        GpuCiphertextData &destination_ciphertext) const;

    /**
     * @brief Evaluate the setup-time high-precision EvalMod plan on GPU.
     *
     * This is public so callers can benchmark and validate the EvalMod stage
     * independently while reusing exactly the implementation used by
     * bootstrap(). Polynomial decomposition and plaintext upload remain
     * outside this runtime operation.
     */
    // Batches corresponding pointwise/leaf operations of two degree-22 dynamic
    // Chebyshev DAGs. Relinearization and rescale retain their scalar kernels.
    void eval_mod_high_precision_pair(
        const GpuCiphertextData &real, const GpuCiphertextData &imag,
        const GpuBootstrapData &data, const GpuRelinKeysData &keys,
        GpuCiphertextData &out_real, GpuCiphertextData &out_imag) const;

    bool try_eval_mod_high_precision_fast(
        const GpuCiphertextData &source,
        const GpuBootstrapData &data,
        const GpuRelinKeysData &keys,
        GpuCiphertextData &out) const;

    void eval_mod_high_precision(
        const GpuCiphertextData &source_ciphertext,
        const GpuBootstrapData &bootstrap_data,
        const GpuRelinKeysData &relin_keys,
        GpuBootstrapWorkspace &workspace,
        GpuCiphertextData &destination_ciphertext) const;

private:
    void validate_plain_input(const GpuCiphertextData &ciphertext,
                              const GpuPlaintextData &plaintext) const;
    const GpuParameterData &params_;

    GpuElementwiseHandler elementwise_handler_;
    GpuKeySwitchHandler keyswitch_handler_;
    GpuNTTHandler ntt_handler_;
    GpuModSwitchHandler modswitch_handler_;
    // Pre-rotated rotate() scratch reused across calls
    // (POSEIDON_GPU_PERSISTENT_ROTATE_WORKSPACE=1): calls on one device are
    // ordered on its stream, so a later call may overwrite it.
    struct RotateScratch
    {
        std::mutex mutex;
        GpuDoubleHoistWorkspace workspace;
    };
    std::shared_ptr<RotateScratch> rotate_scratch_ = std::make_shared<RotateScratch>();
};

}  // namespace gpu
}  // namespace poseidon
