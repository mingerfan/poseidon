#pragma once

#include "poseidon/gpu/gpu_parameter.h"
#include "poseidon/gpu/gpu_rns_poly.h"

#include <cstddef>

namespace poseidon
{
namespace gpu
{
namespace kernel
{

struct NttStageProfileSnapshot
{
    static constexpr std::size_t kMaxStageCount = 16;

    std::size_t stage_count = 0;
    double stage_total_ms[kMaxStageCount] = {};
    std::size_t stage_event_count[kMaxStageCount] = {};
};

void reset_ntt_stage_profile();

void set_ntt_stage_profile_enabled(bool enabled);

NttStageProfileSnapshot get_ntt_stage_profile_snapshot();

/**
 * @brief Launch a simple Barrett-based forward NTT for one aligned RNS-poly shard.
 *
 * First implementation constraints:
 * - source and destination must cover full coefficient limbs;
 * - q limbs only;
 * - roots are read from GpuParameterShard::ntt_tables in
 *   [local limb][degree roots] layout.
 */
void launch_forward_ntt_plaintext_cuda(
    const GpuPolyShardView &destination, const GpuConstPolyShardView &source,
    const GpuParameterShard &parameters, std::size_t degree);

void launch_forward_ntt_poly_shard(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_forward_ntt_poly_shard_fourstep_65536(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

// Contiguous independent polynomials; folds the batch into grid.z.
void launch_forward_ntt_poly_shard_batch_fourstep_65536(
    const GpuPolyShardView &first_destination_shard,
    const GpuConstPolyShardView &first_source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    std::size_t batch_count);

// In-place two-phase forward NTT of `limb_count` contiguous coefficient-form
// limbs whose tables start at `modulus_offset` (each block of phase 1 reads
// and writes the same coefficients).
void launch_forward_ntt_limbs_inplace_fourstep_65536(
    GpuWord *values,
    std::size_t modulus_offset,
    std::size_t limb_count,
    const GpuParameterShard &parameter_shard);

bool is_default_fourstep_ntt_requested();

// Both components of a ciphertext in one launch per phase (grid.z = 2), for
// small limb counts where one component alone underfills the GPU.
// In place, Q tables from index 0 (`limb_count` Q limbs per component).
void launch_forward_ntt_two_components_inplace_fourstep_65536(
    GpuWord *values0,
    GpuWord *values1,
    std::size_t limb_count,
    const GpuParameterShard &parameter_shard);

void launch_forward_ntt_two_components_fourstep_65536(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *source0,
    const GpuWord *source1,
    std::size_t limb_count,
    const GpuParameterShard &parameter_shard);

bool launch_fused_bootstrap_modraise_ntt_two_components_65536(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *coeff_source0,
    const GpuWord *coeff_source1,
    std::size_t source_q_count,
    std::size_t target_q_count,
    const GpuParameterShard &source_parameter_shard,
    const GpuParameterShard &target_parameter_shard);

// Out of place; tables start at `modulus_offset` (P limbs: base_q_size).
void launch_inverse_ntt_two_components_fourstep_65536(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *source0,
    const GpuWord *source1,
    std::size_t modulus_offset,
    std::size_t limb_count,
    const GpuParameterShard &parameter_shard,
    const GpuWord *inv_degree_table = nullptr);

void launch_forward_ntt_qp_active_fourstep_65536(
    GpuWord *destination_q,
    GpuWord *destination_p,
    const GpuWord *source_q,
    const GpuWord *source_p,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool phase1_ready = false);

void launch_forward_ntt_qp_active_batch_fourstep_65536(
    GpuWord *destination_q,
    GpuWord *destination_p,
    const GpuWord *source_q,
    const GpuWord *source_p,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t batch_count,
    std::size_t dst_q_batch_stride,
    std::size_t dst_p_batch_stride,
    std::size_t src_q_batch_stride,
    std::size_t src_p_batch_stride,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_modup_p9_forward_ntt_qp_active_phase1_fourstep_65536(
    GpuWord *destination_q,
    GpuWord *destination_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false,
    unsigned int target_limb_tile = 1);

void launch_forward_ntt_qp_active_fourstep_mul_accumulate_two_components_65536(
    GpuWord *partial_q,
    GpuWord *partial_p,
    const GpuWord *source_q,
    const GpuWord *source_p,
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *c2_ntt,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    bool overwrite_accum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool phase1_ready = false,
    std::size_t batch_count = 1,
    const GpuWord *second_c2_ntt = nullptr);

void launch_hybrid_convert_p_to_q_forward_ntt_two_components_fourstep_65536(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *source_p0,
    const GpuWord *source_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_convert_p9_to_q_forward_ntt_two_components_fourstep_65536(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *source_p0,
    const GpuWord *source_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false);

/**
 * @brief Launch a simple Barrett-based inverse NTT for one aligned RNS-poly shard.
 *
 * The inverse transform performs the final multiplication by N^{-1} with
 * GpuParameterShard::inv_degree_modulo.
 */
void launch_inverse_ntt_poly_shard(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * @brief Launch the optimized out-of-place two-phase inverse NTT for N=65536.
 */
// POSEIDON_OPT_FUSED_RESCALE: destination = (source - NTT(correction)) * inverse
// for the retained limbs [0, limb_count), with the correction built inside the
// NTT from the INTT'd last limb (mode 1, q_last_coeff) or from centered
// remainders of the last two limbs (mode 2). scratch holds limb_count limbs.
// destination == source == nullptr: only NTT(correction) is produced, in scratch.
// Returns false (nothing launched) when the switch is off or it does not apply.
struct RescaleBatchPtrs4
{
    GpuWord *dst[4]{};
    const GpuWord *src[4]{};
};

bool can_batch_rescale_65536(
    int mode,
    std::size_t limb_count,
    std::size_t component_count,
    const GpuParameterShard &parameter_shard);

bool launch_fused_rescale_correction_batch_65536(
    const RescaleBatchPtrs4 &io,
    GpuWord *scratch_batch,
    const GpuWord *q_last_coeff_batch,
    const GpuWide *remainders_batch,
    int mode,
    std::size_t limb_count,
    std::size_t component_count,
    const GpuParameterShard &parameter_shard);

bool launch_fused_rescale_correction_65536(
    GpuWord *destination,
    const GpuWord *source,
    GpuWord *scratch,
    const GpuWord *q_last_coeff,
    const GpuWide *remainders,
    int mode,
    std::size_t limb_count,
    const GpuParameterShard &parameter_shard);

struct RelinRescaleBatchArgs4
{
    GpuWord *dst[4];
    const GpuWord *r_coeff[4];
    const GpuWord *tail_coeff[4];
    const GpuWord *accum_q[4];
    const GpuWord *source[4];
    const GpuWord *extra[4];
    const GpuWord *plain;
};

bool launch_fused_relin_rescale_batch_65536(
    const RelinRescaleBatchArgs4 &args,
    GpuWord *remainder_scratch_words,
    GpuWord *phase1_scratch_ntt,
    std::size_t component_count,
    std::uint32_t drop_count,
    int post_op,
    const GpuParameterShard &parameter_shard);

struct FusedModDownBatchArgs64
{
    GpuWord *dst[64];
    const GpuWord *accum_q[64];
    const GpuWord *add_q[64];
    const GpuWord *galois_src[64];
    std::uint32_t galois_elts[64];
};

bool launch_forward_ntt_moddown_batch_fourstep_65536(
    GpuWord *scratch_batch,
    const GpuWord *coeff_source_batch,
    const FusedModDownBatchArgs64 &args,
    std::size_t component_count,
    bool has_add,
    bool has_galois,
    const GpuParameterShard &parameter_shard);

// Cheddar INTT (in place or out of place, N = 65536) whose final multiplier
// is inv_degree_table[limb] instead of N^{-1}. Returns false (nothing
// launched) when the Cheddar path does not apply.
bool launch_inverse_ntt_poly_shard_scaled_65536(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuWord *inv_degree_table);

void launch_inverse_ntt_poly_shard_fourstep_65536(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * Apply the N=65536 two-phase inverse NTT to equally shaped, strided RNS
 * polynomials. The batch dimension is folded into grid.z so all inputs share
 * one phase-1 launch and one phase-2 launch.
 */
struct BatchConstPolyPtrs32
{
    const GpuWord *ptrs[32];
};

void launch_inverse_ntt_poly_shard_batch_fourstep_65536(
    const GpuPolyShardView &first_destination_shard,
    const GpuConstPolyShardView &first_source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    std::size_t batch_count,
    std::size_t destination_batch_stride,
    std::size_t source_batch_stride,
    const GpuWord *inv_degree_table = nullptr);

void launch_inverse_ntt_multi_sources_fourstep_65536(
    GpuWord *destination_batch,
    const BatchConstPolyPtrs32 &sources,
    std::size_t modulus_offset,
    std::size_t limb_count,
    std::size_t batch_count,
    const GpuParameterShard &parameter_shard,
    const GpuWord *inv_degree_table = nullptr);

void launch_forward_ntt_components_shard_tensor(
    const GpuPolyShardView &first_destination_shard,
    const GpuConstPolyShardView &first_source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    std::size_t component_count,
    std::size_t component_stride);

void launch_inverse_ntt_components_shard_tensor(
    const GpuPolyShardView &first_destination_shard,
    const GpuConstPolyShardView &first_source_shard,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    std::size_t component_count,
    std::size_t component_stride);

}  // namespace kernel
}  // namespace gpu
}  // namespace poseidon
