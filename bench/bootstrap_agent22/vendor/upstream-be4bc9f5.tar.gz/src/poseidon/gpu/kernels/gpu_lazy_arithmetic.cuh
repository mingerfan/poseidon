#pragma once
#include "poseidon/gpu/gpu_memory.h"

namespace poseidon::gpu::kernel::detail {

// At most 2^32-1 products of canonical 32-bit residues fit in 96 bits.
// Carry propagation must be kept in one asm block.
struct LazyAccumulator { GpuWord lo=0, mid=0, hi=0; };

__device__ __forceinline__ void lazy_mac(LazyAccumulator &a, GpuWord x, GpuWord y)
{
    asm("mad.lo.cc.u32 %0, %3, %4, %0;\n\t"
        "madc.hi.cc.u32 %1, %3, %4, %1;\n\t"
        "addc.u32 %2, %2, 0;"
        : "+r"(a.lo), "+r"(a.mid), "+r"(a.hi) : "r"(x), "r"(y));
}

__device__ __forceinline__ GpuWord lazy_reduce_word(GpuWide x, GpuWord q, GpuWide ratio)
{
    GpuWide r=x-__umul64hi(x,ratio)*q;
    if(r>=q)r-=q;
    if(r>=q)r-=q;
    return static_cast<GpuWord>(r);
}

__device__ __forceinline__ GpuWord lazy_reduce(const LazyAccumulator &a, GpuWord q, GpuWide ratio)
{
    GpuWord result=lazy_reduce_word((GpuWide(a.mid)<<32)|a.lo,q,ratio);
    if(a.hi!=0)
    {
        GpuWide two64=GpuWide{0}-ratio*q;
        if(two64>=q)two64-=q;
        const auto carry=lazy_reduce_word(GpuWide(a.hi)*two64,q,ratio);
        const GpuWide sum=GpuWide(result)+carry;
        result=static_cast<GpuWord>(sum>=q?sum-q:sum);
    }
    return result;
}
} // namespace poseidon::gpu::kernel::detail
