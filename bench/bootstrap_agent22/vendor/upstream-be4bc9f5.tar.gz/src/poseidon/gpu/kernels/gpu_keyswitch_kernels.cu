#include "poseidon/gpu/kernels/gpu_keyswitch_kernels.h"
#include "poseidon/gpu/gpu_memory.h"
#include "poseidon/gpu/kernels/gpu_ntt_kernels.h"
#include "poseidon/gpu/gpu_opt_flags.h"

#include <cstdint>
#include <cstdlib>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace poseidon
{
namespace gpu
{
namespace kernel
{
namespace
{

__device__ __forceinline__ GpuWord barrett_reduce_u64_u32(
    GpuWide value,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    const GpuWide quotient = __umul64hi(value, barrett_ratio);
    GpuWide reduced =
        value - quotient * static_cast<GpuWide>(modulus);

    if (reduced >= modulus)
    {
        reduced -= modulus;
    }
    if (reduced >= modulus)
    {
        reduced -= modulus;
    }

    return static_cast<GpuWord>(reduced);
}

__device__ __forceinline__ GpuWord add_mod(
    GpuWord left,
    GpuWord right,
    GpuWord modulus)
{
    const GpuWide sum =
        static_cast<GpuWide>(left) + static_cast<GpuWide>(right);
    return static_cast<GpuWord>(sum >= modulus ? sum - modulus : sum);
}

__device__ __forceinline__ GpuWord sub_mod(
    GpuWord left,
    GpuWord right,
    GpuWord modulus)
{
    return left >= right
        ? static_cast<GpuWord>(left - right)
        : static_cast<GpuWord>(
              static_cast<GpuWide>(left) + modulus - right);
}

__device__ __forceinline__ GpuWord mul_mod(
    GpuWord left,
    GpuWord right,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    return barrett_reduce_u64_u32(
        static_cast<GpuWide>(left) * static_cast<GpuWide>(right),
        modulus,
        barrett_ratio);
}

__device__ __forceinline__ GpuWord reduce_to_modulus(
    GpuWord value,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    return value < modulus
        ? value
        : barrett_reduce_u64_u32(value, modulus, barrett_ratio);
}

__device__ __forceinline__ std::uint32_t reverse_bits_limited(
    std::uint32_t value,
    unsigned int bit_count)
{
    return __brev(value) >> (32U - bit_count);
}

/*
 * Lazy basis-conversion arithmetic: word products (< 2^64) are summed into a
 * 96-bit accumulator with three integer instructions and reduced once, rather
 * than one Barrett reduction and one modular add per term.
 */
struct LazyAccumulator
{
    std::uint32_t lo = 0;
    std::uint32_t mid = 0;
    std::uint32_t hi = 0;
};

__device__ __forceinline__ void lazy_mac(
    LazyAccumulator &acc,
    GpuWord left,
    GpuWord right)
{
    asm("mad.lo.cc.u32 %0, %3, %4, %0;\n\t"
        "madc.hi.cc.u32 %1, %3, %4, %1;\n\t"
        "addc.u32 %2, %2, 0;"
        : "+r"(acc.lo), "+r"(acc.mid), "+r"(acc.hi)
        : "r"(left), "r"(right));
}

__device__ __forceinline__ GpuWord lazy_reduce(
    const LazyAccumulator &acc,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    const GpuWide low =
        (static_cast<GpuWide>(acc.mid) << 32) | static_cast<GpuWide>(acc.lo);
    GpuWord result = barrett_reduce_u64_u32(low, modulus, barrett_ratio);
    if (acc.hi != 0)
    {
        // barrett_ratio = floor(2^64 / modulus): 2^64 mod modulus.
        GpuWide two64 = GpuWide{0} - barrett_ratio * static_cast<GpuWide>(modulus);
        if (two64 >= modulus)
        {
            two64 -= modulus;
        }
        const GpuWord carry = barrett_reduce_u64_u32(
            static_cast<GpuWide>(acc.hi) * two64, modulus, barrett_ratio);
        const GpuWide sum = static_cast<GpuWide>(result) + carry;
        result = static_cast<GpuWord>(sum >= modulus ? sum - modulus : sum);
    }
    return result;
}

__device__ __forceinline__ GpuWord hybrid_modup_contribution(
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *conversion_matrix,
    const GpuWord *qi_inv_punctured,
    std::size_t matrix_row_offset,
    std::size_t inv_offset,
    std::size_t decomp_limb_begin,
    std::size_t col,
    std::size_t coeff,
    std::size_t degree,
    GpuWord target_modulus,
    GpuWide target_barrett)
{
    const std::size_t source_q_limb = decomp_limb_begin + col;
    const GpuWord value = c2_coeff[source_q_limb * degree + coeff];
    const GpuWord source_modulus = rns_primes[source_q_limb];
    const GpuWide source_barrett = rns_modulus_constants[source_q_limb];
    const GpuWord inv_punctured = qi_inv_punctured[inv_offset + col];
    const GpuWord weighted = inv_punctured == 1
        ? value
        : mul_mod(value, inv_punctured, source_modulus, source_barrett);
    const GpuWord matrix_value = conversion_matrix[matrix_row_offset + col];
    return mul_mod(weighted, matrix_value, target_modulus, target_barrett);
}

__device__ __forceinline__ void hybrid_convert_p_to_q_contribution(
    GpuWord &sum0,
    GpuWord &sum1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t q_limb,
    std::size_t p_limb,
    std::size_t coeff,
    std::size_t degree,
    GpuWord q_modulus,
    GpuWide q_barrett)
{
    const std::size_t p_table_limb = base_q_size + p_limb;
    const GpuWord p_modulus = rns_primes[p_table_limb];
    const GpuWide p_barrett = rns_modulus_constants[p_table_limb];
    const GpuWord matrix_value =
        moddown_p_to_q_matrix[q_limb * base_p_size + p_limb];
    const GpuWord inv_punctured = p_inv_punctured[p_limb];

    const GpuWord p_value0 = accum_p0[p_limb * degree + coeff];
    const GpuWord weighted0 = inv_punctured == 1
        ? p_value0
        : mul_mod(p_value0, inv_punctured, p_modulus, p_barrett);
    sum0 = add_mod(
        sum0,
        mul_mod(weighted0, matrix_value, q_modulus, q_barrett),
        q_modulus);

    const GpuWord p_value1 = accum_p1[p_limb * degree + coeff];
    const GpuWord weighted1 = inv_punctured == 1
        ? p_value1
        : mul_mod(p_value1, inv_punctured, p_modulus, p_barrett);
    sum1 = add_mod(
        sum1,
        mul_mod(weighted1, matrix_value, q_modulus, q_barrett),
        q_modulus);
}

template <bool SourcePreweighted>
__device__ __forceinline__ void hybrid_convert_p_to_q_pair_contribution(
    GpuWord &left0,
    GpuWord &right0,
    GpuWord &left1,
    GpuWord &right1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t q_limb,
    std::size_t p_limb,
    std::size_t left_coeff,
    std::size_t right_coeff,
    std::size_t degree,
    GpuWord q_modulus,
    GpuWide q_barrett)
{
    const std::size_t p_table_limb = base_q_size + p_limb;
    const std::size_t p_base = p_limb * degree;
    const GpuWord matrix_value =
        moddown_p_to_q_matrix[q_limb * base_p_size + p_limb];

    const GpuWord p0_left = accum_p0[p_base + left_coeff];
    GpuWord p0_left_weighted = p0_left;
    GpuWord p0_right_weighted = accum_p0[p_base + right_coeff];
    GpuWord p1_left_weighted = accum_p1[p_base + left_coeff];
    GpuWord p1_right_weighted = accum_p1[p_base + right_coeff];
    if constexpr (!SourcePreweighted)
    {
        const GpuWord p_modulus = rns_primes[p_table_limb];
        const GpuWide p_barrett = rns_modulus_constants[p_table_limb];
        const GpuWord inv_punctured = p_inv_punctured[p_limb];
        if (inv_punctured != 1)
        {
            p0_left_weighted = mul_mod(
                p0_left_weighted, inv_punctured, p_modulus, p_barrett);
            p0_right_weighted = mul_mod(
                p0_right_weighted, inv_punctured, p_modulus, p_barrett);
            p1_left_weighted = mul_mod(
                p1_left_weighted, inv_punctured, p_modulus, p_barrett);
            p1_right_weighted = mul_mod(
                p1_right_weighted, inv_punctured, p_modulus, p_barrett);
        }
    }
    left0 = add_mod(
        left0,
        mul_mod(p0_left_weighted, matrix_value, q_modulus, q_barrett),
        q_modulus);

    right0 = add_mod(
        right0,
        mul_mod(p0_right_weighted, matrix_value, q_modulus, q_barrett),
        q_modulus);

    left1 = add_mod(
        left1,
        mul_mod(p1_left_weighted, matrix_value, q_modulus, q_barrett),
        q_modulus);

    right1 = add_mod(
        right1,
        mul_mod(p1_right_weighted, matrix_value, q_modulus, q_barrett),
        q_modulus);
}

template <int FixedPCount, bool SourcePreweighted>
__device__ __forceinline__ void hybrid_convert_p_to_q_pair(
    GpuWord &left0,
    GpuWord &right0,
    GpuWord &left1,
    GpuWord &right1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t q_limb,
    std::size_t left_coeff,
    std::size_t right_coeff,
    std::size_t degree,
    GpuWord q_modulus,
    GpuWide q_barrett)
{
    left0 = 0;
    right0 = 0;
    left1 = 0;
    right1 = 0;

    if constexpr (FixedPCount > 0)
    {
#pragma unroll
        for (std::size_t p_limb = 0; p_limb < FixedPCount; ++p_limb)
        {
            hybrid_convert_p_to_q_pair_contribution<SourcePreweighted>(
                left0,
                right0,
                left1,
                right1,
                accum_p0,
                accum_p1,
                rns_primes,
                rns_modulus_constants,
                moddown_p_to_q_matrix,
                p_inv_punctured,
                base_q_size,
                base_p_size,
                q_limb,
                p_limb,
                left_coeff,
                right_coeff,
                degree,
                q_modulus,
                q_barrett);
        }
    }
    else
    {
        for (std::size_t p_limb = 0; p_limb < base_p_size; ++p_limb)
        {
            hybrid_convert_p_to_q_pair_contribution<SourcePreweighted>(
                left0,
                right0,
                left1,
                right1,
                accum_p0,
                accum_p1,
                rns_primes,
                rns_modulus_constants,
                moddown_p_to_q_matrix,
                p_inv_punctured,
                base_q_size,
                base_p_size,
                q_limb,
                p_limb,
                left_coeff,
                right_coeff,
                degree,
                q_modulus,
                q_barrett);
        }
    }
}

__global__ void apply_galois_ntt_poly_shard_kernel(
    GpuWord *destination,
    const GpuWord *source,
    std::uint32_t galois_elt,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = limb_count * degree;
    if (tid >= total)
    {
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_minus_one = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_minus_one);

    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) *
         static_cast<std::uint64_t>(reversed)) >> 1;
    const std::uint32_t source_coeff =
        reverse_bits_limited(
            static_cast<std::uint32_t>(index_raw & degree_minus_one),
            degree_power);

    destination[limb * degree + coeff] =
        source[limb * degree + source_coeff];
}

__global__ void hybrid_modup_qp_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *c2_ntt,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t q_total = base_q_size * degree;
    const std::size_t p_total = base_p_size * degree;
    const std::size_t total = q_total + p_total;
    if (tid >= total)
    {
        return;
    }

    const std::size_t inv_offset = decomp_index * base_p_size;
    const std::size_t degree_mask = degree - 1;
    const std::size_t coeff = tid & degree_mask;

    /* 整体线程分为两部分，一部分用来计算模升的模数q,另一部分用来计算模升的模数p */
    if (tid < q_total)
    {
        const std::size_t target_q_limb = tid >> degree_power;

        /* 当前 dnum 块内的 Q limb 已经是 NTT 形态，后续乘密钥时直接读 c2_ntt。 */
        if (target_q_limb >= decomp_limb_begin &&
            target_q_limb < decomp_limb_begin + decomp_limb_count)
        {
            return;
        }

        const std::size_t target_offset = tid;
        const GpuWord target_modulus = rns_primes[target_q_limb];
        const GpuWide target_barrett =
            rns_modulus_constants[target_q_limb];

        /* 当前分快只有一个模数，那就直接对应取模 */
        if (decomp_limb_count == 1)
        {
            const GpuWord value =
                c2_coeff[decomp_limb_begin * degree + coeff];
            /*如果小于模数，则返回，否则做巴雷特约减*/
            modup_q[target_offset] =
                reduce_to_modulus(value, target_modulus, target_barrett);
            return;
        }

        const std::size_t matrix_offset = q_matrix_offsets[decomp_index];
        const std::size_t matrix_row_offset =
            matrix_offset + target_q_limb * base_p_size;
        GpuWord sum = 0;
        /* 一般情况下的基转换 */
        std::size_t col = 0;
        for (; col + 1 < decomp_limb_count; col += 2)
        {
            sum = add_mod(
                sum,
                hybrid_modup_contribution(
                    c2_coeff,
                    rns_primes,
                    rns_modulus_constants,
                    q_matrices,
                    qi_inv_punctured,
                    matrix_row_offset,
                    inv_offset,
                    decomp_limb_begin,
                    col,
                    coeff,
                    degree,
                    target_modulus,
                    target_barrett),
                target_modulus);
            sum = add_mod(
                sum,
                hybrid_modup_contribution(
                    c2_coeff,
                    rns_primes,
                    rns_modulus_constants,
                    q_matrices,
                    qi_inv_punctured,
                    matrix_row_offset,
                    inv_offset,
                    decomp_limb_begin,
                    col + 1,
                    coeff,
                    degree,
                    target_modulus,
                    target_barrett),
                target_modulus);
        }
        for (; col < decomp_limb_count; ++col)
        {
            sum = add_mod(
                sum,
                hybrid_modup_contribution(
                    c2_coeff,
                    rns_primes,
                    rns_modulus_constants,
                    q_matrices,
                    qi_inv_punctured,
                    matrix_row_offset,
                    inv_offset,
                    decomp_limb_begin,
                    col,
                    coeff,
                    degree,
                    target_modulus,
                    target_barrett),
                target_modulus);
        }

        modup_q[target_offset] = sum;
        return;
    }

    /* 此处开始计算p模数模升*/
    const std::size_t local_tid = tid - q_total;
    const std::size_t target_p_limb = local_tid >> degree_power;
    const std::size_t target_offset = target_p_limb * degree + coeff;
    const std::size_t target_table_limb = base_q_size + target_p_limb;
    const GpuWord target_modulus = rns_primes[target_table_limb];
    const GpuWide target_barrett =
        rns_modulus_constants[target_table_limb];

    if (decomp_limb_count == 1)
    {
        const GpuWord value =
            c2_coeff[decomp_limb_begin * degree + coeff];
        modup_p[target_offset] =
            reduce_to_modulus(value, target_modulus, target_barrett);
        return;
    }

    const std::size_t matrix_offset = p_matrix_offsets[decomp_index];
    const std::size_t matrix_row_offset =
        matrix_offset + target_p_limb * base_p_size;
    GpuWord sum = 0;

    std::size_t col = 0;
    for (; col + 1 < decomp_limb_count; col += 2)
    {
        sum = add_mod(
            sum,
            hybrid_modup_contribution(
                c2_coeff,
                rns_primes,
                rns_modulus_constants,
                p_matrices,
                qi_inv_punctured,
                matrix_row_offset,
                inv_offset,
                decomp_limb_begin,
                col,
                coeff,
                degree,
                target_modulus,
                target_barrett),
            target_modulus);
        sum = add_mod(
            sum,
            hybrid_modup_contribution(
                c2_coeff,
                rns_primes,
                rns_modulus_constants,
                p_matrices,
                qi_inv_punctured,
                matrix_row_offset,
                inv_offset,
                decomp_limb_begin,
                col + 1,
                coeff,
                degree,
                target_modulus,
                target_barrett),
            target_modulus);
    }
    for (; col < decomp_limb_count; ++col)
    {
        sum = add_mod(
            sum,
            hybrid_modup_contribution(
                c2_coeff,
                rns_primes,
                rns_modulus_constants,
                p_matrices,
                qi_inv_punctured,
                matrix_row_offset,
                inv_offset,
                decomp_limb_begin,
                col,
                coeff,
                degree,
                target_modulus,
                target_barrett),
            target_modulus);
    }

    modup_p[target_offset] = sum;
}

/*
 * ModUp with lazy accumulation. One thread owns one coefficient and a tile of
 * target limbs: each source residue is weighted by its punctured inverse once
 * per tile (not once per target) and every target sum is reduced once.
 * Targets enumerate base Q then base P; the decomposition's own Q limbs are
 * skipped, as in hybrid_modup_qp_kernel.
 */
template <int TargetTile>
__global__ void hybrid_modup_qp_lazy_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    // Two coefficients (j, j + N/2) per thread: twice the independent work
    // per matrix entry and per punctured-inverse weighting.
    const std::size_t half = degree >> 1;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    // Only targets outside the digit: Q limbs before/after it, then P.
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t target_count = active_q_count + base_p_size;
    const std::size_t tile_count = (target_count + TargetTile - 1) / TargetTile;
    if (tid >= tile_count * half)
    {
        return;
    }
    const auto table_limb_of = [&](std::size_t active) {
        return active < active_q_count
            ? (active < decomp_limb_begin ? active : active + decomp_limb_count)
            : base_q_size + (active - active_q_count);
    };
    const std::size_t low = tid & (half - 1);
    const std::size_t high = low + half;
    const std::size_t target_begin = (tid >> (degree_power - 1)) * TargetTile;
    const std::size_t inv_offset = decomp_index * base_p_size;
    const std::size_t q_offset = q_matrix_offsets[decomp_index];
    const std::size_t p_offset = p_matrix_offsets[decomp_index];

    LazyAccumulator low_acc[TargetTile];
    LazyAccumulator high_acc[TargetTile];
    for (std::size_t col = 0; col < decomp_limb_count; ++col)
    {
        const std::size_t source_limb = decomp_limb_begin + col;
        GpuWord low_value = c2_coeff[source_limb * degree + low];
        GpuWord high_value = c2_coeff[source_limb * degree + high];
        const GpuWord inv_punctured = qi_inv_punctured[inv_offset + col];
        if (inv_punctured != 1)
        {
            const GpuWord source_modulus = rns_primes[source_limb];
            const GpuWide source_barrett = rns_modulus_constants[source_limb];
            low_value = mul_mod(low_value, inv_punctured, source_modulus, source_barrett);
            high_value = mul_mod(high_value, inv_punctured, source_modulus, source_barrett);
        }
#pragma unroll
        for (int t = 0; t < TargetTile; ++t)
        {
            const std::size_t target = target_begin + t;
            if (target >= target_count)
            {
                break;
            }
            const std::size_t limb = table_limb_of(target);
            const GpuWord matrix_value = limb < base_q_size
                ? q_matrices[q_offset + limb * base_p_size + col]
                : p_matrices[p_offset + (limb - base_q_size) * base_p_size + col];
            lazy_mac(low_acc[t], low_value, matrix_value);
            lazy_mac(high_acc[t], high_value, matrix_value);
        }
    }
#pragma unroll
    for (int t = 0; t < TargetTile; ++t)
    {
        const std::size_t target = target_begin + t;
        if (target >= target_count)
        {
            break;
        }
        const std::size_t limb = table_limb_of(target);
        const GpuWord modulus = rns_primes[limb];
        const GpuWide barrett = rns_modulus_constants[limb];
        GpuWord *values = limb < base_q_size
            ? modup_q + limb * degree
            : modup_p + (limb - base_q_size) * degree;
        values[low] = lazy_reduce(low_acc[t], modulus, barrett);
        values[high] = lazy_reduce(high_acc[t], modulus, barrett);
    }
}

/*
 * POSEIDON_OPT_MODUP_PW=1. Step 1: weight the digit's source limbs by their
 * punctured inverses once (the lazy kernel above redoes it for every tile of
 * four targets, about 13 times per digit on q49).
 */
template <bool Batched = false>
__global__ void hybrid_preweight_modup_source_kernel(
    GpuWord *weighted,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *qi_inv_punctured,
    unsigned int inv_offset,
    unsigned int decomp_limb_begin,
    unsigned int decomp_limb_count,
    unsigned int degree_power,
    std::size_t source_batch_stride = 0,
    std::size_t weighted_batch_stride = 0)
{
    if constexpr (Batched)
    {
        c2_coeff += blockIdx.z * source_batch_stride;
        weighted += blockIdx.z * weighted_batch_stride;
    }
    const unsigned int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= (decomp_limb_count << degree_power))
    {
        return;
    }
    const unsigned int col = tid >> degree_power;
    const unsigned int coefficient = tid & ((1u << degree_power) - 1u);
    const unsigned int source_limb = decomp_limb_begin + col;
    GpuWord value = c2_coeff[(source_limb << degree_power) + coefficient];
    const GpuWord inv_punctured = qi_inv_punctured[inv_offset + col];
    if (inv_punctured != 1)
    {
        value = mul_mod(
            value,
            inv_punctured,
            rns_primes[source_limb],
            rns_modulus_constants[source_limb]);
    }
    weighted[tid] = value;
}

/*
 * Step 2: the same lazy accumulation as hybrid_modup_qp_lazy_kernel on the
 * preweighted source. A block never straddles a target tile (half degree is a
 * multiple of the block size), so the tile's matrix entries are staged in
 * shared memory once per block, laid out [col][target]. Target-limb indexing
 * and Q/P selection leave the source loop; a ragged last tile repeats its last
 * target and simply skips the store. Same products, same 96-bit sums, same
 * final reduction: bit-identical output.
 */
constexpr unsigned int kModupPreweightMaxCols = 64;

template <int TargetTile, bool Batched = false>
__global__ void __launch_bounds__(256) hybrid_modup_qp_lazy_preweighted_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *weighted,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    unsigned int decomp_index,
    unsigned int decomp_limb_begin,
    unsigned int decomp_limb_count,
    unsigned int base_q_size,
    unsigned int base_p_size,
    unsigned int degree_power,
    std::size_t weighted_batch_stride = 0,
    std::size_t modup_q_batch_stride = 0,
    std::size_t modup_p_batch_stride = 0,
    bool vec2 = false)
{
    __shared__ __align__(16) GpuWord tile_matrix[kModupPreweightMaxCols * TargetTile];
    const unsigned int degree = 1u << degree_power;
    GpuWord *dst_q = modup_q;
    GpuWord *dst_p = modup_p;
    if constexpr (Batched)
    {
        const std::size_t z = blockIdx.z;
        weighted += z * (weighted_batch_stride ? weighted_batch_stride
                                               : static_cast<std::size_t>(decomp_limb_count) * degree);
        if (dst_q != nullptr)
        {
            dst_q += z * (modup_q_batch_stride ? modup_q_batch_stride
                                               : static_cast<std::size_t>(base_q_size) * degree);
        }
        dst_p += z * (modup_p_batch_stride ? modup_p_batch_stride
                                           : static_cast<std::size_t>(base_p_size) * degree);
    }
    const unsigned int half = degree >> 1;
    const unsigned int active_q_count = base_q_size - decomp_limb_count;
    const unsigned int target_count = active_q_count + base_p_size;
    const unsigned int block_first = blockIdx.x * blockDim.x;
    const unsigned int target_begin = (block_first >> (degree_power - 1)) * TargetTile;
    const GpuWord *q_digit =
        active_q_count > 0 ? q_matrices + q_matrix_offsets[decomp_index] : nullptr;
    const GpuWord *p_digit = p_matrices + p_matrix_offsets[decomp_index];
    for (unsigned int i = threadIdx.x; i < decomp_limb_count * TargetTile; i += blockDim.x)
    {
        const unsigned int col = i / TargetTile;
        const unsigned int t = i - col * TargetTile;
        unsigned int target = target_begin + t;
        if (target >= target_count)
        {
            target = target_count - 1;
        }
        const unsigned int limb = target < active_q_count
            ? (target < decomp_limb_begin ? target : target + decomp_limb_count)
            : base_q_size + (target - active_q_count);
        tile_matrix[i] = limb < base_q_size
            ? q_digit[limb * base_p_size + col]
            : p_digit[(limb - base_q_size) * base_p_size + col];
    }
    __syncthreads();

    const unsigned int tid = block_first + threadIdx.x;
    const unsigned int tile_count = (target_count + TargetTile - 1) / TargetTile;
    if (tid >= tile_count * half)
    {
        return;
    }
    const unsigned int low = tid & (half - 1);
    const bool use_vec2 = vec2 && ((degree & 1u) == 0u) &&
        ((reinterpret_cast<std::uintptr_t>(weighted) & 7u) == 0u) &&
        (dst_q == nullptr || (reinterpret_cast<std::uintptr_t>(dst_q) & 7u) == 0u) &&
        ((reinterpret_cast<std::uintptr_t>(dst_p) & 7u) == 0u);
    LazyAccumulator low_acc[TargetTile];
    LazyAccumulator high_acc[TargetTile];
    if (use_vec2)
    {
        const uint2 *source2 = reinterpret_cast<const uint2 *>(weighted) + low;
#pragma unroll 2
        for (unsigned int col = 0; col < decomp_limb_count; ++col)
        {
            const uint2 pair = __ldg(source2);
            source2 += half;
            const GpuWord *row = tile_matrix + col * TargetTile;
#pragma unroll
            for (int t = 0; t < TargetTile; ++t)
            {
                const GpuWord matrix_value = row[t];
                lazy_mac(low_acc[t], pair.x, matrix_value);
                lazy_mac(high_acc[t], pair.y, matrix_value);
            }
        }
#pragma unroll
        for (int t = 0; t < TargetTile; ++t)
        {
            const unsigned int target = target_begin + t;
            if (target >= target_count)
            {
                break;
            }
            const unsigned int limb = target < active_q_count
                ? (target < decomp_limb_begin ? target : target + decomp_limb_count)
                : base_q_size + (target - active_q_count);
            const GpuWord modulus = rns_primes[limb];
            const GpuWide barrett = rns_modulus_constants[limb];
            GpuWord *values = limb < base_q_size
                ? dst_q + (static_cast<std::size_t>(limb) << degree_power)
                : dst_p + (static_cast<std::size_t>(limb - base_q_size) << degree_power);
            uint2 out;
            out.x = lazy_reduce(low_acc[t], modulus, barrett);
            out.y = lazy_reduce(high_acc[t], modulus, barrett);
            reinterpret_cast<uint2 *>(values)[low] = out;
        }
    }
    else
    {
        const GpuWord *source = weighted + low;
#pragma unroll 2
        for (unsigned int col = 0; col < decomp_limb_count; ++col)
        {
            const GpuWord low_value = source[0];
            const GpuWord high_value = source[half];
            source += degree;
            const GpuWord *row = tile_matrix + col * TargetTile;
#pragma unroll
            for (int t = 0; t < TargetTile; ++t)
            {
                const GpuWord matrix_value = row[t];
                lazy_mac(low_acc[t], low_value, matrix_value);
                lazy_mac(high_acc[t], high_value, matrix_value);
            }
        }
#pragma unroll
        for (int t = 0; t < TargetTile; ++t)
        {
            const unsigned int target = target_begin + t;
            if (target >= target_count)
            {
                break;
            }
            const unsigned int limb = target < active_q_count
                ? (target < decomp_limb_begin ? target : target + decomp_limb_count)
                : base_q_size + (target - active_q_count);
            const GpuWord modulus = rns_primes[limb];
            const GpuWide barrett = rns_modulus_constants[limb];
            GpuWord *values = limb < base_q_size
                ? dst_q + (static_cast<std::size_t>(limb) << degree_power)
                : dst_p + (static_cast<std::size_t>(limb - base_q_size) << degree_power);
            values[low] = lazy_reduce(low_acc[t], modulus, barrett);
            values[low + half] = lazy_reduce(high_acc[t], modulus, barrett);
        }
    }
}

/*
 * POSEIDON_OPT_PTOQ_PW: N^{-1} * pHat_j^{-1} mod p_j for the P limbs (Q limbs
 * keep N^{-1}). The Cheddar INTT multiplies by this table in its last step.
 */
__global__ void build_p_preweighted_inv_degree_kernel(
    GpuWord *table,
    const GpuWord *inv_degree,
    const GpuWord *p_inv_punctured,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    unsigned int base_q_size,
    unsigned int base_p_size,
    unsigned int total)
{
    const unsigned int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= total)
    {
        return;
    }
    GpuWord value = inv_degree[i];
    if (i >= base_q_size && i < base_q_size + base_p_size)
    {
        value = mul_mod(value, p_inv_punctured[i - base_q_size], rns_primes[i],
                        rns_modulus_constants[i]);
    }
    table[i] = value;
}

/*
 * POSEIDON_OPT_PTOQ_PW: P->Q conversion of an already weighted P part into
 * coefficient form (the in-place forward NTT follows), for one or two
 * components. As in hybrid_modup_qp_lazy_preweighted_kernel the tile's matrix
 * entries are staged in shared memory once per block and the inner loop has
 * no indexing or bounds work; same products and 96-bit sums as
 * hybrid_convert_p_to_q_forward_ntt_first_stage_lazy_kernel<QTile, false>.
 */
constexpr unsigned int kPToQPreweightMaxP = 64;

template <int QTile, int Components, bool Batched = false>
__global__ void __launch_bounds__(256) hybrid_convert_p_to_q_lazy_preweighted_kernel(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *moddown_p_to_q_matrix,
    unsigned int base_q_size,
    unsigned int base_p_size,
    unsigned int degree_power,
    bool vec2 = false)
{
    static_assert(Components == 1 || Components == 2);
    __shared__ __align__(16) GpuWord tile_matrix[kPToQPreweightMaxP * QTile];
    const unsigned int degree = 1u << degree_power;
    GpuWord *dst_q0 = converted_q0;
    GpuWord *dst_q1 = converted_q1;
    if constexpr (Batched)
    {
        accum_p0 += static_cast<std::size_t>(blockIdx.z) * base_p_size * degree;
        dst_q0 += static_cast<std::size_t>(blockIdx.z) * base_q_size * degree;
        if constexpr (Components == 2)
        {
            accum_p1 += static_cast<std::size_t>(blockIdx.z) * base_p_size * degree;
            dst_q1 += static_cast<std::size_t>(blockIdx.z) * base_q_size * degree;
        }
    }
    const unsigned int half = degree >> 1;
    const unsigned int block_first = blockIdx.x * blockDim.x;
    const unsigned int q_begin = (block_first >> (degree_power - 1)) * QTile;
    for (unsigned int i = threadIdx.x; i < base_p_size * QTile; i += blockDim.x)
    {
        const unsigned int p_limb = i / QTile;
        const unsigned int t = i - p_limb * QTile;
        unsigned int q_limb = q_begin + t;
        if (q_limb >= base_q_size)
        {
            q_limb = base_q_size - 1;
        }
        tile_matrix[i] = moddown_p_to_q_matrix[q_limb * base_p_size + p_limb];
    }
    __syncthreads();

    const unsigned int tile_count = (base_q_size + QTile - 1) / QTile;
    const unsigned int tid = block_first + threadIdx.x;
    if (tid >= tile_count * half)
    {
        return;
    }
    const unsigned int left = tid & (half - 1);
    const bool use_vec2 = vec2 && ((degree & 1u) == 0u) &&
        ((reinterpret_cast<std::uintptr_t>(accum_p0) & 7u) == 0u) &&
        ((reinterpret_cast<std::uintptr_t>(dst_q0) & 7u) == 0u) &&
        (Components == 1 ||
         (((reinterpret_cast<std::uintptr_t>(accum_p1) & 7u) == 0u) &&
          ((reinterpret_cast<std::uintptr_t>(dst_q1) & 7u) == 0u)));
    constexpr int kValues = 2 * Components;
    LazyAccumulator acc[QTile][kValues];
    if (use_vec2)
    {
        const uint2 *source0_2 = reinterpret_cast<const uint2 *>(accum_p0) + left;
        const uint2 *source1_2 = Components == 2 ? reinterpret_cast<const uint2 *>(accum_p1) + left : nullptr;
#pragma unroll 2
        for (unsigned int p_limb = 0; p_limb < base_p_size; ++p_limb)
        {
            GpuWord values[kValues];
            const uint2 p0 = __ldg(source0_2);
            source0_2 += half;
            values[0] = p0.x;
            values[1] = p0.y;
            if constexpr (Components == 2)
            {
                const uint2 p1 = __ldg(source1_2);
                source1_2 += half;
                values[2] = p1.x;
                values[3] = p1.y;
            }
            const GpuWord *row = tile_matrix + p_limb * QTile;
#pragma unroll
            for (int t = 0; t < QTile; ++t)
            {
                const GpuWord matrix_value = row[t];
#pragma unroll
                for (int k = 0; k < kValues; ++k)
                {
                    lazy_mac(acc[t][k], values[k], matrix_value);
                }
            }
        }
#pragma unroll
        for (int t = 0; t < QTile; ++t)
        {
            const unsigned int q_limb = q_begin + t;
            if (q_limb >= base_q_size)
            {
                break;
            }
            const GpuWord q_modulus = rns_primes[q_limb];
            const GpuWide q_barrett = rns_modulus_constants[q_limb];
            const std::size_t q_base = static_cast<std::size_t>(q_limb) << degree_power;
            uint2 out0;
            out0.x = lazy_reduce(acc[t][0], q_modulus, q_barrett);
            out0.y = lazy_reduce(acc[t][1], q_modulus, q_barrett);
            reinterpret_cast<uint2 *>(dst_q0 + q_base)[left] = out0;
            if constexpr (Components == 2)
            {
                uint2 out1;
                out1.x = lazy_reduce(acc[t][2], q_modulus, q_barrett);
                out1.y = lazy_reduce(acc[t][3], q_modulus, q_barrett);
                reinterpret_cast<uint2 *>(dst_q1 + q_base)[left] = out1;
            }
        }
    }
    else
    {
        const GpuWord *source0 = accum_p0 + left;
        const GpuWord *source1 = Components == 2 ? accum_p1 + left : nullptr;
#pragma unroll 2
        for (unsigned int p_limb = 0; p_limb < base_p_size; ++p_limb)
        {
            GpuWord values[kValues];
            values[0] = source0[0];
            values[1] = source0[half];
            source0 += degree;
            if constexpr (Components == 2)
            {
                values[2] = source1[0];
                values[3] = source1[half];
                source1 += degree;
            }
            const GpuWord *row = tile_matrix + p_limb * QTile;
#pragma unroll
            for (int t = 0; t < QTile; ++t)
            {
                const GpuWord matrix_value = row[t];
#pragma unroll
                for (int k = 0; k < kValues; ++k)
                {
                    lazy_mac(acc[t][k], values[k], matrix_value);
                }
            }
        }
#pragma unroll
        for (int t = 0; t < QTile; ++t)
        {
            const unsigned int q_limb = q_begin + t;
            if (q_limb >= base_q_size)
            {
                break;
            }
            const GpuWord q_modulus = rns_primes[q_limb];
            const GpuWide q_barrett = rns_modulus_constants[q_limb];
            const std::size_t q_base = static_cast<std::size_t>(q_limb) << degree_power;
            dst_q0[q_base + left] = lazy_reduce(acc[t][0], q_modulus, q_barrett);
            dst_q0[q_base + left + half] = lazy_reduce(acc[t][1], q_modulus, q_barrett);
            if constexpr (Components == 2)
            {
                dst_q1[q_base + left] = lazy_reduce(acc[t][2], q_modulus, q_barrett);
                dst_q1[q_base + left + half] = lazy_reduce(acc[t][3], q_modulus, q_barrett);
            }
        }
    }
}

inline bool cta_base_conv_enabled()
{
    const char *raw = std::getenv("POSEIDON_CTA_BASE_CONV");
    return raw != nullptr && *raw != '\0' && std::string(raw) == "1";
}

inline int select_adaptive_tile_4_8_12_16(
    std::size_t target_count,
    int configured_tile)
{
    int max_tile = 4;
    if (configured_tile >= 16)
    {
        max_tile = 16;
    }
    else if (configured_tile >= 12)
    {
        max_tile = 12;
    }
    else if (configured_tile >= 8)
    {
        max_tile = 8;
    }
    if (max_tile <= 4 || target_count <= 4)
    {
        return 4;
    }
    const std::size_t min_passes = (target_count + max_tile - 1) / max_tile;
    if (min_passes * 4 >= target_count)
    {
        return 4;
    }
    if (min_passes * 8 >= target_count)
    {
        return 8;
    }
    if (max_tile >= 12 && min_passes * 12 >= target_count)
    {
        return 12;
    }
    return max_tile;
}

inline int select_adaptive_tile_4_6_8(
    std::size_t target_count,
    int configured_tile)
{
    int max_tile = 4;
    if (configured_tile >= 8)
    {
        max_tile = 8;
    }
    else if (configured_tile >= 6)
    {
        max_tile = 6;
    }
    if (max_tile <= 4 || target_count <= 4)
    {
        return 4;
    }
    const std::size_t min_passes = (target_count + max_tile - 1) / max_tile;
    if (min_passes * 4 >= target_count)
    {
        return 4;
    }
    if (max_tile >= 6 && min_passes * 6 >= target_count)
    {
        return 6;
    }
    return max_tile;
}

inline bool ptr_aligned8(const void *ptr)
{
    return (reinterpret_cast<std::uintptr_t>(ptr) & 7u) == 0u;
}

template <int RWarps, int CWarps, int WarpTargets>
__global__ void __launch_bounds__(256, 4) hybrid_modup_qp_cta_tiled_65536_kernel(
    GpuWord *__restrict__ modup_q,
    GpuWord *__restrict__ modup_p,
    const GpuWord *__restrict__ weighted,
    const GpuWord *__restrict__ rns_primes,
    const GpuWide *__restrict__ rns_modulus_constants,
    const GpuWord *__restrict__ q_matrix_offsets,
    const GpuWord *__restrict__ q_matrices,
    const GpuWord *__restrict__ p_matrix_offsets,
    const GpuWord *__restrict__ p_matrices,
    unsigned int decomp_index,
    unsigned int decomp_limb_begin,
    unsigned int decomp_limb_count,
    unsigned int base_q_size,
    unsigned int base_p_size,
    std::size_t weighted_batch_stride,
    std::size_t modup_q_batch_stride,
    std::size_t modup_p_batch_stride)
{
    static_assert(RWarps * CWarps == 8);
    constexpr unsigned int kDegree = 65536;
    constexpr unsigned int kCtaTargets = RWarps * WarpTargets;
    constexpr unsigned int kHalfCoeffs = CWarps * 32;
    constexpr unsigned int kKChunk = 8;

    __shared__ GpuWord shared_x0[kKChunk][kHalfCoeffs];
    __shared__ GpuWord shared_x1[kKChunk][kHalfCoeffs];
    __shared__ GpuWord shared_m[kKChunk][kCtaTargets];

    const std::size_t z = blockIdx.z;
    if (modup_q != nullptr)
    {
        modup_q += z * modup_q_batch_stride;
    }
    modup_p += z * modup_p_batch_stride;
    weighted += z * weighted_batch_stride;

    const unsigned int active_q_count = base_q_size - decomp_limb_count;
    const unsigned int target_count = active_q_count + base_p_size;
    const unsigned int cta_target_begin = blockIdx.y * kCtaTargets;
    const unsigned int base_half = blockIdx.x * kHalfCoeffs;
    const unsigned int tid_cta = threadIdx.y * 32u + threadIdx.x;
    const unsigned int r_warp = threadIdx.y / CWarps;
    const unsigned int c_warp = (CWarps == 1) ? 0u : (threadIdx.y & (CWarps - 1));
    const unsigned int h_col = c_warp * 32u + threadIdx.x;

    const GpuWord *q_digit =
        active_q_count > 0 ? q_matrices + q_matrix_offsets[decomp_index] : nullptr;
    const GpuWord *p_digit = p_matrices + p_matrix_offsets[decomp_index];

    LazyAccumulator acc0[WarpTargets];
    LazyAccumulator acc1[WarpTargets];

    for (unsigned int col_base = 0; col_base < decomp_limb_count; col_base += kKChunk)
    {
        const unsigned int chunk_cols =
            (decomp_limb_count - col_base) < kKChunk
                ? (decomp_limb_count - col_base)
                : kKChunk;
        if (col_base > 0)
        {
            __syncthreads();
        }
        for (unsigned int i = tid_cta; i < chunk_cols * kCtaTargets; i += 256u)
        {
            const unsigned int k = i / kCtaTargets;
            const unsigned int t_local = i - k * kCtaTargets;
            const unsigned int col = col_base + k;
            unsigned int target = cta_target_begin + t_local;
            if (target >= target_count)
            {
                target = target_count - 1;
            }
            const unsigned int limb = target < active_q_count
                ? (target < decomp_limb_begin ? target : target + decomp_limb_count)
                : base_q_size + (target - active_q_count);
            shared_m[k][t_local] = limb < base_q_size
                ? q_digit[limb * base_p_size + col]
                : p_digit[(limb - base_q_size) * base_p_size + col];
        }
        for (unsigned int idx = tid_cta; idx < chunk_cols * kHalfCoeffs; idx += 256u)
        {
            const unsigned int k = idx / kHalfCoeffs;
            const unsigned int h = idx & (kHalfCoeffs - 1);
            const uint2 v = reinterpret_cast<const uint2 *>(
                weighted + static_cast<std::size_t>(col_base + k) * kDegree)[base_half + h];
            shared_x0[k][h] = v.x;
            shared_x1[k][h] = v.y;
        }
        __syncthreads();

        if (chunk_cols == kKChunk)
        {
#pragma unroll
            for (unsigned int k = 0; k < kKChunk; ++k)
            {
                const GpuWord x0 = shared_x0[k][h_col];
                const GpuWord x1 = shared_x1[k][h_col];
#pragma unroll
                for (int t = 0; t < WarpTargets; ++t)
                {
                    const GpuWord m = shared_m[k][r_warp * WarpTargets + t];
                    lazy_mac(acc0[t], x0, m);
                    lazy_mac(acc1[t], x1, m);
                }
            }
        }
        else
        {
            for (unsigned int k = 0; k < chunk_cols; ++k)
            {
                const GpuWord x0 = shared_x0[k][h_col];
                const GpuWord x1 = shared_x1[k][h_col];
#pragma unroll
                for (int t = 0; t < WarpTargets; ++t)
                {
                    const GpuWord m = shared_m[k][r_warp * WarpTargets + t];
                    lazy_mac(acc0[t], x0, m);
                    lazy_mac(acc1[t], x1, m);
                }
            }
        }
    }

    const unsigned int out_half = base_half + h_col;
#pragma unroll
    for (int t = 0; t < WarpTargets; ++t)
    {
        const unsigned int target = cta_target_begin + r_warp * WarpTargets + t;
        if (target >= target_count)
        {
            break;
        }
        const unsigned int limb = target < active_q_count
            ? (target < decomp_limb_begin ? target : target + decomp_limb_count)
            : base_q_size + (target - active_q_count);
        const GpuWord modulus = rns_primes[limb];
        const GpuWide barrett = rns_modulus_constants[limb];
        GpuWord *values = limb < base_q_size
            ? modup_q + (static_cast<std::size_t>(limb) << 16)
            : modup_p + (static_cast<std::size_t>(limb - base_q_size) << 16);
        uint2 out;
        out.x = lazy_reduce(acc0[t], modulus, barrett);
        out.y = lazy_reduce(acc1[t], modulus, barrett);
        reinterpret_cast<uint2 *>(values)[out_half] = out;
    }
}

template <int RWarps, int CWarps, int WarpTargets, bool DualComponent>
__global__ void __launch_bounds__(256, 4) hybrid_convert_p_to_q_cta_tiled_65536_kernel(
    GpuWord *__restrict__ converted_q0,
    GpuWord *__restrict__ converted_q1,
    const GpuWord *__restrict__ accum_p0,
    const GpuWord *__restrict__ accum_p1,
    const GpuWord *__restrict__ rns_primes,
    const GpuWide *__restrict__ rns_modulus_constants,
    const GpuWord *__restrict__ moddown_p_to_q_matrix,
    unsigned int base_q_size,
    unsigned int base_p_size)
{
    static_assert(RWarps * CWarps == 8);
    constexpr unsigned int kDegree = 65536;
    constexpr unsigned int kCtaTargets = RWarps * WarpTargets;
    constexpr unsigned int kHalfCoeffs = CWarps * 32;
    constexpr unsigned int kKChunk = 8;

    __shared__ GpuWord shared_x0[kKChunk][kHalfCoeffs];
    __shared__ GpuWord shared_x1[kKChunk][kHalfCoeffs];
    __shared__ GpuWord shared_m[kKChunk][kCtaTargets];

    GpuWord *dst = DualComponent
        ? (blockIdx.z == 0 ? converted_q0 : converted_q1)
        : (converted_q0 + static_cast<std::size_t>(blockIdx.z) * base_q_size * kDegree);
    const GpuWord *src = DualComponent
        ? (blockIdx.z == 0 ? accum_p0 : accum_p1)
        : (accum_p0 + static_cast<std::size_t>(blockIdx.z) * base_p_size * kDegree);

    const unsigned int cta_q_begin = blockIdx.y * kCtaTargets;
    const unsigned int base_half = blockIdx.x * kHalfCoeffs;
    const unsigned int tid_cta = threadIdx.y * 32u + threadIdx.x;
    const unsigned int r_warp = threadIdx.y / CWarps;
    const unsigned int c_warp = (CWarps == 1) ? 0u : (threadIdx.y & (CWarps - 1));
    const unsigned int h_col = c_warp * 32u + threadIdx.x;

    LazyAccumulator acc0[WarpTargets];
    LazyAccumulator acc1[WarpTargets];

    for (unsigned int p_base = 0; p_base < base_p_size; p_base += kKChunk)
    {
        const unsigned int chunk_cols =
            (base_p_size - p_base) < kKChunk ? (base_p_size - p_base) : kKChunk;
        if (p_base > 0)
        {
            __syncthreads();
        }
        for (unsigned int i = tid_cta; i < chunk_cols * kCtaTargets; i += 256u)
        {
            const unsigned int k = i / kCtaTargets;
            const unsigned int t_local = i - k * kCtaTargets;
            unsigned int q_limb = cta_q_begin + t_local;
            if (q_limb >= base_q_size)
            {
                q_limb = base_q_size - 1;
            }
            shared_m[k][t_local] =
                moddown_p_to_q_matrix[q_limb * base_p_size + (p_base + k)];
        }
        for (unsigned int idx = tid_cta; idx < chunk_cols * kHalfCoeffs; idx += 256u)
        {
            const unsigned int k = idx / kHalfCoeffs;
            const unsigned int h = idx & (kHalfCoeffs - 1);
            const uint2 v = reinterpret_cast<const uint2 *>(
                src + static_cast<std::size_t>(p_base + k) * kDegree)[base_half + h];
            shared_x0[k][h] = v.x;
            shared_x1[k][h] = v.y;
        }
        __syncthreads();

        if (chunk_cols == kKChunk)
        {
#pragma unroll
            for (unsigned int k = 0; k < kKChunk; ++k)
            {
                const GpuWord x0 = shared_x0[k][h_col];
                const GpuWord x1 = shared_x1[k][h_col];
#pragma unroll
                for (int t = 0; t < WarpTargets; ++t)
                {
                    const GpuWord m = shared_m[k][r_warp * WarpTargets + t];
                    lazy_mac(acc0[t], x0, m);
                    lazy_mac(acc1[t], x1, m);
                }
            }
        }
        else
        {
            for (unsigned int k = 0; k < chunk_cols; ++k)
            {
                const GpuWord x0 = shared_x0[k][h_col];
                const GpuWord x1 = shared_x1[k][h_col];
#pragma unroll
                for (int t = 0; t < WarpTargets; ++t)
                {
                    const GpuWord m = shared_m[k][r_warp * WarpTargets + t];
                    lazy_mac(acc0[t], x0, m);
                    lazy_mac(acc1[t], x1, m);
                }
            }
        }
    }

    const unsigned int out_half = base_half + h_col;
#pragma unroll
    for (int t = 0; t < WarpTargets; ++t)
    {
        const unsigned int q_limb = cta_q_begin + r_warp * WarpTargets + t;
        if (q_limb >= base_q_size)
        {
            break;
        }
        const GpuWord q_modulus = rns_primes[q_limb];
        const GpuWide q_barrett = rns_modulus_constants[q_limb];
        GpuWord *values = dst + (static_cast<std::size_t>(q_limb) << 16);
        uint2 out;
        out.x = lazy_reduce(acc0[t], q_modulus, q_barrett);
        out.y = lazy_reduce(acc1[t], q_modulus, q_barrett);
        reinterpret_cast<uint2 *>(values)[out_half] = out;
    }
}

inline bool try_launch_hybrid_modup_qp_cta_tiled_65536(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *weighted,
    const GpuParameterShard &parameters,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t batch_count,
    std::size_t weighted_stride,
    std::size_t dst_q_stride,
    std::size_t dst_p_stride,
    std::size_t degree)
{
    if (degree != 65536 || batch_count == 0 || batch_count > 65535 ||
        decomp_limb_count <= 1 || decomp_limb_count > kModupPreweightMaxCols ||
        !cta_base_conv_enabled())
    {
        return false;
    }
    const std::size_t q = parameters.hybrid_base_q_count;
    const std::size_t p = parameters.hybrid_base_p_count;
    const std::size_t active_q = q - decomp_limb_count;
    const std::size_t targets = active_q + p;
    if (targets == 0 || !ptr_aligned8(modup_p) || !ptr_aligned8(weighted) ||
        (active_q > 0 && (modup_q == nullptr || !ptr_aligned8(modup_q))) ||
        ((weighted_stride | dst_q_stride | dst_p_stride) & 1u) != 0u)
    {
        return false;
    }
    const dim3 block(32, 8, 1);
    const unsigned int z_dim = static_cast<unsigned int>(batch_count);
    auto launch = [&](auto r_tag, auto c_tag, auto wt_tag) {
        constexpr int R = decltype(r_tag)::value;
        constexpr int C = decltype(c_tag)::value;
        constexpr int WT = decltype(wt_tag)::value;
        constexpr unsigned int kCtaTargets = R * WT;
        constexpr unsigned int kHalfCoeffs = C * 32;
        const dim3 grid(
            32768u / kHalfCoeffs,
            static_cast<unsigned int>((targets + kCtaTargets - 1) / kCtaTargets),
            z_dim);
        hybrid_modup_qp_cta_tiled_65536_kernel<R, C, WT>
            <<<grid, block, 0, gpu_execution_stream()>>>(
                active_q > 0 ? modup_q : nullptr,
                modup_p,
                weighted,
                parameters.rns_primes.data(),
                parameters.rns_modulus_constants.data(),
                parameters.hybrid_q_conv_matrix_offsets.data(),
                parameters.hybrid_q_conv_matrices.data(),
                parameters.hybrid_p_conv_matrix_offsets.data(),
                parameters.hybrid_p_conv_matrices.data(),
                static_cast<unsigned int>(decomp_index),
                static_cast<unsigned int>(decomp_limb_begin),
                static_cast<unsigned int>(decomp_limb_count),
                static_cast<unsigned int>(q),
                static_cast<unsigned int>(p),
                weighted_stride,
                dst_q_stride,
                dst_p_stride);
    };
    if (targets <= 8)
    {
        launch(std::integral_constant<int, 2>{},
               std::integral_constant<int, 4>{},
               std::integral_constant<int, 4>{});
    }
    else if (targets <= 16)
    {
        launch(std::integral_constant<int, 4>{},
               std::integral_constant<int, 2>{},
               std::integral_constant<int, 4>{});
    }
    else if (targets <= 32)
    {
        launch(std::integral_constant<int, 8>{},
               std::integral_constant<int, 1>{},
               std::integral_constant<int, 4>{});
    }
    else if (targets <= 48)
    {
        launch(std::integral_constant<int, 8>{},
               std::integral_constant<int, 1>{},
               std::integral_constant<int, 6>{});
    }
    else
    {
        launch(std::integral_constant<int, 8>{},
               std::integral_constant<int, 1>{},
               std::integral_constant<int, 8>{});
    }
    return true;
}

inline bool try_launch_hybrid_convert_p_to_q_cta_tiled_65536(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameters,
    std::size_t batch_count,
    bool dual_component,
    std::size_t degree)
{
    const std::size_t q = parameters.hybrid_base_q_count;
    const std::size_t p = parameters.hybrid_base_p_count;
    if (degree != 65536 || q == 0 || p == 0 || p > kPToQPreweightMaxP ||
        batch_count == 0 || batch_count > 65535 || !cta_base_conv_enabled())
    {
        return false;
    }
    if (!ptr_aligned8(converted_q0) || !ptr_aligned8(accum_p0) ||
        (dual_component && (!ptr_aligned8(converted_q1) || !ptr_aligned8(accum_p1))))
    {
        return false;
    }
    const dim3 block(32, 8, 1);
    const unsigned int z_dim = dual_component ? 2u : static_cast<unsigned int>(batch_count);
    auto launch = [&](auto r_tag, auto c_tag, auto wt_tag, auto dual_tag) {
        constexpr int R = decltype(r_tag)::value;
        constexpr int C = decltype(c_tag)::value;
        constexpr int WT = decltype(wt_tag)::value;
        constexpr bool kDual = decltype(dual_tag)::value;
        constexpr unsigned int kCtaTargets = R * WT;
        constexpr unsigned int kHalfCoeffs = C * 32;
        const dim3 grid(
            32768u / kHalfCoeffs,
            static_cast<unsigned int>((q + kCtaTargets - 1) / kCtaTargets),
            z_dim);
        hybrid_convert_p_to_q_cta_tiled_65536_kernel<R, C, WT, kDual>
            <<<grid, block, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameters.rns_primes.data(),
                parameters.rns_modulus_constants.data(),
                parameters.hybrid_moddown_p_to_q_matrix.data(),
                static_cast<unsigned int>(q),
                static_cast<unsigned int>(p));
    };
    auto dispatch_shape = [&](auto dual_tag) {
        if (q <= 8)
        {
            launch(std::integral_constant<int, 2>{},
                   std::integral_constant<int, 4>{},
                   std::integral_constant<int, 4>{},
                   dual_tag);
        }
        else if (q <= 16)
        {
            launch(std::integral_constant<int, 4>{},
                   std::integral_constant<int, 2>{},
                   std::integral_constant<int, 4>{},
                   dual_tag);
        }
        else if (q <= 32)
        {
            launch(std::integral_constant<int, 8>{},
                   std::integral_constant<int, 1>{},
                   std::integral_constant<int, 4>{},
                   dual_tag);
        }
        else if (q <= 48)
        {
            launch(std::integral_constant<int, 8>{},
                   std::integral_constant<int, 1>{},
                   std::integral_constant<int, 6>{},
                   dual_tag);
        }
        else
        {
            launch(std::integral_constant<int, 8>{},
                   std::integral_constant<int, 1>{},
                   std::integral_constant<int, 8>{},
                   dual_tag);
        }
    };
    if (dual_component)
    {
        dispatch_shape(std::true_type{});
    }
    else
    {
        dispatch_shape(std::false_type{});
    }
    return true;
}

__global__ void build_q_preweighted_inv_degree_kernel(
    GpuWord *table,
    const GpuWord *inv_degree,
    const GpuWord *qi_inv_punctured,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    unsigned int base_q_size,
    unsigned int total)
{
    const unsigned int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= total)
    {
        return;
    }
    GpuWord value = inv_degree[i];
    if (i < base_q_size)
    {
        value = mul_mod(value, qi_inv_punctured[i], rns_primes[i], rns_modulus_constants[i]);
    }
    table[i] = value;
}

/*
 * Device scratch for the preweighted ModUp source, one buffer per (thread,
 * device, stream): reuse is stream-ordered, so no synchronization is needed
 * between digits. Grows once (during warm-up) and is never freed.
 */
GpuWord *modup_preweight_scratch(std::size_t words)
{
    struct Entry
    {
        int device;
        cudaStream_t stream;
        GpuWord *ptr;
        std::size_t words;
    };
    thread_local std::vector<Entry> entries;
    int device = 0;
    gpu_check_cuda(cudaGetDevice(&device), "modup_preweight_scratch cudaGetDevice");
    const cudaStream_t stream = gpu_execution_stream();
    for (auto &entry : entries)
    {
        if (entry.device != device || entry.stream != stream)
        {
            continue;
        }
        if (entry.words < words)
        {
            gpu_check_cuda(cudaStreamSynchronize(stream), "modup_preweight_scratch sync");
            gpu_check_cuda(cudaFree(entry.ptr), "modup_preweight_scratch cudaFree");
            gpu_check_cuda(cudaMalloc(&entry.ptr, words * sizeof(GpuWord)),
                           "modup_preweight_scratch cudaMalloc");
            entry.words = words;
        }
        return entry.ptr;
    }
    Entry entry{device, stream, nullptr, words};
    gpu_check_cuda(cudaMalloc(&entry.ptr, words * sizeof(GpuWord)),
                   "modup_preweight_scratch cudaMalloc");
    entries.push_back(entry);
    return entry.ptr;
}

/*
 * P->Q conversion plus the first forward NTT stage with lazy accumulation.
 * One thread owns one butterfly (left/right coefficient, both components) for
 * a tile of Q limbs; each P residue is loaded and weighted once per tile.
 */
template <int QTile, bool FirstStage = true>
__global__ void hybrid_convert_p_to_q_forward_ntt_first_stage_lazy_kernel(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power,
    bool source_preweighted)
{
    const std::size_t half = degree >> 1;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t tile_count = (base_q_size + QTile - 1) / QTile;
    if (tid >= tile_count * half)
    {
        return;
    }
    const std::size_t left_coeff = tid & (half - 1);
    const std::size_t right_coeff = left_coeff + half;
    const std::size_t q_begin = (tid >> (degree_power - 1)) * QTile;

    LazyAccumulator acc[QTile][4];
    for (std::size_t p_limb = 0; p_limb < base_p_size; ++p_limb)
    {
        const std::size_t p_base = p_limb * degree;
        GpuWord values[4] = {
            accum_p0[p_base + left_coeff],
            accum_p0[p_base + right_coeff],
            accum_p1[p_base + left_coeff],
            accum_p1[p_base + right_coeff]};
        if (!source_preweighted)
        {
            const GpuWord inv_punctured = p_inv_punctured[p_limb];
            if (inv_punctured != 1)
            {
                const GpuWord p_modulus = rns_primes[base_q_size + p_limb];
                const GpuWide p_barrett = rns_modulus_constants[base_q_size + p_limb];
#pragma unroll
                for (int k = 0; k < 4; ++k)
                {
                    values[k] = mul_mod(values[k], inv_punctured, p_modulus, p_barrett);
                }
            }
        }
#pragma unroll
        for (int t = 0; t < QTile; ++t)
        {
            const std::size_t q_limb = q_begin + t;
            if (q_limb >= base_q_size)
            {
                break;
            }
            const GpuWord matrix_value =
                moddown_p_to_q_matrix[q_limb * base_p_size + p_limb];
#pragma unroll
            for (int k = 0; k < 4; ++k)
            {
                lazy_mac(acc[t][k], values[k], matrix_value);
            }
        }
    }
#pragma unroll
    for (int t = 0; t < QTile; ++t)
    {
        const std::size_t q_limb = q_begin + t;
        if (q_limb >= base_q_size)
        {
            break;
        }
        const GpuWord q_modulus = rns_primes[q_limb];
        const GpuWide q_barrett = rns_modulus_constants[q_limb];
        const GpuWord left0 = lazy_reduce(acc[t][0], q_modulus, q_barrett);
        const GpuWord right0 = lazy_reduce(acc[t][1], q_modulus, q_barrett);
        const GpuWord left1 = lazy_reduce(acc[t][2], q_modulus, q_barrett);
        const GpuWord right1 = lazy_reduce(acc[t][3], q_modulus, q_barrett);
        const std::size_t q_base = q_limb * degree;
        if constexpr (!FirstStage)
        {
            // Coefficient form; a separate in-place NTT follows.
            converted_q0[q_base + left_coeff] = left0;
            converted_q0[q_base + right_coeff] = right0;
            converted_q1[q_base + left_coeff] = left1;
            converted_q1[q_base + right_coeff] = right1;
            continue;
        }
        const GpuWord root = roots[q_limb * degree + 1];
        const GpuWord twisted_right0 = mul_mod(right0, root, q_modulus, q_barrett);
        converted_q0[q_base + left_coeff] = add_mod(left0, twisted_right0, q_modulus);
        converted_q0[q_base + right_coeff] = sub_mod(left0, twisted_right0, q_modulus);
        const GpuWord twisted_right1 = mul_mod(right1, root, q_modulus, q_barrett);
        converted_q1[q_base + left_coeff] = add_mod(left1, twisted_right1, q_modulus);
        converted_q1[q_base + right_coeff] = sub_mod(left1, twisted_right1, q_modulus);
    }
}

/*
 * ModUp plus the first forward NTT stage with lazy accumulation: one thread
 * owns one butterfly for a tile of active target limbs (Q outside the digit,
 * then P); each digit residue pair is weighted once per tile.
 */
template <int Tile>
__global__ void hybrid_modup_qp_forward_ntt_first_stage_lazy_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t half = degree >> 1;
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t active_count = active_q_count + base_p_size;
    const std::size_t tile_count = (active_count + Tile - 1) / Tile;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= tile_count * half)
    {
        return;
    }
    const std::size_t left_coeff = tid & (half - 1);
    const std::size_t right_coeff = left_coeff + half;
    const std::size_t active_begin = (tid >> (degree_power - 1)) * Tile;
    const std::size_t inv_offset = decomp_index * base_p_size;
    const std::size_t q_offset = q_matrix_offsets[decomp_index];
    const std::size_t p_offset = p_matrix_offsets[decomp_index];

    LazyAccumulator left_acc[Tile];
    LazyAccumulator right_acc[Tile];
    for (std::size_t col = 0; col < decomp_limb_count; ++col)
    {
        const std::size_t source_limb = decomp_limb_begin + col;
        GpuWord left_value = c2_coeff[source_limb * degree + left_coeff];
        GpuWord right_value = c2_coeff[source_limb * degree + right_coeff];
        const GpuWord inv_punctured = qi_inv_punctured[inv_offset + col];
        if (inv_punctured != 1)
        {
            const GpuWord source_modulus = rns_primes[source_limb];
            const GpuWide source_barrett = rns_modulus_constants[source_limb];
            left_value = mul_mod(left_value, inv_punctured, source_modulus, source_barrett);
            right_value = mul_mod(right_value, inv_punctured, source_modulus, source_barrett);
        }
#pragma unroll
        for (int t = 0; t < Tile; ++t)
        {
            const std::size_t active = active_begin + t;
            if (active >= active_count)
            {
                break;
            }
            GpuWord matrix_value;
            if (active < active_q_count)
            {
                const std::size_t limb =
                    active < decomp_limb_begin ? active : active + decomp_limb_count;
                matrix_value = q_matrices[q_offset + limb * base_p_size + col];
            }
            else
            {
                matrix_value = p_matrices[p_offset + (active - active_q_count) * base_p_size + col];
            }
            lazy_mac(left_acc[t], left_value, matrix_value);
            lazy_mac(right_acc[t], right_value, matrix_value);
        }
    }
#pragma unroll
    for (int t = 0; t < Tile; ++t)
    {
        const std::size_t active = active_begin + t;
        if (active >= active_count)
        {
            break;
        }
        GpuWord *values = modup_q;
        std::size_t value_limb, table_limb;
        if (active < active_q_count)
        {
            value_limb = active < decomp_limb_begin ? active : active + decomp_limb_count;
            table_limb = value_limb;
        }
        else
        {
            values = modup_p;
            value_limb = active - active_q_count;
            table_limb = base_q_size + value_limb;
        }
        const GpuWord modulus = rns_primes[table_limb];
        const GpuWide barrett = rns_modulus_constants[table_limb];
        const GpuWord left = lazy_reduce(left_acc[t], modulus, barrett);
        const GpuWord right = lazy_reduce(right_acc[t], modulus, barrett);
        const GpuWord root = roots[table_limb * degree + 1];
        const GpuWord twisted_right = mul_mod(right, root, modulus, barrett);
        const std::size_t value_base = value_limb * degree;
        values[value_base + left_coeff] = add_mod(left, twisted_right, modulus);
        values[value_base + right_coeff] = sub_mod(left, twisted_right, modulus);
    }
}

bool lazy_base_conversion_enabled()
{
    static const bool enabled = [] {
        const char *raw = std::getenv("POSEIDON_GPU_LAZY_BASECONV");
        return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
    }();
    return enabled;
}

__device__ __forceinline__ void hybrid_modup_pair_contribution(
    GpuWord &left_sum,
    GpuWord &right_sum,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *conversion_matrix,
    const GpuWord *qi_inv_punctured,
    std::size_t matrix_row_offset,
    std::size_t inv_offset,
    std::size_t decomp_limb_begin,
    std::size_t col,
    std::size_t left_coeff,
    std::size_t right_coeff,
    std::size_t degree,
    GpuWord target_modulus,
    GpuWide target_barrett)
{
    const std::size_t source_q_limb = decomp_limb_begin + col;
    const std::size_t source_base = source_q_limb * degree;
    const GpuWord source_modulus = rns_primes[source_q_limb];
    const GpuWide source_barrett = rns_modulus_constants[source_q_limb];
    const GpuWord inv_punctured = qi_inv_punctured[inv_offset + col];
    const GpuWord matrix_value = conversion_matrix[matrix_row_offset + col];

    const GpuWord left_value = c2_coeff[source_base + left_coeff];
    const GpuWord left_weighted = inv_punctured == 1
        ? left_value
        : mul_mod(
              left_value,
              inv_punctured,
              source_modulus,
              source_barrett);
    left_sum = add_mod(
        left_sum,
        mul_mod(
            left_weighted,
            matrix_value,
            target_modulus,
            target_barrett),
        target_modulus);

    const GpuWord right_value = c2_coeff[source_base + right_coeff];
    const GpuWord right_weighted = inv_punctured == 1
        ? right_value
        : mul_mod(
              right_value,
              inv_punctured,
              source_modulus,
              source_barrett);
    right_sum = add_mod(
        right_sum,
        mul_mod(
            right_weighted,
            matrix_value,
            target_modulus,
            target_barrett),
        target_modulus);
}

template <int FixedDecompLimbCount>
__device__ __forceinline__ void hybrid_modup_pair(
    GpuWord &left,
    GpuWord &right,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *conversion_matrix,
    const GpuWord *qi_inv_punctured,
    std::size_t matrix_row_offset,
    std::size_t inv_offset,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t left_coeff,
    std::size_t right_coeff,
    std::size_t degree,
    GpuWord target_modulus,
    GpuWide target_barrett)
{
    if constexpr (FixedDecompLimbCount == 1)
    {
        const std::size_t source_base = decomp_limb_begin * degree;
        left = reduce_to_modulus(
            c2_coeff[source_base + left_coeff],
            target_modulus,
            target_barrett);
        right = reduce_to_modulus(
            c2_coeff[source_base + right_coeff],
            target_modulus,
            target_barrett);
        return;
    }

    left = 0;
    right = 0;
    if constexpr (FixedDecompLimbCount > 0)
    {
#pragma unroll
        for (std::size_t col = 0;
             col < FixedDecompLimbCount;
             ++col)
        {
            hybrid_modup_pair_contribution(
                left,
                right,
                c2_coeff,
                rns_primes,
                rns_modulus_constants,
                conversion_matrix,
                qi_inv_punctured,
                matrix_row_offset,
                inv_offset,
                decomp_limb_begin,
                col,
                left_coeff,
                right_coeff,
                degree,
                target_modulus,
                target_barrett);
        }
    }
    else
    {
        for (std::size_t col = 0; col < decomp_limb_count; ++col)
        {
            hybrid_modup_pair_contribution(
                left,
                right,
                c2_coeff,
                rns_primes,
                rns_modulus_constants,
                conversion_matrix,
                qi_inv_punctured,
                matrix_row_offset,
                inv_offset,
                decomp_limb_begin,
                col,
                left_coeff,
                right_coeff,
                degree,
                target_modulus,
                target_barrett);
        }
    }
}

template <int FixedDecompLimbCount>
__global__ void hybrid_modup_qp_forward_ntt_first_stage_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t butterflies_per_limb = degree >> 1;
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t active_limb_count = active_q_count + base_p_size;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = active_limb_count * butterflies_per_limb;
    if (tid >= total)
    {
        return;
    }

    const std::size_t active_limb = tid >> (degree_power - 1);
    const std::size_t left_coeff = tid & (butterflies_per_limb - 1);
    const std::size_t right_coeff = left_coeff + butterflies_per_limb;

    GpuWord *values = modup_q;
    const GpuWord *conversion_matrix = q_matrices;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;
    std::size_t matrix_row_limb = active_limb;
    std::size_t matrix_offset = q_matrix_offsets[decomp_index];

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + decomp_limb_count;
            table_limb = value_limb;
            matrix_row_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        conversion_matrix = p_matrices;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
        matrix_row_limb = p_limb;
        matrix_offset = p_matrix_offsets[decomp_index];
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const std::size_t matrix_row_offset =
        matrix_offset + matrix_row_limb * base_p_size;
    const std::size_t inv_offset = decomp_index * base_p_size;

    GpuWord left;
    GpuWord right;
    hybrid_modup_pair<FixedDecompLimbCount>(
        left,
        right,
        c2_coeff,
        rns_primes,
        rns_modulus_constants,
        conversion_matrix,
        qi_inv_punctured,
        matrix_row_offset,
        inv_offset,
        decomp_limb_begin,
        decomp_limb_count,
        left_coeff,
        right_coeff,
        degree,
        modulus,
        barrett);

    const GpuWord root = roots[table_limb * degree + 1];
    const GpuWord twisted_right = mul_mod(right, root, modulus, barrett);
    const std::size_t value_base = value_limb * degree;
    values[value_base + left_coeff] = add_mod(left, twisted_right, modulus);
    values[value_base + right_coeff] = sub_mod(left, twisted_right, modulus);
}

__global__ void hybrid_modup_qp_forward_ntt_first_stage_row_tiled2_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree)
{
    constexpr std::size_t kSourceLimbCount = 2;
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kTargetRows = 4;
    __shared__ GpuWord weighted_source[4][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t row = threadIdx.y;
    const std::size_t butterflies_per_limb = degree >> 1;
    const std::size_t coefficient_pair =
        blockIdx.x * kCoefficientTile + lane;
    const bool valid_coefficient =
        coefficient_pair < butterflies_per_limb;

    const std::size_t source_col = row >> 1;
    const std::size_t coefficient_side = row & 1;
    GpuWord weighted = 0;
    if (valid_coefficient)
    {
        const std::size_t source_q_limb =
            decomp_limb_begin + source_col;
        const std::size_t source_coeff =
            coefficient_pair + coefficient_side * butterflies_per_limb;
        const GpuWord source_modulus = rns_primes[source_q_limb];
        const GpuWide source_barrett =
            rns_modulus_constants[source_q_limb];
        const GpuWord inv_punctured =
            qi_inv_punctured[
                decomp_index * base_p_size + source_col];
        const GpuWord source_value =
            c2_coeff[source_q_limb * degree + source_coeff];
        weighted = inv_punctured == 1
            ? source_value
            : mul_mod(
                  source_value,
                  inv_punctured,
                  source_modulus,
                  source_barrett);
    }
    weighted_source[row][lane] = weighted;
    __syncthreads();

    const std::size_t active_q_count =
        base_q_size - kSourceLimbCount;
    const std::size_t active_limb_count =
        active_q_count + base_p_size;
    const std::size_t active_limb =
        blockIdx.y * kTargetRows + row;
    if (!valid_coefficient || active_limb >= active_limb_count)
    {
        return;
    }

    GpuWord *values = modup_q;
    const GpuWord *conversion_matrix = q_matrices;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;
    std::size_t matrix_row_limb = active_limb;
    std::size_t matrix_offset = q_matrix_offsets[decomp_index];

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + kSourceLimbCount;
            table_limb = value_limb;
            matrix_row_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        conversion_matrix = p_matrices;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
        matrix_row_limb = p_limb;
        matrix_offset = p_matrix_offsets[decomp_index];
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const std::size_t matrix_row_offset =
        matrix_offset + matrix_row_limb * base_p_size;
    const GpuWord matrix0 = conversion_matrix[matrix_row_offset];
    const GpuWord matrix1 = conversion_matrix[matrix_row_offset + 1];

    const GpuWord left = add_mod(
        mul_mod(
            weighted_source[0][lane],
            matrix0,
            modulus,
            barrett),
        mul_mod(
            weighted_source[2][lane],
            matrix1,
            modulus,
            barrett),
        modulus);
    const GpuWord right = add_mod(
        mul_mod(
            weighted_source[1][lane],
            matrix0,
            modulus,
            barrett),
        mul_mod(
            weighted_source[3][lane],
            matrix1,
            modulus,
            barrett),
        modulus);

    const GpuWord root = roots[table_limb * degree + 1];
    const GpuWord twisted_right = mul_mod(right, root, modulus, barrett);
    const std::size_t value_base = value_limb * degree;
    values[value_base + coefficient_pair] =
        add_mod(left, twisted_right, modulus);
    values[value_base + coefficient_pair + butterflies_per_limb] =
        sub_mod(left, twisted_right, modulus);
}

__global__ void hybrid_modup_qp_forward_ntt_first_stage_row_tiled8_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree)
{
    constexpr std::size_t kSourceLimbCount = 2;
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kSourcePlanes = 4;
    constexpr std::size_t kTargetRows = 8;
    __shared__ GpuWord weighted_source[kSourcePlanes][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t row = threadIdx.y;
    const std::size_t butterflies_per_limb = degree >> 1;
    const std::size_t coefficient_pair =
        blockIdx.x * kCoefficientTile + lane;
    const bool valid_coefficient =
        coefficient_pair < butterflies_per_limb;

    if (row < kSourcePlanes)
    {
        const std::size_t source_col = row >> 1;
        const std::size_t coefficient_side = row & 1;
        GpuWord weighted = 0;
        if (valid_coefficient)
        {
            const std::size_t source_q_limb =
                decomp_limb_begin + source_col;
            const std::size_t source_coeff =
                coefficient_pair + coefficient_side * butterflies_per_limb;
            const GpuWord source_modulus = rns_primes[source_q_limb];
            const GpuWide source_barrett =
                rns_modulus_constants[source_q_limb];
            const GpuWord inv_punctured =
                qi_inv_punctured[
                    decomp_index * base_p_size + source_col];
            const GpuWord source_value =
                c2_coeff[source_q_limb * degree + source_coeff];
            weighted = inv_punctured == 1
                ? source_value
                : mul_mod(
                      source_value,
                      inv_punctured,
                      source_modulus,
                      source_barrett);
        }
        weighted_source[row][lane] = weighted;
    }
    __syncthreads();

    const std::size_t active_q_count =
        base_q_size - kSourceLimbCount;
    const std::size_t active_limb_count =
        active_q_count + base_p_size;
    const std::size_t active_limb =
        blockIdx.y * kTargetRows + row;
    if (!valid_coefficient || active_limb >= active_limb_count)
    {
        return;
    }

    GpuWord *values = modup_q;
    const GpuWord *conversion_matrix = q_matrices;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;
    std::size_t matrix_row_limb = active_limb;
    std::size_t matrix_offset = q_matrix_offsets[decomp_index];

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + kSourceLimbCount;
            table_limb = value_limb;
            matrix_row_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        conversion_matrix = p_matrices;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
        matrix_row_limb = p_limb;
        matrix_offset = p_matrix_offsets[decomp_index];
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const std::size_t matrix_row_offset =
        matrix_offset + matrix_row_limb * base_p_size;
    const GpuWord matrix0 = conversion_matrix[matrix_row_offset];
    const GpuWord matrix1 = conversion_matrix[matrix_row_offset + 1];

    const GpuWord left = add_mod(
        mul_mod(
            weighted_source[0][lane],
            matrix0,
            modulus,
            barrett),
        mul_mod(
            weighted_source[2][lane],
            matrix1,
            modulus,
            barrett),
        modulus);
    const GpuWord right = add_mod(
        mul_mod(
            weighted_source[1][lane],
            matrix0,
            modulus,
            barrett),
        mul_mod(
            weighted_source[3][lane],
            matrix1,
            modulus,
            barrett),
        modulus);

    const GpuWord root = roots[table_limb * degree + 1];
    const GpuWord twisted_right = mul_mod(right, root, modulus, barrett);
    const std::size_t value_base = value_limb * degree;
    values[value_base + coefficient_pair] =
        add_mod(left, twisted_right, modulus);
    values[value_base + coefficient_pair + butterflies_per_limb] =
        sub_mod(left, twisted_right, modulus);
}

__global__ void hybrid_modup_qp_row_tiled8_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree)
{
    constexpr std::size_t kSourceLimbCount = 2;
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kSourcePlanes = 4;
    constexpr std::size_t kTargetRows = 8;
    __shared__ GpuWord weighted_source[kSourcePlanes][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t row = threadIdx.y;
    const std::size_t coefficients_per_half = degree >> 1;
    const std::size_t coefficient_pair =
        blockIdx.x * kCoefficientTile + lane;
    const bool valid_coefficient =
        coefficient_pair < coefficients_per_half;

    if (row < kSourcePlanes)
    {
        const std::size_t source_col = row >> 1;
        const std::size_t coefficient_side = row & 1;
        GpuWord weighted = 0;
        if (valid_coefficient)
        {
            const std::size_t source_q_limb =
                decomp_limb_begin + source_col;
            const std::size_t source_coeff =
                coefficient_pair + coefficient_side * coefficients_per_half;
            const GpuWord source_modulus = rns_primes[source_q_limb];
            const GpuWide source_barrett =
                rns_modulus_constants[source_q_limb];
            const GpuWord inv_punctured =
                qi_inv_punctured[
                    decomp_index * base_p_size + source_col];
            const GpuWord source_value =
                c2_coeff[source_q_limb * degree + source_coeff];
            weighted = inv_punctured == 1
                ? source_value
                : mul_mod(
                      source_value,
                      inv_punctured,
                      source_modulus,
                      source_barrett);
        }
        weighted_source[row][lane] = weighted;
    }
    __syncthreads();

    const std::size_t active_q_count =
        base_q_size - kSourceLimbCount;
    const std::size_t active_limb_count =
        active_q_count + base_p_size;
    const std::size_t active_limb =
        blockIdx.y * kTargetRows + row;
    if (!valid_coefficient || active_limb >= active_limb_count)
    {
        return;
    }

    GpuWord *values = modup_q;
    const GpuWord *conversion_matrix = q_matrices;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;
    std::size_t matrix_row_limb = active_limb;
    std::size_t matrix_offset = q_matrix_offsets[decomp_index];

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + kSourceLimbCount;
            table_limb = value_limb;
            matrix_row_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        conversion_matrix = p_matrices;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
        matrix_row_limb = p_limb;
        matrix_offset = p_matrix_offsets[decomp_index];
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const std::size_t matrix_row_offset =
        matrix_offset + matrix_row_limb * base_p_size;
    const GpuWord matrix0 = conversion_matrix[matrix_row_offset];
    const GpuWord matrix1 = conversion_matrix[matrix_row_offset + 1];

    const GpuWord left = add_mod(
        mul_mod(
            weighted_source[0][lane],
            matrix0,
            modulus,
            barrett),
        mul_mod(
            weighted_source[2][lane],
            matrix1,
            modulus,
            barrett),
        modulus);
    const GpuWord right = add_mod(
        mul_mod(
            weighted_source[1][lane],
            matrix0,
            modulus,
            barrett),
        mul_mod(
            weighted_source[3][lane],
            matrix1,
            modulus,
            barrett),
        modulus);

    const std::size_t value_base = value_limb * degree;
    values[value_base + coefficient_pair] = left;
    values[value_base + coefficient_pair + coefficients_per_half] = right;
}

template <int FixedSourceLimbCount>
__global__ void hybrid_preweight_modup_source_p9_kernel(
    GpuWord *weighted_source,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t base_p_size,
    std::size_t degree)
{
    static_assert(
        FixedSourceLimbCount >= 1 && FixedSourceLimbCount <= 9,
        "P=9 compact ModUp preweight supports one through nine source limbs");
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = FixedSourceLimbCount * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t source_col = tid / degree;
    const std::size_t coefficient = tid - source_col * degree;
    const std::size_t source_limb = decomp_limb_begin + source_col;
    GpuWord value = c2_coeff[source_limb * degree + coefficient];
    if constexpr (FixedSourceLimbCount > 1)
    {
        const GpuWord inv_punctured = qi_inv_punctured[
            decomp_index * base_p_size + source_col];
        if (inv_punctured != 1)
        {
            value = mul_mod(
                value,
                inv_punctured,
                rns_primes[source_limb],
                rns_modulus_constants[source_limb]);
        }
    }
    weighted_source[tid] = value;
}

template <int FixedSourceLimbCount>
__global__ void hybrid_modup_qp_p9_row_tiled8_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *q_matrix_offsets,
    const GpuWord *q_matrices,
    const GpuWord *p_matrix_offsets,
    const GpuWord *p_matrices,
    const GpuWord *qi_inv_punctured,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree)
{
    static_assert(
        FixedSourceLimbCount >= 1 && FixedSourceLimbCount <= 9,
        "P=9 row-tiled ModUp supports one through nine source limbs");
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kSourcePlanes = FixedSourceLimbCount * 2;
    constexpr std::size_t kTargetRows = 8;
    constexpr std::size_t kBlockThreads =
        kCoefficientTile * kTargetRows;
    __shared__ GpuWord weighted_source[kSourcePlanes][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t row = threadIdx.y;
    const std::size_t linear_thread =
        row * kCoefficientTile + lane;
    const std::size_t coefficients_per_half = degree >> 1;

    for (std::size_t source_index = linear_thread;
         source_index < kSourcePlanes * kCoefficientTile;
         source_index += kBlockThreads)
    {
        const std::size_t source_plane =
            source_index / kCoefficientTile;
        const std::size_t source_lane =
            source_index % kCoefficientTile;
        const std::size_t source_col = source_plane >> 1;
        const std::size_t coefficient_side = source_plane & 1;
        const std::size_t coefficient_pair =
            blockIdx.x * kCoefficientTile + source_lane;
        GpuWord weighted = 0;
        if (coefficient_pair < coefficients_per_half)
        {
            const std::size_t source_q_limb =
                decomp_limb_begin + source_col;
            const std::size_t source_coeff = coefficient_pair +
                coefficient_side * coefficients_per_half;
            const GpuWord source_modulus = rns_primes[source_q_limb];
            const GpuWide source_barrett =
                rns_modulus_constants[source_q_limb];
            const GpuWord inv_punctured = qi_inv_punctured[
                decomp_index * base_p_size + source_col];
            weighted = c2_coeff[
                source_q_limb * degree + source_coeff];
            if constexpr (FixedSourceLimbCount > 1)
            {
                if (inv_punctured != 1)
                {
                    weighted = mul_mod(
                        weighted,
                        inv_punctured,
                        source_modulus,
                        source_barrett);
                }
            }
        }
        weighted_source[source_plane][source_lane] = weighted;
    }
    __syncthreads();

    const std::size_t coefficient_pair =
        blockIdx.x * kCoefficientTile + lane;
    const std::size_t active_q_count =
        base_q_size - FixedSourceLimbCount;
    const std::size_t active_limb_count =
        active_q_count + base_p_size;
    const std::size_t active_limb =
        blockIdx.y * kTargetRows + row;
    if (coefficient_pair >= coefficients_per_half ||
        active_limb >= active_limb_count)
    {
        return;
    }

    GpuWord *values = modup_q;
    const GpuWord *conversion_matrix = q_matrices;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;
    std::size_t matrix_row_limb = active_limb;
    std::size_t matrix_offset = q_matrix_offsets[decomp_index];
    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + FixedSourceLimbCount;
            table_limb = value_limb;
            matrix_row_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        conversion_matrix = p_matrices;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
        matrix_row_limb = p_limb;
        matrix_offset = p_matrix_offsets[decomp_index];
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const std::size_t matrix_row_offset =
        matrix_offset + matrix_row_limb * base_p_size;
    GpuWord left = 0;
    GpuWord right = 0;
    if constexpr (FixedSourceLimbCount == 1)
    {
        left = reduce_to_modulus(
            weighted_source[0][lane],
            modulus,
            barrett);
        right = reduce_to_modulus(
            weighted_source[1][lane],
            modulus,
            barrett);
    }
    else
    {
#pragma unroll
        for (std::size_t source_col = 0;
             source_col < FixedSourceLimbCount;
             ++source_col)
        {
            const GpuWord matrix_value =
                conversion_matrix[matrix_row_offset + source_col];
            left = add_mod(
                left,
                mul_mod(
                    weighted_source[source_col * 2][lane],
                    matrix_value,
                    modulus,
                    barrett),
                modulus);
            right = add_mod(
                right,
                mul_mod(
                    weighted_source[source_col * 2 + 1][lane],
                    matrix_value,
                    modulus,
                    barrett),
                modulus);
        }
    }

    const std::size_t value_base = value_limb * degree;
    values[value_base + coefficient_pair] = left;
    values[value_base + coefficient_pair + coefficients_per_half] = right;
}

__global__ void hybrid_forward_ntt_modup_qp_stage_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    std::size_t m,
    std::size_t gap)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t butterflies_per_limb = degree >> 1;
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t active_limb_count = active_q_count + base_p_size;
    const std::size_t total = active_limb_count * butterflies_per_limb;
    if (tid >= total)
    {
        return;
    }

    const std::size_t active_limb = tid / butterflies_per_limb;
    const std::size_t local_butterfly = tid % butterflies_per_limb;
    const std::size_t group = local_butterfly / gap;
    const std::size_t j = local_butterfly % gap;

    GpuWord *values = modup_q;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + decomp_limb_count;
            table_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
    }

    const std::size_t x_index =
        value_limb * degree + group * (gap << 1) + j;
    const std::size_t y_index = x_index + gap;

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
    const GpuWord root = roots[table_limb * degree + m + group];

    const GpuWord u = values[x_index];
    const GpuWord v = mul_mod(values[y_index], root, modulus, barrett_ratio);

    values[x_index] = add_mod(u, v, modulus);
    values[y_index] = sub_mod(u, v, modulus);
}

template <int FusionStages>
__global__ void hybrid_forward_ntt_modup_qp_fused_stage_kernel(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    std::size_t m,
    std::size_t gap)
{
    static_assert(
        FusionStages >= 2 && FusionStages <= 3,
        "HYBRID QP NTT fusion supports 2-3 stages");

    constexpr std::size_t kLocalSize =
        static_cast<std::size_t>(1) << FusionStages;

    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t tiles_per_limb = degree >> FusionStages;
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t active_limb_count = active_q_count + base_p_size;
    const std::size_t total = active_limb_count * tiles_per_limb;
    if (tid >= total)
    {
        return;
    }

    const std::size_t active_limb = tid / tiles_per_limb;
    const std::size_t local_tile = tid % tiles_per_limb;

    GpuWord *values = modup_q;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + decomp_limb_count;
            table_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
    }

    const std::size_t final_gap = gap >> (FusionStages - 1);
    const std::size_t outer_group = local_tile / final_gap;
    const std::size_t j = local_tile % final_gap;
    const std::size_t base_index =
        value_limb * degree + outer_group * (gap << 1) + j;

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
    const GpuWord *limb_roots = roots + table_limb * degree;

    GpuWord local[kLocalSize];
#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        local[i] = values[base_index + i * final_gap];
    }

#pragma unroll
    for (int stage = 0; stage < FusionStages; ++stage)
    {
        const std::size_t local_stride =
            static_cast<std::size_t>(1) << (FusionStages - 1 - stage);
        const std::size_t stage_m = m << stage;
        const std::size_t stage_group_base = outer_group << stage;

#pragma unroll
        for (std::size_t block = 0; block < kLocalSize;
             block += (local_stride << 1))
        {
            const std::size_t block_group =
                block / (local_stride << 1);
            const GpuWord root =
                limb_roots[stage_m + stage_group_base + block_group];

#pragma unroll
            for (std::size_t offset = 0; offset < local_stride; ++offset)
            {
                const GpuWord u = local[block + offset];
                const GpuWord v = mul_mod(
                    local[block + offset + local_stride],
                    root,
                    modulus,
                    barrett_ratio);
                local[block + offset] = add_mod(u, v, modulus);
                local[block + offset + local_stride] =
                    sub_mod(u, v, modulus);
            }
        }
    }

#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        values[base_index + i * final_gap] = local[i];
    }
}

__device__ __forceinline__ void hybrid_accumulate_two_products(
    GpuWord *accum0,
    GpuWord *accum1,
    GpuWord value,
    GpuWord key0,
    GpuWord key1,
    GpuWord modulus,
    GpuWide barrett_ratio,
    bool overwrite_accum)
{
    const GpuWord product0 =
        mul_mod(value, key0, modulus, barrett_ratio);
    const GpuWord product1 =
        mul_mod(value, key1, modulus, barrett_ratio);

    if (overwrite_accum)
    {
        *accum0 = product0;
        *accum1 = product1;
        return;
    }

    *accum0 = add_mod(*accum0, product0, modulus);
    *accum1 = add_mod(*accum1, product1, modulus);
}

template <int FusionStages>
__global__ void
hybrid_forward_ntt_modup_qp_final_mul_accumulate_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    std::size_t m,
    std::size_t gap,
    bool overwrite_accum)
{
    static_assert(
        FusionStages >= 1 && FusionStages <= 3,
        "HYBRID final QP NTT/IP fusion supports 1-3 stages");

    constexpr std::size_t kLocalSize =
        static_cast<std::size_t>(1) << FusionStages;

    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t tiles_per_limb = degree >> FusionStages;
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t active_limb_count = active_q_count + base_p_size;
    const std::size_t total = active_limb_count * tiles_per_limb;
    if (tid >= total)
    {
        return;
    }

    const std::size_t active_limb = tid / tiles_per_limb;
    const std::size_t local_tile = tid % tiles_per_limb;

    GpuWord *values = modup_q;
    GpuWord *accum0 = accum_q0;
    GpuWord *accum1 = accum_q1;
    std::size_t value_limb = active_limb;
    std::size_t table_limb = active_limb;
    const GpuWord *key0 = key_q0;
    const GpuWord *key1 = key_q1;

    if (active_limb < active_q_count)
    {
        if (active_limb >= decomp_limb_begin)
        {
            value_limb = active_limb + decomp_limb_count;
            table_limb = value_limb;
        }
    }
    else
    {
        const std::size_t p_limb = active_limb - active_q_count;
        values = modup_p;
        accum0 = accum_p0;
        accum1 = accum_p1;
        value_limb = p_limb;
        table_limb = base_q_size + p_limb;
        key0 = key_p0;
        key1 = key_p1;
    }

    const std::size_t final_gap = gap >> (FusionStages - 1);
    const std::size_t outer_group = local_tile / final_gap;
    const std::size_t j = local_tile % final_gap;
    const std::size_t base_index =
        value_limb * degree + outer_group * (gap << 1) + j;

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
    const GpuWord *limb_roots = roots + table_limb * degree;

    GpuWord local[kLocalSize];
#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        local[i] = values[base_index + i * final_gap];
    }

#pragma unroll
    for (int stage = 0; stage < FusionStages; ++stage)
    {
        const std::size_t local_stride =
            static_cast<std::size_t>(1) << (FusionStages - 1 - stage);
        const std::size_t stage_m = m << stage;
        const std::size_t stage_group_base = outer_group << stage;

#pragma unroll
        for (std::size_t block = 0; block < kLocalSize;
             block += (local_stride << 1))
        {
            const std::size_t block_group =
                block / (local_stride << 1);
            const GpuWord root =
                limb_roots[stage_m + stage_group_base + block_group];

#pragma unroll
            for (std::size_t offset = 0; offset < local_stride; ++offset)
            {
                const GpuWord u = local[block + offset];
                const GpuWord v = mul_mod(
                    local[block + offset + local_stride],
                    root,
                    modulus,
                    barrett_ratio);
                local[block + offset] = add_mod(u, v, modulus);
                local[block + offset + local_stride] =
                    sub_mod(u, v, modulus);
            }
        }
    }

#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        const std::size_t local_offset = base_index + i * final_gap;
        hybrid_accumulate_two_products(
            accum0 + local_offset,
            accum1 + local_offset,
            local[i],
            key0[local_offset],
            key1[local_offset],
            modulus,
            barrett_ratio,
            overwrite_accum);
    }
}

template <int FusionStages>
__global__ void
hybrid_forward_ntt_modup_qp_final_mul_accumulate_fused_decomp_q_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power,
    std::size_t m,
    std::size_t gap,
    bool overwrite_accum)
{
    static_assert(
        FusionStages >= 1 && FusionStages <= 3,
        "HYBRID final QP NTT/IP fusion supports 1-3 stages");

    constexpr std::size_t kLocalSize =
        static_cast<std::size_t>(1) << FusionStages;

    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t tiles_per_limb = degree >> FusionStages;
    const std::size_t active_q_count = base_q_size - decomp_limb_count;
    const std::size_t active_limb_count = active_q_count + base_p_size;
    const std::size_t total = active_limb_count * tiles_per_limb;
    const std::size_t decomp_total = decomp_limb_count * degree;
    if (tid >= total + decomp_total)
    {
        return;
    }

    /* Append the skipped Q coefficients as scalar tasks in the same launch. */
    if (tid >= total)
    {
        const std::size_t decomp_tid = tid - total;
        const std::size_t offset =
            decomp_limb_begin * degree + decomp_tid;
        const std::size_t q_limb = offset >> degree_power;
        const GpuWord decomp_modulus = rns_primes[q_limb];
        const GpuWide decomp_barrett = rns_modulus_constants[q_limb];

        hybrid_accumulate_two_products(
            accum_q0 + offset,
            accum_q1 + offset,
            c2_ntt[offset],
            key_q0[offset],
            key_q1[offset],
            decomp_modulus,
            decomp_barrett,
            overwrite_accum);
        return;
    }

    {
        const std::size_t active_limb = tid / tiles_per_limb;
        const std::size_t local_tile = tid % tiles_per_limb;

        GpuWord *values = modup_q;
        GpuWord *accum0 = accum_q0;
        GpuWord *accum1 = accum_q1;
        std::size_t value_limb = active_limb;
        std::size_t table_limb = active_limb;
        const GpuWord *key0 = key_q0;
        const GpuWord *key1 = key_q1;

        if (active_limb < active_q_count)
        {
            if (active_limb >= decomp_limb_begin)
            {
                value_limb = active_limb + decomp_limb_count;
                table_limb = value_limb;
            }
        }
        else
        {
            const std::size_t p_limb = active_limb - active_q_count;
            values = modup_p;
            accum0 = accum_p0;
            accum1 = accum_p1;
            value_limb = p_limb;
            table_limb = base_q_size + p_limb;
            key0 = key_p0;
            key1 = key_p1;
        }

        const std::size_t final_gap = gap >> (FusionStages - 1);
        const std::size_t outer_group = local_tile / final_gap;
        const std::size_t j = local_tile % final_gap;
        const std::size_t base_index =
            value_limb * degree + outer_group * (gap << 1) + j;

        const GpuWord modulus = rns_primes[table_limb];
        const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
        const GpuWord *limb_roots = roots + table_limb * degree;

        GpuWord local[kLocalSize];
#pragma unroll
        for (std::size_t i = 0; i < kLocalSize; ++i)
        {
            local[i] = values[base_index + i * final_gap];
        }

#pragma unroll
        for (int stage = 0; stage < FusionStages; ++stage)
        {
            const std::size_t local_stride =
                static_cast<std::size_t>(1) << (FusionStages - 1 - stage);
            const std::size_t stage_m = m << stage;
            const std::size_t stage_group_base = outer_group << stage;

#pragma unroll
            for (std::size_t block = 0; block < kLocalSize;
                 block += (local_stride << 1))
            {
                const std::size_t block_group =
                    block / (local_stride << 1);
                const GpuWord root =
                    limb_roots[stage_m + stage_group_base + block_group];

#pragma unroll
                for (std::size_t offset = 0; offset < local_stride; ++offset)
                {
                    const GpuWord u = local[block + offset];
                    const GpuWord v = mul_mod(
                        local[block + offset + local_stride],
                        root,
                        modulus,
                        barrett_ratio);
                    local[block + offset] = add_mod(u, v, modulus);
                    local[block + offset + local_stride] =
                        sub_mod(u, v, modulus);
                }
            }
        }

#pragma unroll
        for (std::size_t i = 0; i < kLocalSize; ++i)
        {
            const std::size_t local_offset = base_index + i * final_gap;
            hybrid_accumulate_two_products(
                accum0 + local_offset,
                accum1 + local_offset,
                local[i],
                key0[local_offset],
                key1[local_offset],
                modulus,
                barrett_ratio,
                overwrite_accum);
        }
    }

}

__global__ void hybrid_decomp_q_multiply_accumulate_two_components_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_q1,
    const GpuWord *c2_ntt,
    const GpuWord *key_qp0,
    const GpuWord *key_qp1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    std::size_t degree,
    unsigned int degree_power,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    bool overwrite_accum)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = decomp_limb_count * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t local_limb = tid >> degree_power;
    const std::size_t coeff = tid & (degree - 1);
    const std::size_t q_limb = decomp_limb_begin + local_limb;
    const std::size_t offset = q_limb * degree + coeff;
    const GpuWord modulus = rns_primes[q_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[q_limb];

    hybrid_accumulate_two_products(
        accum_q0 + offset,
        accum_q1 + offset,
        c2_ntt[offset],
        key_qp0[offset],
        key_qp1[offset],
        modulus,
        barrett_ratio,
        overwrite_accum);
}

#if 0
/* Retired all-dnum PAccum experiments. */
__global__ void hybrid_paccum_all_dnum_two_components_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *all_modup_q,
    const GpuWord *all_modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *const *key_qp0_by_dnum,
    const GpuWord *const *key_qp1_by_dnum,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    std::size_t decomp_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t q_word_count = base_q_size * degree;
    const std::size_t p_word_count = base_p_size * degree;
    const std::size_t total = q_word_count + p_word_count;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= total)
    {
        return;
    }

    const bool p_limb = tid >= q_word_count;
    const std::size_t local_offset = p_limb ? tid - q_word_count : tid;
    const std::size_t local_limb = local_offset >> degree_power;
    const std::size_t table_limb = p_limb
        ? base_q_size + local_limb
        : local_limb;
    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];

    GpuWord acc0 = 0;
    GpuWord acc1 = 0;

    for (std::size_t decomp_index = 0;
         decomp_index < decomp_count;
         ++decomp_index)
    {
        const GpuWord *key_qp0 = key_qp0_by_dnum[decomp_index];
        const GpuWord *key_qp1 = key_qp1_by_dnum[decomp_index];
        GpuWord value = 0;
        std::size_t key_offset = 0;

        if (p_limb)
        {
            value =
                all_modup_p[decomp_index * p_word_count + local_offset];
            key_offset = q_word_count + local_offset;
        }
        else
        {
            const std::size_t decomp_limb_begin =
                decomp_index * base_p_size;
            const std::size_t remaining_q =
                base_q_size - decomp_limb_begin;
            const std::size_t decomp_limb_count =
                remaining_q < base_p_size ? remaining_q : base_p_size;
            const bool reuse_c2_ntt =
                local_limb >= decomp_limb_begin &&
                local_limb < decomp_limb_begin + decomp_limb_count;
            value = reuse_c2_ntt
                ? c2_ntt[local_offset]
                : all_modup_q[decomp_index * q_word_count + local_offset];
            key_offset = local_offset;
        }

        const GpuWord product0 =
            mul_mod(value, key_qp0[key_offset], modulus, barrett_ratio);
        const GpuWord product1 =
            mul_mod(value, key_qp1[key_offset], modulus, barrett_ratio);
        acc0 = add_mod(acc0, product0, modulus);
        acc1 = add_mod(acc1, product1, modulus);
    }

    if (p_limb)
    {
        accum_p0[local_offset] = acc0;
        accum_p1[local_offset] = acc1;
    }
    else
    {
        accum_q0[local_offset] = acc0;
        accum_q1[local_offset] = acc1;
    }
}

__global__ __launch_bounds__(256, 4)
void hybrid_final_ntt_paccum_all_dnum_two_components_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *all_modup_q,
    const GpuWord *all_modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *const *key_qp0_by_dnum,
    const GpuWord *const *key_qp1_by_dnum,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    std::size_t decomp_count,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree)
{
    constexpr std::size_t kFinalStages = 3;
    constexpr std::size_t kLocalSize = 1U << kFinalStages;

    const std::size_t tiles_per_limb = degree >> kFinalStages;
    const std::size_t total_limb_count = base_q_size + base_p_size;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= total_limb_count * tiles_per_limb)
    {
        return;
    }

    const std::size_t table_limb = tid / tiles_per_limb;
    const std::size_t local_limb = table_limb < base_q_size
        ? table_limb
        : table_limb - base_q_size;
    const std::size_t local_tile = tid % tiles_per_limb;
    const std::size_t local_base =
        local_limb * degree + local_tile * kLocalSize;
    const std::size_t q_word_count = base_q_size * degree;
    const std::size_t p_word_count = base_p_size * degree;
    const bool p_limb = table_limb >= base_q_size;

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
    const GpuWord *limb_roots = roots + table_limb * degree;

    GpuWord acc0[kLocalSize] = {0};
    GpuWord acc1[kLocalSize] = {0};

    for (std::size_t decomp_index = 0;
         decomp_index < decomp_count;
         ++decomp_index)
    {
        const std::size_t decomp_limb_begin =
            decomp_index * base_p_size;
        const std::size_t remaining_q =
            base_q_size - decomp_limb_begin;
        const std::size_t decomp_limb_count =
            remaining_q < base_p_size ? remaining_q : base_p_size;
        const bool reuse_c2_ntt =
            !p_limb &&
            local_limb >= decomp_limb_begin &&
            local_limb < decomp_limb_begin + decomp_limb_count;

        GpuWord local[kLocalSize];
        const GpuWord *partial = p_limb
            ? all_modup_p + decomp_index * p_word_count
            : all_modup_q + decomp_index * q_word_count;
#pragma unroll
        for (std::size_t i = 0; i < kLocalSize; ++i)
        {
            local[i] = reuse_c2_ntt
                ? c2_ntt[local_base + i]
                : partial[local_base + i];
        }

        if (!reuse_c2_ntt)
        {
#pragma unroll
            for (std::size_t stage = 0; stage < kFinalStages; ++stage)
            {
                const std::size_t local_stride =
                    static_cast<std::size_t>(1)
                    << (kFinalStages - 1 - stage);
                const std::size_t stage_m =
                    (degree >> kFinalStages) << stage;
                const std::size_t stage_group_base =
                    local_tile << stage;

#pragma unroll
                for (std::size_t block = 0; block < kLocalSize;
                     block += (local_stride << 1))
                {
                    const std::size_t block_group =
                        block / (local_stride << 1);
                    const GpuWord root =
                        limb_roots[
                            stage_m + stage_group_base + block_group];

#pragma unroll
                    for (std::size_t offset = 0;
                         offset < local_stride;
                         ++offset)
                    {
                        const GpuWord u = local[block + offset];
                        const GpuWord v = mul_mod(
                            local[block + offset + local_stride],
                            root,
                            modulus,
                            barrett_ratio);
                        local[block + offset] = add_mod(u, v, modulus);
                        local[block + offset + local_stride] =
                            sub_mod(u, v, modulus);
                    }
                }
            }
        }

        const GpuWord *key_qp0 = key_qp0_by_dnum[decomp_index];
        const GpuWord *key_qp1 = key_qp1_by_dnum[decomp_index];
        const std::size_t key_base = p_limb
            ? q_word_count + local_base
            : local_base;
#pragma unroll
        for (std::size_t i = 0; i < kLocalSize; ++i)
        {
            acc0[i] = add_mod(
                acc0[i],
                mul_mod(
                    local[i],
                    key_qp0[key_base + i],
                    modulus,
                    barrett_ratio),
                modulus);
            acc1[i] = add_mod(
                acc1[i],
                mul_mod(
                    local[i],
                    key_qp1[key_base + i],
                    modulus,
                    barrett_ratio),
                modulus);
        }
    }

    GpuWord *output0 = p_limb ? accum_p0 : accum_q0;
    GpuWord *output1 = p_limb ? accum_p1 : accum_q1;
#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        output0[local_base + i] = acc0[i];
        output1[local_base + i] = acc1[i];
    }
}
#endif

__global__ void hybrid_multiply_accumulate_kernel(
    GpuWord *accum_q,
    GpuWord *accum_p,
    const GpuWord *modup_q,
    const GpuWord *modup_p,
    const GpuWord *key_qp,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t q_word_count = base_q_size * degree;
    const std::size_t p_word_count = base_p_size * degree;
    const std::size_t total = q_word_count + p_word_count;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= total)
    {
        return;
    }

    GpuWord *accum = accum_q;
    const GpuWord *modup = modup_q;
    std::size_t local_offset = tid;
    std::size_t table_limb = tid >> degree_power;
    std::size_t key_offset = tid;

    if (tid >= q_word_count)
    {
        local_offset = tid - q_word_count;
        accum = accum_p;
        modup = modup_p;
        table_limb = base_q_size + (local_offset >> degree_power);
        key_offset = q_word_count + local_offset;
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
    const GpuWord product = mul_mod(
        modup[local_offset],
        key_qp[key_offset],
        modulus,
        barrett_ratio);
    accum[local_offset] =
        add_mod(accum[local_offset], product, modulus);
}

__global__ void hybrid_multiply_accumulate_two_components_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *modup_q,
    const GpuWord *modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    bool overwrite_accum)
{
    const std::size_t q_word_count = base_q_size * degree;
    const std::size_t p_word_count = base_p_size * degree;
    const std::size_t total = q_word_count + p_word_count;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= total)
    {
        return;
    }

    GpuWord *accum0 = accum_q0;
    GpuWord *accum1 = accum_q1;
    const GpuWord *modup = modup_q;
    std::size_t local_offset = tid;
    std::size_t table_limb = tid >> degree_power;
    const GpuWord *key0 = key_q0;
    const GpuWord *key1 = key_q1;

    if (tid >= q_word_count)
    {
        local_offset = tid - q_word_count;
        accum0 = accum_p0;
        accum1 = accum_p1;
        modup = modup_p;
        table_limb = base_q_size + (local_offset >> degree_power);
        key0 = key_p0;
        key1 = key_p1;
    }

    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett_ratio = rns_modulus_constants[table_limb];
    const bool reuse_c2_ntt =
        tid < q_word_count &&
        table_limb >= decomp_limb_begin &&
        table_limb < decomp_limb_begin + decomp_limb_count;
    const GpuWord value =
        reuse_c2_ntt ? c2_ntt[local_offset] : modup[local_offset];
    const GpuWord product0 = mul_mod(
        value,
        key0[local_offset],
        modulus,
        barrett_ratio);
    const GpuWord product1 = mul_mod(
        value,
        key1[local_offset],
        modulus,
        barrett_ratio);

    if (overwrite_accum)
    {
        accum0[local_offset] = product0;
        accum1[local_offset] = product1;
        return;
    }

    accum0[local_offset] =
        add_mod(accum0[local_offset], product0, modulus);
    accum1[local_offset] =
        add_mod(accum1[local_offset], product1, modulus);
}

__global__ void hybrid_moddown_kernel(
    GpuWord *accum_q,
    const GpuWord *accum_p,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    const GpuWord *inv_p_mod_q,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = base_q_size * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t q_limb = tid >> degree_power;
    const std::size_t coeff = tid & (degree - 1);
    const GpuWord q_modulus = rns_primes[q_limb];
    const GpuWide q_barrett = rns_modulus_constants[q_limb];
    GpuWord converted_p = 0;

    for (std::size_t p_limb = 0; p_limb < base_p_size; ++p_limb)
    {
        const std::size_t p_table_limb = base_q_size + p_limb;
        const GpuWord p_value =
            accum_p[p_limb * degree + coeff];
        const GpuWord p_modulus = rns_primes[p_table_limb];
        const GpuWide p_barrett =
            rns_modulus_constants[p_table_limb];
        const GpuWord weighted = p_inv_punctured[p_limb] == 1
            ? p_value
            : mul_mod(
                  p_value,
                  p_inv_punctured[p_limb],
                  p_modulus,
                  p_barrett);
        const GpuWord matrix_value =
            moddown_p_to_q_matrix[q_limb * base_p_size + p_limb];
        const GpuWord product =
            mul_mod(weighted, matrix_value, q_modulus, q_barrett);
        converted_p = add_mod(converted_p, product, q_modulus);
    }

    const GpuWord difference =
        sub_mod(accum_q[tid], converted_p, q_modulus);
    accum_q[tid] = mul_mod(
        difference,
        inv_p_mod_q[q_limb],
        q_modulus,
        q_barrett);
}

__global__ void hybrid_convert_p_to_q_two_components_kernel(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = base_q_size * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t q_limb = tid >> degree_power;
    const std::size_t coeff = tid & (degree - 1);
    const GpuWord q_modulus = rns_primes[q_limb];
    const GpuWide q_barrett = rns_modulus_constants[q_limb];
    GpuWord sum0 = 0;
    GpuWord sum1 = 0;

    std::size_t p_limb = 0;
    for (; p_limb + 1 < base_p_size; p_limb += 2)
    {
        hybrid_convert_p_to_q_contribution(
            sum0,
            sum1,
            accum_p0,
            accum_p1,
            rns_primes,
            rns_modulus_constants,
            moddown_p_to_q_matrix,
            p_inv_punctured,
            base_q_size,
            base_p_size,
            q_limb,
            p_limb,
            coeff,
            degree,
            q_modulus,
            q_barrett);
        hybrid_convert_p_to_q_contribution(
            sum0,
            sum1,
            accum_p0,
            accum_p1,
            rns_primes,
            rns_modulus_constants,
            moddown_p_to_q_matrix,
            p_inv_punctured,
            base_q_size,
            base_p_size,
            q_limb,
            p_limb + 1,
            coeff,
            degree,
            q_modulus,
            q_barrett);
    }
    for (; p_limb < base_p_size; ++p_limb)
    {
        hybrid_convert_p_to_q_contribution(
            sum0,
            sum1,
            accum_p0,
            accum_p1,
            rns_primes,
            rns_modulus_constants,
            moddown_p_to_q_matrix,
            p_inv_punctured,
            base_q_size,
            base_p_size,
            q_limb,
            p_limb,
            coeff,
            degree,
            q_modulus,
            q_barrett);
    }

    converted_q0[tid] = sum0;
    converted_q1[tid] = sum1;
}

template <int FixedPCount, bool SourcePreweighted>
__global__ void hybrid_convert_p_to_q_forward_ntt_first_stage_kernel(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t butterflies_per_limb = degree >> 1;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = base_q_size * butterflies_per_limb;
    if (tid >= total)
    {
        return;
    }

    const std::size_t q_limb = tid >> (degree_power - 1);
    const std::size_t left_coeff = tid & (butterflies_per_limb - 1);
    const std::size_t right_coeff = left_coeff + butterflies_per_limb;
    const GpuWord q_modulus = rns_primes[q_limb];
    const GpuWide q_barrett = rns_modulus_constants[q_limb];

    GpuWord left0;
    GpuWord right0;
    GpuWord left1;
    GpuWord right1;
    hybrid_convert_p_to_q_pair<FixedPCount, SourcePreweighted>(
        left0,
        right0,
        left1,
        right1,
        accum_p0,
        accum_p1,
        rns_primes,
        rns_modulus_constants,
        moddown_p_to_q_matrix,
        p_inv_punctured,
        base_q_size,
        base_p_size,
        q_limb,
        left_coeff,
        right_coeff,
        degree,
        q_modulus,
        q_barrett);

    const GpuWord root = roots[q_limb * degree + 1];
    const std::size_t q_base = q_limb * degree;

    const GpuWord twisted_right0 =
        mul_mod(right0, root, q_modulus, q_barrett);
    converted_q0[q_base + left_coeff] =
        add_mod(left0, twisted_right0, q_modulus);
    converted_q0[q_base + right_coeff] =
        sub_mod(left0, twisted_right0, q_modulus);

    const GpuWord twisted_right1 =
        mul_mod(right1, root, q_modulus, q_barrett);
    converted_q1[q_base + left_coeff] =
        add_mod(left1, twisted_right1, q_modulus);
    converted_q1[q_base + right_coeff] =
        sub_mod(left1, twisted_right1, q_modulus);
}

__global__ void hybrid_preweight_p_two_components_kernel(
    GpuWord *accum_p0,
    GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t base_p_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = base_p_size * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t p_limb = tid >> degree_power;
    const GpuWord inv_punctured = p_inv_punctured[p_limb];
    if (inv_punctured == 1)
    {
        return;
    }

    const std::size_t table_limb = base_q_size + p_limb;
    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    accum_p0[tid] = mul_mod(
        accum_p0[tid], inv_punctured, modulus, barrett);
    accum_p1[tid] = mul_mod(
        accum_p1[tid], inv_punctured, modulus, barrett);
}

__global__ void
hybrid_convert_p_to_q_forward_ntt_first_stage_row_tiled8_kernel(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t degree)
{
    constexpr std::size_t kPCount = 2;
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kTargetRows = 8;
    constexpr std::size_t kPlanesPerComponent = kPCount * 2;
    constexpr std::size_t kSourcePlanes = 2 * kPlanesPerComponent;
    __shared__ GpuWord weighted_p[kSourcePlanes][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t row = threadIdx.y;
    const std::size_t butterflies_per_limb = degree >> 1;
    const std::size_t coefficient_pair =
        blockIdx.x * kCoefficientTile + lane;
    const bool valid_coefficient =
        coefficient_pair < butterflies_per_limb;

    const std::size_t component = row / kPlanesPerComponent;
    const std::size_t component_plane = row % kPlanesPerComponent;
    const std::size_t p_limb = component_plane >> 1;
    const std::size_t coefficient_side = component_plane & 1;
    GpuWord weighted = 0;
    if (valid_coefficient)
    {
        const std::size_t coefficient =
            coefficient_pair + coefficient_side * butterflies_per_limb;
        const std::size_t p_table_limb = base_q_size + p_limb;
        const GpuWord p_modulus = rns_primes[p_table_limb];
        const GpuWide p_barrett =
            rns_modulus_constants[p_table_limb];
        const GpuWord inv_punctured = p_inv_punctured[p_limb];
        const GpuWord *component_values =
            component == 0 ? accum_p0 : accum_p1;
        const GpuWord value =
            component_values[p_limb * degree + coefficient];
        weighted = inv_punctured == 1
            ? value
            : mul_mod(value, inv_punctured, p_modulus, p_barrett);
    }
    weighted_p[row][lane] = weighted;
    __syncthreads();

    const std::size_t q_limb = blockIdx.y * kTargetRows + row;
    if (!valid_coefficient || q_limb >= base_q_size)
    {
        return;
    }

    const GpuWord q_modulus = rns_primes[q_limb];
    const GpuWide q_barrett = rns_modulus_constants[q_limb];
    const std::size_t matrix_base = q_limb * kPCount;
    const GpuWord matrix0 = moddown_p_to_q_matrix[matrix_base];
    const GpuWord matrix1 = moddown_p_to_q_matrix[matrix_base + 1];

    const GpuWord left0 = add_mod(
        mul_mod(weighted_p[0][lane], matrix0, q_modulus, q_barrett),
        mul_mod(weighted_p[2][lane], matrix1, q_modulus, q_barrett),
        q_modulus);
    const GpuWord right0 = add_mod(
        mul_mod(weighted_p[1][lane], matrix0, q_modulus, q_barrett),
        mul_mod(weighted_p[3][lane], matrix1, q_modulus, q_barrett),
        q_modulus);
    const GpuWord left1 = add_mod(
        mul_mod(weighted_p[4][lane], matrix0, q_modulus, q_barrett),
        mul_mod(weighted_p[6][lane], matrix1, q_modulus, q_barrett),
        q_modulus);
    const GpuWord right1 = add_mod(
        mul_mod(weighted_p[5][lane], matrix0, q_modulus, q_barrett),
        mul_mod(weighted_p[7][lane], matrix1, q_modulus, q_barrett),
        q_modulus);

    const GpuWord root = roots[q_limb * degree + 1];
    const std::size_t q_base = q_limb * degree;
    const std::size_t right_coefficient =
        coefficient_pair + butterflies_per_limb;

    const GpuWord twisted_right0 =
        mul_mod(right0, root, q_modulus, q_barrett);
    converted_q0[q_base + coefficient_pair] =
        add_mod(left0, twisted_right0, q_modulus);
    converted_q0[q_base + right_coefficient] =
        sub_mod(left0, twisted_right0, q_modulus);

    const GpuWord twisted_right1 =
        mul_mod(right1, root, q_modulus, q_barrett);
    converted_q1[q_base + coefficient_pair] =
        add_mod(left1, twisted_right1, q_modulus);
    converted_q1[q_base + right_coefficient] =
        sub_mod(left1, twisted_right1, q_modulus);
}

template <bool SourcePreweighted>
__global__ void
hybrid_convert_p9_to_q_forward_ntt_first_stage_row_tiled8_kernel(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    const GpuWord *moddown_p_to_q_matrix,
    const GpuWord *p_inv_punctured,
    std::size_t base_q_size,
    std::size_t degree)
{
    constexpr std::size_t kPCount = 9;
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kTargetRows = 8;
    constexpr std::size_t kPlanesPerComponent = kPCount * 2;
    constexpr std::size_t kSourcePlanes = 2 * kPlanesPerComponent;
    constexpr std::size_t kBlockThreads =
        kCoefficientTile * kTargetRows;
    __shared__ GpuWord weighted_p[kSourcePlanes][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t row = threadIdx.y;
    const std::size_t linear_thread =
        row * kCoefficientTile + lane;
    const std::size_t butterflies_per_limb = degree >> 1;

    for (std::size_t source_index = linear_thread;
         source_index < kSourcePlanes * kCoefficientTile;
         source_index += kBlockThreads)
    {
        const std::size_t source_plane =
            source_index / kCoefficientTile;
        const std::size_t source_lane =
            source_index % kCoefficientTile;
        const std::size_t component =
            source_plane / kPlanesPerComponent;
        const std::size_t component_plane =
            source_plane % kPlanesPerComponent;
        const std::size_t p_limb = component_plane >> 1;
        const std::size_t coefficient_side = component_plane & 1;
        const std::size_t coefficient_pair =
            blockIdx.x * kCoefficientTile + source_lane;

        GpuWord weighted = 0;
        if (coefficient_pair < butterflies_per_limb)
        {
            const std::size_t coefficient = coefficient_pair +
                coefficient_side * butterflies_per_limb;
            const GpuWord *component_values =
                component == 0 ? accum_p0 : accum_p1;
            weighted = component_values[p_limb * degree + coefficient];
            if constexpr (!SourcePreweighted)
            {
                const std::size_t table_limb = base_q_size + p_limb;
                const GpuWord modulus = rns_primes[table_limb];
                const GpuWide barrett =
                    rns_modulus_constants[table_limb];
                const GpuWord inv_punctured = p_inv_punctured[p_limb];
                if (inv_punctured != 1)
                {
                    weighted = mul_mod(
                        weighted,
                        inv_punctured,
                        modulus,
                        barrett);
                }
            }
        }
        weighted_p[source_plane][source_lane] = weighted;
    }
    __syncthreads();

    const std::size_t coefficient_pair =
        blockIdx.x * kCoefficientTile + lane;
    const std::size_t q_limb = blockIdx.y * kTargetRows + row;
    if (coefficient_pair >= butterflies_per_limb ||
        q_limb >= base_q_size)
    {
        return;
    }

    const GpuWord q_modulus = rns_primes[q_limb];
    const GpuWide q_barrett = rns_modulus_constants[q_limb];
    const std::size_t matrix_base = q_limb * kPCount;
    GpuWord left0 = 0;
    GpuWord right0 = 0;
    GpuWord left1 = 0;
    GpuWord right1 = 0;
#pragma unroll
    for (std::size_t p_limb = 0; p_limb < kPCount; ++p_limb)
    {
        const GpuWord matrix_value =
            moddown_p_to_q_matrix[matrix_base + p_limb];
        const std::size_t component0_plane = p_limb * 2;
        const std::size_t component1_plane =
            kPlanesPerComponent + component0_plane;
        left0 = add_mod(
            left0,
            mul_mod(
                weighted_p[component0_plane][lane],
                matrix_value,
                q_modulus,
                q_barrett),
            q_modulus);
        right0 = add_mod(
            right0,
            mul_mod(
                weighted_p[component0_plane + 1][lane],
                matrix_value,
                q_modulus,
                q_barrett),
            q_modulus);
        left1 = add_mod(
            left1,
            mul_mod(
                weighted_p[component1_plane][lane],
                matrix_value,
                q_modulus,
                q_barrett),
            q_modulus);
        right1 = add_mod(
            right1,
            mul_mod(
                weighted_p[component1_plane + 1][lane],
                matrix_value,
                q_modulus,
                q_barrett),
            q_modulus);
    }

    const GpuWord root = roots[q_limb * degree + 1];
    const std::size_t q_base = q_limb * degree;
    const std::size_t right_coefficient =
        coefficient_pair + butterflies_per_limb;
    const GpuWord twisted_right0 =
        mul_mod(right0, root, q_modulus, q_barrett);
    converted_q0[q_base + coefficient_pair] =
        add_mod(left0, twisted_right0, q_modulus);
    converted_q0[q_base + right_coefficient] =
        sub_mod(left0, twisted_right0, q_modulus);

    const GpuWord twisted_right1 =
        mul_mod(right1, root, q_modulus, q_barrett);
    converted_q1[q_base + coefficient_pair] =
        add_mod(left1, twisted_right1, q_modulus);
    converted_q1[q_base + right_coefficient] =
        sub_mod(left1, twisted_right1, q_modulus);
}

template <int FusionStages>
__global__ void hybrid_forward_ntt_q_two_components_fused_stage_kernel(
    GpuWord *values0,
    GpuWord *values1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *roots,
    std::size_t base_q_size,
    std::size_t degree,
    std::size_t m,
    std::size_t gap)
{
    static_assert(
        FusionStages >= 1 && FusionStages <= 3,
        "HYBRID two-component Q NTT fusion supports 1-3 stages");

    constexpr std::size_t kLocalSize =
        static_cast<std::size_t>(1) << FusionStages;
    const std::size_t tiles_per_limb = degree >> FusionStages;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = 2 * base_q_size * tiles_per_limb;
    if (tid >= total)
    {
        return;
    }

    const std::size_t component_limb = tid / tiles_per_limb;
    const std::size_t local_tile = tid % tiles_per_limb;
    const bool second_component = component_limb >= base_q_size;
    const std::size_t q_limb = second_component
        ? component_limb - base_q_size
        : component_limb;
    GpuWord *values = second_component ? values1 : values0;

    const std::size_t final_gap = gap >> (FusionStages - 1);
    const std::size_t outer_group = local_tile / final_gap;
    const std::size_t j = local_tile % final_gap;
    const std::size_t base_index =
        q_limb * degree + outer_group * (gap << 1) + j;
    const GpuWord modulus = rns_primes[q_limb];
    const GpuWide barrett = rns_modulus_constants[q_limb];
    const GpuWord *limb_roots = roots + q_limb * degree;

    GpuWord local[kLocalSize];
#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        local[i] = values[base_index + i * final_gap];
    }

#pragma unroll
    for (int stage = 0; stage < FusionStages; ++stage)
    {
        const std::size_t local_stride =
            static_cast<std::size_t>(1) << (FusionStages - 1 - stage);
        const std::size_t stage_m = m << stage;
        const std::size_t stage_group_base = outer_group << stage;

#pragma unroll
        for (std::size_t block = 0; block < kLocalSize;
             block += (local_stride << 1))
        {
            const std::size_t block_group = block / (local_stride << 1);
            const GpuWord root =
                limb_roots[stage_m + stage_group_base + block_group];

#pragma unroll
            for (std::size_t offset = 0; offset < local_stride; ++offset)
            {
                const GpuWord u = local[block + offset];
                const GpuWord v = mul_mod(
                    local[block + offset + local_stride],
                    root,
                    modulus,
                    barrett);
                local[block + offset] = add_mod(u, v, modulus);
                local[block + offset + local_stride] =
                    sub_mod(u, v, modulus);
            }
        }
    }

#pragma unroll
    for (std::size_t i = 0; i < kLocalSize; ++i)
    {
        values[base_index + i * final_gap] = local[i];
    }
}

__global__ void hybrid_apply_moddown_ntt_two_components_kernel(
    GpuWord *accum_q0,
    GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t base_q_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = base_q_size * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t q_limb = tid >> degree_power;
    const GpuWord modulus = rns_primes[q_limb];
    const GpuWide barrett = rns_modulus_constants[q_limb];
    const GpuWord inv_p = inv_p_mod_q[q_limb];

    const GpuWord difference0 =
        sub_mod(accum_q0[tid], converted_q0[tid], modulus);
    accum_q0[tid] = mul_mod(difference0, inv_p, modulus, barrett);

    const GpuWord difference1 =
        sub_mod(accum_q1[tid], converted_q1[tid], modulus);
    accum_q1[tid] = mul_mod(difference1, inv_p, modulus, barrett);
}

__global__ void hybrid_apply_moddown_ntt_out_of_place_two_components_kernel(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t base_q_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = base_q_size * degree;
    if (tid >= total)
    {
        return;
    }

    const std::size_t q_limb = tid >> degree_power;
    const GpuWord modulus = rns_primes[q_limb];
    const GpuWide barrett = rns_modulus_constants[q_limb];
    const GpuWord inv_p = inv_p_mod_q[q_limb];

    destination_q0[tid] = mul_mod(
        sub_mod(source_q0[tid], converted_q0[tid], modulus),
        inv_p,
        modulus,
        barrett);
    destination_q1[tid] = mul_mod(
        sub_mod(source_q1[tid], converted_q1[tid], modulus),
        inv_p,
        modulus,
        barrett);
}

__global__ void hybrid_apply_moddown_ntt_out_of_place_batch_kernel(
    GpuWord *destination_q,
    const GpuWord *source_q,
    const GpuWord *converted_q,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t batch_count,
    std::size_t base_q_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t words_per_component = base_q_size * degree;
    const std::size_t total = batch_count * 2 * words_per_component;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= total)
    {
        return;
    }
    const std::size_t local = tid % words_per_component;
    const std::size_t q_limb = local >> degree_power;
    const GpuWord modulus = rns_primes[q_limb];
    destination_q[tid] = mul_mod(
        sub_mod(source_q[tid], converted_q[tid], modulus),
        inv_p_mod_q[q_limb],
        modulus,
        rns_modulus_constants[q_limb]);
}

struct SelectedModDownComponents
{
    std::uint32_t index[kMaxSelectedModDownComponents];
};

/*
 * Out-of-place ModDown apply for a scattered set of components. Converted
 * slot k belongs to component index[k] of source/destination, both laid out
 * as consecutive Q components of words_per_component words.
 */
__global__ void hybrid_apply_moddown_ntt_selected_kernel(
    GpuWord *destination_q,
    const GpuWord *source_q,
    const GpuWord *converted_q,
    SelectedModDownComponents components,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t component_count,
    std::size_t base_q_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t words_per_component = base_q_size * degree;
    const std::size_t total = component_count * words_per_component;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= total)
    {
        return;
    }
    const std::size_t slot = tid / words_per_component;
    const std::size_t local = tid - slot * words_per_component;
    const std::size_t offset =
        static_cast<std::size_t>(components.index[slot]) *
            words_per_component +
        local;
    const std::size_t q_limb = local >> degree_power;
    const GpuWord modulus = rns_primes[q_limb];
    destination_q[offset] = mul_mod(
        sub_mod(source_q[offset], converted_q[tid], modulus),
        inv_p_mod_q[q_limb],
        modulus,
        rns_modulus_constants[q_limb]);
}

__global__ void hybrid_apply_moddown_ntt_from_q_groups_kernel(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *group_q,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t group_count,
    std::size_t base_q_size,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t component_words = base_q_size * degree;
    if (tid >= component_words)
    {
        return;
    }
    const std::size_t q_limb = tid >> degree_power;
    const GpuWord modulus = rns_primes[q_limb];
    GpuWord sum0 = 0;
    GpuWord sum1 = 0;
    for (std::size_t group = 0; group < group_count; ++group)
    {
        sum0 = add_mod(
            sum0,
            group_q[(group * 2) * component_words + tid],
            modulus);
        sum1 = add_mod(
            sum1,
            group_q[(group * 2 + 1) * component_words + tid],
            modulus);
    }
    const GpuWide barrett = rns_modulus_constants[q_limb];
    const GpuWord inv_p = inv_p_mod_q[q_limb];
    destination_q0[tid] = mul_mod(
        sub_mod(sum0, converted_q0[tid], modulus),
        inv_p,
        modulus,
        barrett);
    destination_q1[tid] = mul_mod(
        sub_mod(sum1, converted_q1[tid], modulus),
        inv_p,
        modulus,
        barrett);
}

__global__ void hybrid_apply_moddown_ntt_add_back_two_components_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *add_source0,
    const GpuWord *add_source1,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t modulus_offset,
    std::size_t limb_count,
    std::size_t coeff_count,
    unsigned int degree_power)
{
    const std::size_t values_per_component = limb_count * coeff_count;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= values_per_component * 2)
    {
        return;
    }

    const bool second_component = tid >= values_per_component;
    const std::size_t local_index =
        second_component ? tid - values_per_component : tid;
    const std::size_t local_limb = local_index >> degree_power;
    const std::size_t local_coeff = local_index & (coeff_count - 1);
    const std::size_t table_limb = modulus_offset + local_limb;
    const std::size_t scratch_index = table_limb * coeff_count + local_coeff;
    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const GpuWord inv_p = inv_p_mod_q[table_limb];

    GpuWord *destination = second_component ? destination1 : destination0;
    const GpuWord *add_source =
        second_component ? add_source1 : add_source0;
    const GpuWord *accum_q = second_component ? accum_q1 : accum_q0;
    const GpuWord *converted_q = second_component ? converted_q1 : converted_q0;

    const GpuWord difference =
        sub_mod(accum_q[scratch_index], converted_q[scratch_index], modulus);
    const GpuWord moddown =
        mul_mod(difference, inv_p, modulus, barrett);
    destination[local_index] = add_source == nullptr
        ? moddown
        : add_mod(add_source[local_index], moddown, modulus);
}

__global__ void hybrid_apply_moddown_ntt_c2s_split_two_components_kernel(
    GpuWord *real0,
    GpuWord *real1,
    GpuWord *imag0,
    GpuWord *imag1,
    const GpuWord *dft0,
    const GpuWord *dft1,
    const GpuWord *minus_i_plain,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    std::size_t modulus_offset,
    std::size_t limb_count,
    std::size_t coeff_count,
    unsigned int degree_power)
{
    const std::size_t values_per_component = limb_count * coeff_count;
    const std::size_t local_index = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (local_index >= values_per_component)
    {
        return;
    }

    const bool second_component = blockIdx.y != 0;
    const std::size_t local_limb = local_index >> degree_power;
    const std::size_t local_coeff = local_index & (coeff_count - 1);
    const std::size_t table_limb = modulus_offset + local_limb;
    const std::size_t scratch_index = table_limb * coeff_count + local_coeff;
    const GpuWord modulus = rns_primes[table_limb];
    const GpuWide barrett = rns_modulus_constants[table_limb];
    const GpuWord inv_p = inv_p_mod_q[table_limb];

    GpuWord *real_out = second_component ? real1 : real0;
    GpuWord *imag_out = second_component ? imag1 : imag0;
    const GpuWord *dft_in = second_component ? dft1 : dft0;
    const GpuWord *accum_q = second_component ? accum_q1 : accum_q0;
    const GpuWord *converted_q = second_component ? converted_q1 : converted_q0;

    const GpuWord conj_val = mul_mod(
        sub_mod(accum_q[scratch_index], converted_q[scratch_index], modulus),
        inv_p,
        modulus,
        barrett);
    const GpuWord dft_val = dft_in[local_index];
    real_out[local_index] = add_mod(dft_val, conj_val, modulus);
    imag_out[local_index] = mul_mod(
        sub_mod(dft_val, conj_val, modulus),
        minus_i_plain[local_index],
        modulus,
        barrett);
}

__global__ void hybrid_apply_moddown_ntt_add_back_rescale_x2_two_components_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *add_source0,
    const GpuWord *add_source1,
    const GpuWord *correction_ntt0,
    const GpuWord *correction_ntt1,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuWord *rns_primes,
    const GpuWide *rns_modulus_constants,
    const GpuWord *inv_p_mod_q,
    const GpuWord *inv_q_last_two_product_mod_q,
    std::size_t limb_count,
    std::size_t coeff_count,
    unsigned int degree_power)
{
    const std::size_t values_per_component = limb_count * coeff_count;
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= values_per_component * 2)
    {
        return;
    }

    const bool second_component = tid >= values_per_component;
    const std::size_t local_index =
        second_component ? tid - values_per_component : tid;
    const std::size_t q_limb = local_index >> degree_power;
    const GpuWord modulus = rns_primes[q_limb];
    const GpuWide barrett = rns_modulus_constants[q_limb];

    GpuWord *destination = second_component ? destination1 : destination0;
    const GpuWord *add_source =
        second_component ? add_source1 : add_source0;
    const GpuWord *correction_ntt =
        second_component ? correction_ntt1 : correction_ntt0;
    const GpuWord *accum_q = second_component ? accum_q1 : accum_q0;
    const GpuWord *converted_q = second_component ? converted_q1 : converted_q0;

    const GpuWord switched = mul_mod(
        sub_mod(accum_q[local_index], converted_q[local_index], modulus),
        inv_p_mod_q[q_limb],
        modulus,
        barrett);
    const GpuWord relin_value =
        add_mod(add_source[local_index], switched, modulus);
    const GpuWord corrected =
        sub_mod(relin_value, correction_ntt[local_index], modulus);
    destination[local_index] = mul_mod(
        corrected,
        inv_q_last_two_product_mod_q[q_limb],
        modulus,
        barrett);
}

__global__ void hybrid_relin_rescale_x2_tail_kernel(
    GpuWord *tail0, GpuWord *tail1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    unsigned q, unsigned degree_power)
{
    const std::size_t n = std::size_t{1} << degree_power;
    const std::size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= 2 * n) return;
    const unsigned limb = q - 2 + (i >> degree_power);
    const std::size_t index = (q - 2) * n + i;
    auto *out = blockIdx.y ? tail1 : tail0;
    const auto *accum = blockIdx.y ? accum1 : accum0;
    const auto *source = blockIdx.y ? source1 : source0;
    const auto switched = mul_mod(accum[index], inv_p[limb], primes[limb], ratios[limb]);
    out[i] = source ? add_mod(switched, source[index], primes[limb]) : switched;
}

__global__ void hybrid_relin_rescale_x2_merge_correction_kernel(
    GpuWord *converted0, GpuWord *converted1,
    const GpuWord *tail0, const GpuWord *tail1,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    const GpuWord *m_mod_q, GpuWide half_m,
    GpuWord inv_last_mod_second, unsigned q, unsigned degree_power)
{
    const std::size_t n = std::size_t{1} << degree_power;
    const std::size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    auto *r = blockIdx.y ? converted1 : converted0;
    const auto *tail = blockIdx.y ? tail1 : tail0;
    const auto qa = primes[q - 2], qb = primes[q - 1];
    // tail = INTT(P^-1*A + S). Subtract the untransformed ModDown
    // correction to recover exactly the old K on the two discarded limbs.
    const auto a = sub_mod(tail[i],
        mul_mod(r[(q - 2) * n + i], inv_p[q - 2], qa, ratios[q - 2]), qa);
    const auto b = sub_mod(tail[n + i],
        mul_mod(r[(q - 1) * n + i], inv_p[q - 1], qb, ratios[q - 1]), qb);
    const auto delta = sub_mod(a, barrett_reduce_u64_u32(b, qa, ratios[q - 2]), qa);
    const GpuWide remainder = static_cast<GpuWide>(b) + static_cast<GpuWide>(qb) *
        mul_mod(delta, inv_last_mod_second, qa, ratios[q - 2]);
    // Reuse the CRT remainder for every retained limb. Adjacent threads
    // access adjacent coefficients at every iteration of this loop.
    for (unsigned limb = 0; limb + 2 < q; ++limb) {
        const auto prime = primes[limb];
        const auto ratio = ratios[limb];
        auto centered = barrett_reduce_u64_u32(remainder, prime, ratio);
        if (remainder > half_m) centered = sub_mod(centered, m_mod_q[limb], prime);
        const std::size_t index = limb * n + i;
        r[index] = add_mod(mul_mod(r[index], inv_p[limb], prime, ratio), centered, prime);
    }
}

__global__ void hybrid_relin_rescale_x2_apply_kernel(
    GpuWord *out0, GpuWord *out1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *correction0, const GpuWord *correction1,
    const GpuWord *primes, const GpuWide *ratios,
    const GpuWord *inv_p, const GpuWord *inv_m, unsigned q, unsigned degree_power)
{
    const std::size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= (std::size_t{q - 2} << degree_power)) return;
    const auto limb = i >> degree_power;
    auto *out = blockIdx.y ? out1 : out0;
    const auto *accum = blockIdx.y ? accum1 : accum0;
    const auto *source = blockIdx.y ? source1 : source0;
    const auto *correction = blockIdx.y ? correction1 : correction0;
    const auto prime = primes[limb];
    const auto ratio = ratios[limb];
    const auto switched = mul_mod(accum[i], inv_p[limb], prime, ratio);
    const auto value = source ? add_mod(switched, source[i], prime) : switched;
    out[i] = mul_mod(sub_mod(value, correction[i], prime), inv_m[limb], prime, ratio);
}

__global__ void hybrid_relin_rescale_x1_tail_kernel(
    GpuWord *tail0, GpuWord *tail1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    unsigned q, unsigned degree_power, bool double_moddown)
{
    const std::size_t n = std::size_t{1} << degree_power;
    const std::size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    const unsigned limb = q - 1;
    const std::size_t index = static_cast<std::size_t>(limb) * n + i;
    auto *out = blockIdx.y ? tail1 : tail0;
    const auto *accum = blockIdx.y ? accum1 : accum0;
    const auto *source = blockIdx.y ? source1 : source0;
    const auto prime = primes[limb];
    auto switched = mul_mod(accum[index], inv_p[limb], prime, ratios[limb]);
    if (double_moddown) switched = add_mod(switched, switched, prime);
    out[i] = source ? add_mod(switched, source[index], prime) : switched;
}

__global__ void hybrid_relin_rescale_x1_merge_correction_kernel(
    GpuWord *converted0, GpuWord *converted1,
    const GpuWord *tail0, const GpuWord *tail1,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    const GpuWord *half_q_last_mod_q, GpuWord q_last, GpuWord half_q_last,
    unsigned q, unsigned degree_power, bool double_moddown)
{
    const std::size_t n = std::size_t{1} << degree_power;
    const std::size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    auto *r = blockIdx.y ? converted1 : converted0;
    const auto *tail = blockIdx.y ? tail1 : tail0;
    auto r_last = mul_mod(
        r[static_cast<std::size_t>(q - 1) * n + i],
        inv_p[q - 1], q_last, ratios[q - 1]);
    if (double_moddown) r_last = add_mod(r_last, r_last, q_last);
    const auto b = sub_mod(tail[i], r_last, q_last);
    const auto rounded = add_mod(b, half_q_last, q_last);
    for (unsigned limb = 0; limb + 1 < q; ++limb) {
        const auto prime = primes[limb];
        const auto ratio = ratios[limb];
        const auto centered = sub_mod(
            barrett_reduce_u64_u32(rounded, prime, ratio),
            half_q_last_mod_q[limb], prime);
        const std::size_t index = static_cast<std::size_t>(limb) * n + i;
        auto r_switched = mul_mod(r[index], inv_p[limb], prime, ratio);
        if (double_moddown) r_switched = add_mod(r_switched, r_switched, prime);
        r[index] = add_mod(r_switched, centered, prime);
    }
}

__global__ void hybrid_relin_rescale_x1_apply_kernel(
    GpuWord *out0, GpuWord *out1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *correction0, const GpuWord *correction1,
    const GpuWord *primes, const GpuWide *ratios,
    const GpuWord *inv_p, const GpuWord *inv_q_last,
    unsigned q, unsigned degree_power, bool double_moddown)
{
    const std::size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= (std::size_t{q - 1} << degree_power)) return;
    const auto limb = i >> degree_power;
    auto *out = blockIdx.y ? out1 : out0;
    const auto *accum = blockIdx.y ? accum1 : accum0;
    const auto *source = blockIdx.y ? source1 : source0;
    const auto *correction = blockIdx.y ? correction1 : correction0;
    const auto prime = primes[limb];
    const auto ratio = ratios[limb];
    auto switched = mul_mod(accum[i], inv_p[limb], prime, ratio);
    if (double_moddown) switched = add_mod(switched, switched, prime);
    const auto value = source ? add_mod(switched, source[i], prime) : switched;
    out[i] = mul_mod(sub_mod(value, correction[i], prime), inv_q_last[limb], prime, ratio);
}

void validate_hybrid_tables(
    const char *name,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t decomp_count = parameter_shard.hybrid_decomp_count;

    if (degree == 0 || base_q_size == 0 || base_p_size == 0 || decomp_count == 0)
    {
        throw std::invalid_argument(std::string(name) + ": empty HYBRID shape");
    }
    if (parameter_shard.rns_primes.data() == nullptr ||
        parameter_shard.rns_modulus_constants.data() == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null RNS modulus tables");
    }
    if (parameter_shard.rns_primes.size() < base_q_size + base_p_size ||
        parameter_shard.rns_modulus_constants.size() < base_q_size + base_p_size)
    {
        throw std::invalid_argument(std::string(name) + ": RNS modulus tables are too small");
    }
    if (parameter_shard.hybrid_q_conv_matrix_offsets.data() == nullptr ||
        parameter_shard.hybrid_p_conv_matrix_offsets.data() == nullptr ||
        parameter_shard.hybrid_q_conv_matrices.data() == nullptr ||
        parameter_shard.hybrid_p_conv_matrices.data() == nullptr ||
        parameter_shard.hybrid_qi_inv_punctured.data() == nullptr ||
        parameter_shard.hybrid_moddown_p_to_q_matrix.data() == nullptr ||
        parameter_shard.hybrid_p_inv_punctured.data() == nullptr ||
        parameter_shard.hybrid_inv_p_mod_q.data() == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null HYBRID table pointer");
    }
    if (parameter_shard.hybrid_q_conv_matrix_offsets.size() < decomp_count + 1 ||
        parameter_shard.hybrid_p_conv_matrix_offsets.size() < decomp_count + 1 ||
        parameter_shard.hybrid_q_conv_matrices.size() <
            decomp_count * base_q_size * base_p_size ||
        parameter_shard.hybrid_p_conv_matrices.size() <
            decomp_count * base_p_size * base_p_size ||
        parameter_shard.hybrid_qi_inv_punctured.size() < decomp_count * base_p_size ||
        parameter_shard.hybrid_moddown_p_to_q_matrix.size() < base_q_size * base_p_size ||
        parameter_shard.hybrid_p_inv_punctured.size() < base_p_size ||
        parameter_shard.hybrid_inv_p_mod_q.size() < base_q_size)
    {
        throw std::invalid_argument(std::string(name) + ": HYBRID tables are too small");
    }
}

unsigned int checked_log2_degree(std::size_t degree, const char *name)
{
    if (degree < 2 || (degree & (degree - 1)) != 0)
    {
        throw std::invalid_argument(std::string(name) + ": degree must be a power of two");
    }

    unsigned int result = 0;
    while (degree > 1)
    {
        degree >>= 1;
        ++result;
    }
    return result;
}

void launch_hybrid_forward_ntt_q_two_components_stages(
    GpuWord *values0,
    GpuWord *values1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    unsigned int degree_power,
    unsigned int completed_stages,
    const char *name)
{
    constexpr int kFusionStages = 3;
    constexpr int block_size = 256;
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    std::size_t remaining_stages = degree_power - completed_stages;
    std::size_t m = static_cast<std::size_t>(1) << completed_stages;
    std::size_t gap = degree >> (completed_stages + 1);

    while (remaining_stages > 0)
    {
        std::size_t stage_count = remaining_stages % kFusionStages;
        if (stage_count == 0)
        {
            stage_count = kFusionStages;
        }

        const std::size_t tiles_per_limb = degree >> stage_count;
        const std::size_t total = 2 * base_q_size * tiles_per_limb;
        const int grid_size = static_cast<int>(
            (total + block_size - 1) / block_size);

        if (stage_count == 1)
        {
            hybrid_forward_ntt_q_two_components_fused_stage_kernel<1>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    values0,
                    values1,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    base_q_size,
                    degree,
                    m,
                    gap);
        }
        else if (stage_count == 2)
        {
            hybrid_forward_ntt_q_two_components_fused_stage_kernel<2>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    values0,
                    values1,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    base_q_size,
                    degree,
                    m,
                    gap);
        }
        else
        {
            hybrid_forward_ntt_q_two_components_fused_stage_kernel<3>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    values0,
                    values1,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    base_q_size,
                    degree,
                    m,
                    gap);
        }
        gpu_check_cuda(cudaGetLastError(), name);

        m <<= stage_count;
        gap >>= stage_count;
        remaining_stages -= stage_count;
    }
}

}  // namespace

void launch_hybrid_modup_decomposition(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *c2_ntt,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted)
{
    validate_hybrid_tables(
        "launch_hybrid_modup_decomposition",
        parameter_shard,
        degree);

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr ||
        c2_coeff == nullptr || c2_ntt == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_modup_decomposition: null data pointer");
    }
    /* Check that the current HYBRID decomposition block stays inside base Q. */
    if (decomp_index >= parameter_shard.hybrid_decomp_count ||
        decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument("launch_hybrid_modup_decomposition: invalid decomposition range");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_modup_decomposition cudaSetDevice");

    constexpr int block_size = 256;
    const std::size_t total = (base_q_size + base_p_size) * degree;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_modup_decomposition");
    if (source_preweighted && decomp_limb_count > 1 &&
        !(lazy_base_conversion_enabled() && opt_flag(OptFlag::ModupPreweight) &&
          decomp_limb_count <= kModupPreweightMaxCols && ((degree >> 1) % block_size) == 0 &&
          decomp_index * base_p_size == decomp_limb_begin))
    {
        throw std::logic_error(
            "launch_hybrid_modup_decomposition: preweighted source needs the preweighted ModUp path");
    }
    if (lazy_base_conversion_enabled() && decomp_limb_count > 1 &&
        opt_flag(OptFlag::ModupPreweight) &&
        decomp_limb_count <= kModupPreweightMaxCols &&
        ((degree >> 1) % block_size) == 0)
    {
        const GpuWord *weighted = c2_coeff + decomp_limb_begin * degree;
        if (!source_preweighted)
        {
        GpuWord *scratch = modup_preweight_scratch(decomp_limb_count * degree);
        const unsigned int weight_grid = static_cast<unsigned int>(
            (decomp_limb_count * degree + block_size - 1) / block_size);
        hybrid_preweight_modup_source_kernel<<<weight_grid, block_size, 0, gpu_execution_stream()>>>(
            scratch,
            c2_coeff,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_qi_inv_punctured.data(),
            static_cast<unsigned int>(decomp_index * base_p_size),
            static_cast<unsigned int>(decomp_limb_begin),
            static_cast<unsigned int>(decomp_limb_count),
            degree_power);
        gpu_check_cuda(cudaGetLastError(), "launch_hybrid_modup_decomposition preweight kernel launch");
        weighted = scratch;
        }
        if (try_launch_hybrid_modup_qp_cta_tiled_65536(
                modup_q, modup_p, weighted, parameter_shard,
                decomp_index, decomp_limb_begin, decomp_limb_count,
                1, decomp_limb_count * degree, base_q_size * degree,
                base_p_size * degree, degree))
        {
            gpu_check_cuda(cudaGetLastError(), "launch_hybrid_modup_decomposition cta_tiled kernel launch");
            return;
        }
        const std::size_t targets = base_q_size - decomp_limb_count + base_p_size;
        const int tile = select_adaptive_tile_4_8_12_16(targets, opt_flag_value(OptFlag::ModupTile));
        const std::size_t tiles = (targets + tile - 1) / tile;
        const int grid = static_cast<int>(((tiles * degree >> 1) + block_size - 1) / block_size);
        const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_MODUP_PW(T)                                                            \
        hybrid_modup_qp_lazy_preweighted_kernel<T><<<grid, block_size, 0, gpu_execution_stream()>>>( \
            modup_q, modup_p, weighted,                                                        \
            parameter_shard.rns_primes.data(),                                                 \
            parameter_shard.rns_modulus_constants.data(),                                      \
            parameter_shard.hybrid_q_conv_matrix_offsets.data(),                               \
            parameter_shard.hybrid_q_conv_matrices.data(),                                     \
            parameter_shard.hybrid_p_conv_matrix_offsets.data(),                               \
            parameter_shard.hybrid_p_conv_matrices.data(),                                     \
            static_cast<unsigned int>(decomp_index),                                           \
            static_cast<unsigned int>(decomp_limb_begin),                                      \
            static_cast<unsigned int>(decomp_limb_count),                                      \
            static_cast<unsigned int>(base_q_size),                                            \
            static_cast<unsigned int>(base_p_size),                                            \
            degree_power, 0, 0, 0, vec_bconv)
        if (tile == 16) { POSEIDON_LAUNCH_MODUP_PW(16); }
        else if (tile == 12) { POSEIDON_LAUNCH_MODUP_PW(12); }
        else if (tile == 8) { POSEIDON_LAUNCH_MODUP_PW(8); }
        else { POSEIDON_LAUNCH_MODUP_PW(4); }
#undef POSEIDON_LAUNCH_MODUP_PW
        gpu_check_cuda(cudaGetLastError(), "launch_hybrid_modup_decomposition preweighted kernel launch");
        return;
    }
    if (lazy_base_conversion_enabled() && decomp_limb_count > 1)
    {
        constexpr int target_tile = 4;
        const std::size_t tiles =
            (base_q_size - decomp_limb_count + base_p_size + target_tile - 1) / target_tile;
        const int lazy_grid = static_cast<int>(((tiles * degree >> 1) + block_size - 1) / block_size);
        hybrid_modup_qp_lazy_kernel<target_tile><<<lazy_grid, block_size, 0, gpu_execution_stream()>>>(
            modup_q,
            modup_p,
            c2_coeff,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_q_conv_matrix_offsets.data(),
            parameter_shard.hybrid_q_conv_matrices.data(),
            parameter_shard.hybrid_p_conv_matrix_offsets.data(),
            parameter_shard.hybrid_p_conv_matrices.data(),
            parameter_shard.hybrid_qi_inv_punctured.data(),
            decomp_index,
            decomp_limb_begin,
            decomp_limb_count,
            base_q_size,
            base_p_size,
            degree,
            degree_power);
        gpu_check_cuda(cudaGetLastError(), "launch_hybrid_modup_decomposition lazy kernel launch");
        return;
    }
    /* 发射模升kernel */
    hybrid_modup_qp_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        modup_q,
        modup_p,
        c2_coeff,
        c2_ntt,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        parameter_shard.hybrid_q_conv_matrix_offsets.data(),
        parameter_shard.hybrid_q_conv_matrices.data(),
        parameter_shard.hybrid_p_conv_matrix_offsets.data(),
        parameter_shard.hybrid_p_conv_matrices.data(),
        parameter_shard.hybrid_qi_inv_punctured.data(),
        decomp_index,
        decomp_limb_begin,
        decomp_limb_count,
        base_q_size,
        base_p_size,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_modup_decomposition kernel launch");
}

void launch_hybrid_modup_decomposition_forward_ntt_first_stage(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage",
        parameter_shard,
        degree);

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr || c2_coeff == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage: null data pointer");
    }
    if (parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage: null NTT table pointer");
    }
    if (degree < 2 ||
        decomp_index >= parameter_shard.hybrid_decomp_count ||
        decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage: invalid decomposition range");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage cudaSetDevice");

    constexpr int block_size = 256;
    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    const std::size_t total = active_limb_count * (degree >> 1);
    const int grid_size = static_cast<int>(
        (total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage");

#define POSEIDON_LAUNCH_MODUP_NTT_HEAD(FIXED_COUNT)                         \
    hybrid_modup_qp_forward_ntt_first_stage_kernel<FIXED_COUNT>            \
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(                                       \
            modup_q,                                                       \
            modup_p,                                                       \
            c2_coeff,                                                      \
            parameter_shard.rns_primes.data(),                             \
            parameter_shard.rns_modulus_constants.data(),                  \
            parameter_shard.ntt_tables.data(),                             \
            parameter_shard.hybrid_q_conv_matrix_offsets.data(),           \
            parameter_shard.hybrid_q_conv_matrices.data(),                 \
            parameter_shard.hybrid_p_conv_matrix_offsets.data(),           \
            parameter_shard.hybrid_p_conv_matrices.data(),                 \
            parameter_shard.hybrid_qi_inv_punctured.data(),                \
            decomp_index,                                                  \
            decomp_limb_begin,                                             \
            decomp_limb_count,                                             \
            base_q_size,                                                   \
            base_p_size,                                                   \
            degree,                                                        \
            degree_power)

    if (lazy_base_conversion_enabled() && decomp_limb_count >= 4 && decomp_limb_count != 9)
    {
        constexpr int tile = 4;
        const std::size_t tiles = (active_limb_count + tile - 1) / tile;
        const int lazy_grid = static_cast<int>(
            (tiles * (degree >> 1) + block_size - 1) / block_size);
        hybrid_modup_qp_forward_ntt_first_stage_lazy_kernel<tile>
            <<<lazy_grid, block_size, 0, gpu_execution_stream()>>>(
                modup_q,
                modup_p,
                c2_coeff,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_q_conv_matrix_offsets.data(),
                parameter_shard.hybrid_q_conv_matrices.data(),
                parameter_shard.hybrid_p_conv_matrix_offsets.data(),
                parameter_shard.hybrid_p_conv_matrices.data(),
                parameter_shard.hybrid_qi_inv_punctured.data(),
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    else if (decomp_limb_count == 1)
    {
        POSEIDON_LAUNCH_MODUP_NTT_HEAD(1);
    }
    else if (decomp_limb_count == 2)
    {
        POSEIDON_LAUNCH_MODUP_NTT_HEAD(2);
    }
    else if (decomp_limb_count == 3)
    {
        POSEIDON_LAUNCH_MODUP_NTT_HEAD(3);
    }
    else if (decomp_limb_count == 9)
    {
        POSEIDON_LAUNCH_MODUP_NTT_HEAD(9);
    }
    else
    {
        POSEIDON_LAUNCH_MODUP_NTT_HEAD(0);
    }
#undef POSEIDON_LAUNCH_MODUP_NTT_HEAD

    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage kernel launch");
}

void launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    if (decomp_limb_count != 2)
    {
        launch_hybrid_modup_decomposition_forward_ntt_first_stage(
            modup_q,
            modup_p,
            c2_coeff,
            decomp_index,
            decomp_limb_begin,
            decomp_limb_count,
            parameter_shard,
            degree);
        return;
    }

    validate_hybrid_tables(
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled",
        parameter_shard,
        degree);
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr || c2_coeff == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled: null data pointer");
    }
    if (parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled: null NTT table pointer");
    }
    if (decomp_index >= parameter_shard.hybrid_decomp_count ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled: invalid decomposition range");
    }

    checked_log2_degree(
        degree,
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled");
    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled cudaSetDevice");

    constexpr unsigned int kCoefficientTile = 32;
    constexpr unsigned int kTargetRows = 4;
    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    const dim3 block_size(kCoefficientTile, kTargetRows);
    const dim3 grid_size(
        static_cast<unsigned int>(
            ((degree >> 1) + kCoefficientTile - 1) / kCoefficientTile),
        static_cast<unsigned int>(
            (active_limb_count + kTargetRows - 1) / kTargetRows));

    hybrid_modup_qp_forward_ntt_first_stage_row_tiled2_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            modup_q,
            modup_p,
            c2_coeff,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.ntt_tables.data(),
            parameter_shard.hybrid_q_conv_matrix_offsets.data(),
            parameter_shard.hybrid_q_conv_matrices.data(),
            parameter_shard.hybrid_p_conv_matrix_offsets.data(),
            parameter_shard.hybrid_p_conv_matrices.data(),
            parameter_shard.hybrid_qi_inv_punctured.data(),
            decomp_index,
            decomp_limb_begin,
            base_q_size,
            base_p_size,
            degree);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled kernel launch");
}

void launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    if (decomp_limb_count != 2)
    {
        launch_hybrid_modup_decomposition_forward_ntt_first_stage(
            modup_q,
            modup_p,
            c2_coeff,
            decomp_index,
            decomp_limb_begin,
            decomp_limb_count,
            parameter_shard,
            degree);
        return;
    }

    validate_hybrid_tables(
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8",
        parameter_shard,
        degree);
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr || c2_coeff == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8: null data pointer");
    }
    if (parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8: null NTT table pointer");
    }
    if (decomp_index >= parameter_shard.hybrid_decomp_count ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8: invalid decomposition range");
    }

    checked_log2_degree(
        degree,
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8");
    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8 cudaSetDevice");

    constexpr unsigned int kCoefficientTile = 32;
    constexpr unsigned int kTargetRows = 8;
    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    const dim3 block_size(kCoefficientTile, kTargetRows);
    const dim3 grid_size(
        static_cast<unsigned int>(
            ((degree >> 1) + kCoefficientTile - 1) / kCoefficientTile),
        static_cast<unsigned int>(
            (active_limb_count + kTargetRows - 1) / kTargetRows));

    hybrid_modup_qp_forward_ntt_first_stage_row_tiled8_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            modup_q,
            modup_p,
            c2_coeff,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.ntt_tables.data(),
            parameter_shard.hybrid_q_conv_matrix_offsets.data(),
            parameter_shard.hybrid_q_conv_matrices.data(),
            parameter_shard.hybrid_p_conv_matrix_offsets.data(),
            parameter_shard.hybrid_p_conv_matrices.data(),
            parameter_shard.hybrid_qi_inv_punctured.data(),
            decomp_index,
            decomp_limb_begin,
            base_q_size,
            base_p_size,
            degree);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8 kernel launch");
}

void launch_hybrid_modup_decomposition_row_tiled8(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    if (decomp_limb_count == 0 || decomp_limb_count > 9)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_row_tiled8: one through nine decomposition limbs are required");
    }
    validate_hybrid_tables(
        "launch_hybrid_modup_decomposition_row_tiled8",
        parameter_shard,
        degree);
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr || c2_coeff == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_row_tiled8: null data pointer");
    }
    if (decomp_index >= parameter_shard.hybrid_decomp_count ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_decomposition_row_tiled8: invalid decomposition range");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_modup_decomposition_row_tiled8 cudaSetDevice");
    constexpr unsigned int kCoefficientTile = 32;
    constexpr unsigned int kTargetRows = 8;
    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    const dim3 block_size(kCoefficientTile, kTargetRows);
    const dim3 grid_size(
        static_cast<unsigned int>(
            ((degree >> 1) + kCoefficientTile - 1) / kCoefficientTile),
        static_cast<unsigned int>(
            (active_limb_count + kTargetRows - 1) / kTargetRows));

    if (decomp_limb_count == 2)
    {
        hybrid_modup_qp_row_tiled8_kernel
            <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                modup_q,
                modup_p,
                c2_coeff,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.hybrid_q_conv_matrix_offsets.data(),
                parameter_shard.hybrid_q_conv_matrices.data(),
                parameter_shard.hybrid_p_conv_matrix_offsets.data(),
                parameter_shard.hybrid_p_conv_matrices.data(),
                parameter_shard.hybrid_qi_inv_punctured.data(),
                decomp_index,
                decomp_limb_begin,
                base_q_size,
                base_p_size,
                degree);
    }
    else
    {
#define POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(FIXED_COUNT)                   \
        hybrid_modup_qp_p9_row_tiled8_kernel<FIXED_COUNT>                 \
            <<<grid_size, block_size, 0, gpu_execution_stream()>>>(                                  \
                modup_q,                                                  \
                modup_p,                                                  \
                c2_coeff,                                                 \
                parameter_shard.rns_primes.data(),                        \
                parameter_shard.rns_modulus_constants.data(),             \
                parameter_shard.hybrid_q_conv_matrix_offsets.data(),      \
                parameter_shard.hybrid_q_conv_matrices.data(),            \
                parameter_shard.hybrid_p_conv_matrix_offsets.data(),      \
                parameter_shard.hybrid_p_conv_matrices.data(),            \
                parameter_shard.hybrid_qi_inv_punctured.data(),           \
                decomp_index,                                             \
                decomp_limb_begin,                                        \
                base_q_size,                                              \
                base_p_size,                                              \
                degree)

        switch (decomp_limb_count)
        {
        case 1:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(1);
            break;
        case 3:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(3);
            break;
        case 4:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(4);
            break;
        case 5:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(5);
            break;
        case 6:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(6);
            break;
        case 7:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(7);
            break;
        case 8:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(8);
            break;
        case 9:
            POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8(9);
            break;
        default:
            throw std::logic_error(
                "launch_hybrid_modup_decomposition_row_tiled8: unreachable decomposition width");
        }
#undef POSEIDON_LAUNCH_P9_MODUP_ROW_TILED8
    }
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_modup_decomposition_row_tiled8 kernel launch");
}

void launch_hybrid_preweight_modup_source_p9(
    GpuWord *weighted_source,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_preweight_modup_source_p9",
        parameter_shard,
        degree);
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (degree != 65536 || base_p_size != 9)
    {
        throw std::invalid_argument(
            "launch_hybrid_preweight_modup_source_p9: N=65536 and P=9 are required");
    }
    if (weighted_source == nullptr || c2_coeff == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_preweight_modup_source_p9: null data pointer");
    }
    if (decomp_index >= parameter_shard.hybrid_decomp_count ||
        decomp_limb_count == 0 || decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_preweight_modup_source_p9: invalid decomposition range");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_preweight_modup_source_p9 cudaSetDevice");
    constexpr unsigned int kBlockSize = 256;
    const std::size_t total = decomp_limb_count * degree;
    const unsigned int grid_size = static_cast<unsigned int>(
        (total + kBlockSize - 1) / kBlockSize);

#define POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(FIXED_COUNT)                   \
    hybrid_preweight_modup_source_p9_kernel<FIXED_COUNT>                 \
        <<<grid_size, kBlockSize, 0, gpu_execution_stream()>>>(                                     \
            weighted_source,                                             \
            c2_coeff,                                                     \
            parameter_shard.rns_primes.data(),                           \
            parameter_shard.rns_modulus_constants.data(),                \
            parameter_shard.hybrid_qi_inv_punctured.data(),              \
            decomp_index,                                                 \
            decomp_limb_begin,                                            \
            base_p_size,                                                  \
            degree)

    switch (decomp_limb_count)
    {
    case 1: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(1); break;
    case 2: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(2); break;
    case 3: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(3); break;
    case 4: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(4); break;
    case 5: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(5); break;
    case 6: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(6); break;
    case 7: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(7); break;
    case 8: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(8); break;
    case 9: POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT(9); break;
    default:
        throw std::logic_error(
            "launch_hybrid_preweight_modup_source_p9: unreachable decomposition width");
    }
#undef POSEIDON_LAUNCH_P9_MODUP_PREWEIGHT

    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_preweight_modup_source_p9 kernel launch");
}

#if 0
/* Retired all-dnum preparation launchers. */
void launch_hybrid_forward_ntt_qp(
    GpuWord *modup_q,
    GpuWord *modup_p,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_forward_ntt_qp",
        parameter_shard,
        degree);

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_forward_ntt_qp: null data pointer");
    }
    if (parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_forward_ntt_qp: null NTT table pointer");
    }
    if (decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument("launch_hybrid_forward_ntt_qp: invalid decomposition range");
    }
    if (parameter_shard.limb_begin != 0 ||
        parameter_shard.limb_count < base_q_size + base_p_size)
    {
        throw std::invalid_argument("launch_hybrid_forward_ntt_qp: parameter shard must cover full QP limb range");
    }
    if (parameter_shard.ntt_tables.size() <
        (base_q_size + base_p_size) * degree)
    {
        throw std::invalid_argument("launch_hybrid_forward_ntt_qp: NTT tables are too small");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_forward_ntt_qp cudaSetDevice");

    /* 计算真正需要做NTT的部分，decomp_limb_count在块内，之前有NTT形式不需要重复计算*/
    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    constexpr int kFusionStages = 3;
    constexpr int block_size = 256;
    std::size_t remaining_stages = checked_log2_degree(
        degree,
        "launch_hybrid_forward_ntt_qp");

    for (std::size_t m = 1, gap = degree >> 1;
         remaining_stages > 0;)
    {
        std::size_t stage_count = remaining_stages % kFusionStages;
        if (stage_count == 0)
        {
            stage_count = kFusionStages;
        }

        const std::size_t tiles_per_limb = degree >> stage_count;
        const std::size_t total_tiles = active_limb_count * tiles_per_limb;
        const int grid_size = static_cast<int>(
            (total_tiles + block_size - 1) / block_size);

        if (stage_count == 1)
        {
            hybrid_forward_ntt_modup_qp_stage_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                modup_q,
                modup_p,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                decomp_limb_begin,
                decomp_limb_count,
                base_q_size,
                base_p_size,
                degree,
                m,
                gap);
        }
        else if (stage_count == 2)
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<2>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        else
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<3>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        gpu_check_cuda(
            cudaGetLastError(),
            "launch_hybrid_forward_ntt_qp stage kernel launch");

        m <<= stage_count;
        gap >>= stage_count;
        remaining_stages -= stage_count;
    }
}

void launch_hybrid_forward_ntt_qp_prepare_final_tail(
    GpuWord *modup_q,
    GpuWord *modup_p,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_forward_ntt_qp_prepare_final_tail",
        parameter_shard,
        degree);

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_prepare_final_tail: null data pointer");
    }
    if (parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_prepare_final_tail: null NTT table pointer");
    }
    if (decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_prepare_final_tail: invalid decomposition range");
    }
    if (parameter_shard.limb_begin != 0 ||
        parameter_shard.limb_count < base_q_size + base_p_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_prepare_final_tail: parameter shard must cover full QP limb range");
    }

    const std::size_t degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_forward_ntt_qp_prepare_final_tail");
    constexpr std::size_t kFinalStages = 3;
    if (degree_power <= kFinalStages)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_prepare_final_tail: degree is too small");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_forward_ntt_qp_prepare_final_tail cudaSetDevice");

    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    constexpr std::size_t kFusionStages = 3;
    constexpr int block_size = 256;
    std::size_t remaining_stages = degree_power - 1;
    std::size_t m = 2;
    std::size_t gap = degree >> 2;

    while (remaining_stages > kFinalStages)
    {
        std::size_t stage_count = remaining_stages % kFusionStages;
        if (stage_count == 0)
        {
            stage_count = kFusionStages;
        }

        const std::size_t tiles_per_limb = degree >> stage_count;
        const std::size_t total_tiles = active_limb_count * tiles_per_limb;
        const int grid_size = static_cast<int>(
            (total_tiles + block_size - 1) / block_size);

        if (stage_count == 1)
        {
            hybrid_forward_ntt_modup_qp_stage_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                modup_q,
                modup_p,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                decomp_limb_begin,
                decomp_limb_count,
                base_q_size,
                base_p_size,
                degree,
                m,
                gap);
        }
        else if (stage_count == 2)
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<2>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        else
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<3>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        gpu_check_cuda(
            cudaGetLastError(),
            "launch_hybrid_forward_ntt_qp_prepare_final_tail stage kernel launch");

        m <<= stage_count;
        gap >>= stage_count;
        remaining_stages -= stage_count;
    }
}
#endif

void launch_hybrid_forward_ntt_qp_mul_accumulate_two_components(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool overwrite_accum,
    bool fuse_decomp_q,
    bool skip_first_ntt_stage)
{
    validate_hybrid_tables(
        "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components",
        parameter_shard,
        degree);

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (accum_q0 == nullptr || accum_p0 == nullptr ||
        accum_q1 == nullptr || accum_p1 == nullptr ||
        modup_q == nullptr || modup_p == nullptr ||
        c2_ntt == nullptr || key_q0 == nullptr || key_p0 == nullptr ||
        key_q1 == nullptr || key_p1 == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components: null data pointer");
    }
    if (parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components: null NTT table pointer");
    }
    if (decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components: invalid decomposition range");
    }
    if (parameter_shard.limb_begin != 0 ||
        parameter_shard.limb_count < base_q_size + base_p_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components: parameter shard must cover full QP limb range");
    }
    if (parameter_shard.ntt_tables.size() <
        (base_q_size + base_p_size) * degree)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components: NTT tables are too small");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components cudaSetDevice");

    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    constexpr int kFusionStages = 3;
    constexpr int block_size = 256;
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components");
    std::size_t remaining_stages = degree_power;
    std::size_t first_m = 1;
    std::size_t first_gap = degree >> 1;
    if (skip_first_ntt_stage)
    {
        if (degree_power < 2)
        {
            throw std::invalid_argument(
                "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components: cannot skip the first NTT stage for degree below four");
        }
        --remaining_stages;
        first_m <<= 1;
        first_gap >>= 1;
    }

    for (std::size_t m = first_m, gap = first_gap;
         remaining_stages > 0;)
    {
        std::size_t stage_count = remaining_stages % kFusionStages;
        if (stage_count == 0)
        {
            stage_count = kFusionStages;
        }

        const std::size_t tiles_per_limb = degree >> stage_count;
        const std::size_t total_tiles = active_limb_count * tiles_per_limb;
        const bool final_stage = remaining_stages == stage_count;
        const std::size_t total_tasks = final_stage && fuse_decomp_q
            ? total_tiles + decomp_limb_count * degree
            : total_tiles;
        const int grid_size = static_cast<int>(
            (total_tasks + block_size - 1) / block_size);

        if (final_stage)
        {
            if (stage_count == 1)
            {
                if (fuse_decomp_q)
                {
                    hybrid_forward_ntt_modup_qp_final_mul_accumulate_fused_decomp_q_kernel<1>
                        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                            accum_q0,
                            accum_p0,
                            accum_q1,
                            accum_p1,
                            modup_q,
                            modup_p,
                            c2_ntt,
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            parameter_shard.ntt_tables.data(),
                            key_q0,
                            key_p0,
                            key_q1,
                            key_p1,
                            decomp_limb_begin,
                            decomp_limb_count,
                            base_q_size,
                            base_p_size,
                            degree,
                            degree_power,
                            m,
                            gap,
                            overwrite_accum);
                }
                else
                {
                    hybrid_forward_ntt_modup_qp_final_mul_accumulate_kernel<1>
                        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                            accum_q0,
                            accum_p0,
                            accum_q1,
                            accum_p1,
                            modup_q,
                            modup_p,
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            parameter_shard.ntt_tables.data(),
                            key_q0,
                            key_p0,
                            key_q1,
                            key_p1,
                            decomp_limb_begin,
                            decomp_limb_count,
                            base_q_size,
                            base_p_size,
                            degree,
                            m,
                            gap,
                            overwrite_accum);
                }
            }
            else if (stage_count == 2)
            {
                if (fuse_decomp_q)
                {
                    hybrid_forward_ntt_modup_qp_final_mul_accumulate_fused_decomp_q_kernel<2>
                        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                            accum_q0,
                            accum_p0,
                            accum_q1,
                            accum_p1,
                            modup_q,
                            modup_p,
                            c2_ntt,
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            parameter_shard.ntt_tables.data(),
                            key_q0,
                            key_p0,
                            key_q1,
                            key_p1,
                            decomp_limb_begin,
                            decomp_limb_count,
                            base_q_size,
                            base_p_size,
                            degree,
                            degree_power,
                            m,
                            gap,
                            overwrite_accum);
                }
                else
                {
                    hybrid_forward_ntt_modup_qp_final_mul_accumulate_kernel<2>
                        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                            accum_q0,
                            accum_p0,
                            accum_q1,
                            accum_p1,
                            modup_q,
                            modup_p,
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            parameter_shard.ntt_tables.data(),
                            key_q0,
                            key_p0,
                            key_q1,
                            key_p1,
                            decomp_limb_begin,
                            decomp_limb_count,
                            base_q_size,
                            base_p_size,
                            degree,
                            m,
                            gap,
                            overwrite_accum);
                }
            }
            else
            {
                if (fuse_decomp_q)
                {
                    hybrid_forward_ntt_modup_qp_final_mul_accumulate_fused_decomp_q_kernel<3>
                        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                            accum_q0,
                            accum_p0,
                            accum_q1,
                            accum_p1,
                            modup_q,
                            modup_p,
                            c2_ntt,
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            parameter_shard.ntt_tables.data(),
                            key_q0,
                            key_p0,
                            key_q1,
                            key_p1,
                            decomp_limb_begin,
                            decomp_limb_count,
                            base_q_size,
                            base_p_size,
                            degree,
                            degree_power,
                            m,
                            gap,
                            overwrite_accum);
                }
                else
                {
                    hybrid_forward_ntt_modup_qp_final_mul_accumulate_kernel<3>
                        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                            accum_q0,
                            accum_p0,
                            accum_q1,
                            accum_p1,
                            modup_q,
                            modup_p,
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            parameter_shard.ntt_tables.data(),
                            key_q0,
                            key_p0,
                            key_q1,
                            key_p1,
                            decomp_limb_begin,
                            decomp_limb_count,
                            base_q_size,
                            base_p_size,
                            degree,
                            m,
                            gap,
                            overwrite_accum);
                }
            }
        }
        else if (stage_count == 1)
        {
            hybrid_forward_ntt_modup_qp_stage_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                modup_q,
                modup_p,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                decomp_limb_begin,
                decomp_limb_count,
                base_q_size,
                base_p_size,
                degree,
                m,
                gap);
        }
        else if (stage_count == 2)
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<2>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        else
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<3>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        gpu_check_cuda(
            cudaGetLastError(),
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components stage kernel launch");

        m <<= stage_count;
        gap >>= stage_count;
        remaining_stages -= stage_count;
    }

    if (!fuse_decomp_q)
    {
        const std::size_t decomp_total = decomp_limb_count * degree;
        const int decomp_grid_size = static_cast<int>(
            (decomp_total + block_size - 1) / block_size);
        hybrid_decomp_q_multiply_accumulate_two_components_kernel
            <<<decomp_grid_size, block_size, 0, gpu_execution_stream()>>>(
                accum_q0,
                accum_q1,
                c2_ntt,
                key_q0,
                key_q1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                degree,
                degree_power,
                decomp_limb_begin,
                decomp_limb_count,
                overwrite_accum);
        gpu_check_cuda(
            cudaGetLastError(),
            "launch_hybrid_forward_ntt_qp_mul_accumulate_two_components baseline decomp Q kernel launch");
    }
}

#if 0
/* Retired all-dnum PAccum launchers. */
void launch_hybrid_paccum_all_dnum_two_components(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *all_modup_q,
    const GpuWord *all_modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *const *key_qp0_by_dnum,
    const GpuWord *const *key_qp1_by_dnum,
    std::size_t decomp_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_paccum_all_dnum_two_components",
        parameter_shard,
        degree);
    if (accum_q0 == nullptr || accum_p0 == nullptr ||
        accum_q1 == nullptr || accum_p1 == nullptr ||
        all_modup_q == nullptr || all_modup_p == nullptr ||
        c2_ntt == nullptr ||
        key_qp0_by_dnum == nullptr || key_qp1_by_dnum == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_paccum_all_dnum_two_components: null data pointer");
    }
    if (decomp_count == 0 ||
        decomp_count > parameter_shard.hybrid_decomp_count)
    {
        throw std::invalid_argument(
            "launch_hybrid_paccum_all_dnum_two_components: invalid decomposition count");
    }
    if (parameter_shard.limb_begin != 0 ||
        parameter_shard.limb_count <
            parameter_shard.hybrid_base_q_count +
                parameter_shard.hybrid_base_p_count)
    {
        throw std::invalid_argument(
            "launch_hybrid_paccum_all_dnum_two_components: parameter shard must cover full QP limb range");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_paccum_all_dnum_two_components cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = (base_q_size + base_p_size) * degree;
    if (total == 0)
    {
        return;
    }

    constexpr int block_size = 256;
    const int grid_size =
        static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_paccum_all_dnum_two_components");

    hybrid_paccum_all_dnum_two_components_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            accum_q0,
            accum_p0,
            accum_q1,
            accum_p1,
            all_modup_q,
            all_modup_p,
            c2_ntt,
            key_qp0_by_dnum,
            key_qp1_by_dnum,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            decomp_count,
            base_q_size,
            base_p_size,
            degree,
            degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_paccum_all_dnum_two_components kernel launch");
}

void launch_hybrid_final_ntt_paccum_all_dnum_two_components(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *all_modup_q,
    const GpuWord *all_modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *const *key_qp0_by_dnum,
    const GpuWord *const *key_qp1_by_dnum,
    std::size_t decomp_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_final_ntt_paccum_all_dnum_two_components",
        parameter_shard,
        degree);
    if (accum_q0 == nullptr || accum_p0 == nullptr ||
        accum_q1 == nullptr || accum_p1 == nullptr ||
        all_modup_q == nullptr || all_modup_p == nullptr ||
        c2_ntt == nullptr ||
        key_qp0_by_dnum == nullptr || key_qp1_by_dnum == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_final_ntt_paccum_all_dnum_two_components: null data pointer");
    }
    if (decomp_count == 0 ||
        decomp_count > parameter_shard.hybrid_decomp_count)
    {
        throw std::invalid_argument(
            "launch_hybrid_final_ntt_paccum_all_dnum_two_components: invalid decomposition count");
    }
    if (parameter_shard.limb_begin != 0 ||
        parameter_shard.limb_count <
            parameter_shard.hybrid_base_q_count +
                parameter_shard.hybrid_base_p_count)
    {
        throw std::invalid_argument(
            "launch_hybrid_final_ntt_paccum_all_dnum_two_components: parameter shard must cover full QP limb range");
    }

    constexpr std::size_t kFinalStages = 3;
    const std::size_t degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_final_ntt_paccum_all_dnum_two_components");
    if (degree_power <= kFinalStages)
    {
        throw std::invalid_argument(
            "launch_hybrid_final_ntt_paccum_all_dnum_two_components: degree is too small");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_final_ntt_paccum_all_dnum_two_components cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total_tiles =
        (base_q_size + base_p_size) * (degree >> kFinalStages);
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>(
        (total_tiles + block_size - 1) / block_size);

    hybrid_final_ntt_paccum_all_dnum_two_components_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            accum_q0,
            accum_p0,
            accum_q1,
            accum_p1,
            all_modup_q,
            all_modup_p,
            c2_ntt,
            key_qp0_by_dnum,
            key_qp1_by_dnum,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.ntt_tables.data(),
            decomp_count,
            base_q_size,
            base_p_size,
            degree);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_final_ntt_paccum_all_dnum_two_components kernel launch");
}
#endif

void launch_hybrid_forward_ntt_qp_active(
    GpuWord *modup_q,
    GpuWord *modup_p,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_forward_ntt_qp_active",
        parameter_shard,
        degree);
    const std::size_t base_q_size =
        parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size =
        parameter_shard.hybrid_base_p_count;
    if (modup_q == nullptr || modup_p == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_active: null data pointer");
    }
    if (decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_active: invalid decomposition range");
    }
    if (parameter_shard.ntt_tables.size() <
        (base_q_size + base_p_size) * degree)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_qp_active: incomplete NTT tables");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_forward_ntt_qp_active cudaSetDevice");
    const std::size_t active_limb_count =
        base_q_size - decomp_limb_count + base_p_size;
    constexpr int kFusionStages = 3;
    constexpr int block_size = 256;
    std::size_t remaining_stages = checked_log2_degree(
        degree,
        "launch_hybrid_forward_ntt_qp_active");

    for (std::size_t m = 1, gap = degree >> 1;
         remaining_stages > 0;)
    {
        std::size_t stage_count =
            remaining_stages % kFusionStages;
        if (stage_count == 0)
        {
            stage_count = kFusionStages;
        }
        const std::size_t tiles_per_limb =
            degree >> stage_count;
        const std::size_t total_tiles =
            active_limb_count * tiles_per_limb;
        const int grid_size = static_cast<int>(
            (total_tiles + block_size - 1) / block_size);

        if (stage_count == 1)
        {
            hybrid_forward_ntt_modup_qp_stage_kernel
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        else if (stage_count == 2)
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<2>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        else
        {
            hybrid_forward_ntt_modup_qp_fused_stage_kernel<3>
                <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
                    modup_q,
                    modup_p,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    base_q_size,
                    base_p_size,
                    degree,
                    m,
                    gap);
        }
        gpu_check_cuda(
            cudaGetLastError(),
            "launch_hybrid_forward_ntt_qp_active kernel launch");
        m <<= stage_count;
        gap >>= stage_count;
        remaining_stages -= stage_count;
    }
}

void launch_hybrid_multiply_accumulate(
    GpuWord *accum_q,
    GpuWord *accum_p,
    const GpuWord *modup_q,
    const GpuWord *modup_p,
    const GpuWord *key_qp,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_multiply_accumulate",
        parameter_shard,
        degree);
    if (accum_q == nullptr || accum_p == nullptr ||
        modup_q == nullptr || modup_p == nullptr || key_qp == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_multiply_accumulate: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_multiply_accumulate cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = (base_q_size + base_p_size) * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_multiply_accumulate");

    hybrid_multiply_accumulate_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        accum_q,
        accum_p,
        modup_q,
        modup_p,
        key_qp,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        base_q_size,
        base_p_size,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_multiply_accumulate kernel launch");
}

void launch_hybrid_multiply_accumulate_two_components(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *modup_q,
    const GpuWord *modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    bool overwrite_accum)
{
    validate_hybrid_tables(
        "launch_hybrid_multiply_accumulate_two_components",
        parameter_shard,
        degree);
    if (accum_q0 == nullptr || accum_p0 == nullptr ||
        accum_q1 == nullptr || accum_p1 == nullptr ||
        modup_q == nullptr || modup_p == nullptr || c2_ntt == nullptr ||
        key_q0 == nullptr || key_p0 == nullptr ||
        key_q1 == nullptr || key_p1 == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_multiply_accumulate_two_components: null data pointer");
    }
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (decomp_limb_count == 0 ||
        decomp_limb_count > base_p_size ||
        decomp_limb_begin + decomp_limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_multiply_accumulate_two_components: invalid decomposition range");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_multiply_accumulate_two_components cudaSetDevice");

    const std::size_t total = (base_q_size + base_p_size) * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_multiply_accumulate_two_components");

    hybrid_multiply_accumulate_two_components_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        accum_q0,
        accum_p0,
        accum_q1,
        accum_p1,
        modup_q,
        modup_p,
        c2_ntt,
        key_q0,
        key_p0,
        key_q1,
        key_p1,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        base_q_size,
        base_p_size,
        degree,
        degree_power,
        decomp_limb_begin,
        decomp_limb_count,
        overwrite_accum);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_multiply_accumulate_two_components kernel launch");
}

void launch_hybrid_moddown(
    GpuWord *accum_q,
    const GpuWord *accum_p,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_moddown",
        parameter_shard,
        degree);
    if (accum_q == nullptr || accum_p == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_moddown: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_moddown cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = base_q_size * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_moddown");

    hybrid_moddown_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        accum_q,
        accum_p,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
        parameter_shard.hybrid_p_inv_punctured.data(),
        parameter_shard.hybrid_inv_p_mod_q.data(),
        base_q_size,
        base_p_size,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_moddown kernel launch");
}

void launch_hybrid_convert_p_to_q(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_convert_p_to_q",
        parameter_shard,
        degree);
    if (converted_q0 == nullptr || converted_q1 == nullptr ||
        accum_p0 == nullptr || accum_p1 == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_convert_p_to_q: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_convert_p_to_q cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = base_q_size * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_convert_p_to_q");

    hybrid_convert_p_to_q_two_components_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        converted_q0,
        converted_q1,
        accum_p0,
        accum_p1,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
        parameter_shard.hybrid_p_inv_punctured.data(),
        base_q_size,
        base_p_size,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_convert_p_to_q kernel launch");
}

void launch_hybrid_convert_p_to_q_coeff_lazy(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *p_coeff0,
    const GpuWord *p_coeff1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted)
{
    const char *name = "launch_hybrid_convert_p_to_q_coeff_lazy";
    validate_hybrid_tables(name, parameter_shard, degree);
    if (converted_q0 == nullptr || converted_q1 == nullptr ||
        p_coeff0 == nullptr || p_coeff1 == nullptr)
        throw std::invalid_argument(std::string(name) + ": null data pointer");
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    constexpr int block_size = 256;
    constexpr int q_tile = 4;
    const std::size_t tiles = (base_q_size + q_tile - 1) / q_tile;
    const int grid = static_cast<int>((tiles * (degree >> 1) + block_size - 1) / block_size);
    if (source_preweighted && base_p_size <= kPToQPreweightMaxP)
    {
        if (try_launch_hybrid_convert_p_to_q_cta_tiled_65536(
                converted_q0, converted_q1, p_coeff0, p_coeff1,
                parameter_shard, 2, true, degree))
        {
            gpu_check_cuda(cudaGetLastError(), name);
            return;
        }
        const int dual_cfg = opt_flag_value(OptFlag::PToQDualTile);
        const int pw_tile = select_adaptive_tile_4_6_8(base_q_size, dual_cfg > 0 ? dual_cfg : 4);
        const std::size_t pw_tiles = (base_q_size + pw_tile - 1) / pw_tile;
        const int pw_grid = static_cast<int>((pw_tiles * (degree >> 1) + block_size - 1) / block_size);
        const unsigned int deg_pow = checked_log2_degree(degree, name);
        const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_DUAL_PTOQ_COEFF(T)                                                     \
        hybrid_convert_p_to_q_lazy_preweighted_kernel<T, 2>                                    \
            <<<pw_grid, block_size, 0, gpu_execution_stream()>>>(                              \
                converted_q0, converted_q1, p_coeff0, p_coeff1,                                \
                parameter_shard.rns_primes.data(),                                             \
                parameter_shard.rns_modulus_constants.data(),                                  \
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),                           \
                static_cast<unsigned int>(base_q_size),                                        \
                static_cast<unsigned int>(base_p_size), deg_pow, vec_bconv)
        if (pw_tile == 8) { POSEIDON_LAUNCH_DUAL_PTOQ_COEFF(8); }
        else if (pw_tile == 6) { POSEIDON_LAUNCH_DUAL_PTOQ_COEFF(6); }
        else { POSEIDON_LAUNCH_DUAL_PTOQ_COEFF(4); }
#undef POSEIDON_LAUNCH_DUAL_PTOQ_COEFF
        gpu_check_cuda(cudaGetLastError(), name);
        return;
    }
    hybrid_convert_p_to_q_forward_ntt_first_stage_lazy_kernel<q_tile, false>
        <<<grid, block_size, 0, gpu_execution_stream()>>>(
            converted_q0,
            converted_q1,
            p_coeff0,
            p_coeff1,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.ntt_tables.data(),
            parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
            parameter_shard.hybrid_p_inv_punctured.data(),
            base_q_size,
            base_p_size,
            degree,
            checked_log2_degree(degree, name),
            false);
    gpu_check_cuda(cudaGetLastError(), name);
}

bool launch_hybrid_convert_p_to_q_forward_ntt_single_preweighted(
    GpuWord *converted_q,
    const GpuWord *accum_p,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    if (degree != 65536 || !lazy_base_conversion_enabled() ||
        base_p_size <= 2 || (base_p_size == 9 && !opt_flag(OptFlag::UnifyP9)) ||
        base_p_size > kPToQPreweightMaxP || converted_q == nullptr || accum_p == nullptr)
    {
        return false;
    }
    const char *name = "launch_hybrid_convert_p_to_q_forward_ntt_single_preweighted";
    validate_hybrid_tables(name, parameter_shard, degree);
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);
    if (!try_launch_hybrid_convert_p_to_q_cta_tiled_65536(
            converted_q, nullptr, accum_p, nullptr,
            parameter_shard, 1, false, degree))
    {
        constexpr int block_size = 256;
        const int ptoq_cfg = opt_flag_value(OptFlag::PToQTile);
        const int q_tile = select_adaptive_tile_4_8_12_16(base_q_size, ptoq_cfg > 0 ? ptoq_cfg : 4);
        const std::size_t tiles = (base_q_size + q_tile - 1) / q_tile;
        const int grid = static_cast<int>((tiles * (degree >> 1) + block_size - 1) / block_size);
        const unsigned int deg_pow = checked_log2_degree(degree, name);
        const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_SINGLE_PTOQ(T)                                                         \
        hybrid_convert_p_to_q_lazy_preweighted_kernel<T, 1>                                    \
            <<<grid, block_size, 0, gpu_execution_stream()>>>(                                 \
                converted_q, nullptr, accum_p, nullptr,                                        \
                parameter_shard.rns_primes.data(),                                             \
                parameter_shard.rns_modulus_constants.data(),                                  \
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),                           \
                static_cast<unsigned int>(base_q_size),                                        \
                static_cast<unsigned int>(base_p_size), deg_pow, vec_bconv)
        if (q_tile == 16) { POSEIDON_LAUNCH_SINGLE_PTOQ(16); }
        else if (q_tile == 12) { POSEIDON_LAUNCH_SINGLE_PTOQ(12); }
        else if (q_tile == 8) { POSEIDON_LAUNCH_SINGLE_PTOQ(8); }
        else { POSEIDON_LAUNCH_SINGLE_PTOQ(4); }
#undef POSEIDON_LAUNCH_SINGLE_PTOQ
    }
    gpu_check_cuda(cudaGetLastError(), name);
    launch_forward_ntt_limbs_inplace_fourstep_65536(converted_q, 0, base_q_size, parameter_shard);
    return true;
}

void launch_hybrid_convert_p_to_q_forward_ntt(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted)
{
    validate_hybrid_tables(
        "launch_hybrid_convert_p_to_q_forward_ntt",
        parameter_shard,
        degree);
    if (converted_q0 == nullptr || converted_q1 == nullptr ||
        accum_p0 == nullptr || accum_p1 == nullptr ||
        parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_convert_p_to_q_forward_ntt: null data pointer");
    }
    if (degree < 2)
    {
        throw std::invalid_argument(
            "launch_hybrid_convert_p_to_q_forward_ntt: degree must be at least two");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_convert_p_to_q_forward_ntt cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_convert_p_to_q_forward_ntt");
    constexpr int block_size = 256;
    const std::size_t first_stage_total = base_q_size * (degree >> 1);
    const int first_stage_grid = static_cast<int>(
        (first_stage_total + block_size - 1) / block_size);

    if (lazy_base_conversion_enabled() && base_p_size > 2 &&
        (base_p_size != 9 || opt_flag(OptFlag::UnifyP9)))
    {
        // Generic P (3..8 and >9): tiled, lazily reduced; P=2 and
        // P=9 keep their tuned kernels below.
        constexpr int q_tile = 4;
        const std::size_t tiles = (base_q_size + q_tile - 1) / q_tile;
        const int lazy_grid = static_cast<int>(
            (tiles * (degree >> 1) + block_size - 1) / block_size);
        static const bool fourstep = [] {
            const char *raw = std::getenv("POSEIDON_GPU_MODDOWN_FOURSTEP");
            return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
        }();
        if (fourstep && degree == 65536 && source_preweighted &&
            opt_flag(OptFlag::PToQPreweight) && base_p_size <= kPToQPreweightMaxP)
        {
            if (!try_launch_hybrid_convert_p_to_q_cta_tiled_65536(
                    converted_q0, converted_q1, accum_p0, accum_p1,
                    parameter_shard, 2, true, degree))
            {
                const int dual_cfg = opt_flag_value(OptFlag::PToQDualTile);
                const int pw_tile = select_adaptive_tile_4_6_8(base_q_size, dual_cfg > 0 ? dual_cfg : 4);
                const std::size_t pw_tiles = (base_q_size + pw_tile - 1) / pw_tile;
                const int pw_grid = static_cast<int>(
                    (pw_tiles * (degree >> 1) + block_size - 1) / block_size);
                const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_DUAL_PTOQ_NTT(T)                                                       \
                hybrid_convert_p_to_q_lazy_preweighted_kernel<T, 2>                            \
                    <<<pw_grid, block_size, 0, gpu_execution_stream()>>>(                      \
                        converted_q0, converted_q1, accum_p0, accum_p1,                        \
                        parameter_shard.rns_primes.data(),                                     \
                        parameter_shard.rns_modulus_constants.data(),                          \
                        parameter_shard.hybrid_moddown_p_to_q_matrix.data(),                   \
                        static_cast<unsigned int>(base_q_size),                                \
                        static_cast<unsigned int>(base_p_size), degree_power, vec_bconv)
                if (pw_tile == 8) { POSEIDON_LAUNCH_DUAL_PTOQ_NTT(8); }
                else if (pw_tile == 6) { POSEIDON_LAUNCH_DUAL_PTOQ_NTT(6); }
                else { POSEIDON_LAUNCH_DUAL_PTOQ_NTT(4); }
#undef POSEIDON_LAUNCH_DUAL_PTOQ_NTT
            }
            gpu_check_cuda(cudaGetLastError(),
                           "launch_hybrid_convert_p_to_q_forward_ntt preweighted conversion launch");
            launch_forward_ntt_two_components_inplace_fourstep_65536(
                converted_q0, converted_q1, base_q_size, parameter_shard);
            return;
        }
        if (fourstep && degree == 65536)
        {
            // Convert into coefficient form, then two-phase NTT for both
            // components instead of the stage-by-stage tail.
            hybrid_convert_p_to_q_forward_ntt_first_stage_lazy_kernel<q_tile, false>
                <<<lazy_grid, block_size, 0, gpu_execution_stream()>>>(
                    converted_q0,
                    converted_q1,
                    accum_p0,
                    accum_p1,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    parameter_shard.ntt_tables.data(),
                    parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                    parameter_shard.hybrid_p_inv_punctured.data(),
                    base_q_size,
                    base_p_size,
                    degree,
                    degree_power,
                    source_preweighted);
            gpu_check_cuda(cudaGetLastError(),
                           "launch_hybrid_convert_p_to_q_forward_ntt lazy conversion launch");
            launch_forward_ntt_two_components_inplace_fourstep_65536(
                converted_q0, converted_q1, base_q_size, parameter_shard);
            return;
        }
        hybrid_convert_p_to_q_forward_ntt_first_stage_lazy_kernel<q_tile>
            <<<lazy_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power,
                source_preweighted);
    }
    else if (base_p_size == 2 && source_preweighted)
    {
        hybrid_convert_p_to_q_forward_ntt_first_stage_kernel<2, true>
            <<<first_stage_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    else if (base_p_size == 2)
    {
        hybrid_convert_p_to_q_forward_ntt_first_stage_kernel<2, false>
            <<<first_stage_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    else if (base_p_size == 9 && source_preweighted)
    {
        hybrid_convert_p_to_q_forward_ntt_first_stage_kernel<9, true>
            <<<first_stage_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    else if (base_p_size == 9)
    {
        hybrid_convert_p_to_q_forward_ntt_first_stage_kernel<9, false>
            <<<first_stage_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    else if (source_preweighted)
    {
        hybrid_convert_p_to_q_forward_ntt_first_stage_kernel<0, true>
            <<<first_stage_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    else
    {
        hybrid_convert_p_to_q_forward_ntt_first_stage_kernel<0, false>
            <<<first_stage_grid, block_size, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                base_p_size,
                degree,
                degree_power);
    }
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_convert_p_to_q_forward_ntt first-stage kernel launch");

    launch_hybrid_forward_ntt_q_two_components_stages(
        converted_q0,
        converted_q1,
        parameter_shard,
        degree,
        degree_power,
        1,
        "launch_hybrid_convert_p_to_q_forward_ntt remaining-stage kernel launch");
}

const GpuWord *hybrid_q_preweighted_inv_degree_table(
    const GpuParameterShard &parameter_shard)
{
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = parameter_shard.inv_degree_modulo.size();
    if (base_p_size == 0 || base_q_size == 0 || total < base_q_size ||
        parameter_shard.hybrid_qi_inv_punctured.size() < base_q_size ||
        parameter_shard.hybrid_decomp_count * base_p_size < base_q_size ||
        parameter_shard.rns_primes.size() < base_q_size)
    {
        return nullptr;
    }
    auto &table = parameter_shard.opt_q_preweighted_inv_degree;
    if (table.size() != total)
    {
        gpu_check_cuda(cudaSetDevice(parameter_shard.device_id),
                       "hybrid_q_preweighted_inv_degree_table cudaSetDevice");
        table.allocate(total, parameter_shard.device_id);
        constexpr int block_size = 256;
        build_q_preweighted_inv_degree_kernel<<<
            static_cast<unsigned int>((total + block_size - 1) / block_size), block_size, 0,
            gpu_execution_stream()>>>(
            table.data(),
            parameter_shard.inv_degree_modulo.data(),
            parameter_shard.hybrid_qi_inv_punctured.data(),
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            static_cast<unsigned int>(base_q_size),
            static_cast<unsigned int>(total));
        gpu_check_cuda(cudaGetLastError(), "build_q_preweighted_inv_degree_kernel launch");
    }
    return table.data();
}

bool modup_fold_applicable(std::size_t degree)
{
    return opt_flag(OptFlag::ModupFold) && opt_flag(OptFlag::ModupPreweight) &&
        lazy_base_conversion_enabled() && degree == 65536;
}

const GpuWord *hybrid_p_preweighted_inv_degree_table(
    const GpuParameterShard &parameter_shard)
{
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = parameter_shard.inv_degree_modulo.size();
    if (base_p_size == 0 || total < base_q_size + base_p_size ||
        parameter_shard.hybrid_p_inv_punctured.size() < base_p_size ||
        parameter_shard.rns_primes.size() < base_q_size + base_p_size)
    {
        return nullptr;
    }
    auto &table = parameter_shard.opt_p_preweighted_inv_degree;
    if (table.size() != total)
    {
        gpu_check_cuda(cudaSetDevice(parameter_shard.device_id),
                       "hybrid_p_preweighted_inv_degree_table cudaSetDevice");
        table.allocate(total, parameter_shard.device_id);
        constexpr int block_size = 256;
        build_p_preweighted_inv_degree_kernel<<<
            static_cast<unsigned int>((total + block_size - 1) / block_size), block_size, 0,
            gpu_execution_stream()>>>(
            table.data(),
            parameter_shard.inv_degree_modulo.data(),
            parameter_shard.hybrid_p_inv_punctured.data(),
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            static_cast<unsigned int>(base_q_size),
            static_cast<unsigned int>(base_p_size),
            static_cast<unsigned int>(total));
        gpu_check_cuda(cudaGetLastError(), "build_p_preweighted_inv_degree_kernel launch");
    }
    return table.data();
}

void launch_hybrid_preweight_p_two_components(
    GpuWord *accum_p0,
    GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_preweight_p_two_components",
        parameter_shard,
        degree);
    if (accum_p0 == nullptr || accum_p1 == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_preweight_p_two_components: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_preweight_p_two_components cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t base_p_size = parameter_shard.hybrid_base_p_count;
    const std::size_t total = base_p_size * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>(
        (total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_preweight_p_two_components");

    hybrid_preweight_p_two_components_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        accum_p0,
        accum_p1,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        parameter_shard.hybrid_p_inv_punctured.data(),
        base_q_size,
        base_p_size,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_preweight_p_two_components kernel launch");
}

void launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted)
{
    validate_hybrid_tables(
        "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8",
        parameter_shard,
        degree);
    if (converted_q0 == nullptr || converted_q1 == nullptr ||
        accum_p0 == nullptr || accum_p1 == nullptr ||
        parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8: null data pointer");
    }
    const std::size_t base_p_size =
        parameter_shard.hybrid_base_p_count;
    if (base_p_size != 2 && base_p_size != 9)
    {
        throw std::invalid_argument(
            "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8: requires two or nine P limbs");
    }
    if (degree < 2)
    {
        throw std::invalid_argument(
            "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8: degree must be at least two");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8 cudaSetDevice");

    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kTargetRows = 8;
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8");
    const std::size_t butterflies_per_limb = degree >> 1;
    const dim3 block_dim(kCoefficientTile, kTargetRows);
    const dim3 grid_dim(
        static_cast<unsigned int>(
            (butterflies_per_limb + kCoefficientTile - 1) /
            kCoefficientTile),
        static_cast<unsigned int>(
            (base_q_size + kTargetRows - 1) / kTargetRows));

    if (base_p_size == 2)
    {
        if (source_preweighted)
        {
            throw std::invalid_argument(
                "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8: preweighted P=2 source is unsupported");
        }
        hybrid_convert_p_to_q_forward_ntt_first_stage_row_tiled8_kernel
            <<<grid_dim, block_dim, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                degree);
    }
    else if (source_preweighted)
    {
        hybrid_convert_p9_to_q_forward_ntt_first_stage_row_tiled8_kernel<true>
            <<<grid_dim, block_dim, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                degree);
    }
    else
    {
        hybrid_convert_p9_to_q_forward_ntt_first_stage_row_tiled8_kernel<false>
            <<<grid_dim, block_dim, 0, gpu_execution_stream()>>>(
                converted_q0,
                converted_q1,
                accum_p0,
                accum_p1,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                parameter_shard.ntt_tables.data(),
                parameter_shard.hybrid_moddown_p_to_q_matrix.data(),
                parameter_shard.hybrid_p_inv_punctured.data(),
                base_q_size,
                degree);
    }
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8 first-stage kernel launch");

    launch_hybrid_forward_ntt_q_two_components_stages(
        converted_q0,
        converted_q1,
        parameter_shard,
        degree,
        degree_power,
        1,
        "launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8 remaining-stage kernel launch");
}

void launch_hybrid_forward_ntt_q_two_components(
    GpuWord *values0,
    GpuWord *values1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_forward_ntt_q_two_components",
        parameter_shard,
        degree);
    if (values0 == nullptr || values1 == nullptr ||
        parameter_shard.ntt_tables.data() == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_forward_ntt_q_two_components: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_forward_ntt_q_two_components cudaSetDevice");
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_forward_ntt_q_two_components");
    launch_hybrid_forward_ntt_q_two_components_stages(
        values0,
        values1,
        parameter_shard,
        degree,
        degree_power,
        0,
        "launch_hybrid_forward_ntt_q_two_components stage kernel launch");
}

void launch_hybrid_apply_moddown_ntt(
    GpuWord *accum_q0,
    GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_apply_moddown_ntt",
        parameter_shard,
        degree);
    if (accum_q0 == nullptr || accum_q1 == nullptr ||
        converted_q0 == nullptr || converted_q1 == nullptr)
    {
        throw std::invalid_argument("launch_hybrid_apply_moddown_ntt: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_apply_moddown_ntt cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t total = base_q_size * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_apply_moddown_ntt");

    hybrid_apply_moddown_ntt_two_components_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        accum_q0,
        accum_q1,
        converted_q0,
        converted_q1,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        parameter_shard.hybrid_inv_p_mod_q.data(),
        base_q_size,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_apply_moddown_ntt kernel launch");
}

void launch_hybrid_apply_moddown_ntt_out_of_place(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_apply_moddown_ntt_out_of_place",
        parameter_shard,
        degree);
    if (destination_q0 == nullptr || destination_q1 == nullptr ||
        source_q0 == nullptr || source_q1 == nullptr ||
        converted_q0 == nullptr || converted_q1 == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_out_of_place: null data pointer");
    }

    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_apply_moddown_ntt_out_of_place cudaSetDevice");

    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t total = base_q_size * degree;
    constexpr int block_size = 256;
    const int grid_size =
        static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_apply_moddown_ntt_out_of_place");

    hybrid_apply_moddown_ntt_out_of_place_two_components_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            destination_q0,
            destination_q1,
            source_q0,
            source_q1,
            converted_q0,
            converted_q1,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            base_q_size,
            degree,
            degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_apply_moddown_ntt_out_of_place kernel launch");
}

void launch_hybrid_apply_moddown_ntt_out_of_place_batch(
    GpuWord *destination_q,
    const GpuWord *source_q,
    const GpuWord *converted_q,
    std::size_t batch_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_apply_moddown_ntt_out_of_place_batch",
        parameter_shard,
        degree);
    if (destination_q == nullptr || source_q == nullptr ||
        converted_q == nullptr || batch_count == 0)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_out_of_place_batch: invalid argument");
    }
    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_apply_moddown_ntt_out_of_place_batch cudaSetDevice");

    const std::size_t base_q_size =
        parameter_shard.hybrid_base_q_count;
    const std::size_t total =
        batch_count * 2 * base_q_size * degree;
    constexpr int block_size = 256;
    const int grid_size =
        static_cast<int>((total + block_size - 1) / block_size);
    hybrid_apply_moddown_ntt_out_of_place_batch_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            destination_q,
            source_q,
            converted_q,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            batch_count,
            base_q_size,
            degree,
            checked_log2_degree(
                degree,
                "launch_hybrid_apply_moddown_ntt_out_of_place_batch"));
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_apply_moddown_ntt_out_of_place_batch kernel launch");
}

void launch_hybrid_apply_moddown_ntt_selected(
    GpuWord *destination_q,
    const GpuWord *source_q,
    const GpuWord *converted_q,
    const std::uint32_t *component_indices,
    std::size_t component_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name = "launch_hybrid_apply_moddown_ntt_selected";
    validate_hybrid_tables(name, parameter_shard, degree);
    if (destination_q == nullptr || source_q == nullptr ||
        converted_q == nullptr || component_indices == nullptr ||
        component_count == 0 ||
        component_count > kMaxSelectedModDownComponents)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);
    SelectedModDownComponents components{};
    for (std::size_t slot = 0; slot < component_count; ++slot)
    {
        components.index[slot] = component_indices[slot];
    }
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    const std::size_t total = component_count * base_q_size * degree;
    constexpr int block_size = 256;
    const int grid_size =
        static_cast<int>((total + block_size - 1) / block_size);
    hybrid_apply_moddown_ntt_selected_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            destination_q,
            source_q,
            converted_q,
            components,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            component_count,
            base_q_size,
            degree,
            checked_log2_degree(degree, name));
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_hybrid_apply_moddown_ntt_from_q_groups(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *group_q,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    std::size_t group_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_apply_moddown_ntt_from_q_groups",
        parameter_shard,
        degree);
    if (destination_q0 == nullptr || destination_q1 == nullptr ||
        group_q == nullptr || converted_q0 == nullptr ||
        converted_q1 == nullptr || group_count == 0)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_from_q_groups: "
            "invalid argument");
    }
    gpu_check_cuda(
        cudaSetDevice(parameter_shard.device_id),
        "launch_hybrid_apply_moddown_ntt_from_q_groups cudaSetDevice");
    constexpr int block_size = 256;
    const std::size_t total =
        parameter_shard.hybrid_base_q_count * degree;
    const int grid_size =
        static_cast<int>((total + block_size - 1) / block_size);
    hybrid_apply_moddown_ntt_from_q_groups_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            destination_q0,
            destination_q1,
            group_q,
            converted_q0,
            converted_q1,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            group_count,
            parameter_shard.hybrid_base_q_count,
            degree,
            checked_log2_degree(
                degree,
                "launch_hybrid_apply_moddown_ntt_from_q_groups"));
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_apply_moddown_ntt_from_q_groups kernel launch");
}

void launch_hybrid_apply_moddown_ntt_add_back(
    const GpuPolyShardView &destination_shard0,
    const GpuPolyShardView &destination_shard1,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuConstPolyShardView *add_source_shard0,
    const GpuConstPolyShardView *add_source_shard1)
{
    validate_hybrid_tables(
        "launch_hybrid_apply_moddown_ntt_add_back",
        parameter_shard,
        degree);
    if (destination_shard0.ptr == nullptr ||
        destination_shard1.ptr == nullptr ||
        accum_q0 == nullptr || accum_q1 == nullptr ||
        converted_q0 == nullptr || converted_q1 == nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: null data pointer");
    }
    if (destination_shard0.device_id != destination_shard1.device_id ||
        destination_shard0.device_id != parameter_shard.device_id)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: device mismatch");
    }
    if (degree == 0 ||
        destination_shard0.limb_count == 0 ||
        destination_shard0.coeff_count != degree)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: invalid shard shape");
    }
    if (destination_shard0.limb_begin != destination_shard1.limb_begin ||
        destination_shard0.limb_count != destination_shard1.limb_count ||
        destination_shard0.coeff_begin != destination_shard1.coeff_begin ||
        destination_shard0.coeff_count != destination_shard1.coeff_count)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: shard shape mismatch");
    }
    if (add_source_shard0 == nullptr && add_source_shard1 != nullptr)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: add-source0 is required when add-source1 is set");
    }
    if (add_source_shard0 != nullptr)
    {
        if (add_source_shard0->ptr == nullptr ||
            add_source_shard0->device_id != destination_shard0.device_id ||
            add_source_shard0->limb_begin != destination_shard0.limb_begin ||
            add_source_shard0->limb_count != destination_shard0.limb_count ||
            add_source_shard0->coeff_begin != destination_shard0.coeff_begin ||
            add_source_shard0->coeff_count != destination_shard0.coeff_count)
        {
            throw std::invalid_argument(
                "launch_hybrid_apply_moddown_ntt_add_back: add-source0 shard placement mismatch");
        }
    }
    if (add_source_shard1 != nullptr)
    {
        if (add_source_shard1->ptr == nullptr ||
            add_source_shard1->device_id != destination_shard1.device_id ||
            add_source_shard1->limb_begin != destination_shard1.limb_begin ||
            add_source_shard1->limb_count != destination_shard1.limb_count ||
            add_source_shard1->coeff_begin != destination_shard1.coeff_begin ||
            add_source_shard1->coeff_count != destination_shard1.coeff_count)
        {
            throw std::invalid_argument(
                "launch_hybrid_apply_moddown_ntt_add_back: add-source1 shard placement mismatch");
        }
    }
    if (destination_shard0.coeff_begin != 0)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: non-zero coeff offset is not supported");
    }
    if (destination_shard0.limb_begin < parameter_shard.limb_begin)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: parameter shard does not cover limb range");
    }

    const std::size_t modulus_offset =
        destination_shard0.limb_begin - parameter_shard.limb_begin;
    const std::size_t base_q_size = parameter_shard.hybrid_base_q_count;
    if (modulus_offset + destination_shard0.limb_count > base_q_size)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_add_back: Q limb range exceeds HYBRID base");
    }

    const std::size_t values_per_component =
        destination_shard0.limb_count * destination_shard0.coeff_count;
    const std::size_t total = values_per_component * 2;
    if (total == 0)
    {
        return;
    }

    gpu_check_cuda(
        cudaSetDevice(destination_shard0.device_id),
        "launch_hybrid_apply_moddown_ntt_add_back cudaSetDevice");

    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(
        degree,
        "launch_hybrid_apply_moddown_ntt_add_back");
    const bool legacy_in_place =
        add_source_shard0 == nullptr && add_source_shard1 == nullptr;
    hybrid_apply_moddown_ntt_add_back_two_components_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            destination_shard0.ptr,
            destination_shard1.ptr,
            legacy_in_place ? destination_shard0.ptr : add_source_shard0->ptr,
            legacy_in_place
                ? destination_shard1.ptr
                : (add_source_shard1 == nullptr ? nullptr : add_source_shard1->ptr),
            accum_q0,
            accum_q1,
            converted_q0,
            converted_q1,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            modulus_offset,
            destination_shard0.limb_count,
            destination_shard0.coeff_count,
            degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_apply_moddown_ntt_add_back kernel launch");
}

void launch_hybrid_apply_moddown_ntt_c2s_split(
    const GpuPolyShardView &real_shard0,
    const GpuPolyShardView &real_shard1,
    const GpuPolyShardView &imag_shard0,
    const GpuPolyShardView &imag_shard1,
    const GpuConstPolyShardView &dft_shard0,
    const GpuConstPolyShardView &dft_shard1,
    const GpuConstPolyShardView &minus_i_plain_shard,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    constexpr const char *name = "launch_hybrid_apply_moddown_ntt_c2s_split";
    validate_hybrid_tables(name, parameter_shard, degree);
    if (real_shard0.ptr == nullptr || real_shard1.ptr == nullptr ||
        imag_shard0.ptr == nullptr || imag_shard1.ptr == nullptr ||
        dft_shard0.ptr == nullptr || dft_shard1.ptr == nullptr ||
        minus_i_plain_shard.ptr == nullptr ||
        accum_q0 == nullptr || accum_q1 == nullptr ||
        converted_q0 == nullptr || converted_q1 == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null data pointer");
    }
    const auto same_placement = [&real_shard0](const auto &s) {
        return s.device_id == real_shard0.device_id &&
               s.limb_begin == real_shard0.limb_begin &&
               s.limb_count == real_shard0.limb_count &&
               s.coeff_begin == real_shard0.coeff_begin &&
               s.coeff_count == real_shard0.coeff_count;
    };
    if (degree == 0 || real_shard0.limb_count == 0 || real_shard0.coeff_begin != 0 ||
        real_shard0.coeff_count != degree ||
        !same_placement(real_shard1) || !same_placement(imag_shard0) ||
        !same_placement(imag_shard1) || !same_placement(dft_shard0) ||
        !same_placement(dft_shard1) ||
        minus_i_plain_shard.device_id != real_shard0.device_id ||
        minus_i_plain_shard.limb_begin != real_shard0.limb_begin ||
        minus_i_plain_shard.limb_count < real_shard0.limb_count ||
        minus_i_plain_shard.coeff_begin != 0 ||
        minus_i_plain_shard.coeff_count != degree ||
        real_shard0.device_id != parameter_shard.device_id ||
        real_shard0.limb_begin < parameter_shard.limb_begin)
    {
        throw std::invalid_argument(std::string(name) + ": shard placement mismatch");
    }
    const std::size_t modulus_offset = real_shard0.limb_begin - parameter_shard.limb_begin;
    if (modulus_offset + real_shard0.limb_count > parameter_shard.hybrid_base_q_count)
    {
        throw std::invalid_argument(std::string(name) + ": Q limb range exceeds HYBRID base");
    }
    const std::size_t values_per_component = real_shard0.limb_count * real_shard0.coeff_count;
    gpu_check_cuda(cudaSetDevice(real_shard0.device_id), name);
    constexpr unsigned int block_size = 256;
    const auto grid_size = static_cast<unsigned int>((values_per_component + block_size - 1) / block_size);
    const unsigned int degree_power = checked_log2_degree(degree, name);
    hybrid_apply_moddown_ntt_c2s_split_two_components_kernel
        <<<dim3(grid_size, 2), block_size, 0, gpu_execution_stream()>>>(
            real_shard0.ptr,
            real_shard1.ptr,
            imag_shard0.ptr,
            imag_shard1.ptr,
            dft_shard0.ptr,
            dft_shard1.ptr,
            minus_i_plain_shard.ptr,
            accum_q0,
            accum_q1,
            converted_q0,
            converted_q1,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            modulus_offset,
            real_shard0.limb_count,
            real_shard0.coeff_count,
            degree_power);
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_hybrid_apply_moddown_ntt_add_back_rescale_x2(
    const GpuPolyShardView &destination_shard0,
    const GpuPolyShardView &destination_shard1,
    const GpuConstPolyShardView &correction_ntt_shard0,
    const GpuConstPolyShardView &correction_ntt_shard1,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuConstPolyShardView *add_source_shard0,
    const GpuConstPolyShardView *add_source_shard1)
{
    constexpr const char *name =
        "launch_hybrid_apply_moddown_ntt_add_back_rescale_x2";
    validate_hybrid_tables(name, parameter_shard, degree);
    if (destination_shard0.ptr == nullptr ||
        destination_shard1.ptr == nullptr ||
        correction_ntt_shard0.ptr == nullptr ||
        correction_ntt_shard1.ptr == nullptr ||
        accum_q0 == nullptr || accum_q1 == nullptr ||
        converted_q0 == nullptr || converted_q1 == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null data pointer");
    }
    if (destination_shard0.device_id != destination_shard1.device_id ||
        destination_shard0.device_id != correction_ntt_shard0.device_id ||
        destination_shard0.device_id != correction_ntt_shard1.device_id ||
        destination_shard0.device_id != parameter_shard.device_id)
    {
        throw std::invalid_argument(std::string(name) + ": device mismatch");
    }
    if (degree == 0 ||
        destination_shard0.limb_begin != 0 ||
        destination_shard1.limb_begin != 0 ||
        correction_ntt_shard0.limb_begin != 0 ||
        correction_ntt_shard1.limb_begin != 0 ||
        destination_shard0.coeff_begin != 0 ||
        destination_shard1.coeff_begin != 0 ||
        correction_ntt_shard0.coeff_begin != 0 ||
        correction_ntt_shard1.coeff_begin != 0 ||
        destination_shard0.coeff_count != degree ||
        destination_shard1.coeff_count != degree ||
        correction_ntt_shard0.coeff_count != degree ||
        correction_ntt_shard1.coeff_count != degree ||
        destination_shard0.limb_count == 0 ||
        destination_shard0.limb_count != destination_shard1.limb_count ||
        destination_shard0.limb_count != correction_ntt_shard0.limb_count ||
        destination_shard0.limb_count != correction_ntt_shard1.limb_count)
    {
        throw std::invalid_argument(std::string(name) + ": invalid shard shape");
    }
    if (add_source_shard0 == nullptr || add_source_shard1 == nullptr ||
        add_source_shard0->ptr == nullptr || add_source_shard1->ptr == nullptr)
    {
        throw std::invalid_argument(
            std::string(name) + ": add-source shards are required");
    }
    if (add_source_shard0->device_id != destination_shard0.device_id ||
        add_source_shard1->device_id != destination_shard1.device_id ||
        add_source_shard0->limb_begin != 0 ||
        add_source_shard1->limb_begin != 0 ||
        add_source_shard0->limb_count < destination_shard0.limb_count ||
        add_source_shard1->limb_count < destination_shard1.limb_count ||
        add_source_shard0->coeff_begin != 0 ||
        add_source_shard1->coeff_begin != 0 ||
        add_source_shard0->coeff_count != degree ||
        add_source_shard1->coeff_count != degree)
    {
        throw std::invalid_argument(
            std::string(name) + ": add-source shard placement mismatch");
    }
    const std::size_t destination_q_count = destination_shard0.limb_count;
    if (parameter_shard.limb_begin != 0 ||
        destination_q_count + 2 != parameter_shard.hybrid_base_q_count ||
        parameter_shard.inv_q_last_two_product_mod_q.size() <
            destination_q_count)
    {
        throw std::invalid_argument(
            std::string(name) + ": rescale_x2 constants mismatch");
    }

    const std::size_t values_per_component =
        destination_q_count * degree;
    const std::size_t total = values_per_component * 2;
    if (total == 0)
    {
        return;
    }

    gpu_check_cuda(
        cudaSetDevice(destination_shard0.device_id),
        "launch_hybrid_apply_moddown_ntt_add_back_rescale_x2 cudaSetDevice");

    constexpr int block_size = 256;
    const int grid_size = static_cast<int>(
        (total + block_size - 1) / block_size);
    hybrid_apply_moddown_ntt_add_back_rescale_x2_two_components_kernel
        <<<grid_size, block_size, 0, gpu_execution_stream()>>>(
            destination_shard0.ptr,
            destination_shard1.ptr,
            add_source_shard0->ptr,
            add_source_shard1->ptr,
            correction_ntt_shard0.ptr,
            correction_ntt_shard1.ptr,
            accum_q0,
            accum_q1,
            converted_q0,
            converted_q1,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            parameter_shard.hybrid_inv_p_mod_q.data(),
            parameter_shard.inv_q_last_two_product_mod_q.data(),
            destination_q_count,
            degree,
            checked_log2_degree(degree, name));
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_hybrid_apply_moddown_ntt_add_back_rescale_x2 kernel launch");
}

namespace {
void validate_joint_rescale(const GpuParameterShard &p, std::size_t degree)
{
    validate_hybrid_tables("joint relin rescale", p, degree);
    if (p.limb_begin || p.hybrid_base_q_count < 3 || !p.q_last_two_product ||
        p.hybrid_inv_p_mod_q.size() < p.hybrid_base_q_count ||
        p.q_last_two_product_mod_q.size() < p.hybrid_base_q_count - 2 ||
        p.inv_q_last_two_product_mod_q.size() < p.hybrid_base_q_count - 2)
        throw std::invalid_argument("joint relin rescale: incompatible constants");
    gpu_check_cuda(cudaSetDevice(p.device_id), "joint relin rescale select device");
}

void validate_joint_rescale_x1(const GpuParameterShard &p, std::size_t degree)
{
    validate_hybrid_tables("joint relin rescale x1", p, degree);
    if (p.limb_begin || p.hybrid_base_q_count < 2 || !p.q_last ||
        p.hybrid_inv_p_mod_q.size() < p.hybrid_base_q_count ||
        p.half_q_last_mod_q.size() < p.hybrid_base_q_count - 1 ||
        p.inv_q_last_mod_q.size() < p.hybrid_base_q_count - 1)
        throw std::invalid_argument("joint relin rescale x1: incompatible constants");
    gpu_check_cuda(cudaSetDevice(p.device_id), "joint relin rescale x1 select device");
}
}

void launch_hybrid_relin_rescale_x2_tail(
    GpuWord *tail0, GpuWord *tail1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_joint_rescale(p, degree);
    if (!tail0 || !tail1 || !accum0 || !accum1 || ((source0 == nullptr) != (source1 == nullptr)))
        throw std::invalid_argument("joint relin rescale tail: null pointer");
    hybrid_relin_rescale_x2_tail_kernel<<<dim3((2 * degree + 255) / 256, 2), 256, 0, gpu_execution_stream()>>>(
        tail0, tail1, accum0, accum1, source0, source1, p.rns_primes.data(),
        p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(), p.hybrid_base_q_count,
        checked_log2_degree(degree, "joint relin rescale tail"));
    gpu_check_cuda(cudaGetLastError(), "joint relin rescale tail");
}

void launch_hybrid_relin_rescale_x2_merge_correction(
    GpuWord *converted0, GpuWord *converted1,
    const GpuWord *tail0, const GpuWord *tail1,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_joint_rescale(p, degree);
    if (!converted0 || !converted1 || !tail0 || !tail1)
        throw std::invalid_argument("joint relin rescale correction: null pointer");
    hybrid_relin_rescale_x2_merge_correction_kernel<<<dim3((degree + 255) / 256, 2), 256, 0, gpu_execution_stream()>>>(
        converted0, converted1, tail0, tail1, p.rns_primes.data(), p.rns_modulus_constants.data(),
        p.hybrid_inv_p_mod_q.data(), p.q_last_two_product_mod_q.data(),
        p.half_q_last_two_product, p.inv_q_last_mod_q_second_last, p.hybrid_base_q_count,
        checked_log2_degree(degree, "joint relin rescale correction"));
    gpu_check_cuda(cudaGetLastError(), "joint relin rescale correction");
}

void launch_hybrid_relin_rescale_x2_apply(
    GpuWord *out0, GpuWord *out1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *correction0, const GpuWord *correction1,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_joint_rescale(p, degree);
    if (!out0 || !out1 || !accum0 || !accum1 || !correction0 || !correction1 ||
        ((source0 == nullptr) != (source1 == nullptr)))
        throw std::invalid_argument("joint relin rescale apply: null pointer");
    hybrid_relin_rescale_x2_apply_kernel<<<dim3(((p.hybrid_base_q_count - 2) * degree + 255) / 256, 2), 256, 0, gpu_execution_stream()>>>(
        out0, out1, accum0, accum1, source0, source1, correction0, correction1,
        p.rns_primes.data(), p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(),
        p.inv_q_last_two_product_mod_q.data(), p.hybrid_base_q_count,
        checked_log2_degree(degree, "joint relin rescale apply"));
    gpu_check_cuda(cudaGetLastError(), "joint relin rescale apply");
}

void launch_hybrid_relin_rescale_x1_tail(
    GpuWord *tail0, GpuWord *tail1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuParameterShard &p, std::size_t degree, bool double_moddown)
{
    validate_joint_rescale_x1(p, degree);
    if (!tail0 || !tail1 || !accum0 || !accum1 || ((source0 == nullptr) != (source1 == nullptr)))
        throw std::invalid_argument("joint relin rescale x1 tail: null pointer");
    hybrid_relin_rescale_x1_tail_kernel<<<dim3((degree + 255) / 256, 2), 256, 0, gpu_execution_stream()>>>(
        tail0, tail1, accum0, accum1, source0, source1, p.rns_primes.data(),
        p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(),
        static_cast<unsigned>(p.hybrid_base_q_count),
        checked_log2_degree(degree, "joint relin rescale x1 tail"), double_moddown);
    gpu_check_cuda(cudaGetLastError(), "joint relin rescale x1 tail");
}

void launch_hybrid_relin_rescale_x1_merge_correction(
    GpuWord *converted0, GpuWord *converted1,
    const GpuWord *tail0, const GpuWord *tail1,
    const GpuParameterShard &p, std::size_t degree, bool double_moddown)
{
    validate_joint_rescale_x1(p, degree);
    if (!converted0 || !converted1 || !tail0 || !tail1)
        throw std::invalid_argument("joint relin rescale x1 correction: null pointer");
    hybrid_relin_rescale_x1_merge_correction_kernel<<<dim3((degree + 255) / 256, 2), 256, 0, gpu_execution_stream()>>>(
        converted0, converted1, tail0, tail1, p.rns_primes.data(), p.rns_modulus_constants.data(),
        p.hybrid_inv_p_mod_q.data(), p.half_q_last_mod_q.data(), p.q_last, p.half_q_last,
        static_cast<unsigned>(p.hybrid_base_q_count),
        checked_log2_degree(degree, "joint relin rescale x1 correction"), double_moddown);
    gpu_check_cuda(cudaGetLastError(), "joint relin rescale x1 correction");
}

void launch_hybrid_relin_rescale_x1_apply(
    GpuWord *out0, GpuWord *out1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *correction0, const GpuWord *correction1,
    const GpuParameterShard &p, std::size_t degree, bool double_moddown)
{
    validate_joint_rescale_x1(p, degree);
    if (!out0 || !out1 || !accum0 || !accum1 || !correction0 || !correction1 ||
        ((source0 == nullptr) != (source1 == nullptr)))
        throw std::invalid_argument("joint relin rescale x1 apply: null pointer");
    hybrid_relin_rescale_x1_apply_kernel<<<dim3(((p.hybrid_base_q_count - 1) * degree + 255) / 256, 2), 256, 0, gpu_execution_stream()>>>(
        out0, out1, accum0, accum1, source0, source1, correction0, correction1,
        p.rns_primes.data(), p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(),
        p.inv_q_last_mod_q.data(), static_cast<unsigned>(p.hybrid_base_q_count),
        checked_log2_degree(degree, "joint relin rescale x1 apply"), double_moddown);
    gpu_check_cuda(cudaGetLastError(), "joint relin rescale x1 apply");
}

void launch_apply_galois_ntt_poly_shard(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    std::uint32_t galois_elt,
    std::size_t degree)
{
    if (destination_shard.ptr == nullptr || source_shard.ptr == nullptr)
    {
        throw std::invalid_argument("launch_apply_galois_ntt_poly_shard: null data pointer");
    }
    if (destination_shard.ptr == source_shard.ptr)
    {
        throw std::invalid_argument(
            "launch_apply_galois_ntt_poly_shard: in-place permutation is not supported");
    }
    if (destination_shard.device_id != source_shard.device_id)
    {
        throw std::invalid_argument("launch_apply_galois_ntt_poly_shard: device mismatch");
    }
    if (destination_shard.limb_begin != source_shard.limb_begin ||
        destination_shard.limb_count != source_shard.limb_count ||
        destination_shard.coeff_begin != source_shard.coeff_begin ||
        destination_shard.coeff_count != source_shard.coeff_count)
    {
        throw std::invalid_argument("launch_apply_galois_ntt_poly_shard: shard shape mismatch");
    }
    if (destination_shard.coeff_begin != 0 ||
        destination_shard.coeff_count != degree ||
        destination_shard.limb_count == 0)
    {
        throw std::invalid_argument(
            "launch_apply_galois_ntt_poly_shard: only full coefficient shards are supported");
    }
    if (degree > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max() / 2))
    {
        throw std::overflow_error("launch_apply_galois_ntt_poly_shard: degree is too large");
    }

    const std::uint64_t m = static_cast<std::uint64_t>(degree) << 1;
    if ((galois_elt & 1U) == 0U || static_cast<std::uint64_t>(galois_elt) >= m)
    {
        throw std::invalid_argument("launch_apply_galois_ntt_poly_shard: invalid Galois element");
    }

    const unsigned int degree_power =
        checked_log2_degree(degree, "launch_apply_galois_ntt_poly_shard");

    gpu_check_cuda(
        cudaSetDevice(destination_shard.device_id),
        "launch_apply_galois_ntt_poly_shard cudaSetDevice");

    const std::size_t total = destination_shard.limb_count * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>(
        (total + block_size - 1) / block_size);

    apply_galois_ntt_poly_shard_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        destination_shard.ptr,
        source_shard.ptr,
        galois_elt,
        destination_shard.limb_count,
        degree,
        degree_power);
    gpu_check_cuda(
        cudaGetLastError(),
        "launch_apply_galois_ntt_poly_shard kernel launch");
}

void validate_hybrid_relinearize_pair_parameters(
    const GpuParameterShard &parameters, std::size_t degree)
{
    validate_hybrid_tables("relinearize pair", parameters, degree);
    const auto limbs = parameters.hybrid_base_q_count + parameters.hybrid_base_p_count;
    if (degree != 65536 || parameters.hybrid_base_p_count > 64 ||
        parameters.limb_begin != 0 || parameters.limb_count < limbs ||
        parameters.ntt_tables.size() < limbs * degree ||
        parameters.fourstep_intt_tables.size() < limbs * degree ||
        parameters.inv_degree_modulo.size() < limbs)
        throw std::invalid_argument("relinearize pair: unsupported parameter tables");
}

__global__ void hybrid_modup_singleton_pair_kernel(
    GpuWord *modup_q, GpuWord *modup_p, const GpuWord *c2_coeff,
    const GpuWord *primes, const GpuWide *barrett,
    std::size_t q, std::size_t p, std::size_t source_limb,
    std::size_t source_batch_stride = 0,
    std::size_t modup_q_batch_stride = 0,
    std::size_t modup_p_batch_stride = 0)
{
    constexpr std::size_t n = 65536;
    const auto i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= (q + p) * n) return;
    const auto limb = i >> 16;
    if (limb == source_limb) return; // Keymul uses the original c2 NTT here.
    const std::size_t batch = blockIdx.z;
    const std::size_t src_stride = source_batch_stride ? source_batch_stride : q * n;
    const std::size_t dst_q_stride = modup_q_batch_stride ? modup_q_batch_stride : q * n;
    const std::size_t dst_p_stride = modup_p_batch_stride ? modup_p_batch_stride : p * n;
    const auto value = c2_coeff[batch * src_stride + source_limb * n + (i & (n - 1))];
    auto *target = limb < q ? modup_q + batch * dst_q_stride + i
                            : modup_p + batch * dst_p_stride + (i - q * n);
    *target = reduce_to_modulus(value, primes[limb], barrett[limb]);
}

__global__ void copy_strided_q_limbs_batch_kernel(
    GpuWord *destination,
    const GpuWord *source,
    std::size_t words_per_batch,
    std::size_t destination_batch_stride,
    std::size_t source_batch_stride)
{
    const std::size_t i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= words_per_batch) return;
    const std::size_t z = blockIdx.z;
    destination[z * destination_batch_stride + i] = source[z * source_batch_stride + i];
}

void launch_copy_strided_q_limbs_batch(
    GpuWord *destination,
    const GpuWord *source,
    std::size_t limb_count,
    std::size_t degree,
    std::size_t batch_count,
    std::size_t destination_batch_stride,
    std::size_t source_batch_stride,
    int device_id)
{
    if (batch_count == 0 || limb_count == 0) return;
    if (!destination || !source || degree == 0 || batch_count > 65535)
        throw std::invalid_argument("launch_copy_strided_q_limbs_batch: invalid arguments");
    gpu_check_cuda(cudaSetDevice(device_id), "launch_copy_strided_q_limbs_batch cudaSetDevice");
    const std::size_t words = limb_count * degree;
    constexpr unsigned int threads = 256;
    const auto blocks = static_cast<unsigned int>((words + threads - 1) / threads);
    copy_strided_q_limbs_batch_kernel<<<dim3(blocks, 1, static_cast<unsigned int>(batch_count)),
                                        threads, 0, gpu_execution_stream()>>>(
        destination, source, words, destination_batch_stride, source_batch_stride);
    gpu_check_cuda(cudaGetLastError(), "launch_copy_strided_q_limbs_batch");
}

void launch_hybrid_modup_decomposition_pair(
    GpuWord *modup_q, GpuWord *modup_p, GpuWord *weighted,
    const GpuWord *c2_coeff, std::size_t digit, std::size_t limb_begin,
    std::size_t limb_count, const GpuParameterShard &parameters,
    std::size_t degree, bool source_preweighted)
{
    validate_hybrid_relinearize_pair_parameters(parameters, degree);
    const auto q = parameters.hybrid_base_q_count;
    const auto p = parameters.hybrid_base_p_count;
    if (!modup_q || !modup_p || (!source_preweighted && limb_count > 1 && !weighted) || !c2_coeff ||
        digit >= parameters.hybrid_decomp_count || limb_count == 0 ||
        limb_count > p || limb_begin != digit * p || limb_begin + limb_count > q)
        throw std::invalid_argument("pair ModUp: invalid buffers or digit");
    gpu_check_cuda(cudaSetDevice(parameters.device_id), "pair ModUp cudaSetDevice");
    constexpr unsigned int threads = 256;
    // A singleton digit has no converter: its uploaded matrix is zero-filled.
    // Match the scalar path's direct residue reduction instead of using it.
    if (limb_count == 1)
    {
        const auto blocks = static_cast<unsigned int>(((q + p) * degree + threads - 1) / threads);
        hybrid_modup_singleton_pair_kernel<<<dim3(blocks, 1, 2), threads, 0, gpu_execution_stream()>>>(
            modup_q, modup_p, c2_coeff, parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(), q, p, limb_begin);
        gpu_check_cuda(cudaGetLastError(), "pair singleton ModUp");
        return;
    }
    const GpuWord *weighted_src = c2_coeff + limb_begin * degree;
    std::size_t weighted_stride = q * degree;
    if (!source_preweighted)
    {
        const auto weight_blocks = static_cast<unsigned int>((limb_count * degree + threads - 1) / threads);
        hybrid_preweight_modup_source_kernel<true><<<dim3(weight_blocks, 1, 2), threads, 0, gpu_execution_stream()>>>(
            weighted, c2_coeff, parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(), parameters.hybrid_qi_inv_punctured.data(),
            static_cast<unsigned int>(digit * p), static_cast<unsigned int>(limb_begin),
            static_cast<unsigned int>(limb_count), 16, q * degree, limb_count * degree);
        gpu_check_cuda(cudaGetLastError(), "pair ModUp preweight");
        weighted_src = weighted;
        weighted_stride = limb_count * degree;
    }
    if (try_launch_hybrid_modup_qp_cta_tiled_65536(
            modup_q, modup_p, weighted_src, parameters,
            digit, limb_begin, limb_count, 2,
            weighted_stride, q * degree, p * degree, degree))
    {
        gpu_check_cuda(cudaGetLastError(), "pair ModUp cta_tiled conversion");
        return;
    }
    const std::size_t pair_targets = q - limb_count + p;
    const int tile = select_adaptive_tile_4_8_12_16(pair_targets, opt_flag_value(OptFlag::ModupTile));
    const auto tiles = (pair_targets + tile - 1) / tile;
    const auto blocks = static_cast<unsigned int>((tiles * (degree / 2) + threads - 1) / threads);
    const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_PAIR_MODUP_PW(T)                                                           \
    hybrid_modup_qp_lazy_preweighted_kernel<T, true><<<dim3(blocks, 1, 2), threads, 0, gpu_execution_stream()>>>( \
        modup_q, modup_p, weighted_src, parameters.rns_primes.data(),                              \
        parameters.rns_modulus_constants.data(), parameters.hybrid_q_conv_matrix_offsets.data(),   \
        parameters.hybrid_q_conv_matrices.data(), parameters.hybrid_p_conv_matrix_offsets.data(),  \
        parameters.hybrid_p_conv_matrices.data(), static_cast<unsigned int>(digit),                \
        static_cast<unsigned int>(limb_begin), static_cast<unsigned int>(limb_count),              \
        static_cast<unsigned int>(q), static_cast<unsigned int>(p), 16, weighted_stride, 0, 0, vec_bconv)
    if (tile == 16) { POSEIDON_LAUNCH_PAIR_MODUP_PW(16); }
    else if (tile == 12) { POSEIDON_LAUNCH_PAIR_MODUP_PW(12); }
    else if (tile == 8) { POSEIDON_LAUNCH_PAIR_MODUP_PW(8); }
    else { POSEIDON_LAUNCH_PAIR_MODUP_PW(4); }
#undef POSEIDON_LAUNCH_PAIR_MODUP_PW
    gpu_check_cuda(cudaGetLastError(), "pair ModUp conversion");
}

void launch_hybrid_modup_decomposition_batch(
    GpuWord *modup_q, GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t digit, std::size_t limb_begin, std::size_t limb_count,
    std::size_t batch_count,
    std::size_t source_batch_stride,
    std::size_t modup_q_batch_stride,
    std::size_t modup_p_batch_stride,
    const GpuParameterShard &parameters,
    std::size_t degree,
    bool source_preweighted)
{
    if (batch_count == 0) return;
    validate_hybrid_relinearize_pair_parameters(parameters, degree);
    const auto q = parameters.hybrid_base_q_count;
    const auto p = parameters.hybrid_base_p_count;
    const std::size_t active_q = q - limb_count;
    if ((active_q > 0 && !modup_q) || !modup_p || !c2_coeff ||
        batch_count > 65535 || digit >= parameters.hybrid_decomp_count ||
        limb_count == 0 || limb_count > p || limb_begin != digit * p ||
        limb_begin + limb_count > q)
        throw std::invalid_argument("batch ModUp: invalid buffers or digit");
    gpu_check_cuda(cudaSetDevice(parameters.device_id), "batch ModUp cudaSetDevice");
    constexpr unsigned int threads = 256;
    const auto z_dim = static_cast<unsigned int>(batch_count);
    const std::size_t src_stride = source_batch_stride ? source_batch_stride : q * degree;
    const std::size_t dst_q_stride = modup_q_batch_stride ? modup_q_batch_stride : q * degree;
    const std::size_t dst_p_stride = modup_p_batch_stride ? modup_p_batch_stride : p * degree;
    if (limb_count == 1)
    {
        const auto blocks = static_cast<unsigned int>(((q + p) * degree + threads - 1) / threads);
        hybrid_modup_singleton_pair_kernel<<<dim3(blocks, 1, z_dim), threads, 0, gpu_execution_stream()>>>(
            modup_q, modup_p, c2_coeff, parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(), q, p, limb_begin,
            src_stride, dst_q_stride, dst_p_stride);
        gpu_check_cuda(cudaGetLastError(), "batch singleton ModUp");
        return;
    }
    const GpuWord *weighted_src = c2_coeff + limb_begin * degree;
    std::size_t weighted_stride = src_stride;
    if (!source_preweighted)
    {
        const std::size_t weight_words = limb_count * degree;
        GpuWord *scratch = modup_preweight_scratch(batch_count * weight_words);
        const auto weight_blocks = static_cast<unsigned int>((weight_words + threads - 1) / threads);
        hybrid_preweight_modup_source_kernel<true><<<dim3(weight_blocks, 1, z_dim), threads, 0, gpu_execution_stream()>>>(
            scratch, c2_coeff, parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(), parameters.hybrid_qi_inv_punctured.data(),
            static_cast<unsigned int>(digit * p), static_cast<unsigned int>(limb_begin),
            static_cast<unsigned int>(limb_count), 16, src_stride, weight_words);
        gpu_check_cuda(cudaGetLastError(), "batch ModUp preweight");
        weighted_src = scratch;
        weighted_stride = weight_words;
    }
    if (try_launch_hybrid_modup_qp_cta_tiled_65536(
            modup_q, modup_p, weighted_src, parameters,
            digit, limb_begin, limb_count, batch_count,
            weighted_stride, dst_q_stride, dst_p_stride, degree))
    {
        gpu_check_cuda(cudaGetLastError(), "batch ModUp cta_tiled conversion");
        return;
    }
    const std::size_t batch_targets = active_q + p;
    const int tile = select_adaptive_tile_4_8_12_16(batch_targets, opt_flag_value(OptFlag::ModupTile));
    const auto tiles = (batch_targets + tile - 1) / tile;
    const auto blocks = static_cast<unsigned int>((tiles * (degree / 2) + threads - 1) / threads);
    const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_BATCH_MODUP_PW(T)                                                          \
    hybrid_modup_qp_lazy_preweighted_kernel<T, true><<<dim3(blocks, 1, z_dim), threads, 0, gpu_execution_stream()>>>( \
        modup_q, modup_p, weighted_src, parameters.rns_primes.data(),                              \
        parameters.rns_modulus_constants.data(), parameters.hybrid_q_conv_matrix_offsets.data(),   \
        parameters.hybrid_q_conv_matrices.data(), parameters.hybrid_p_conv_matrix_offsets.data(),  \
        parameters.hybrid_p_conv_matrices.data(), static_cast<unsigned int>(digit),                \
        static_cast<unsigned int>(limb_begin), static_cast<unsigned int>(limb_count),              \
        static_cast<unsigned int>(q), static_cast<unsigned int>(p), 16,                            \
        weighted_stride, dst_q_stride, dst_p_stride, vec_bconv)
    if (tile == 16) { POSEIDON_LAUNCH_BATCH_MODUP_PW(16); }
    else if (tile == 12) { POSEIDON_LAUNCH_BATCH_MODUP_PW(12); }
    else if (tile == 8) { POSEIDON_LAUNCH_BATCH_MODUP_PW(8); }
    else { POSEIDON_LAUNCH_BATCH_MODUP_PW(4); }
#undef POSEIDON_LAUNCH_BATCH_MODUP_PW
    gpu_check_cuda(cudaGetLastError(), "batch ModUp conversion");
}

void launch_hybrid_convert_p_to_q_preweighted_batch4(
    GpuWord *converted_q, const GpuWord *weighted_p,
    const GpuParameterShard &parameters, std::size_t degree)
{
    validate_hybrid_relinearize_pair_parameters(parameters, degree);
    if (!converted_q || !weighted_p)
        throw std::invalid_argument("pair PtoQ: null pointer");
    gpu_check_cuda(cudaSetDevice(parameters.device_id), "pair PtoQ cudaSetDevice");
    const auto q = parameters.hybrid_base_q_count;
    const auto p = parameters.hybrid_base_p_count;
    if (try_launch_hybrid_convert_p_to_q_cta_tiled_65536(
            converted_q, nullptr, weighted_p, nullptr,
            parameters, 4, false, degree))
    {
        gpu_check_cuda(cudaGetLastError(), "pair PtoQ cta_tiled conversion");
        return;
    }
    constexpr unsigned int threads = 256;
    const int ptoq_cfg = opt_flag_value(OptFlag::PToQTile);
    const int tile = select_adaptive_tile_4_8_12_16(q, ptoq_cfg > 0 ? ptoq_cfg : 4);
    const auto blocks = static_cast<unsigned int>(((q + tile - 1) / tile * (degree / 2) + threads - 1) / threads);
    const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_PAIR4_PTOQ(T)                                                              \
    hybrid_convert_p_to_q_lazy_preweighted_kernel<T, 1, true>                                      \
        <<<dim3(blocks, 1, 4), threads, 0, gpu_execution_stream()>>>(                              \
            converted_q, nullptr, weighted_p, nullptr, parameters.rns_primes.data(),               \
            parameters.rns_modulus_constants.data(), parameters.hybrid_moddown_p_to_q_matrix.data(), \
            static_cast<unsigned int>(q), static_cast<unsigned int>(p), 16, vec_bconv)
    if (tile == 16) { POSEIDON_LAUNCH_PAIR4_PTOQ(16); }
    else if (tile == 12) { POSEIDON_LAUNCH_PAIR4_PTOQ(12); }
    else if (tile == 8) { POSEIDON_LAUNCH_PAIR4_PTOQ(8); }
    else { POSEIDON_LAUNCH_PAIR4_PTOQ(4); }
#undef POSEIDON_LAUNCH_PAIR4_PTOQ
    gpu_check_cuda(cudaGetLastError(), "pair PtoQ conversion");
}

__global__ void hybrid_relinearize_pair_addback_kernel(
    GpuWord *destination00, GpuWord *destination01,
    GpuWord *destination10, GpuWord *destination11,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *accum_q, const GpuWord *converted_q,
    const GpuWord *primes, const GpuWide *barrett, const GpuWord *inv_p,
    std::size_t words)
{
    const auto i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= words) return;
    // z is [component][batch], matching the shared ModDown buffers.
    const auto z = blockIdx.z;
    GpuWord *destination = z == 0 ? destination00 : z == 1 ? destination10 :
                           z == 2 ? destination01 : destination11;
    const GpuWord *source = z == 0 ? source00 : z == 1 ? source10 :
                            z == 2 ? source01 : source11;
    const auto limb = i >> 16;
    const auto offset = z * words + i;
    const auto switched = mul_mod(sub_mod(accum_q[offset], converted_q[offset], primes[limb]),
                                  inv_p[limb], primes[limb], barrett[limb]);
    destination[i] = add_mod(source[i], switched, primes[limb]);
}

void launch_hybrid_relinearize_pair_addback(
    GpuWord *destination00, GpuWord *destination01,
    GpuWord *destination10, GpuWord *destination11,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *accum_q, const GpuWord *converted_q,
    const GpuParameterShard &parameters, std::size_t degree)
{
    validate_hybrid_relinearize_pair_parameters(parameters, degree);
    if (!destination00 || !destination01 || !destination10 || !destination11 ||
        !source00 || !source01 || !source10 || !source11 || !accum_q || !converted_q)
        throw std::invalid_argument("pair ModDown addback: null pointer");
    gpu_check_cuda(cudaSetDevice(parameters.device_id), "pair addback cudaSetDevice");
    const auto words = parameters.hybrid_base_q_count * degree;
    hybrid_relinearize_pair_addback_kernel<<<dim3(static_cast<unsigned int>((words + 255) / 256), 1, 4),
                                           256, 0, gpu_execution_stream()>>>(
        destination00, destination01, destination10, destination11,
        source00, source01, source10, source11, accum_q, converted_q,
        parameters.rns_primes.data(), parameters.rns_modulus_constants.data(),
        parameters.hybrid_inv_p_mod_q.data(), words);
    gpu_check_cuda(cudaGetLastError(), "pair ModDown addback");
}

namespace {

template <int PostOp>
__device__ __forceinline__ GpuWord pair_relin_post_base(
    GpuWord accum_val, GpuWord src_val, GpuWord extra_val,
    GpuWord inv_p, GpuWord prime, GpuWide ratio)
{
    const GpuWord switched = mul_mod(accum_val, inv_p, prime, ratio);
    if constexpr (PostOp == 4)
    {
        return add_mod(add_mod(switched, switched, prime), src_val, prime);
    }
    const GpuWord base = add_mod(switched, src_val, prime);
    if constexpr (PostOp == 0)
    {
        return base;
    }
    else
    {
        const GpuWord doubled = add_mod(base, base, prime);
        if constexpr (PostOp == 1)
        {
            return add_mod(doubled, extra_val, prime);
        }
        else
        {
            return sub_mod(doubled, extra_val, prime);
        }
    }
}

template <int PostOp>
__device__ __forceinline__ GpuWord pair_relin_scale_r(
    GpuWord r_val, GpuWord inv_p, GpuWord prime, GpuWide ratio)
{
    const GpuWord switched = mul_mod(r_val, inv_p, prime, ratio);
    if constexpr (PostOp == 0)
    {
        return switched;
    }
    else
    {
        return add_mod(switched, switched, prime);
    }
}

template <unsigned Drop, int PostOp>
__global__ void hybrid_relin_rescale_pair_tail_kernel(
    GpuWord *tail_ntt,
    const GpuWord *accum_q,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *plain,
    const GpuWord *extra00, const GpuWord *extra01,
    const GpuWord *extra10, const GpuWord *extra11,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    unsigned q)
{
    constexpr std::size_t n = 65536;
    const std::size_t i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= Drop * n) return;
    const unsigned z = blockIdx.z;
    const unsigned limb = (q - Drop) + static_cast<unsigned>(i >> 16);
    const std::size_t full_idx = static_cast<std::size_t>(q - Drop) * n + i;
    const GpuWord *source = z == 0 ? source00 : z == 1 ? source10 : z == 2 ? source01 : source11;
    GpuWord extra_val = 0;
    if constexpr (PostOp == 1 || PostOp == 2)
    {
        if (z < 2 && plain != nullptr) extra_val = plain[full_idx];
    }
    else if constexpr (PostOp == 3)
    {
        const GpuWord *extra = z == 0 ? extra00 : z == 1 ? extra10 : z == 2 ? extra01 : extra11;
        extra_val = extra[full_idx];
    }
    else if constexpr (PostOp == 5)
    {
        const GpuWord *extra = z == 0 ? extra00 : z == 1 ? extra10 : z == 2 ? extra01 : extra11;
        extra_val = mul_mod(extra[full_idx], plain[full_idx], primes[limb], ratios[limb]);
    }
    const GpuWord accum_val = accum_q[static_cast<std::size_t>(z) * q * n + full_idx];
    tail_ntt[static_cast<std::size_t>(z) * Drop * n + i] = pair_relin_post_base<PostOp>(
        accum_val, source[full_idx], extra_val, inv_p[limb], primes[limb], ratios[limb]);
}

template <unsigned Drop, int PostOp>
__global__ void hybrid_relin_rescale_pair_merge_correction_kernel(
    GpuWord *merged_coeff,
    const GpuWord *converted_coeff,
    const GpuWord *tail_coeff,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    const GpuWord *half_q_last_mod_q, GpuWord q_last, GpuWord half_q_last,
    const GpuWord *m_mod_q, GpuWide half_m, GpuWord inv_last_mod_second,
    unsigned q)
{
    constexpr std::size_t n = 65536;
    const std::size_t i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= n) return;
    const unsigned z = blockIdx.z;
    const GpuWord *r_in = converted_coeff + static_cast<std::size_t>(z) * q * n;
    GpuWord *r_out = merged_coeff + static_cast<std::size_t>(z) * (q - Drop) * n;
    const GpuWord *tail = tail_coeff + static_cast<std::size_t>(z) * Drop * n;

    if constexpr (Drop == 1)
    {
        const auto r_last = pair_relin_scale_r<PostOp>(
            r_in[static_cast<std::size_t>(q - 1) * n + i], inv_p[q - 1], q_last, ratios[q - 1]);
        const auto b = sub_mod(tail[i], r_last, q_last);
        const auto rounded = add_mod(b, half_q_last, q_last);
        for (unsigned limb = 0; limb + 1 < q; ++limb)
        {
            const auto prime = primes[limb];
            const auto ratio = ratios[limb];
            const auto centered = sub_mod(
                barrett_reduce_u64_u32(rounded, prime, ratio),
                half_q_last_mod_q[limb], prime);
            const std::size_t idx = static_cast<std::size_t>(limb) * n + i;
            const auto r_switched = pair_relin_scale_r<PostOp>(r_in[idx], inv_p[limb], prime, ratio);
            r_out[idx] = add_mod(r_switched, centered, prime);
        }
    }
    else
    {
        const auto qa = primes[q - 2], qb = primes[q - 1];
        const auto ra = pair_relin_scale_r<PostOp>(
            r_in[static_cast<std::size_t>(q - 2) * n + i], inv_p[q - 2], qa, ratios[q - 2]);
        const auto rb = pair_relin_scale_r<PostOp>(
            r_in[static_cast<std::size_t>(q - 1) * n + i], inv_p[q - 1], qb, ratios[q - 1]);
        const auto a = sub_mod(tail[i], ra, qa);
        const auto b = sub_mod(tail[n + i], rb, qb);
        const auto delta = sub_mod(a, barrett_reduce_u64_u32(b, qa, ratios[q - 2]), qa);
        const GpuWide remainder = static_cast<GpuWide>(b) + static_cast<GpuWide>(qb) *
            mul_mod(delta, inv_last_mod_second, qa, ratios[q - 2]);
        for (unsigned limb = 0; limb + 2 < q; ++limb)
        {
            const auto prime = primes[limb];
            const auto ratio = ratios[limb];
            auto centered = barrett_reduce_u64_u32(remainder, prime, ratio);
            if (remainder > half_m) centered = sub_mod(centered, m_mod_q[limb], prime);
            const std::size_t idx = static_cast<std::size_t>(limb) * n + i;
            const auto r_switched = pair_relin_scale_r<PostOp>(r_in[idx], inv_p[limb], prime, ratio);
            r_out[idx] = add_mod(r_switched, centered, prime);
        }
    }
}

template <unsigned Drop, int PostOp>
__global__ void hybrid_relin_rescale_pair_apply_kernel(
    GpuWord *destination00, GpuWord *destination01,
    GpuWord *destination10, GpuWord *destination11,
    const GpuWord *accum_q,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *plain,
    const GpuWord *extra00, const GpuWord *extra01,
    const GpuWord *extra10, const GpuWord *extra11,
    const GpuWord *correction_ntt,
    const GpuWord *primes, const GpuWide *ratios,
    const GpuWord *inv_p, const GpuWord *inv_divisor,
    unsigned q)
{
    constexpr std::size_t n = 65536;
    const std::size_t retained_words = static_cast<std::size_t>(q - Drop) * n;
    const std::size_t i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= retained_words) return;
    const unsigned z = blockIdx.z;
    const unsigned limb = static_cast<unsigned>(i >> 16);
    GpuWord *destination = z == 0 ? destination00 : z == 1 ? destination10 :
                           z == 2 ? destination01 : destination11;
    const GpuWord *source = z == 0 ? source00 : z == 1 ? source10 :
                            z == 2 ? source01 : source11;
    GpuWord extra_val = 0;
    if constexpr (PostOp == 1 || PostOp == 2)
    {
        if (z < 2 && plain != nullptr) extra_val = plain[i];
    }
    else if constexpr (PostOp == 3)
    {
        const GpuWord *extra = z == 0 ? extra00 : z == 1 ? extra10 : z == 2 ? extra01 : extra11;
        extra_val = extra[i];
    }
    else if constexpr (PostOp == 5)
    {
        const GpuWord *extra = z == 0 ? extra00 : z == 1 ? extra10 : z == 2 ? extra01 : extra11;
        extra_val = mul_mod(extra[i], plain[i], primes[limb], ratios[limb]);
    }
    const auto prime = primes[limb];
    const auto ratio = ratios[limb];
    const GpuWord accum_val = accum_q[static_cast<std::size_t>(z) * q * n + i];
    const GpuWord base_val = pair_relin_post_base<PostOp>(
        accum_val, source[i], extra_val, inv_p[limb], prime, ratio);
    const GpuWord corr_val = correction_ntt[static_cast<std::size_t>(z) * retained_words + i];
    destination[i] = mul_mod(sub_mod(base_val, corr_val, prime), inv_divisor[limb], prime, ratio);
}

void validate_pair_relin_rescale(
    const GpuParameterShard &p, std::size_t degree, std::uint32_t drop_count, int post_op)
{
    validate_hybrid_relinearize_pair_parameters(p, degree);
    if (post_op < 0 || post_op > 5)
        throw std::invalid_argument("pair relin rescale: invalid post_op");
    if (drop_count == 1)
    {
        validate_joint_rescale_x1(p, degree);
    }
    else if (drop_count == 2)
    {
        validate_joint_rescale(p, degree);
    }
    else
    {
        throw std::invalid_argument("pair relin rescale: drop_count must be 1 or 2");
    }
}

template <unsigned Drop, int PostOp>
__global__ void hybrid_relin_rescale_single_tail_kernel(
    GpuWord *tail_ntt,
    const GpuWord *accum_q0, const GpuWord *accum_q1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *plain,
    const GpuWord *extra0, const GpuWord *extra1,
    const GpuWord *primes, const GpuWide *ratios, const GpuWord *inv_p,
    unsigned q)
{
    constexpr std::size_t n = 65536;
    const std::size_t i = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i >= Drop * n) return;
    const unsigned z = blockIdx.z;
    const unsigned limb = (q - Drop) + static_cast<unsigned>(i >> 16);
    const std::size_t full_idx = static_cast<std::size_t>(q - Drop) * n + i;
    const GpuWord *source = z == 0 ? source0 : source1;
    const GpuWord *accum_q = z == 0 ? accum_q0 : accum_q1;
    GpuWord extra_val = 0;
    if constexpr (PostOp == 1 || PostOp == 2)
    {
        if (z == 0 && plain != nullptr) extra_val = plain[full_idx];
    }
    else if constexpr (PostOp == 3)
    {
        const GpuWord *extra = z == 0 ? extra0 : extra1;
        extra_val = extra[full_idx];
    }
    else if constexpr (PostOp == 5)
    {
        const GpuWord *extra = z == 0 ? extra0 : extra1;
        extra_val = mul_mod(extra[full_idx], plain[full_idx], primes[limb], ratios[limb]);
    }
    tail_ntt[static_cast<std::size_t>(z) * Drop * n + i] = pair_relin_post_base<PostOp>(
        accum_q[full_idx], source[full_idx], extra_val, inv_p[limb], primes[limb], ratios[limb]);
}

}  // namespace

void launch_hybrid_relin_rescale_single_tail(
    GpuWord *tail_ntt,
    const GpuWord *accum_q0, const GpuWord *accum_q1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *plain,
    const GpuWord *extra0, const GpuWord *extra1,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_pair_relin_rescale(p, degree, drop_count, post_op);
    if (!tail_ntt || !accum_q0 || !accum_q1 || !source0 || !source1)
        throw std::invalid_argument("single relin rescale tail: null pointer");
    if ((post_op == 3 || post_op == 5) && (!extra0 || !extra1))
        throw std::invalid_argument("single relin rescale tail: missing extra cipher pointers");
    if (post_op == 5 && !plain)
        throw std::invalid_argument("single relin rescale tail: missing plain pointer");
    const dim3 grid(static_cast<unsigned>((drop_count * degree + 255) / 256), 1, 2);
    const unsigned q = static_cast<unsigned>(p.hybrid_base_q_count);
    #define POSEIDON_LAUNCH_SINGLE_TAIL(D, OP) \
        hybrid_relin_rescale_single_tail_kernel<D, OP><<<grid, 256, 0, gpu_execution_stream()>>>( \
            tail_ntt, accum_q0, accum_q1, source0, source1, plain, \
            extra0, extra1, p.rns_primes.data(), \
            p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(), q)
    if (drop_count == 1)
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_SINGLE_TAIL(1, 0); break;
        case 1: POSEIDON_LAUNCH_SINGLE_TAIL(1, 1); break;
        case 2: POSEIDON_LAUNCH_SINGLE_TAIL(1, 2); break;
        case 3: POSEIDON_LAUNCH_SINGLE_TAIL(1, 3); break;
        case 4: POSEIDON_LAUNCH_SINGLE_TAIL(1, 4); break;
        case 5: POSEIDON_LAUNCH_SINGLE_TAIL(1, 5); break;
        }
    }
    else
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_SINGLE_TAIL(2, 0); break;
        case 1: POSEIDON_LAUNCH_SINGLE_TAIL(2, 1); break;
        case 2: POSEIDON_LAUNCH_SINGLE_TAIL(2, 2); break;
        case 3: POSEIDON_LAUNCH_SINGLE_TAIL(2, 3); break;
        case 4: POSEIDON_LAUNCH_SINGLE_TAIL(2, 4); break;
        case 5: POSEIDON_LAUNCH_SINGLE_TAIL(2, 5); break;
        }
    }
    #undef POSEIDON_LAUNCH_SINGLE_TAIL
    gpu_check_cuda(cudaGetLastError(), "single relin rescale tail");
}

void launch_hybrid_relin_rescale_pair_tail(
    GpuWord *tail_ntt,
    const GpuWord *accum_q,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *plain,
    const GpuWord *extra00, const GpuWord *extra01,
    const GpuWord *extra10, const GpuWord *extra11,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_pair_relin_rescale(p, degree, drop_count, post_op);
    if (!tail_ntt || !accum_q || !source00 || !source01 || !source10 || !source11)
        throw std::invalid_argument("pair relin rescale tail: null pointer");
    if ((post_op == 3 || post_op == 5) && (!extra00 || !extra01 || !extra10 || !extra11))
        throw std::invalid_argument("pair relin rescale tail: missing extra cipher pointers");
    if (post_op == 5 && !plain)
        throw std::invalid_argument("pair relin rescale tail: missing plain pointer");
    const dim3 grid(static_cast<unsigned>((drop_count * degree + 255) / 256), 1, 4);
    const unsigned q = static_cast<unsigned>(p.hybrid_base_q_count);
    #define POSEIDON_LAUNCH_PAIR_TAIL(D, OP) \
        hybrid_relin_rescale_pair_tail_kernel<D, OP><<<grid, 256, 0, gpu_execution_stream()>>>( \
            tail_ntt, accum_q, source00, source01, source10, source11, plain, \
            extra00, extra01, extra10, extra11, p.rns_primes.data(), \
            p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(), q)
    if (drop_count == 1)
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_PAIR_TAIL(1, 0); break;
        case 1: POSEIDON_LAUNCH_PAIR_TAIL(1, 1); break;
        case 2: POSEIDON_LAUNCH_PAIR_TAIL(1, 2); break;
        case 3: POSEIDON_LAUNCH_PAIR_TAIL(1, 3); break;
        case 4: POSEIDON_LAUNCH_PAIR_TAIL(1, 4); break;
        case 5: POSEIDON_LAUNCH_PAIR_TAIL(1, 5); break;
        }
    }
    else
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_PAIR_TAIL(2, 0); break;
        case 1: POSEIDON_LAUNCH_PAIR_TAIL(2, 1); break;
        case 2: POSEIDON_LAUNCH_PAIR_TAIL(2, 2); break;
        case 3: POSEIDON_LAUNCH_PAIR_TAIL(2, 3); break;
        case 4: POSEIDON_LAUNCH_PAIR_TAIL(2, 4); break;
        case 5: POSEIDON_LAUNCH_PAIR_TAIL(2, 5); break;
        }
    }
    #undef POSEIDON_LAUNCH_PAIR_TAIL
    gpu_check_cuda(cudaGetLastError(), "pair relin rescale tail");
}

void launch_hybrid_relin_rescale_pair_merge_correction(
    GpuWord *merged_coeff,
    const GpuWord *converted_coeff,
    const GpuWord *tail_coeff,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_pair_relin_rescale(p, degree, drop_count, post_op);
    if (!merged_coeff || !converted_coeff || !tail_coeff)
        throw std::invalid_argument("pair relin rescale merge: null pointer");
    const dim3 grid(static_cast<unsigned>((degree + 255) / 256), 1, 4);
    const unsigned q = static_cast<unsigned>(p.hybrid_base_q_count);
    #define POSEIDON_LAUNCH_PAIR_MERGE(D, OP) \
        hybrid_relin_rescale_pair_merge_correction_kernel<D, OP><<<grid, 256, 0, gpu_execution_stream()>>>( \
            merged_coeff, converted_coeff, tail_coeff, p.rns_primes.data(), \
            p.rns_modulus_constants.data(), p.hybrid_inv_p_mod_q.data(), \
            p.half_q_last_mod_q.data(), p.q_last, p.half_q_last, \
            p.q_last_two_product_mod_q.data(), p.half_q_last_two_product, \
            p.inv_q_last_mod_q_second_last, q)
    if (drop_count == 1)
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_PAIR_MERGE(1, 0); break;
        case 1: POSEIDON_LAUNCH_PAIR_MERGE(1, 1); break;
        case 2: POSEIDON_LAUNCH_PAIR_MERGE(1, 2); break;
        case 3: POSEIDON_LAUNCH_PAIR_MERGE(1, 3); break;
        case 4: POSEIDON_LAUNCH_PAIR_MERGE(1, 4); break;
        case 5: POSEIDON_LAUNCH_PAIR_MERGE(1, 5); break;
        }
    }
    else
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_PAIR_MERGE(2, 0); break;
        case 1: POSEIDON_LAUNCH_PAIR_MERGE(2, 1); break;
        case 2: POSEIDON_LAUNCH_PAIR_MERGE(2, 2); break;
        case 3: POSEIDON_LAUNCH_PAIR_MERGE(2, 3); break;
        case 4: POSEIDON_LAUNCH_PAIR_MERGE(2, 4); break;
        case 5: POSEIDON_LAUNCH_PAIR_MERGE(2, 5); break;
        }
    }
    #undef POSEIDON_LAUNCH_PAIR_MERGE
    gpu_check_cuda(cudaGetLastError(), "pair relin rescale merge");
}

void launch_hybrid_relin_rescale_pair_apply(
    GpuWord *destination00, GpuWord *destination01,
    GpuWord *destination10, GpuWord *destination11,
    const GpuWord *accum_q,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *plain,
    const GpuWord *extra00, const GpuWord *extra01,
    const GpuWord *extra10, const GpuWord *extra11,
    const GpuWord *correction_ntt,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &p, std::size_t degree)
{
    validate_pair_relin_rescale(p, degree, drop_count, post_op);
    if (!destination00 || !destination01 || !destination10 || !destination11 ||
        !accum_q || !source00 || !source01 || !source10 || !source11 || !correction_ntt)
        throw std::invalid_argument("pair relin rescale apply: null pointer");
    if ((post_op == 3 || post_op == 5) && (!extra00 || !extra01 || !extra10 || !extra11))
        throw std::invalid_argument("pair relin rescale apply: missing extra cipher pointers");
    if (post_op == 5 && !plain)
        throw std::invalid_argument("pair relin rescale apply: missing plain pointer");
    const unsigned q = static_cast<unsigned>(p.hybrid_base_q_count);
    const dim3 grid(static_cast<unsigned>(((q - drop_count) * degree + 255) / 256), 1, 4);
    const GpuWord *inv_div = drop_count == 1
        ? p.inv_q_last_mod_q.data()
        : p.inv_q_last_two_product_mod_q.data();
    #define POSEIDON_LAUNCH_PAIR_APPLY(D, OP) \
        hybrid_relin_rescale_pair_apply_kernel<D, OP><<<grid, 256, 0, gpu_execution_stream()>>>( \
            destination00, destination01, destination10, destination11, accum_q, \
            source00, source01, source10, source11, plain, \
            extra00, extra01, extra10, extra11, correction_ntt, \
            p.rns_primes.data(), p.rns_modulus_constants.data(), \
            p.hybrid_inv_p_mod_q.data(), inv_div, q)
    if (drop_count == 1)
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_PAIR_APPLY(1, 0); break;
        case 1: POSEIDON_LAUNCH_PAIR_APPLY(1, 1); break;
        case 2: POSEIDON_LAUNCH_PAIR_APPLY(1, 2); break;
        case 3: POSEIDON_LAUNCH_PAIR_APPLY(1, 3); break;
        case 4: POSEIDON_LAUNCH_PAIR_APPLY(1, 4); break;
        case 5: POSEIDON_LAUNCH_PAIR_APPLY(1, 5); break;
        }
    }
    else
    {
        switch (post_op)
        {
        case 0: POSEIDON_LAUNCH_PAIR_APPLY(2, 0); break;
        case 1: POSEIDON_LAUNCH_PAIR_APPLY(2, 1); break;
        case 2: POSEIDON_LAUNCH_PAIR_APPLY(2, 2); break;
        case 3: POSEIDON_LAUNCH_PAIR_APPLY(2, 3); break;
        case 4: POSEIDON_LAUNCH_PAIR_APPLY(2, 4); break;
        case 5: POSEIDON_LAUNCH_PAIR_APPLY(2, 5); break;
        }
    }
    #undef POSEIDON_LAUNCH_PAIR_APPLY
    gpu_check_cuda(cudaGetLastError(), "pair relin rescale apply");
}

namespace
{

__device__ __forceinline__ std::uint32_t galois_ntt_source_coeff_65536(
    std::uint32_t coeff,
    std::uint32_t galois_elt)
{
    constexpr std::uint32_t kDegree = 65536U;
    constexpr std::uint32_t kMask = kDegree - 1U;
    const std::uint32_t reversed = reverse_bits_limited(kDegree + coeff, 17U);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) *
         static_cast<std::uint64_t>(reversed)) >>
        1;
    return reverse_bits_limited(
        static_cast<std::uint32_t>(index_raw & kMask), 16U);
}

struct GaloisBatchArgs16
{
    const GpuWord *src_c1[kMaxBatchKeySwitchItems];
    std::uint32_t galois_elts[kMaxBatchKeySwitchItems];
};

struct KeyMulBatchArgs16
{
    const GpuWord *key_q0[kMaxBatchKeySwitchItems];
    const GpuWord *key_p0[kMaxBatchKeySwitchItems];
    const GpuWord *key_q1[kMaxBatchKeySwitchItems];
    const GpuWord *key_p1[kMaxBatchKeySwitchItems];
};

struct ApplyModDownBatchArgs16
{
    GpuWord *dst_c0[kMaxBatchKeySwitchItems];
    GpuWord *dst_c1[kMaxBatchKeySwitchItems];
    const GpuWord *src_c0[kMaxBatchKeySwitchItems];
    const GpuWord *add_c0[kMaxBatchKeySwitchItems];
    const GpuWord *add_c1[kMaxBatchKeySwitchItems];
    std::uint32_t galois_elts[kMaxBatchKeySwitchItems];
};

struct ApplyModDownSumArgs16
{
    const GpuWord *src_c0[kMaxBatchKeySwitchItems];
    std::uint32_t galois_elts[kMaxBatchKeySwitchItems];
};

__global__ void __launch_bounds__(256)
hybrid_apply_moddown_ntt_multi_destinations_65536_kernel(
    BatchMutPolyPtrs32 destinations,
    const GpuWord *__restrict__ source_q_base,
    std::size_t source_component_offset,
    const GpuWord *__restrict__ converted_q,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    const GpuWord *__restrict__ inv_p,
    std::size_t q_words)
{
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= q_words)
    {
        return;
    }
    const std::size_t comp = blockIdx.z;
    const std::size_t limb = tid >> 16;
    const GpuWord modulus = primes[limb];
    const GpuWord src_val =
        source_q_base[(source_component_offset + comp) * q_words + tid];
    const GpuWord conv_val = converted_q[comp * q_words + tid];
    destinations.ptrs[comp][tid] = mul_mod(
        sub_mod(src_val, conv_val, modulus),
        inv_p[limb],
        modulus,
        barrett[limb]);
}

__global__ void __launch_bounds__(256) batch_apply_galois_ntt_65536_kernel(
    GpuWord *__restrict__ permuted_batch,
    GaloisBatchArgs16 args,
    std::size_t limb_count)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t poly_words = limb_count * kDegree;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= poly_words)
    {
        return;
    }
    const std::size_t b = blockIdx.z;
    const std::size_t limb = tid >> 16;
    const std::uint32_t coeff = static_cast<std::uint32_t>(tid & (kDegree - 1));
    const std::uint32_t src_coeff =
        galois_ntt_source_coeff_65536(coeff, args.galois_elts[b]);
    permuted_batch[b * poly_words + tid] =
        args.src_c1[b][(limb << 16) + src_coeff];
}

__global__ void __launch_bounds__(256)
hybrid_modup_p_only_singleton_batch_65536_kernel(
    GpuWord *__restrict__ modup_p_batch,
    const GpuWord *__restrict__ c1_coeff_batch,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    std::size_t p_count)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t p_words = p_count * kDegree;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= p_words)
    {
        return;
    }
    const std::size_t b = blockIdx.z;
    const std::size_t target_p = tid >> 16;
    const std::size_t coeff = tid & (kDegree - 1);
    const std::size_t table_limb = 1 + target_p;
    const GpuWord val = c1_coeff_batch[b * kDegree + coeff];
    modup_p_batch[b * p_words + tid] =
        reduce_to_modulus(val, primes[table_limb], barrett[table_limb]);
}

__global__ void __launch_bounds__(256)
batch_dnum1_keymul_shared_key_65536_kernel(
    GpuWord *__restrict__ accum_q_batch,
    GpuWord *__restrict__ accum_p_batch,
    const GpuWord *__restrict__ permuted_c1_batch,
    const GpuWord *__restrict__ modup_p_batch,
    const GpuWord *__restrict__ key_q0,
    const GpuWord *__restrict__ key_p0,
    const GpuWord *__restrict__ key_q1,
    const GpuWord *__restrict__ key_p1,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    std::size_t q_count,
    std::size_t p_count,
    std::size_t batch_count)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t q_words = q_count * kDegree;
    const std::size_t p_words = p_count * kDegree;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= q_words + p_words)
    {
        return;
    }
    const std::size_t table_limb = tid >> 16;
    const GpuWord modulus = primes[table_limb];
    const GpuWide ratio = barrett[table_limb];
    if (tid < q_words)
    {
        const GpuWord k0 = key_q0[tid];
        const GpuWord k1 = key_q1[tid];
        for (std::size_t b = 0; b < batch_count; ++b)
        {
            const GpuWord val = permuted_c1_batch[b * q_words + tid];
            accum_q_batch[(2 * b + 0) * q_words + tid] =
                mul_mod(val, k0, modulus, ratio);
            accum_q_batch[(2 * b + 1) * q_words + tid] =
                mul_mod(val, k1, modulus, ratio);
        }
    }
    else
    {
        const std::size_t p_tid = tid - q_words;
        const GpuWord k0 = key_p0[p_tid];
        const GpuWord k1 = key_p1[p_tid];
        for (std::size_t b = 0; b < batch_count; ++b)
        {
            const GpuWord val = modup_p_batch[b * p_words + p_tid];
            accum_p_batch[(2 * b + 0) * p_words + p_tid] =
                mul_mod(val, k0, modulus, ratio);
            accum_p_batch[(2 * b + 1) * p_words + p_tid] =
                mul_mod(val, k1, modulus, ratio);
        }
    }
}

__global__ void __launch_bounds__(256)
batch_dnum1_keymul_distinct_keys_65536_kernel(
    GpuWord *__restrict__ accum_q_batch,
    GpuWord *__restrict__ accum_p_batch,
    const GpuWord *__restrict__ permuted_c1_batch,
    const GpuWord *__restrict__ modup_p_batch,
    KeyMulBatchArgs16 keys,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    std::size_t q_count,
    std::size_t p_count)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t q_words = q_count * kDegree;
    const std::size_t p_words = p_count * kDegree;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= q_words + p_words)
    {
        return;
    }
    const std::size_t b = blockIdx.z;
    const std::size_t table_limb = tid >> 16;
    const GpuWord modulus = primes[table_limb];
    const GpuWide ratio = barrett[table_limb];
    if (tid < q_words)
    {
        const GpuWord val = permuted_c1_batch[b * q_words + tid];
        accum_q_batch[(2 * b + 0) * q_words + tid] =
            mul_mod(val, keys.key_q0[b][tid], modulus, ratio);
        accum_q_batch[(2 * b + 1) * q_words + tid] =
            mul_mod(val, keys.key_q1[b][tid], modulus, ratio);
    }
    else
    {
        const std::size_t p_tid = tid - q_words;
        const GpuWord val = modup_p_batch[b * p_words + p_tid];
        accum_p_batch[(2 * b + 0) * p_words + p_tid] =
            mul_mod(val, keys.key_p0[b][p_tid], modulus, ratio);
        accum_p_batch[(2 * b + 1) * p_words + p_tid] =
            mul_mod(val, keys.key_p1[b][p_tid], modulus, ratio);
    }
}

__global__ void __launch_bounds__(256)
batch_dnum1_keymul_sum_lazy_moddown_65536_kernel(
    GpuWord *__restrict__ accum_q_two,
    GpuWord *__restrict__ accum_p_two,
    const GpuWord *__restrict__ permuted_c1_batch,
    const GpuWord *__restrict__ modup_p_batch,
    KeyMulBatchArgs16 keys,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    std::size_t q_count,
    std::size_t p_count,
    std::size_t batch_count)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t q_words = q_count * kDegree;
    const std::size_t p_words = p_count * kDegree;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= q_words + p_words)
    {
        return;
    }
    const std::size_t table_limb = tid >> 16;
    const GpuWord modulus = primes[table_limb];
    const GpuWide ratio = barrett[table_limb];
    LazyAccumulator acc0;
    LazyAccumulator acc1;
    if (tid < q_words)
    {
        for (std::size_t b = 0; b < batch_count; ++b)
        {
            const GpuWord val = permuted_c1_batch[b * q_words + tid];
            lazy_mac(acc0, val, keys.key_q0[b][tid]);
            lazy_mac(acc1, val, keys.key_q1[b][tid]);
        }
        accum_q_two[tid] = lazy_reduce(acc0, modulus, ratio);
        accum_q_two[q_words + tid] = lazy_reduce(acc1, modulus, ratio);
    }
    else
    {
        const std::size_t p_tid = tid - q_words;
        for (std::size_t b = 0; b < batch_count; ++b)
        {
            const GpuWord val = modup_p_batch[b * p_words + p_tid];
            lazy_mac(acc0, val, keys.key_p0[b][p_tid]);
            lazy_mac(acc1, val, keys.key_p1[b][p_tid]);
        }
        accum_p_two[p_tid] = lazy_reduce(acc0, modulus, ratio);
        accum_p_two[p_words + p_tid] = lazy_reduce(acc1, modulus, ratio);
    }
}

template <bool HasAdd>
__global__ void __launch_bounds__(256)
batch_dnum1_apply_moddown_65536_kernel(
    ApplyModDownBatchArgs16 args,
    const GpuWord *__restrict__ accum_q_batch,
    const GpuWord *__restrict__ converted_q_batch,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    const GpuWord *__restrict__ inv_p,
    std::size_t q_words)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= q_words)
    {
        return;
    }
    const std::size_t b = blockIdx.z;
    const std::size_t limb = tid >> 16;
    const std::uint32_t coeff = static_cast<std::uint32_t>(tid & (kDegree - 1));
    const GpuWord modulus = primes[limb];
    const GpuWide ratio = barrett[limb];
    const GpuWord inv_p_limb = inv_p[limb];
    const std::size_t off0 = (2 * b + 0) * q_words + tid;
    const std::size_t off1 = (2 * b + 1) * q_words + tid;
    GpuWord c0_val = mul_mod(
        sub_mod(accum_q_batch[off0], converted_q_batch[off0], modulus),
        inv_p_limb,
        modulus,
        ratio);
    GpuWord c1_val = mul_mod(
        sub_mod(accum_q_batch[off1], converted_q_batch[off1], modulus),
        inv_p_limb,
        modulus,
        ratio);
    const std::uint32_t src_coeff =
        galois_ntt_source_coeff_65536(coeff, args.galois_elts[b]);
    c0_val = add_mod(c0_val, args.src_c0[b][(limb << 16) + src_coeff], modulus);
    if constexpr (HasAdd)
    {
        c0_val = add_mod(c0_val, args.add_c0[b][tid], modulus);
        c1_val = add_mod(c1_val, args.add_c1[b][tid], modulus);
    }
    args.dst_c0[b][tid] = c0_val;
    args.dst_c1[b][tid] = c1_val;
}

__global__ void __launch_bounds__(256)
batch_dnum1_apply_moddown_sum_65536_kernel(
    GpuWord *__restrict__ dst_c0,
    GpuWord *__restrict__ dst_c1,
    const GpuWord *__restrict__ identity_c0,
    const GpuWord *__restrict__ identity_c1,
    ApplyModDownSumArgs16 args,
    const GpuWord *__restrict__ accum_q_two,
    const GpuWord *__restrict__ converted_q_two,
    const GpuWord *__restrict__ primes,
    const GpuWide *__restrict__ barrett,
    const GpuWord *__restrict__ inv_p,
    std::size_t q_words,
    std::size_t batch_count)
{
    constexpr std::size_t kDegree = 65536;
    const std::size_t tid =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (tid >= q_words)
    {
        return;
    }
    const std::size_t limb = tid >> 16;
    const std::uint32_t coeff = static_cast<std::uint32_t>(tid & (kDegree - 1));
    const std::size_t limb_base = limb << 16;
    const GpuWord modulus = primes[limb];
    const GpuWide ratio = barrett[limb];
    const GpuWord inv_p_limb = inv_p[limb];
    GpuWord c0_val = mul_mod(
        sub_mod(accum_q_two[tid], converted_q_two[tid], modulus),
        inv_p_limb,
        modulus,
        ratio);
    GpuWord c1_val = mul_mod(
        sub_mod(
            accum_q_two[q_words + tid],
            converted_q_two[q_words + tid],
            modulus),
        inv_p_limb,
        modulus,
        ratio);
    if (identity_c0 != nullptr)
    {
        c0_val = add_mod(c0_val, identity_c0[tid], modulus);
        c1_val = add_mod(c1_val, identity_c1[tid], modulus);
    }
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        const std::uint32_t src_coeff =
            galois_ntt_source_coeff_65536(coeff, args.galois_elts[b]);
        c0_val = add_mod(c0_val, args.src_c0[b][limb_base + src_coeff], modulus);
    }
    dst_c0[tid] = c0_val;
    dst_c1[tid] = c1_val;
}

}  // namespace

void launch_hybrid_convert_p_to_q_preweighted_batch(
    GpuWord *converted_q,
    const GpuWord *weighted_p,
    std::size_t component_count,
    const GpuParameterShard &parameters,
    std::size_t degree)
{
    validate_hybrid_relinearize_pair_parameters(parameters, degree);
    if (converted_q == nullptr || weighted_p == nullptr ||
        component_count == 0 || component_count > 64)
    {
        throw std::invalid_argument(
            "launch_hybrid_convert_p_to_q_preweighted_batch: invalid arguments");
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batched PtoQ cudaSetDevice");
    const auto q = parameters.hybrid_base_q_count;
    const auto p = parameters.hybrid_base_p_count;
    if (try_launch_hybrid_convert_p_to_q_cta_tiled_65536(
            converted_q, nullptr, weighted_p, nullptr,
            parameters, component_count, false, degree))
    {
        gpu_check_cuda(cudaGetLastError(), "batched PtoQ cta_tiled conversion");
        return;
    }
    constexpr unsigned int threads = 256;
    const int ptoq_cfg = opt_flag_value(OptFlag::PToQTile);
    const int tile = select_adaptive_tile_4_8_12_16(q, ptoq_cfg > 0 ? ptoq_cfg : 4);
    const auto blocks = static_cast<unsigned int>(
        ((q + tile - 1) / tile * (degree / 2) + threads - 1) / threads);
    const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_BATCH_PTOQ(T)                                                              \
    hybrid_convert_p_to_q_lazy_preweighted_kernel<T, 1, true><<<                                   \
        dim3(blocks, 1, static_cast<unsigned int>(component_count)),                               \
        threads, 0, gpu_execution_stream()>>>(                                                     \
        converted_q, nullptr, weighted_p, nullptr,                                                 \
        parameters.rns_primes.data(),                                                              \
        parameters.rns_modulus_constants.data(),                                                   \
        parameters.hybrid_moddown_p_to_q_matrix.data(),                                            \
        static_cast<unsigned int>(q),                                                              \
        static_cast<unsigned int>(p),                                                              \
        16, vec_bconv)
    if (tile == 16) { POSEIDON_LAUNCH_BATCH_PTOQ(16); }
    else if (tile == 12) { POSEIDON_LAUNCH_BATCH_PTOQ(12); }
    else if (tile == 8) { POSEIDON_LAUNCH_BATCH_PTOQ(8); }
    else { POSEIDON_LAUNCH_BATCH_PTOQ(4); }
#undef POSEIDON_LAUNCH_BATCH_PTOQ
    gpu_check_cuda(cudaGetLastError(), "batched PtoQ conversion");
}

void launch_hybrid_apply_moddown_ntt_multi_destinations(
    const BatchMutPolyPtrs32 &destinations,
    const GpuWord *source_q_base,
    std::size_t source_component_offset,
    const GpuWord *converted_q,
    std::size_t component_count,
    const GpuParameterShard &parameters,
    std::size_t degree)
{
    validate_hybrid_tables(
        "launch_hybrid_apply_moddown_ntt_multi_destinations",
        parameters,
        degree);
    if (degree != 65536 || source_q_base == nullptr ||
        converted_q == nullptr || component_count == 0 || component_count > 32)
    {
        throw std::invalid_argument(
            "launch_hybrid_apply_moddown_ntt_multi_destinations: invalid arguments");
    }
    for (std::size_t c = 0; c < component_count; ++c)
    {
        if (destinations.ptrs[c] == nullptr)
        {
            throw std::invalid_argument(
                "launch_hybrid_apply_moddown_ntt_multi_destinations: null destination");
        }
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "multi-dest ModDown apply cudaSetDevice");
    const std::size_t q_words = parameters.hybrid_base_q_count * degree;
    const auto blocks = static_cast<unsigned int>((q_words + 255) / 256);
    hybrid_apply_moddown_ntt_multi_destinations_65536_kernel<<<
        dim3(blocks, 1, static_cast<unsigned int>(component_count)),
        256,
        0,
        gpu_execution_stream()>>>(
        destinations,
        source_q_base,
        source_component_offset,
        converted_q,
        parameters.rns_primes.data(),
        parameters.rns_modulus_constants.data(),
        parameters.hybrid_inv_p_mod_q.data(),
        q_words);
    gpu_check_cuda(cudaGetLastError(), "multi-dest ModDown apply");
}

void launch_batch_apply_galois_ntt_65536(
    GpuWord *permuted_batch,
    const BatchRotateDnum1Args &args,
    std::size_t batch_count,
    std::size_t limb_count,
    int device_id)
{
    constexpr std::size_t kDegree = 65536;
    if (permuted_batch == nullptr || limb_count == 0 ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems)
    {
        throw std::invalid_argument(
            "launch_batch_apply_galois_ntt_65536: invalid arguments");
    }
    GaloisBatchArgs16 kargs{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        const std::uint32_t elt = args.galois_elts[b];
        if (args.src_c1[b] == nullptr ||
            args.src_c1[b] == permuted_batch + b * limb_count * kDegree ||
            (elt & 1U) == 0U || elt >= 2U * kDegree)
        {
            throw std::invalid_argument(
                "launch_batch_apply_galois_ntt_65536: invalid source or Galois element");
        }
        kargs.src_c1[b] = args.src_c1[b];
        kargs.galois_elts[b] = elt;
    }
    gpu_check_cuda(cudaSetDevice(device_id), "batch Galois cudaSetDevice");
    const std::size_t poly_words = limb_count * kDegree;
    const auto blocks = static_cast<unsigned int>((poly_words + 255) / 256);
    batch_apply_galois_ntt_65536_kernel<<<
        dim3(blocks, 1, static_cast<unsigned int>(batch_count)),
        256,
        0,
        gpu_execution_stream()>>>(permuted_batch, kargs, limb_count);
    gpu_check_cuda(cudaGetLastError(), "batch Galois kernel");
}

void launch_hybrid_modup_p_only_preweighted_batch_65536(
    GpuWord *modup_p_batch,
    const GpuWord *c1_coeff_batch,
    std::size_t batch_count,
    const GpuParameterShard &parameters)
{
    constexpr std::size_t kDegree = 65536;
    validate_hybrid_relinearize_pair_parameters(parameters, kDegree);
    const std::size_t q = parameters.hybrid_base_q_count;
    const std::size_t p = parameters.hybrid_base_p_count;
    if (modup_p_batch == nullptr || c1_coeff_batch == nullptr ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems ||
        parameters.hybrid_decomp_count != 1 || q == 0 || q > p ||
        p > kModupPreweightMaxCols)
    {
        throw std::invalid_argument(
            "launch_hybrid_modup_p_only_preweighted_batch_65536: invalid arguments");
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batch P-only ModUp cudaSetDevice");
    constexpr unsigned int threads = 256;
    if (q == 1)
    {
        const auto blocks =
            static_cast<unsigned int>((p * kDegree + threads - 1) / threads);
        hybrid_modup_p_only_singleton_batch_65536_kernel<<<
            dim3(blocks, 1, static_cast<unsigned int>(batch_count)),
            threads,
            0,
            gpu_execution_stream()>>>(
            modup_p_batch,
            c1_coeff_batch,
            parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(),
            p);
        gpu_check_cuda(cudaGetLastError(), "batch singleton P-only ModUp");
        return;
    }
    if (try_launch_hybrid_modup_qp_cta_tiled_65536(
            nullptr, modup_p_batch, c1_coeff_batch, parameters,
            0, 0, q, batch_count,
            q * kDegree, 0, p * kDegree, kDegree))
    {
        gpu_check_cuda(cudaGetLastError(), "batch preweighted P-only ModUp cta_tiled");
        return;
    }
    const int tile = select_adaptive_tile_4_8_12_16(p, opt_flag_value(OptFlag::ModupTile));
    const std::size_t tiles = (p + tile - 1) / tile;
    const auto blocks = static_cast<unsigned int>(
        (tiles * (kDegree / 2) + threads - 1) / threads);
    const bool vec_bconv = opt_flag(OptFlag::VecBconv);
#define POSEIDON_LAUNCH_PONLY_MODUP_PW(T)                                                          \
    hybrid_modup_qp_lazy_preweighted_kernel<T, true><<<                                            \
        dim3(blocks, 1, static_cast<unsigned int>(batch_count)),                                   \
        threads, 0, gpu_execution_stream()>>>(                                                     \
        nullptr, modup_p_batch, c1_coeff_batch,                                                    \
        parameters.rns_primes.data(),                                                              \
        parameters.rns_modulus_constants.data(),                                                   \
        parameters.hybrid_q_conv_matrix_offsets.data(),                                            \
        parameters.hybrid_q_conv_matrices.data(),                                                  \
        parameters.hybrid_p_conv_matrix_offsets.data(),                                            \
        parameters.hybrid_p_conv_matrices.data(),                                                  \
        0U, 0U, static_cast<unsigned int>(q),                                                      \
        static_cast<unsigned int>(q), static_cast<unsigned int>(p), 16U,                           \
        0, 0, 0, vec_bconv)
    if (tile == 16) { POSEIDON_LAUNCH_PONLY_MODUP_PW(16); }
    else if (tile == 12) { POSEIDON_LAUNCH_PONLY_MODUP_PW(12); }
    else if (tile == 8) { POSEIDON_LAUNCH_PONLY_MODUP_PW(8); }
    else { POSEIDON_LAUNCH_PONLY_MODUP_PW(4); }
#undef POSEIDON_LAUNCH_PONLY_MODUP_PW
    gpu_check_cuda(cudaGetLastError(), "batch preweighted P-only ModUp");
}

void launch_batch_dnum1_keymul_shared_key_65536(
    GpuWord *accum_q_batch,
    GpuWord *accum_p_batch,
    const GpuWord *permuted_c1_batch,
    const GpuWord *modup_p_batch,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t batch_count,
    const GpuParameterShard &parameters)
{
    constexpr std::size_t kDegree = 65536;
    validate_hybrid_relinearize_pair_parameters(parameters, kDegree);
    if (accum_q_batch == nullptr || accum_p_batch == nullptr ||
        permuted_c1_batch == nullptr || modup_p_batch == nullptr ||
        key_q0 == nullptr || key_p0 == nullptr ||
        key_q1 == nullptr || key_p1 == nullptr ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems)
    {
        throw std::invalid_argument(
            "launch_batch_dnum1_keymul_shared_key_65536: invalid arguments");
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batch shared-key keymul cudaSetDevice");
    const std::size_t q = parameters.hybrid_base_q_count;
    const std::size_t p = parameters.hybrid_base_p_count;
    const auto blocks =
        static_cast<unsigned int>(((q + p) * kDegree + 255) / 256);
    batch_dnum1_keymul_shared_key_65536_kernel<<<
        blocks,
        256,
        0,
        gpu_execution_stream()>>>(
        accum_q_batch,
        accum_p_batch,
        permuted_c1_batch,
        modup_p_batch,
        key_q0,
        key_p0,
        key_q1,
        key_p1,
        parameters.rns_primes.data(),
        parameters.rns_modulus_constants.data(),
        q,
        p,
        batch_count);
    gpu_check_cuda(cudaGetLastError(), "batch shared-key keymul");
}

void launch_batch_dnum1_keymul_distinct_keys_65536(
    GpuWord *accum_q_batch,
    GpuWord *accum_p_batch,
    const GpuWord *permuted_c1_batch,
    const GpuWord *modup_p_batch,
    const BatchRotateDnum1Args &args,
    std::size_t batch_count,
    const GpuParameterShard &parameters)
{
    constexpr std::size_t kDegree = 65536;
    validate_hybrid_relinearize_pair_parameters(parameters, kDegree);
    if (accum_q_batch == nullptr || accum_p_batch == nullptr ||
        permuted_c1_batch == nullptr || modup_p_batch == nullptr ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems)
    {
        throw std::invalid_argument(
            "launch_batch_dnum1_keymul_distinct_keys_65536: invalid arguments");
    }
    KeyMulBatchArgs16 kargs{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        if (args.key_q0[b] == nullptr || args.key_p0[b] == nullptr ||
            args.key_q1[b] == nullptr || args.key_p1[b] == nullptr)
        {
            throw std::invalid_argument(
                "launch_batch_dnum1_keymul_distinct_keys_65536: null key pointer");
        }
        kargs.key_q0[b] = args.key_q0[b];
        kargs.key_p0[b] = args.key_p0[b];
        kargs.key_q1[b] = args.key_q1[b];
        kargs.key_p1[b] = args.key_p1[b];
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batch distinct-keys keymul cudaSetDevice");
    const std::size_t q = parameters.hybrid_base_q_count;
    const std::size_t p = parameters.hybrid_base_p_count;
    const auto blocks =
        static_cast<unsigned int>(((q + p) * kDegree + 255) / 256);
    batch_dnum1_keymul_distinct_keys_65536_kernel<<<
        dim3(blocks, 1, static_cast<unsigned int>(batch_count)),
        256,
        0,
        gpu_execution_stream()>>>(
        accum_q_batch,
        accum_p_batch,
        permuted_c1_batch,
        modup_p_batch,
        kargs,
        parameters.rns_primes.data(),
        parameters.rns_modulus_constants.data(),
        q,
        p);
    gpu_check_cuda(cudaGetLastError(), "batch distinct-keys keymul");
}

void launch_batch_dnum1_keymul_sum_lazy_moddown_65536(
    GpuWord *accum_q_two,
    GpuWord *accum_p_two,
    const GpuWord *permuted_c1_batch,
    const GpuWord *modup_p_batch,
    const BatchRotateDnum1Args &args,
    std::size_t batch_count,
    const GpuParameterShard &parameters)
{
    constexpr std::size_t kDegree = 65536;
    validate_hybrid_relinearize_pair_parameters(parameters, kDegree);
    if (accum_q_two == nullptr || accum_p_two == nullptr ||
        permuted_c1_batch == nullptr || modup_p_batch == nullptr ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems)
    {
        throw std::invalid_argument(
            "launch_batch_dnum1_keymul_sum_lazy_moddown_65536: invalid arguments");
    }
    KeyMulBatchArgs16 kargs{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        if (args.key_q0[b] == nullptr || args.key_p0[b] == nullptr ||
            args.key_q1[b] == nullptr || args.key_p1[b] == nullptr)
        {
            throw std::invalid_argument(
                "launch_batch_dnum1_keymul_sum_lazy_moddown_65536: null key pointer");
        }
        kargs.key_q0[b] = args.key_q0[b];
        kargs.key_p0[b] = args.key_p0[b];
        kargs.key_q1[b] = args.key_q1[b];
        kargs.key_p1[b] = args.key_p1[b];
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batch sum keymul cudaSetDevice");
    const std::size_t q = parameters.hybrid_base_q_count;
    const std::size_t p = parameters.hybrid_base_p_count;
    const auto blocks =
        static_cast<unsigned int>(((q + p) * kDegree + 255) / 256);
    batch_dnum1_keymul_sum_lazy_moddown_65536_kernel<<<
        blocks,
        256,
        0,
        gpu_execution_stream()>>>(
        accum_q_two,
        accum_p_two,
        permuted_c1_batch,
        modup_p_batch,
        kargs,
        parameters.rns_primes.data(),
        parameters.rns_modulus_constants.data(),
        q,
        p,
        batch_count);
    gpu_check_cuda(cudaGetLastError(), "batch sum keymul");
}

void launch_batch_dnum1_apply_moddown_65536(
    const BatchRotateDnum1Args &args,
    const GpuWord *accum_q_batch,
    const GpuWord *converted_q_batch,
    std::size_t batch_count,
    bool has_add_sources,
    const GpuParameterShard &parameters)
{
    constexpr std::size_t kDegree = 65536;
    validate_hybrid_relinearize_pair_parameters(parameters, kDegree);
    if (accum_q_batch == nullptr || converted_q_batch == nullptr ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems)
    {
        throw std::invalid_argument(
            "launch_batch_dnum1_apply_moddown_65536: invalid arguments");
    }
    ApplyModDownBatchArgs16 kargs{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        const std::uint32_t elt = args.galois_elts[b];
        if (args.dst_c0[b] == nullptr || args.dst_c1[b] == nullptr ||
            args.src_c0[b] == nullptr || args.dst_c0[b] == args.dst_c1[b] ||
            args.dst_c0[b] == args.src_c0[b] ||
            args.dst_c1[b] == args.src_c0[b] ||
            (elt & 1U) == 0U || elt >= 2U * kDegree)
        {
            throw std::invalid_argument(
                "launch_batch_dnum1_apply_moddown_65536: invalid buffers or Galois element");
        }
        if (has_add_sources &&
            (args.add_c0[b] == nullptr || args.add_c1[b] == nullptr ||
             args.add_c0[b] == args.dst_c1[b] ||
             args.add_c1[b] == args.dst_c0[b]))
        {
            throw std::invalid_argument(
                "launch_batch_dnum1_apply_moddown_65536: invalid add source buffers");
        }
        kargs.dst_c0[b] = args.dst_c0[b];
        kargs.dst_c1[b] = args.dst_c1[b];
        kargs.src_c0[b] = args.src_c0[b];
        kargs.add_c0[b] = args.add_c0[b];
        kargs.add_c1[b] = args.add_c1[b];
        kargs.galois_elts[b] = elt;
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batch ModDown apply cudaSetDevice");
    const std::size_t q_words = parameters.hybrid_base_q_count * kDegree;
    const auto blocks = static_cast<unsigned int>((q_words + 255) / 256);
    if (has_add_sources)
    {
        batch_dnum1_apply_moddown_65536_kernel<true><<<
            dim3(blocks, 1, static_cast<unsigned int>(batch_count)),
            256,
            0,
            gpu_execution_stream()>>>(
            kargs,
            accum_q_batch,
            converted_q_batch,
            parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(),
            parameters.hybrid_inv_p_mod_q.data(),
            q_words);
    }
    else
    {
        batch_dnum1_apply_moddown_65536_kernel<false><<<
            dim3(blocks, 1, static_cast<unsigned int>(batch_count)),
            256,
            0,
            gpu_execution_stream()>>>(
            kargs,
            accum_q_batch,
            converted_q_batch,
            parameters.rns_primes.data(),
            parameters.rns_modulus_constants.data(),
            parameters.hybrid_inv_p_mod_q.data(),
            q_words);
    }
    gpu_check_cuda(cudaGetLastError(), "batch ModDown apply");
}

void launch_batch_dnum1_apply_moddown_sum_65536(
    GpuWord *dst_c0,
    GpuWord *dst_c1,
    const GpuWord *identity_c0,
    const GpuWord *identity_c1,
    const BatchRotateDnum1Args &args,
    const GpuWord *accum_q_two,
    const GpuWord *converted_q_two,
    std::size_t batch_count,
    const GpuParameterShard &parameters)
{
    constexpr std::size_t kDegree = 65536;
    validate_hybrid_relinearize_pair_parameters(parameters, kDegree);
    if (dst_c0 == nullptr || dst_c1 == nullptr || dst_c0 == dst_c1 ||
        (identity_c0 == nullptr) != (identity_c1 == nullptr) ||
        identity_c0 == dst_c1 || identity_c1 == dst_c0 ||
        accum_q_two == nullptr || converted_q_two == nullptr ||
        batch_count == 0 || batch_count > kMaxBatchKeySwitchItems)
    {
        throw std::invalid_argument(
            "launch_batch_dnum1_apply_moddown_sum_65536: invalid arguments");
    }
    ApplyModDownSumArgs16 kargs{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        const std::uint32_t elt = args.galois_elts[b];
        if (args.src_c0[b] == nullptr ||
            args.src_c0[b] == dst_c0 || args.src_c0[b] == dst_c1 ||
            (elt & 1U) == 0U || elt >= 2U * kDegree)
        {
            throw std::invalid_argument(
                "launch_batch_dnum1_apply_moddown_sum_65536: invalid source or Galois element");
        }
        kargs.src_c0[b] = args.src_c0[b];
        kargs.galois_elts[b] = elt;
    }
    gpu_check_cuda(
        cudaSetDevice(parameters.device_id),
        "batch sum ModDown apply cudaSetDevice");
    const std::size_t q_words = parameters.hybrid_base_q_count * kDegree;
    const auto blocks = static_cast<unsigned int>((q_words + 255) / 256);
    batch_dnum1_apply_moddown_sum_65536_kernel<<<
        blocks,
        256,
        0,
        gpu_execution_stream()>>>(
        dst_c0,
        dst_c1,
        identity_c0,
        identity_c1,
        kargs,
        accum_q_two,
        converted_q_two,
        parameters.rns_primes.data(),
        parameters.rns_modulus_constants.data(),
        parameters.hybrid_inv_p_mod_q.data(),
        q_words,
        batch_count);
    gpu_check_cuda(cudaGetLastError(), "batch sum ModDown apply");
}

}  // namespace kernel
}  // namespace gpu
}  // namespace poseidon
