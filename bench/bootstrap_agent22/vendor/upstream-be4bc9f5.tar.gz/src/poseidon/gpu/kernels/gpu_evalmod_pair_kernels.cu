#include "poseidon/gpu/kernels/gpu_evalmod_pair_kernels.h"
#include "poseidon/gpu/kernels/gpu_fast_index.cuh"

namespace poseidon::gpu::kernel {
namespace {
__device__ __forceinline__ GpuWord reduce(GpuWide x, GpuWord q, GpuWide ratio) {
    GpuWide r=x-__umul64hi(x,ratio)*q;
    if(r>=q)r-=q;
    if(r>=q)r-=q;
    return static_cast<GpuWord>(r);
}
__device__ __forceinline__ GpuWord addmod(GpuWord a,GpuWord b,GpuWord q) {
    GpuWord s=a+b;
    if(s<a || s>=q)s-=q;
    return s;
}
template<EvalModPairOp Op, unsigned Branches = 2> __global__ void evalmod_pair_kernel(EvalModPairArgs a) {
    const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=a.degree*a.limbs)return;
    const unsigned limb=fast_div(i,a.degree);
    const GpuWord q=a.moduli[limb];
    const GpuWide ratio=a.ratios[limb];
    // The common plaintext coefficients and modulus are fetched once for the
    // real and imaginary branch; no arithmetic mixes the two ciphertexts.
    // All array indices into `a` are compile-time unrolled constants so nvcc
    // keeps `EvalModPairArgs` in constant parameter space with zero stack spill.
    GpuWord p[4]{};
    if constexpr(Op==EvalModPairOp::MultiplyPlain)p[0]=a.plain[0][i];
    if constexpr(Op==EvalModPairOp::Combine) {
        if(a.plain[0])p[0]=a.plain[0][i];
        if(a.plain[1])p[1]=a.plain[1][i];
    }
    if constexpr(Op==EvalModPairOp::Leaf) {
        #pragma unroll
        for(unsigned k=0;k<4;++k) {
            if(k<a.term_count)p[k]=a.plain[k][i];
        }
    }
    const GpuWord constant=a.constant?a.constant[i]:0;
    #pragma unroll
    for(unsigned branch=0;branch<Branches;++branch) {
        if constexpr(Op==EvalModPairOp::Square) {
            const auto x0=a.left[branch][0][i],x1=a.left[branch][1][i];
            const auto cross=reduce(GpuWide(x0)*x1,q,ratio);
            a.out[branch][0][i]=reduce(GpuWide(x0)*x0,q,ratio);
            a.out[branch][1][i]=addmod(cross,cross,q);
            a.out[branch][2][i]=reduce(GpuWide(x1)*x1,q,ratio);
        } else if constexpr(Op==EvalModPairOp::Multiply) {
            const auto x0=a.left[branch][0][i],x1=a.left[branch][1][i];
            const auto y0=a.right[branch][0][i],y1=a.right[branch][1][i];
            a.out[branch][0][i]=reduce(GpuWide(x0)*y0,q,ratio);
            a.out[branch][1][i]=addmod(reduce(GpuWide(x0)*y1,q,ratio),reduce(GpuWide(x1)*y0,q,ratio),q);
            a.out[branch][2][i]=reduce(GpuWide(x1)*y1,q,ratio);
        } else if constexpr(Op==EvalModPairOp::Combine) {
            const auto x0=a.left[branch][0][i],x1=a.left[branch][1][i];
            const auto y0=a.right[branch][0][i],y1=a.right[branch][1][i];
            GpuWord d0=reduce(GpuWide(x0)*y0,q,ratio);
            GpuWord d1=addmod(reduce(GpuWide(x0)*y1,q,ratio),reduce(GpuWide(x1)*y0,q,ratio),q);
            GpuWord d2=reduce(GpuWide(x1)*y1,q,ratio);
            if(a.plain[0]) {
                d0=reduce(GpuWide(d0)*p[0],q,ratio);
                d1=reduce(GpuWide(d1)*p[0],q,ratio);
                d2=reduce(GpuWide(d2)*p[0],q,ratio);
            }
            GpuWord r0=a.terms[0][branch][0][i];
            GpuWord r1=a.terms[0][branch][1][i];
            GpuWord r2=a.term_count>2?a.terms[1][branch][0][i]:0;
            if(a.plain[1]) {
                r0=reduce(GpuWide(r0)*p[1],q,ratio);
                r1=reduce(GpuWide(r1)*p[1],q,ratio);
                if(a.term_count>2)r2=reduce(GpuWide(r2)*p[1],q,ratio);
            }
            a.out[branch][0][i]=addmod(d0,r0,q);
            a.out[branch][1][i]=addmod(d1,r1,q);
            a.out[branch][2][i]=a.term_count>2?addmod(d2,r2,q):d2;
        } else if constexpr(Op==EvalModPairOp::Leaf) {
            #pragma unroll
            for(unsigned c=0;c<2;++c) {
                GpuWord value=c==0?constant:0;
                #pragma unroll
                for(unsigned k=0;k<4;++k) {
                    if(k<a.term_count)
                        value=addmod(value,reduce(GpuWide(a.terms[k][branch][c][i])*p[k],q,ratio),q);
                }
                a.out[branch][c][i]=value;
            }
        } else {
            #pragma unroll
            for(unsigned c=0;c<3;++c) {
                if(c<a.components) {
                    GpuWord value=0;
                    auto x=c<a.left_components?a.left[branch][c][i]:0;
                    if constexpr(Op==EvalModPairOp::DoubleAddPlain || Op==EvalModPairOp::DoubleSubtractPlain || Op==EvalModPairOp::DoubleSubtract)x=addmod(x,x,q);
                    if constexpr(Op==EvalModPairOp::Copy || Op==EvalModPairOp::DoubleAddPlain)value=addmod(x,c==0?constant:0,q);
                    if constexpr(Op==EvalModPairOp::SubtractPlain || Op==EvalModPairOp::DoubleSubtractPlain) {
                        const auto y=c==0?constant:0;
                        value=x-y;if(x<y)value+=q;
                    }
                    if constexpr(Op==EvalModPairOp::MultiplyPlain)value=reduce(GpuWide(x)*p[0],q,ratio);
                    if constexpr(Op==EvalModPairOp::Add || Op==EvalModPairOp::Subtract || Op==EvalModPairOp::DoubleSubtract) {
                        const auto y=c<a.right_components?a.right[branch][c][i]:0;
                        if constexpr(Op==EvalModPairOp::Add)value=addmod(x,y,q);
                        else {value=x-y;if(x<y)value+=q;}
                    }
                    a.out[branch][c][i]=value;
                }
            }
        }
    }
}
template<ComponentwiseOp Op> __global__ void componentwise_kernel(ComponentwiseArgs a) {
    const unsigned i=blockIdx.x*blockDim.x+threadIdx.x,c=blockIdx.y;
    if(i>=a.coefficients*a.limbs)return;
    const auto limb=fast_div(i,a.coefficients);
    // Dynamic indexing into a by-value parameter array makes nvcc copy the
    // entire argument block to each thread's stack. Select fixed slots so
    // all pointers stay in parameter space (zero stack/local memory).
    const auto *left=c==0?a.left[0]:c==1?a.left[1]:a.left[2];
    auto *out=c==0?a.out[0]:c==1?a.out[1]:a.out[2];
    const auto q=a.moduli[limb],x=left[i];
    GpuWord value=0;
    if constexpr(Op==ComponentwiseOp::Negate)value=x?q-x:0;
    if constexpr(Op==ComponentwiseOp::Scalar) {
        const auto ratio=a.ratios[limb];
        value=reduce(GpuWide(x)*reduce(a.scalar,q,ratio),q,ratio);
    }
    if constexpr(Op==ComponentwiseOp::Subtract || Op==ComponentwiseOp::SubtractPlain) {
        const auto *right=c==0?a.right[0]:c==1?a.right[1]:a.right[2];
        const auto y=Op==ComponentwiseOp::Subtract?right[i]:(c==0?a.plain[i]:0);
        value=x-y;if(x<y)value+=q;
    }
    if constexpr(Op==ComponentwiseOp::AddPlain)value=addmod(x,c==0?a.plain[i]:0,q);
    out[i]=value;
}
}
void launch_evalmod_pair(EvalModPairOp op,const EvalModPairArgs &a,int device) {
    gpu_check_cuda(cudaSetDevice(device),"EvalMod pair device");
    const unsigned blocks=(a.degree*a.limbs+255)/256;
    #define LAUNCH(OP) case EvalModPairOp::OP: evalmod_pair_kernel<EvalModPairOp::OP,2><<<blocks,256,0,gpu_execution_stream()>>>(a);break
    switch(op) { LAUNCH(Copy); LAUNCH(SubtractPlain); LAUNCH(Add); LAUNCH(Subtract); LAUNCH(Multiply); LAUNCH(MultiplyPlain); LAUNCH(Leaf); LAUNCH(Square); LAUNCH(DoubleAddPlain); LAUNCH(DoubleSubtractPlain); LAUNCH(DoubleSubtract); LAUNCH(Combine); }
    #undef LAUNCH
    gpu_check_cuda(cudaGetLastError(),"EvalMod pair kernel");
}
void launch_evalmod_single(EvalModPairOp op,const EvalModPairArgs &a,int device) {
    gpu_check_cuda(cudaSetDevice(device),"EvalMod single device");
    const unsigned blocks=(a.degree*a.limbs+255)/256;
    #define LAUNCH(OP) case EvalModPairOp::OP: evalmod_pair_kernel<EvalModPairOp::OP,1><<<blocks,256,0,gpu_execution_stream()>>>(a);break
    switch(op) { LAUNCH(Copy); LAUNCH(SubtractPlain); LAUNCH(Add); LAUNCH(Subtract); LAUNCH(Multiply); LAUNCH(MultiplyPlain); LAUNCH(Leaf); LAUNCH(Square); LAUNCH(DoubleAddPlain); LAUNCH(DoubleSubtractPlain); LAUNCH(DoubleSubtract); LAUNCH(Combine); }
    #undef LAUNCH
    gpu_check_cuda(cudaGetLastError(),"EvalMod single kernel");
}
void launch_componentwise(ComponentwiseOp op,const ComponentwiseArgs &a,int device) {
    gpu_check_cuda(cudaSetDevice(device),"component batch device");
    const dim3 grid((a.coefficients*a.limbs+255)/256,a.components);
    #define LAUNCH(OP) case ComponentwiseOp::OP: componentwise_kernel<ComponentwiseOp::OP><<<grid,256,0,gpu_execution_stream()>>>(a);break
    switch(op) { LAUNCH(Subtract); LAUNCH(Negate); LAUNCH(Scalar); LAUNCH(AddPlain); LAUNCH(SubtractPlain); }
    #undef LAUNCH
    gpu_check_cuda(cudaGetLastError(),"component batch kernel");
}
bool is_componentwise_kernel(const void *function) {
    #define MATCH(OP) if(function==reinterpret_cast<const void *>(componentwise_kernel<ComponentwiseOp::OP>))return true
    MATCH(Subtract);MATCH(Negate);MATCH(Scalar);MATCH(AddPlain);MATCH(SubtractPlain);
    #undef MATCH
    return false;
}
} // namespace poseidon::gpu::kernel
