#pragma once

// A800 catch-up (2026-11-13): element-wise kernels split a flat thread index
// with runtime std::size_t '/' and '%'. A 64-bit integer division is a long
// SASS subroutine, often more instructions than the element's modular
// arithmetic. The divisors are a power of two (degree) or small enough for a
// 32-bit division; both give exactly the same quotient and remainder.

#include <cstddef>

namespace poseidon
{
namespace gpu
{
namespace kernel
{

__device__ __forceinline__ void fast_divmod(
    std::size_t value,
    std::size_t divisor,
    std::size_t &quotient,
    std::size_t &remainder)
{
    if ((divisor & (divisor - 1)) == 0)
    {
        const unsigned int shift =
            static_cast<unsigned int>(__ffsll(static_cast<long long>(divisor)) - 1);
        quotient = value >> shift;
        remainder = value & (divisor - 1);
    }
    else if (value <= 0xffffffffULL && divisor <= 0xffffffffULL)
    {
        const unsigned int v = static_cast<unsigned int>(value);
        const unsigned int d = static_cast<unsigned int>(divisor);
        const unsigned int q = v / d;
        quotient = q;
        remainder = v - q * d;
    }
    else
    {
        quotient = value / divisor;
        remainder = value - quotient * divisor;
    }
}

__device__ __forceinline__ std::size_t fast_div(std::size_t value, std::size_t divisor)
{
    std::size_t quotient, remainder;
    fast_divmod(value, divisor, quotient, remainder);
    return quotient;
}

__device__ __forceinline__ std::size_t fast_mod(std::size_t value, std::size_t divisor)
{
    std::size_t quotient, remainder;
    fast_divmod(value, divisor, quotient, remainder);
    return remainder;
}

}  // namespace kernel
}  // namespace gpu
}  // namespace poseidon
