#include "poseidon/gpu/kernels/gpu_double_hoist_kernels.h"
#include "poseidon/gpu/gpu_memory.h"
#include "poseidon/gpu/gpu_opt_flags.h"

#include <cuda_runtime_api.h>

#include <cstdlib>
#include <limits>
#include <stdexcept>
#include <string>
#include <type_traits>

namespace poseidon
{
namespace gpu
{
namespace kernel
{
namespace
{

constexpr std::size_t kMaxFusedGiantGroups = 64;
constexpr std::size_t kMaxFusedBabyGroups = kMaxDoubleHoistFusedBabyGroups;

struct GiantGroupKernelArguments
{
    const GpuWord *digit_ptrs[kMaxFusedGiantGroups];
    std::uint32_t group_indices[kMaxFusedGiantGroups];
    std::uint32_t galois_elts[kMaxFusedGiantGroups];
    std::uint32_t key_indices[kMaxFusedGiantGroups];
};

struct BabyKeyMacKernelArguments
{
    std::uint32_t galois_elts[kMaxDoubleHoistFusedBabySteps];
    std::uint32_t key_indices[kMaxDoubleHoistFusedBabySteps];
    std::uint32_t
        term_indices[kMaxFusedBabyGroups]
                    [kMaxDoubleHoistFusedBabySteps];
};

__device__ __forceinline__ GpuWord reduce_u64(
    GpuWide value,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    const GpuWide quotient = __umul64hi(value, barrett_ratio);
    GpuWide reduced = value - quotient * static_cast<GpuWide>(modulus);
    if (reduced >= modulus)
    {
        reduced -= modulus;
    }
    if (reduced >= modulus)
    {
        reduced -= modulus;
    }
    return static_cast<GpuWord>(reduced);
}

// POSEIDON_OPT_LAZY_PMAC: 96-bit exact accumulation of word products,
// reduced once (same as LazyAccumulator in gpu_keyswitch_kernels.cu).
struct PmacAccumulator
{
    std::uint32_t lo = 0;
    std::uint32_t mid = 0;
    std::uint32_t hi = 0;
};

__device__ __forceinline__ void pmac_mac(PmacAccumulator &acc, GpuWord left, GpuWord right)
{
    asm("mad.lo.cc.u32 %0, %3, %4, %0;\n\t"
        "madc.hi.cc.u32 %1, %3, %4, %1;\n\t"
        "addc.u32 %2, %2, 0;"
        : "+r"(acc.lo), "+r"(acc.mid), "+r"(acc.hi)
        : "r"(left), "r"(right));
}

__device__ __forceinline__ GpuWord pmac_reduce(
    const PmacAccumulator &acc,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    const GpuWide low =
        (static_cast<GpuWide>(acc.mid) << 32) | static_cast<GpuWide>(acc.lo);
    GpuWord result = reduce_u64(low, modulus, barrett_ratio);
    if (acc.hi != 0)
    {
        // barrett_ratio = floor(2^64 / modulus): 2^64 mod modulus.
        GpuWide two64 = GpuWide{0} - barrett_ratio * static_cast<GpuWide>(modulus);
        if (two64 >= modulus)
        {
            two64 -= modulus;
        }
        const GpuWord carry = reduce_u64(
            static_cast<GpuWide>(acc.hi) * two64, modulus, barrett_ratio);
        const GpuWide sum = static_cast<GpuWide>(result) + carry;
        result = static_cast<GpuWord>(sum >= modulus ? sum - modulus : sum);
    }
    return result;
}

__device__ __forceinline__ GpuWord multiply_mod(
    GpuWord left,
    GpuWord right,
    GpuWord modulus,
    GpuWide barrett_ratio)
{
    return reduce_u64(
        static_cast<GpuWide>(left) * static_cast<GpuWide>(right),
        modulus,
        barrett_ratio);
}

__device__ __forceinline__ GpuWord add_mod(
    GpuWord left,
    GpuWord right,
    GpuWord modulus)
{
    const GpuWide sum =
        static_cast<GpuWide>(left) + static_cast<GpuWide>(right);
    return static_cast<GpuWord>(sum >= modulus ? sum - modulus : sum);
}

__device__ __forceinline__ std::uint32_t reverse_bits_limited(
    std::uint32_t value,
    unsigned int bit_count)
{
    return __brev(value) >> (32U - bit_count);
}

__global__ void lift_identity_kernel(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuWord *p_mod_q,
    const GpuWord *q_primes,
    const GpuWide *q_barrett,
    std::size_t q_count,
    std::size_t degree,
    unsigned int degree_power,
    bool accumulate)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t words_per_component = q_count * degree;
    const std::size_t total = 2 * words_per_component;
    if (tid >= total)
    {
        return;
    }

    const std::size_t component = tid / words_per_component;
    const std::size_t local = tid - component * words_per_component;
    const std::size_t limb = local >> degree_power;
    const GpuWord modulus = q_primes[limb];
    const GpuWord lifted = multiply_mod(
        component == 0 ? source_q0[local] : source_q1[local],
        p_mod_q[limb],
        modulus,
        q_barrett[limb]);
    GpuWord *destination =
        component == 0 ? destination_q0 : destination_q1;
    destination[local] = accumulate
        ? add_mod(destination[local], lifted, modulus)
        : lifted;
}

__global__ void pre_rotated_keymul_digit_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *digit,
    const GpuWord *key0,
    const GpuWord *key1,
    std::uint32_t galois_elt,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    bool overwrite)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = limb_count * degree;
    if (tid >= total)
    {
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
    const std::uint32_t source_coeff = reverse_bits_limited(
        static_cast<std::uint32_t>(index_raw & degree_mask),
        degree_power);
    const std::size_t source_index = limb * degree + source_coeff;

    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    const GpuWord source_value = digit[source_index];
    const GpuWord product0 = multiply_mod(
        source_value,
        key0[source_index],
        modulus,
        ratio);
    const GpuWord product1 = multiply_mod(
        source_value,
        key1[source_index],
        modulus,
        ratio);
    destination0[tid] = overwrite
        ? product0
        : add_mod(destination0[tid], product0, modulus);
    destination1[tid] = overwrite
        ? product1
        : add_mod(destination1[tid], product1, modulus);
}

template <bool AddLiftedC0, bool Lazy = false>
__global__ void pre_rotated_keymul_batch_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *digits,
    const GpuWord *const *key0_ptrs,
    const GpuWord *const *key1_ptrs,
    const GpuWord *lifted_c0_source,
    const GpuWord *p_mod_q,
    std::uint32_t galois_elt,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t dnum,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    bool overwrite)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t words_per_digit = limb_count * degree;
    if (tid >= words_per_digit)
    {
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
    const std::uint32_t source_coeff = reverse_bits_limited(
        static_cast<std::uint32_t>(index_raw & degree_mask),
        degree_power);
    const std::size_t source_index = limb * degree + source_coeff;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];

    GpuWord accumulator0 = 0;
    GpuWord accumulator1 = 0;
    if constexpr (Lazy)
    {
        PmacAccumulator acc0{};
        PmacAccumulator acc1{};
        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value =
                digits[digit * words_per_digit + source_index];
            pmac_mac(acc0, source_value, key0_ptrs[digit][source_index]);
            pmac_mac(acc1, source_value, key1_ptrs[digit][source_index]);
        }
        if constexpr (AddLiftedC0)
        {
            pmac_mac(acc0, lifted_c0_source[source_index], p_mod_q[limb]);
        }
        accumulator0 = pmac_reduce(acc0, modulus, ratio);
        accumulator1 = pmac_reduce(acc1, modulus, ratio);
    }
    else
    {
        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value =
                digits[digit * words_per_digit + source_index];
            accumulator0 = add_mod(
                accumulator0,
                multiply_mod(
                    source_value,
                    key0_ptrs[digit][source_index],
                    modulus,
                    ratio),
                modulus);
            accumulator1 = add_mod(
                accumulator1,
                multiply_mod(
                    source_value,
                    key1_ptrs[digit][source_index],
                    modulus,
                    ratio),
                modulus);
        }
        if constexpr (AddLiftedC0)
        {
            accumulator0 = add_mod(
                accumulator0,
                multiply_mod(
                    lifted_c0_source[source_index],
                    p_mod_q[limb],
                    modulus,
                    ratio),
                modulus);
        }
    }
    destination0[tid] = overwrite
        ? accumulator0
        : add_mod(destination0[tid], accumulator0, modulus);
    destination1[tid] = overwrite
        ? accumulator1
        : add_mod(destination1[tid], accumulator1, modulus);
}

template <bool KeyPreRotated, bool QSide, bool Lazy>
__global__ void __launch_bounds__(256) hoisted_baby_tile_batch_kernel(
    GpuWord *destination_batch,
    const GpuWord *digits,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuWord *p_mod_q,
    HoistedKeymulBatchArgs args,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t dnum,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const std::size_t words_per_digit = limb_count * degree;
    if (tid >= words_per_digit)
    {
        return;
    }

    const std::size_t batch = blockIdx.z;
    GpuWord *destination0 = destination_batch + (batch * 2) * words_per_digit;
    GpuWord *destination1 = destination_batch + (batch * 2 + 1) * words_per_digit;
    const std::size_t limb = tid >> degree_power;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    const std::uint32_t galois_elt = args.galois_elts[batch];
    if (galois_elt == 0)
    {
        if constexpr (QSide)
        {
            const GpuWord scale = p_mod_q[limb];
            destination0[tid] = multiply_mod(source_q0[tid], scale, modulus, ratio);
            destination1[tid] = multiply_mod(source_q1[tid], scale, modulus, ratio);
        }
        else
        {
            destination0[tid] = 0;
            destination1[tid] = 0;
        }
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::uint32_t coeff = static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
    const std::uint32_t source_coeff = reverse_bits_limited(
        static_cast<std::uint32_t>(index_raw & degree_mask),
        degree_power);
    const std::size_t source_index = limb * degree + source_coeff;
    const std::size_t key_index = KeyPreRotated ? source_index : tid;
    const std::size_t key_base = batch * dnum;

    GpuWord result0 = 0;
    GpuWord result1 = 0;
    if constexpr (Lazy)
    {
        PmacAccumulator acc0{};
        PmacAccumulator acc1{};
        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value = digits[digit * words_per_digit + source_index];
            pmac_mac(acc0, source_value, args.key0[key_base + digit][key_index]);
            pmac_mac(acc1, source_value, args.key1[key_base + digit][key_index]);
        }
        if constexpr (QSide)
        {
            pmac_mac(acc0, source_q0[source_index], p_mod_q[limb]);
        }
        result0 = pmac_reduce(acc0, modulus, ratio);
        result1 = pmac_reduce(acc1, modulus, ratio);
    }
    else
    {
        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value = digits[digit * words_per_digit + source_index];
            result0 = add_mod(
                result0,
                multiply_mod(source_value, args.key0[key_base + digit][key_index], modulus, ratio),
                modulus);
            result1 = add_mod(
                result1,
                multiply_mod(source_value, args.key1[key_base + digit][key_index], modulus, ratio),
                modulus);
        }
        if constexpr (QSide)
        {
            result0 = add_mod(
                result0,
                multiply_mod(source_q0[source_index], p_mod_q[limb], modulus, ratio),
                modulus);
        }
    }
    destination0[tid] = result0;
    destination1[tid] = result1;
}

template <bool KeyPreRotated, bool QSide>
__global__ void __launch_bounds__(256) hoisted_keymul_sum_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *digits,
    const GpuWord *source_q0,
    const GpuWord *p_mod_q,
    HoistedKeymulBatchArgs args,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t batch_count,
    std::size_t dnum,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    bool initialize)
{
    const std::size_t tid = static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const std::size_t words_per_digit = limb_count * degree;
    if (tid >= words_per_digit)
    {
        return;
    }

    const std::size_t limb = tid >> degree_power;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::uint32_t coeff = static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const GpuWord p_scale = QSide ? p_mod_q[limb] : 0;

    PmacAccumulator acc0{};
    PmacAccumulator acc1{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        const std::uint32_t galois_elt = args.galois_elts[b];
        const std::uint64_t index_raw =
            (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
        const std::uint32_t source_coeff = reverse_bits_limited(
            static_cast<std::uint32_t>(index_raw & degree_mask),
            degree_power);
        const std::size_t source_index = limb * degree + source_coeff;
        const std::size_t key_index = KeyPreRotated ? source_index : tid;
        const std::size_t key_base = b * dnum;
        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value = digits[digit * words_per_digit + source_index];
            pmac_mac(acc0, source_value, args.key0[key_base + digit][key_index]);
            pmac_mac(acc1, source_value, args.key1[key_base + digit][key_index]);
        }
        if constexpr (QSide)
        {
            pmac_mac(acc0, source_q0[source_index], p_scale);
        }
    }
    const GpuWord sum0 = pmac_reduce(acc0, modulus, ratio);
    const GpuWord sum1 = pmac_reduce(acc1, modulus, ratio);
    destination0[tid] = initialize ? sum0 : add_mod(destination0[tid], sum0, modulus);
    destination1[tid] = initialize ? sum1 : add_mod(destination1[tid], sum1, modulus);
}

template <bool AddLiftedC0>
__global__ void pre_rotated_keymul_dnum1_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *digit,
    const GpuWord *const *key0_ptrs,
    const GpuWord *const *key1_ptrs,
    const GpuWord *lifted_c0_source,
    const GpuWord *p_mod_q,
    std::uint32_t galois_elt,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    bool overwrite)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = limb_count * degree;
    if (tid >= total)
    {
        return;
    }

    const std::uint32_t degree_u32 =
        static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed = reverse_bits_limited(
        degree_u32 + coeff,
        degree_power + 1);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
    const std::uint32_t source_coeff = reverse_bits_limited(
        static_cast<std::uint32_t>(index_raw & degree_mask),
        degree_power);
    const std::size_t source_index =
        limb * degree + source_coeff;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    const GpuWord source_value = digit[source_index];
    GpuWord result0 = multiply_mod(
        source_value,
        key0_ptrs[0][source_index],
        modulus,
        ratio);
    const GpuWord result1 = multiply_mod(
        source_value,
        key1_ptrs[0][source_index],
        modulus,
        ratio);
    if constexpr (AddLiftedC0)
    {
        result0 = add_mod(
            result0,
            multiply_mod(
                lifted_c0_source[source_index],
                p_mod_q[limb],
                modulus,
                ratio),
            modulus);
    }
    destination0[tid] = overwrite
        ? result0
        : add_mod(destination0[tid], result0, modulus);
    destination1[tid] = overwrite
        ? result1
        : add_mod(destination1[tid], result1, modulus);
}

__global__ void pre_rotated_giant_group_reduce_kernel(
    GpuWord *group_destination,
    const GpuWord *inner_q_batch,
    GiantGroupKernelArguments group_args,
    const GpuWord *const *key0_ptrs,
    const GpuWord *const *key1_ptrs,
    const GpuWord *p_mod_q,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    std::size_t limb_count,
    std::size_t q_count,
    std::size_t degree,
    unsigned int degree_power,
    bool q_side)
{
    const std::size_t flat_tid =
        blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t words_per_digit = limb_count * degree;
    const std::size_t total = active_group_count * words_per_digit;
    if (flat_tid >= total)
    {
        return;
    }
    const std::size_t active_group = flat_tid / words_per_digit;
    const std::size_t tid =
        flat_tid - active_group * words_per_digit;

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    GpuWord accumulator0 = 0;
    GpuWord accumulator1 = 0;
    {
        const std::uint32_t galois_elt =
            group_args.galois_elts[active_group];
        const std::uint64_t index_raw =
            (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
        const std::uint32_t source_coeff = reverse_bits_limited(
            static_cast<std::uint32_t>(index_raw & degree_mask),
            degree_power);
        const std::size_t source_index =
            limb * degree + source_coeff;
        const std::size_t key_base =
            static_cast<std::size_t>(
                group_args.key_indices[active_group]) *
            storage_dnum;
        const GpuWord *digits =
            group_args.digit_ptrs[active_group];

        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value =
                digits[digit * words_per_digit + source_index];
            accumulator0 = add_mod(
                accumulator0,
                multiply_mod(
                    source_value,
                    key0_ptrs[key_base + digit][source_index],
                    modulus,
                    ratio),
                modulus);
            accumulator1 = add_mod(
                accumulator1,
                multiply_mod(
                    source_value,
                    key1_ptrs[key_base + digit][source_index],
                    modulus,
                    ratio),
                modulus);
        }

        if (q_side)
        {
            const std::size_t q_component_words = q_count * degree;
            const std::size_t source_q_offset =
                (static_cast<std::size_t>(
                     group_args.group_indices[active_group]) *
                 2) *
                    q_component_words +
                source_index;
            accumulator0 = add_mod(
                accumulator0,
                multiply_mod(
                    inner_q_batch[source_q_offset],
                    p_mod_q[limb],
                    modulus,
                    ratio),
                modulus);
        }
    }

    const std::size_t group =
        group_args.group_indices[active_group];
    const std::size_t component_words = words_per_digit;
    group_destination[
        (group * 2) * component_words + tid] = accumulator0;
    group_destination[
        (group * 2 + 1) * component_words + tid] = accumulator1;
}

__global__ void pre_rotated_giant_group_accumulate_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *inner_q_batch,
    std::size_t identity_group_index,
    GiantGroupKernelArguments group_args,
    const GpuWord *const *key0_ptrs,
    const GpuWord *const *key1_ptrs,
    const GpuWord *p_mod_q,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    std::size_t limb_count,
    std::size_t q_count,
    std::size_t degree,
    unsigned int degree_power,
    bool q_side)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t component_words = limb_count * degree;
    if (tid >= component_words)
    {
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];

    GpuWord accumulator0 = 0;
    GpuWord accumulator1 = 0;
    if (q_side)
    {
        const std::size_t q_component_words = q_count * degree;
        const std::size_t identity_offset =
            identity_group_index * 2 * q_component_words + tid;
        accumulator0 = multiply_mod(
            inner_q_batch[identity_offset],
            p_mod_q[limb],
            modulus,
            ratio);
        accumulator1 = multiply_mod(
            inner_q_batch[identity_offset + q_component_words],
            p_mod_q[limb],
            modulus,
            ratio);
    }

    for (std::size_t active_group = 0;
         active_group < active_group_count;
         ++active_group)
    {
        const std::uint32_t galois_elt =
            group_args.galois_elts[active_group];
        const std::uint64_t index_raw =
            (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
        const std::uint32_t source_coeff = reverse_bits_limited(
            static_cast<std::uint32_t>(index_raw & degree_mask),
            degree_power);
        const std::size_t source_index = limb * degree + source_coeff;
        const std::size_t key_base =
            static_cast<std::size_t>(
                group_args.key_indices[active_group]) *
            storage_dnum;
        const GpuWord *digits =
            group_args.digit_ptrs[active_group];

        for (std::size_t digit = 0; digit < dnum; ++digit)
        {
            const GpuWord source_value =
                digits[digit * component_words + source_index];
            accumulator0 = add_mod(
                accumulator0,
                multiply_mod(
                    source_value,
                    key0_ptrs[key_base + digit][source_index],
                    modulus,
                    ratio),
                modulus);
            accumulator1 = add_mod(
                accumulator1,
                multiply_mod(
                    source_value,
                    key1_ptrs[key_base + digit][source_index],
                    modulus,
                    ratio),
                modulus);
        }

        if (q_side)
        {
            const std::size_t q_component_words = q_count * degree;
            const std::size_t source_q_offset =
                (static_cast<std::size_t>(
                     group_args.group_indices[active_group]) *
                 2) *
                    q_component_words +
                source_index;
            accumulator0 = add_mod(
                accumulator0,
                multiply_mod(
                    inner_q_batch[source_q_offset],
                    p_mod_q[limb],
                    modulus,
                    ratio),
                modulus);
        }
    }

    destination0[tid] = accumulator0;
    destination1[tid] = accumulator1;
}

/*
 * Same output as pre_rotated_giant_group_accumulate_kernel, but c0 of every
 * giant group (and both components of the identity group) is read from the
 * QP group accumulators instead of from ModDown(accumulator) lifted back by P.
 * Only c1 of the non-identity groups has to leave QP (it is decomposed for the
 * giant key switch). The kernel runs once per side (Q limbs, then P limbs);
 * qp_groups points at that side's [group][component][limb][coeff] storage.
 */
template <bool Lazy = false, int FixedDnum = 0, bool HasSelfDigit = true>
__global__ void pre_rotated_giant_group_accumulate_qp_c0_kernel(
    GpuWord *destination0,
    GpuWord *destination1,
    const GpuWord *qp_groups,
    std::size_t identity_group_index,
    GiantGroupKernelArguments group_args,
    const GpuWord *const *key0_ptrs,
    const GpuWord *const *key1_ptrs,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    const GpuWord *inner_q_c1_batch = nullptr,
    std::size_t self_digit_p_count = 0)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t component_words = limb_count * degree;
    if (tid >= component_words)
    {
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    std::size_t self_digit = std::numeric_limits<std::size_t>::max();
    if constexpr (HasSelfDigit)
    {
        if (inner_q_c1_batch != nullptr && self_digit_p_count != 0)
        {
            if constexpr (FixedDnum == 1)
            {
                self_digit = (limb < self_digit_p_count) ? 0u : 1u;
            }
            else if constexpr (FixedDnum == 2)
            {
                self_digit = (limb < self_digit_p_count)
                    ? 0u
                    : ((limb < 2 * self_digit_p_count) ? 1u : 2u);
            }
            else
            {
                self_digit = limb / self_digit_p_count;
            }
        }
    }

    const std::size_t identity_offset =
        identity_group_index * 2 * component_words + tid;
    GpuWord accumulator0 = qp_groups[identity_offset];
    GpuWord accumulator1 = qp_groups[identity_offset + component_words];
    PmacAccumulator lazy0;
    PmacAccumulator lazy1;
    const std::size_t actual_dnum =
        FixedDnum > 0 ? static_cast<std::size_t>(FixedDnum) : dnum;

    for (std::size_t active_group = 0;
         active_group < active_group_count;
         ++active_group)
    {
        const std::uint32_t galois_elt =
            group_args.galois_elts[active_group];
        const std::uint32_t raw_perm = (degree_power <= 30u)
            ? (((galois_elt * reversed) >> 1) & degree_mask)
            : static_cast<std::uint32_t>(
                  ((static_cast<std::uint64_t>(galois_elt) * reversed) >> 1) &
                  degree_mask);
        const std::uint32_t source_coeff =
            reverse_bits_limited(raw_perm, degree_power);
        const std::size_t source_index = limb * degree + source_coeff;
        const std::size_t key_base =
            static_cast<std::size_t>(
                group_args.key_indices[active_group]) *
            storage_dnum;
        const GpuWord *digits =
            group_args.digit_ptrs[active_group];

        const std::size_t group_c0_offset =
            static_cast<std::size_t>(
                group_args.group_indices[active_group]) *
                2 * component_words +
            source_index;
        if constexpr (Lazy)
        {
            // POSEIDON_OPT_LAZY_BABY: exact 96-bit sums (the c0 term enters
            // as value * 1), one reduction per component at the end.
            #pragma unroll
            for (std::size_t digit = 0; digit < actual_dnum; ++digit)
            {
                GpuWord source_value;
                if constexpr (HasSelfDigit)
                {
                    source_value = (digit == self_digit)
                        ? inner_q_c1_batch[group_c0_offset + component_words]
                        : digits[digit * component_words + source_index];
                }
                else
                {
                    source_value = digits[digit * component_words + source_index];
                }
                pmac_mac(lazy0, source_value, key0_ptrs[key_base + digit][source_index]);
                pmac_mac(lazy1, source_value, key1_ptrs[key_base + digit][source_index]);
            }
            pmac_mac(lazy0, qp_groups[group_c0_offset], 1u);
        }
        else
        {
            #pragma unroll
            for (std::size_t digit = 0; digit < actual_dnum; ++digit)
            {
                GpuWord source_value;
                if constexpr (HasSelfDigit)
                {
                    source_value = (digit == self_digit)
                        ? inner_q_c1_batch[group_c0_offset + component_words]
                        : digits[digit * component_words + source_index];
                }
                else
                {
                    source_value = digits[digit * component_words + source_index];
                }
                accumulator0 = add_mod(
                    accumulator0,
                    multiply_mod(
                        source_value,
                        key0_ptrs[key_base + digit][source_index],
                        modulus,
                        ratio),
                    modulus);
                accumulator1 = add_mod(
                    accumulator1,
                    multiply_mod(
                        source_value,
                        key1_ptrs[key_base + digit][source_index],
                        modulus,
                        ratio),
                    modulus);
            }
            accumulator0 = add_mod(
                accumulator0,
                qp_groups[group_c0_offset],
                modulus);
        }
    }

    if constexpr (Lazy)
    {
        accumulator0 = add_mod(accumulator0, pmac_reduce(lazy0, modulus, ratio), modulus);
        accumulator1 = add_mod(accumulator1, pmac_reduce(lazy1, modulus, ratio), modulus);
    }
    destination0[tid] = accumulator0;
    destination1[tid] = accumulator1;
}

__global__ void reduce_qp_groups_kernel(
    GpuWord *destination,
    const GpuWord *group_values,
    const GpuWord *moduli,
    std::size_t group_count,
    std::size_t limb_count,
    std::size_t degree)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t component_words = limb_count * degree;
    const std::size_t total = 2 * component_words;
    if (tid >= total)
    {
        return;
    }
    const std::size_t component = tid / component_words;
    const std::size_t in_component =
        tid - component * component_words;
    const std::size_t limb = in_component / degree;
    const GpuWord modulus = moduli[limb];
    GpuWord accumulator = 0;
    for (std::size_t group = 0; group < group_count; ++group)
    {
        accumulator = add_mod(
            accumulator,
            group_values[
                (group * 2 + component) * component_words +
                in_component],
            modulus);
    }
    destination[tid] = accumulator;
}

__global__ void add_lifted_galois_c0_kernel(
    GpuWord *destination_q0,
    const GpuWord *source_q0,
    std::uint32_t galois_elt,
    const GpuWord *p_mod_q,
    const GpuWord *q_primes,
    const GpuWide *q_barrett,
    std::size_t q_count,
    std::size_t degree,
    unsigned int degree_power)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t total = q_count * degree;
    if (tid >= total)
    {
        return;
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coeff =
        static_cast<std::uint32_t>(tid & degree_mask);
    const std::uint32_t reversed =
        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
    const std::uint64_t index_raw =
        (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
    const std::uint32_t source_coeff = reverse_bits_limited(
        static_cast<std::uint32_t>(index_raw & degree_mask),
        degree_power);
    const std::size_t source_index = limb * degree + source_coeff;

    const GpuWord modulus = q_primes[limb];
    const GpuWord lifted = multiply_mod(
        source_q0[source_index],
        p_mod_q[limb],
        modulus,
        q_barrett[limb]);
    destination_q0[tid] = add_mod(destination_q0[tid], lifted, modulus);
}

template <bool Compressed>
__device__ __forceinline__ GpuWord load_qp_diagonal(
    const GpuWord *const *diagonal_ptrs,
    const std::uint32_t *diagonal_periods,
    std::uint32_t term,
    std::size_t limb,
    std::size_t coefficient,
    std::size_t degree,
    unsigned int degree_power)
{
    if constexpr (!Compressed)
    {
        return diagonal_ptrs[term][limb * degree + coefficient];
    }
    else
    {
        const std::size_t period = diagonal_periods[term];
        // A period equal to N is retained in ordinary NTT order. This avoids
        // turning an uncompressible diagonal into a bit-reversed, uncoalesced
        // read stream.
        if (period >= degree)
        {
            return diagonal_ptrs[term][limb * degree + coefficient];
        }
        const auto reversed = reverse_bits_limited(
            static_cast<std::uint32_t>(coefficient),
            degree_power);
        const std::size_t compact_coefficient =
            compressed_diagonal_compact_index(reversed, period, degree_power);
        return diagonal_ptrs[term][
            limb * period + compact_coefficient];
    }
}

template <bool Compressed>
__global__ void qp_plain_mul_accumulate_kernel(
    GpuWord *group_values,
    const GpuWord *baby_values,
    const GpuWord *const *diagonal_ptrs,
    const std::uint32_t *diagonal_periods,
    const std::uint32_t *term_baby_indices,
    const std::uint32_t *group_term_offsets,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    std::size_t tile_begin,
    std::size_t tile_count,
    bool initialize_accumulators)
{
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t words_per_group = 2 * limb_count * degree;
    const std::size_t total = group_count * words_per_group;
    if (tid >= total)
    {
        return;
    }

    const std::size_t group = tid / words_per_group;
    const std::size_t in_group = tid - group * words_per_group;
    const std::size_t component_stride = limb_count * degree;
    const std::size_t component = in_group / component_stride;
    const std::size_t in_component =
        in_group - component * component_stride;
    const std::size_t limb = in_component >> degree_power;
    const std::size_t coeff = in_component & (degree - 1);
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];

    GpuWord accumulator =
        initialize_accumulators ? 0 : group_values[tid];
    const std::uint32_t begin = group_term_offsets[group];
    const std::uint32_t end = group_term_offsets[group + 1];
    if (end > term_count || begin > end)
    {
        return;
    }

    for (std::uint32_t term = begin; term < end; ++term)
    {
        const std::size_t baby_index = term_baby_indices[term];
        if (baby_index < tile_begin ||
            baby_index >= tile_begin + tile_count)
        {
            continue;
        }

        const std::size_t local_baby = baby_index - tile_begin;
        const std::size_t baby_offset =
            ((local_baby * 2 + component) * limb_count + limb) *
                degree +
            coeff;
        const GpuWord diagonal = load_qp_diagonal<Compressed>(
            diagonal_ptrs,
            diagonal_periods,
            term,
            limb,
            coeff,
            degree,
            degree_power);
        const GpuWord product = multiply_mod(
            baby_values[baby_offset],
            diagonal,
            modulus,
            ratio);
        accumulator = add_mod(accumulator, product, modulus);
    }

    group_values[tid] = accumulator;
}

template <int GroupTile, bool Compressed>
__global__ void qp_plain_mul_accumulate_group_tiled_kernel(
    GpuWord *group_values,
    const GpuWord *baby_values,
    const GpuWord *const *diagonal_ptrs,
    const std::uint32_t *diagonal_periods,
    const std::uint32_t *term_baby_indices,
    const std::uint32_t *group_term_offsets,
    const GpuWord *moduli,
    const GpuWide *barrett,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    std::size_t tile_begin,
    std::size_t tile_count,
    bool initialize_accumulators)
{
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kMaxBabyTile = 8;
    static_assert(GroupTile == 4 || GroupTile == 8);
    __shared__ GpuWord shared_baby[kMaxBabyTile][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t group_row = threadIdx.y;
    const std::size_t coefficient =
        blockIdx.x * kCoefficientTile + lane;
    const std::size_t packed_component_limb = blockIdx.y;
    const std::size_t component =
        packed_component_limb / limb_count;
    const std::size_t limb =
        packed_component_limb - component * limb_count;
    const std::size_t group =
        blockIdx.z * GroupTile + group_row;

    const std::size_t linear_thread =
        group_row * kCoefficientTile + lane;
    const std::size_t shared_word_count =
        tile_count * kCoefficientTile;
    for (std::size_t shared_index = linear_thread;
         shared_index < shared_word_count;
         shared_index += kCoefficientTile * GroupTile)
    {
        const std::size_t local_baby =
            shared_index / kCoefficientTile;
        const std::size_t source_lane =
            shared_index - local_baby * kCoefficientTile;
        const std::size_t source_coefficient =
            blockIdx.x * kCoefficientTile + source_lane;
        GpuWord value = 0;
        if (source_coefficient < degree)
        {
            const std::size_t baby_offset =
                ((local_baby * 2 + component) * limb_count + limb) *
                    degree +
                source_coefficient;
            value = baby_values[baby_offset];
        }
        shared_baby[local_baby][source_lane] = value;
    }
    __syncthreads();

    if (group >= group_count || coefficient >= degree)
    {
        return;
    }

    const std::size_t words_per_group = 2 * limb_count * degree;
    const std::size_t group_offset =
        group * words_per_group +
        (component * limb_count + limb) * degree +
        coefficient;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    GpuWord accumulator = initialize_accumulators
        ? 0
        : group_values[group_offset];
    const std::uint32_t begin = group_term_offsets[group];
    const std::uint32_t end = group_term_offsets[group + 1];
    if (end > term_count || begin > end)
    {
        return;
    }

    for (std::uint32_t term = begin; term < end; ++term)
    {
        const std::size_t baby_index = term_baby_indices[term];
        if (baby_index < tile_begin ||
            baby_index >= tile_begin + tile_count)
        {
            continue;
        }

        const std::size_t local_baby = baby_index - tile_begin;
        const GpuWord diagonal = load_qp_diagonal<Compressed>(
            diagonal_ptrs,
            diagonal_periods,
            term,
            limb,
            coefficient,
            degree,
            degree_power);
        accumulator = add_mod(
            accumulator,
            multiply_mod(
                shared_baby[local_baby][lane],
                diagonal,
                modulus,
                ratio),
            modulus);
    }

    group_values[group_offset] = accumulator;
}

template <int GroupTile, bool Compressed>
__global__ void qp_plain_mul_accumulate_group_component_fused_kernel(
    GpuWord *__restrict__ group_values,
    const GpuWord *__restrict__ baby_values,
    const GpuWord *const *__restrict__ diagonal_ptrs,
    const std::uint32_t *__restrict__ diagonal_periods,
    const std::uint32_t *__restrict__ term_baby_indices,
    const std::uint32_t *__restrict__ group_term_offsets,
    const GpuWord *__restrict__ moduli,
    const GpuWide *__restrict__ barrett,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    std::size_t tile_begin,
    std::size_t tile_count,
    bool initialize_accumulators,
    bool lazy_accumulate = false)
{
    constexpr std::size_t kCoefficientTile = 32;
    constexpr std::size_t kMaxBabyTile = 8;
    static_assert(GroupTile == 4 || GroupTile == 8);
    __shared__ GpuWord
        shared_baby[2][kMaxBabyTile][kCoefficientTile];

    const std::size_t lane = threadIdx.x;
    const std::size_t group_row = threadIdx.y;
    const std::size_t coefficient =
        blockIdx.x * kCoefficientTile + lane;
    const std::size_t limb = blockIdx.y;
    const std::size_t group =
        blockIdx.z * GroupTile + group_row;

    const std::size_t linear_thread =
        group_row * kCoefficientTile + lane;
    const std::size_t words_per_component =
        tile_count * kCoefficientTile;
    const std::size_t shared_word_count = 2 * words_per_component;
    for (std::size_t shared_index = linear_thread;
         shared_index < shared_word_count;
         shared_index += kCoefficientTile * GroupTile)
    {
        const std::size_t component =
            shared_index / words_per_component;
        const std::size_t in_component =
            shared_index - component * words_per_component;
        const std::size_t local_baby =
            in_component / kCoefficientTile;
        const std::size_t source_lane =
            in_component - local_baby * kCoefficientTile;
        const std::size_t source_coefficient =
            blockIdx.x * kCoefficientTile + source_lane;
        GpuWord value = 0;
        if (source_coefficient < degree)
        {
            const std::size_t baby_offset =
                ((local_baby * 2 + component) * limb_count + limb) *
                    degree +
                source_coefficient;
            value = baby_values[baby_offset];
        }
        shared_baby[component][local_baby][source_lane] = value;
    }
    __syncthreads();

    if (group >= group_count || coefficient >= degree)
    {
        return;
    }

    const std::size_t component_stride = limb_count * degree;
    const std::size_t group_offset =
        group * 2 * component_stride + limb * degree + coefficient;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    GpuWord accumulator0 = initialize_accumulators
        ? 0
        : group_values[group_offset];
    GpuWord accumulator1 = initialize_accumulators
        ? 0
        : group_values[group_offset + component_stride];
    const std::uint32_t begin = group_term_offsets[group];
    const std::uint32_t end = group_term_offsets[group + 1];
    if (end > term_count || begin > end)
    {
        return;
    }

    if (lazy_accumulate)
    {
        // POSEIDON_OPT_LAZY_PMAC: exact 96-bit sums, one reduction per
        // component; the bit-reversed coefficient is loop invariant.
        PmacAccumulator lazy0;
        PmacAccumulator lazy1;
        const std::uint32_t reversed = Compressed
            ? reverse_bits_limited(static_cast<std::uint32_t>(coefficient), degree_power)
            : 0u;
        const unsigned int limb32 = static_cast<unsigned int>(limb);
        const unsigned int coefficient32 = static_cast<unsigned int>(coefficient);
        const unsigned int degree32 = static_cast<unsigned int>(degree);
        const unsigned int tile_begin32 = static_cast<unsigned int>(tile_begin);
        const unsigned int tile_count32 = static_cast<unsigned int>(tile_count);
        for (std::uint32_t term = begin; term < end; ++term)
        {
            const unsigned int local_baby = term_baby_indices[term] - tile_begin32;
            if (local_baby >= tile_count32)
            {
                continue;
            }
            GpuWord diagonal;
            if constexpr (!Compressed)
            {
                diagonal = diagonal_ptrs[term][limb32 * degree32 + coefficient32];
            }
            else
            {
                const unsigned int period = diagonal_periods[term];
                diagonal = period >= degree32
                    ? diagonal_ptrs[term][limb32 * degree32 + coefficient32]
                    : diagonal_ptrs[term][
                          limb32 * period +
                          static_cast<unsigned int>(compressed_diagonal_compact_index(
                              reversed, period, degree_power))];
            }
            pmac_mac(lazy0, shared_baby[0][local_baby][lane], diagonal);
            pmac_mac(lazy1, shared_baby[1][local_baby][lane], diagonal);
        }
        accumulator0 = add_mod(accumulator0, pmac_reduce(lazy0, modulus, ratio), modulus);
        accumulator1 = add_mod(accumulator1, pmac_reduce(lazy1, modulus, ratio), modulus);
    }
    else
    {
    for (std::uint32_t term = begin; term < end; ++term)
    {
        const std::size_t baby_index = term_baby_indices[term];
        if (baby_index < tile_begin ||
            baby_index >= tile_begin + tile_count)
        {
            continue;
        }

        const std::size_t local_baby = baby_index - tile_begin;
        const GpuWord diagonal = load_qp_diagonal<Compressed>(
            diagonal_ptrs,
            diagonal_periods,
            term,
            limb,
            coefficient,
            degree,
            degree_power);
        accumulator0 = add_mod(
            accumulator0,
            multiply_mod(
                shared_baby[0][local_baby][lane],
                diagonal,
                modulus,
                ratio),
            modulus);
        accumulator1 = add_mod(
            accumulator1,
            multiply_mod(
                shared_baby[1][local_baby][lane],
                diagonal,
                modulus,
                ratio),
            modulus);
    }
    }

    group_values[group_offset] = accumulator0;
    group_values[group_offset + component_stride] = accumulator1;
}

template <int GroupTile, int CoeffTiles, bool IsQ, bool Compressed, bool Lazy = false, int FixedDnum = 0, int ItemsPerThread = 1>
__global__ void __launch_bounds__(256, 4) shared_baby_keyswitch_plain_accumulate_kernel(
    GpuWord *__restrict__ group_values,
    const GpuWord *__restrict__ digits,
    const GpuWord *__restrict__ source_q0,
    const GpuWord *__restrict__ source_q1,
    BabyKeyMacKernelArguments arguments,
    const GpuWord *const *__restrict__ key0_ptrs,
    const GpuWord *const *__restrict__ key1_ptrs,
    const GpuWord *const *__restrict__ diagonal_ptrs,
    const std::uint32_t *__restrict__ diagonal_periods,
    const GpuWord *__restrict__ p_mod_q,
    const GpuWord *__restrict__ moduli,
    const GpuWide *__restrict__ barrett,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t tile_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    bool initialize_accumulators)
{
    static_assert((GroupTile == 8 && CoeffTiles == 1) ||
                  (GroupTile == 4 && CoeffTiles == 2));
    static_assert(ItemsPerThread == 1 || ItemsPerThread == 2 || ItemsPerThread == 4);
    constexpr unsigned int kWarpSize = 32;
    constexpr unsigned int kSharedBabySlots = 8;
    constexpr unsigned int kSharedCols = kWarpSize * CoeffTiles * ItemsPerThread;
    constexpr unsigned int kBabyWarps = 8 / CoeffTiles;
    __shared__ GpuWord shared_baby[2][kSharedBabySlots][kSharedCols];

    const unsigned int lane = threadIdx.x;
    const unsigned int warp = threadIdx.y;
    const std::size_t limb = blockIdx.y;
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    const GpuWord p_mod_q_limb = IsQ ? p_mod_q[limb] : 0u;
    const std::size_t words_per_digit = limb_count * degree;
    const std::size_t limb_base = limb * degree;
    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;

    const unsigned int ctile = (CoeffTiles == 1) ? 0u : (warp & 1u);
    const std::uint32_t coeff_base =
        ((static_cast<std::uint32_t>(blockIdx.x) * CoeffTiles + ctile) *
         static_cast<std::uint32_t>(ItemsPerThread)) *
            kWarpSize +
        lane;
    const std::size_t tid_base = limb_base + coeff_base;

#pragma unroll
    for (unsigned int sub = 0; sub < static_cast<unsigned int>(CoeffTiles); ++sub)
    {
        const unsigned int baby = (warp / CoeffTiles) + sub * kBabyWarps;
        if (baby < tile_count)
        {
            const std::uint32_t galois_elt = arguments.galois_elts[baby];
            if (galois_elt == 0)
            {
                if constexpr (IsQ)
                {
#pragma unroll
                    for (int item = 0; item < ItemsPerThread; ++item)
                    {
                        const std::size_t tid =
                            tid_base + static_cast<std::size_t>(item) * kWarpSize;
                        const unsigned int scol =
                            (ctile * ItemsPerThread + static_cast<unsigned int>(item)) * kWarpSize + lane;
                        shared_baby[0][baby][scol] =
                            multiply_mod(source_q0[tid], p_mod_q_limb, modulus, ratio);
                        shared_baby[1][baby][scol] =
                            multiply_mod(source_q1[tid], p_mod_q_limb, modulus, ratio);
                    }
                }
                else
                {
#pragma unroll
                    for (int item = 0; item < ItemsPerThread; ++item)
                    {
                        const unsigned int scol =
                            (ctile * ItemsPerThread + static_cast<unsigned int>(item)) * kWarpSize + lane;
                        shared_baby[0][baby][scol] = 0u;
                        shared_baby[1][baby][scol] = 0u;
                    }
                }
            }
            else
            {
                const std::size_t key_base =
                    static_cast<std::size_t>(arguments.key_indices[baby]) * storage_dnum;
                const std::size_t actual_dnum =
                    FixedDnum > 0 ? static_cast<std::size_t>(FixedDnum) : dnum;
                const GpuWord *k0_0 = (FixedDnum >= 1) ? key0_ptrs[key_base] : nullptr;
                const GpuWord *k1_0 = (FixedDnum >= 1) ? key1_ptrs[key_base] : nullptr;
                const GpuWord *k0_1 = (FixedDnum == 2) ? key0_ptrs[key_base + 1] : nullptr;
                const GpuWord *k1_1 = (FixedDnum == 2) ? key1_ptrs[key_base + 1] : nullptr;

#pragma unroll
                for (int item = 0; item < ItemsPerThread; ++item)
                {
                    const std::uint32_t coeff =
                        coeff_base + static_cast<std::uint32_t>(item) * kWarpSize;
                    const std::uint32_t reversed =
                        reverse_bits_limited(degree_u32 + coeff, degree_power + 1);
                    const std::uint32_t raw_perm = (degree_power <= 30u)
                        ? (((galois_elt * reversed) >> 1) & degree_mask)
                        : static_cast<std::uint32_t>(
                              ((static_cast<std::uint64_t>(galois_elt) * reversed) >> 1) &
                              degree_mask);
                    const std::uint32_t source_coeff = reverse_bits_limited(
                        raw_perm,
                        degree_power);
                    const std::size_t source_index = limb_base + source_coeff;
                    GpuWord baby0 = 0;
                    GpuWord baby1 = 0;
                    if constexpr (Lazy)
                    {
                        PmacAccumulator lazy0;
                        PmacAccumulator lazy1;
                        if constexpr (FixedDnum == 1)
                        {
                            const GpuWord d0 = digits[source_index];
                            pmac_mac(lazy0, d0, k0_0[source_index]);
                            pmac_mac(lazy1, d0, k1_0[source_index]);
                        }
                        else if constexpr (FixedDnum == 2)
                        {
                            const GpuWord d0 = digits[source_index];
                            const GpuWord d1 = digits[words_per_digit + source_index];
                            pmac_mac(lazy0, d0, k0_0[source_index]);
                            pmac_mac(lazy1, d0, k1_0[source_index]);
                            pmac_mac(lazy0, d1, k0_1[source_index]);
                            pmac_mac(lazy1, d1, k1_1[source_index]);
                        }
                        else
                        {
#pragma unroll
                            for (std::size_t digit = 0; digit < actual_dnum; ++digit)
                            {
                                const GpuWord digit_value =
                                    digits[digit * words_per_digit + source_index];
                                pmac_mac(lazy0, digit_value, key0_ptrs[key_base + digit][source_index]);
                                pmac_mac(lazy1, digit_value, key1_ptrs[key_base + digit][source_index]);
                            }
                        }
                        if constexpr (IsQ)
                        {
                            pmac_mac(lazy0, source_q0[source_index], p_mod_q_limb);
                        }
                        baby0 = pmac_reduce(lazy0, modulus, ratio);
                        baby1 = pmac_reduce(lazy1, modulus, ratio);
                    }
                    else
                    {
                        if constexpr (FixedDnum == 1)
                        {
                            const GpuWord d0 = digits[source_index];
                            baby0 = add_mod(baby0, multiply_mod(d0, k0_0[source_index], modulus, ratio), modulus);
                            baby1 = add_mod(baby1, multiply_mod(d0, k1_0[source_index], modulus, ratio), modulus);
                        }
                        else if constexpr (FixedDnum == 2)
                        {
                            const GpuWord d0 = digits[source_index];
                            const GpuWord d1 = digits[words_per_digit + source_index];
                            baby0 = add_mod(baby0, multiply_mod(d0, k0_0[source_index], modulus, ratio), modulus);
                            baby1 = add_mod(baby1, multiply_mod(d0, k1_0[source_index], modulus, ratio), modulus);
                            baby0 = add_mod(baby0, multiply_mod(d1, k0_1[source_index], modulus, ratio), modulus);
                            baby1 = add_mod(baby1, multiply_mod(d1, k1_1[source_index], modulus, ratio), modulus);
                        }
                        else
                        {
#pragma unroll
                            for (std::size_t digit = 0; digit < actual_dnum; ++digit)
                            {
                                const GpuWord digit_value =
                                    digits[digit * words_per_digit + source_index];
                                baby0 = add_mod(
                                    baby0,
                                    multiply_mod(digit_value, key0_ptrs[key_base + digit][source_index], modulus, ratio),
                                    modulus);
                                baby1 = add_mod(
                                    baby1,
                                    multiply_mod(digit_value, key1_ptrs[key_base + digit][source_index], modulus, ratio),
                                    modulus);
                            }
                        }
                        if constexpr (IsQ)
                        {
                            baby0 = add_mod(
                                baby0,
                                multiply_mod(source_q0[source_index], p_mod_q_limb, modulus, ratio),
                                modulus);
                        }
                    }
                    const unsigned int scol =
                        (ctile * ItemsPerThread + static_cast<unsigned int>(item)) * kWarpSize + lane;
                    shared_baby[0][baby][scol] = baby0;
                    shared_baby[1][baby][scol] = baby1;
                }
            }
        }
    }
    __syncthreads();

    const unsigned int group = (CoeffTiles == 1) ? warp : (warp >> 1);
    if (group >= group_count)
    {
        return;
    }

    const std::size_t component_stride = words_per_digit;
    const std::size_t group_base_offset =
        static_cast<std::size_t>(group) * 2 * component_stride + tid_base;
    const unsigned int limb32 = static_cast<unsigned int>(limb);
    const unsigned int degree32 = static_cast<unsigned int>(degree);
    std::uint32_t reversed_coeffs[ItemsPerThread];
    if constexpr (Compressed)
    {
#pragma unroll
        for (int item = 0; item < ItemsPerThread; ++item)
        {
            reversed_coeffs[item] = reverse_bits_limited(
                coeff_base + static_cast<std::uint32_t>(item) * kWarpSize,
                degree_power);
        }
    }

    if constexpr (Lazy)
    {
        PmacAccumulator acc0[ItemsPerThread];
        PmacAccumulator acc1[ItemsPerThread];
        for (unsigned int baby = 0; baby < tile_count; ++baby)
        {
            if constexpr (!IsQ)
            {
                if (arguments.galois_elts[baby] == 0)
                {
                    continue;
                }
            }
            const std::uint32_t term = arguments.term_indices[group][baby];
            if (term >= term_count)
            {
                continue;
            }
            const GpuWord *diag_ptr = diagonal_ptrs[term];
            const unsigned int period = Compressed ? diagonal_periods[term] : degree32;
#pragma unroll
            for (int item = 0; item < ItemsPerThread; ++item)
            {
                const std::uint32_t coeff =
                    coeff_base + static_cast<std::uint32_t>(item) * kWarpSize;
                GpuWord diagonal;
                if constexpr (!Compressed)
                {
                    diagonal = diag_ptr[limb32 * degree32 + coeff];
                }
                else
                {
                    diagonal = period >= degree32
                        ? diag_ptr[limb32 * degree32 + coeff]
                        : diag_ptr[
                              limb32 * period +
                              static_cast<unsigned int>(compressed_diagonal_compact_index(
                                  reversed_coeffs[item], period, degree_power))];
                }
                const unsigned int scol =
                    (ctile * ItemsPerThread + static_cast<unsigned int>(item)) * kWarpSize + lane;
                pmac_mac(acc0[item], shared_baby[0][baby][scol], diagonal);
                pmac_mac(acc1[item], shared_baby[1][baby][scol], diagonal);
            }
        }
#pragma unroll
        for (int item = 0; item < ItemsPerThread; ++item)
        {
            const std::size_t group_offset =
                group_base_offset + static_cast<std::size_t>(item) * kWarpSize;
            GpuWord out0 = pmac_reduce(acc0[item], modulus, ratio);
            GpuWord out1 = pmac_reduce(acc1[item], modulus, ratio);
            if (!initialize_accumulators)
            {
                out0 = add_mod(group_values[group_offset], out0, modulus);
                out1 = add_mod(group_values[group_offset + component_stride], out1, modulus);
            }
            group_values[group_offset] = out0;
            group_values[group_offset + component_stride] = out1;
        }
    }
    else
    {
        GpuWord acc0[ItemsPerThread];
        GpuWord acc1[ItemsPerThread];
#pragma unroll
        for (int item = 0; item < ItemsPerThread; ++item)
        {
            const std::size_t group_offset =
                group_base_offset + static_cast<std::size_t>(item) * kWarpSize;
            acc0[item] = initialize_accumulators ? 0 : group_values[group_offset];
            acc1[item] = initialize_accumulators ? 0 : group_values[group_offset + component_stride];
        }
        for (unsigned int baby = 0; baby < tile_count; ++baby)
        {
            if constexpr (!IsQ)
            {
                if (arguments.galois_elts[baby] == 0)
                {
                    continue;
                }
            }
            const std::uint32_t term = arguments.term_indices[group][baby];
            if (term >= term_count)
            {
                continue;
            }
#pragma unroll
            for (int item = 0; item < ItemsPerThread; ++item)
            {
                const std::uint32_t coeff =
                    coeff_base + static_cast<std::uint32_t>(item) * kWarpSize;
                const GpuWord diagonal = load_qp_diagonal<Compressed>(
                    diagonal_ptrs,
                    diagonal_periods,
                    term,
                    limb,
                    coeff,
                    degree,
                    degree_power);
                const unsigned int scol =
                    (ctile * ItemsPerThread + static_cast<unsigned int>(item)) * kWarpSize + lane;
                acc0[item] = add_mod(acc0[item], multiply_mod(shared_baby[0][baby][scol], diagonal, modulus, ratio), modulus);
                acc1[item] = add_mod(acc1[item], multiply_mod(shared_baby[1][baby][scol], diagonal, modulus, ratio), modulus);
            }
        }
#pragma unroll
        for (int item = 0; item < ItemsPerThread; ++item)
        {
            const std::size_t group_offset =
                group_base_offset + static_cast<std::size_t>(item) * kWarpSize;
            group_values[group_offset] = acc0[item];
            group_values[group_offset + component_stride] = acc1[item];
        }
    }
}

template <int GroupTile, bool IsQ, bool Compressed, bool Lazy = false>
__global__ void fused_baby_keyswitch_plain_accumulate_kernel(
    GpuWord *__restrict__ group_values,
    const GpuWord *__restrict__ digits,
    const GpuWord *__restrict__ source_q0,
    const GpuWord *__restrict__ source_q1,
    BabyKeyMacKernelArguments arguments,
    const GpuWord *const *__restrict__ key0_ptrs,
    const GpuWord *const *__restrict__ key1_ptrs,
    const GpuWord *const *__restrict__ diagonal_ptrs,
    const std::uint32_t *__restrict__ diagonal_periods,
    const GpuWord *__restrict__ p_mod_q,
    const GpuWord *__restrict__ moduli,
    const GpuWide *__restrict__ barrett,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t tile_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    std::size_t limb_count,
    std::size_t degree,
    unsigned int degree_power,
    bool initialize_accumulators)
{
    static_assert(GroupTile == 1 || GroupTile == 4 || GroupTile == 8);
    const std::size_t tid = blockIdx.x * blockDim.x + threadIdx.x;
    const std::size_t words_per_digit = limb_count * degree;
    if (tid >= words_per_digit)
    {
        return;
    }

    const std::size_t limb = tid >> degree_power;
    const std::uint32_t coefficient = static_cast<std::uint32_t>(
        tid & (degree - 1));
    const GpuWord modulus = moduli[limb];
    const GpuWide ratio = barrett[limb];
    const std::size_t component_stride = limb_count * degree;
    const std::size_t group_stride = 2 * component_stride;

    using AccType = std::conditional_t<Lazy, PmacAccumulator, GpuWord>;
    AccType acc0[GroupTile];
    AccType acc1[GroupTile];
    if constexpr (!Lazy)
    {
#pragma unroll
        for (int group = 0; group < GroupTile; ++group)
        {
            if (static_cast<std::size_t>(group) < group_count &&
                !initialize_accumulators)
            {
                const std::size_t offset =
                    static_cast<std::size_t>(group) * group_stride + tid;
                acc0[group] = group_values[offset];
                acc1[group] = group_values[offset + component_stride];
            }
            else
            {
                acc0[group] = 0;
                acc1[group] = 0;
            }
        }
    }

    const std::uint32_t degree_u32 = static_cast<std::uint32_t>(degree);
    const std::uint32_t degree_mask = degree_u32 - 1;
    for (std::size_t baby = 0; baby < tile_count; ++baby)
    {
        const std::uint32_t galois_elt = arguments.galois_elts[baby];
        GpuWord baby0 = 0;
        GpuWord baby1 = 0;
        if (galois_elt == 0)
        {
            if constexpr (IsQ)
            {
                baby0 = multiply_mod(
                    source_q0[tid], p_mod_q[limb], modulus, ratio);
                baby1 = multiply_mod(
                    source_q1[tid], p_mod_q[limb], modulus, ratio);
            }
        }
        else
        {
            const std::uint32_t reversed = reverse_bits_limited(
                degree_u32 + coefficient, degree_power + 1);
            const std::uint64_t index_raw =
                (static_cast<std::uint64_t>(galois_elt) * reversed) >> 1;
            const std::uint32_t source_coefficient = reverse_bits_limited(
                static_cast<std::uint32_t>(index_raw & degree_mask),
                degree_power);
            const std::size_t source_index =
                limb * degree + source_coefficient;
            const std::size_t key_base =
                static_cast<std::size_t>(arguments.key_indices[baby]) *
                storage_dnum;
            if constexpr (Lazy)
            {
                // POSEIDON_OPT_LAZY_BABY: exact 96-bit sums, one reduction each.
                PmacAccumulator lazy0;
                PmacAccumulator lazy1;
                for (std::size_t digit = 0; digit < dnum; ++digit)
                {
                    const GpuWord digit_value =
                        digits[digit * words_per_digit + source_index];
                    pmac_mac(lazy0, digit_value, key0_ptrs[key_base + digit][source_index]);
                    pmac_mac(lazy1, digit_value, key1_ptrs[key_base + digit][source_index]);
                }
                if constexpr (IsQ)
                {
                    pmac_mac(lazy0, source_q0[source_index], p_mod_q[limb]);
                }
                baby0 = pmac_reduce(lazy0, modulus, ratio);
                baby1 = pmac_reduce(lazy1, modulus, ratio);
            }
            else
            {
            for (std::size_t digit = 0; digit < dnum; ++digit)
            {
                const GpuWord digit_value =
                    digits[digit * words_per_digit + source_index];
                baby0 = add_mod(
                    baby0,
                    multiply_mod(
                        digit_value,
                        key0_ptrs[key_base + digit][source_index],
                        modulus,
                        ratio),
                    modulus);
                baby1 = add_mod(
                    baby1,
                    multiply_mod(
                        digit_value,
                        key1_ptrs[key_base + digit][source_index],
                        modulus,
                        ratio),
                    modulus);
            }
            if constexpr (IsQ)
            {
                baby0 = add_mod(
                    baby0,
                    multiply_mod(
                        source_q0[source_index],
                        p_mod_q[limb],
                        modulus,
                        ratio),
                    modulus);
            }
            }
        }

#pragma unroll
        for (int group = 0; group < GroupTile; ++group)
        {
            if (static_cast<std::size_t>(group) >= group_count)
            {
                continue;
            }
            const std::uint32_t term =
                arguments.term_indices[group][baby];
            if (term >= term_count)
            {
                continue;
            }
            const GpuWord diagonal = load_qp_diagonal<Compressed>(
                diagonal_ptrs,
                diagonal_periods,
                term,
                limb,
                coefficient,
                degree,
                degree_power);
            if constexpr (Lazy)
            {
                pmac_mac(acc0[group], baby0, diagonal);
                pmac_mac(acc1[group], baby1, diagonal);
            }
            else
            {
                acc0[group] = add_mod(
                    acc0[group],
                    multiply_mod(baby0, diagonal, modulus, ratio),
                    modulus);
                acc1[group] = add_mod(
                    acc1[group],
                    multiply_mod(baby1, diagonal, modulus, ratio),
                    modulus);
            }
        }
    }

#pragma unroll
    for (int group = 0; group < GroupTile; ++group)
    {
        if (static_cast<std::size_t>(group) < group_count)
        {
            const std::size_t offset =
                static_cast<std::size_t>(group) * group_stride + tid;
            if constexpr (Lazy)
            {
                GpuWord out0 = pmac_reduce(acc0[group], modulus, ratio);
                GpuWord out1 = pmac_reduce(acc1[group], modulus, ratio);
                if (!initialize_accumulators)
                {
                    out0 = add_mod(group_values[offset], out0, modulus);
                    out1 = add_mod(
                        group_values[offset + component_stride], out1, modulus);
                }
                group_values[offset] = out0;
                group_values[offset + component_stride] = out1;
            }
            else
            {
                group_values[offset] = acc0[group];
                group_values[offset + component_stride] = acc1[group];
            }
        }
    }
}

unsigned int log2_degree(std::size_t degree, const char *name)
{
    if (degree == 0 || (degree & (degree - 1)) != 0 ||
        degree > static_cast<std::size_t>(
            std::numeric_limits<std::uint32_t>::max()))
    {
        throw std::invalid_argument(std::string(name) + ": invalid degree");
    }
    unsigned int result = 0;
    while ((std::size_t{1} << result) < degree)
    {
        ++result;
    }
    return result;
}

void validate_parameter_shard(
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const char *name)
{
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    if (q_count == 0 || p_count == 0 ||
        parameter_shard.rns_primes.size() < q_count + p_count ||
        parameter_shard.rns_modulus_constants.size() < q_count + p_count ||
        parameter_shard.hybrid_p_mod_q.size() < q_count)
    {
        throw std::invalid_argument(std::string(name) + ": incomplete HYBRID tables");
    }
    (void)log2_degree(degree, name);
}

}  // namespace

void launch_double_hoist_pre_rotated_keymul_digit(
    GpuWord *destination_q0,
    GpuWord *destination_p0,
    GpuWord *destination_q1,
    GpuWord *destination_p1,
    GpuWord *scratch_group_q,
    GpuWord *scratch_group_p,
    const GpuWord *digit_q,
    const GpuWord *digit_p,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::uint32_t galois_elt,
    bool overwrite,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name =
        "launch_double_hoist_pre_rotated_keymul_digit";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || destination_p0 == nullptr ||
        destination_q1 == nullptr || destination_p1 == nullptr ||
        digit_q == nullptr || digit_p == nullptr ||
        key_q0 == nullptr || key_p0 == nullptr ||
        key_q1 == nullptr || key_p1 == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null pointer");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    constexpr int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const int q_grid = static_cast<int>(
        (q_count * degree + block_size - 1) / block_size);
    pre_rotated_keymul_digit_kernel<<<q_grid, block_size, 0, gpu_execution_stream()>>>(
        destination_q0,
        destination_q1,
        digit_q,
        key_q0,
        key_q1,
        galois_elt,
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        q_count,
        degree,
        degree_power,
        overwrite);
    gpu_check_cuda(cudaGetLastError(), name);

    const int p_grid = static_cast<int>(
        (p_count * degree + block_size - 1) / block_size);
    pre_rotated_keymul_digit_kernel<<<p_grid, block_size, 0, gpu_execution_stream()>>>(
        destination_p0,
        destination_p1,
        digit_p,
        key_p0,
        key_p1,
        galois_elt,
        parameter_shard.rns_primes.data() + q_count,
        parameter_shard.rns_modulus_constants.data() + q_count,
        p_count,
        degree,
        degree_power,
        overwrite);
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_pre_rotated_keymul_batch(
    GpuWord *destination_q0,
    GpuWord *destination_p0,
    GpuWord *destination_q1,
    GpuWord *destination_p1,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t dnum,
    std::uint32_t galois_elt,
    bool overwrite,
    const GpuWord *lifted_c0_source_q,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name =
        "launch_double_hoist_pre_rotated_keymul_batch";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || destination_p0 == nullptr ||
        destination_q1 == nullptr || destination_p1 == nullptr ||
        digits_q == nullptr || digits_p == nullptr ||
        key_q0_ptrs == nullptr || key_p0_ptrs == nullptr ||
        key_q1_ptrs == nullptr || key_p1_ptrs == nullptr ||
        dnum == 0)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    constexpr int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const bool lazy = opt_flag(OptFlag::LazyBaby);
    const int q_grid = static_cast<int>(
        (q_count * degree + block_size - 1) / block_size);
    if (dnum == 1 && lifted_c0_source_q != nullptr && !lazy)
    {
        pre_rotated_keymul_dnum1_kernel<true><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_q0,
            destination_q1,
            digits_q,
            key_q0_ptrs,
            key_q1_ptrs,
            lifted_c0_source_q,
            parameter_shard.hybrid_p_mod_q.data(),
            galois_elt,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            q_count,
            degree,
            degree_power,
            overwrite);
    }
    else if (dnum == 1 && lifted_c0_source_q == nullptr)
    {
        pre_rotated_keymul_dnum1_kernel<false><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_q0,
            destination_q1,
            digits_q,
            key_q0_ptrs,
            key_q1_ptrs,
            nullptr,
            nullptr,
            galois_elt,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            q_count,
            degree,
            degree_power,
            overwrite);
    }
    else if (lifted_c0_source_q != nullptr)
    {
        if (lazy)
        {
            pre_rotated_keymul_batch_kernel<true, true><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
                destination_q0, destination_q1, digits_q, key_q0_ptrs, key_q1_ptrs,
                lifted_c0_source_q, parameter_shard.hybrid_p_mod_q.data(), galois_elt,
                parameter_shard.rns_primes.data(), parameter_shard.rns_modulus_constants.data(),
                dnum, q_count, degree, degree_power, overwrite);
        }
        else
        {
            pre_rotated_keymul_batch_kernel<true, false><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
                destination_q0, destination_q1, digits_q, key_q0_ptrs, key_q1_ptrs,
                lifted_c0_source_q, parameter_shard.hybrid_p_mod_q.data(), galois_elt,
                parameter_shard.rns_primes.data(), parameter_shard.rns_modulus_constants.data(),
                dnum, q_count, degree, degree_power, overwrite);
        }
    }
    else if (lazy)
    {
        pre_rotated_keymul_batch_kernel<false, true><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_q0, destination_q1, digits_q, key_q0_ptrs, key_q1_ptrs,
            nullptr, nullptr, galois_elt,
            parameter_shard.rns_primes.data(), parameter_shard.rns_modulus_constants.data(),
            dnum, q_count, degree, degree_power, overwrite);
    }
    else
    {
        pre_rotated_keymul_batch_kernel<false, false><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_q0,
            destination_q1,
            digits_q,
            key_q0_ptrs,
            key_q1_ptrs,
            nullptr,
            nullptr,
            galois_elt,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            dnum,
            q_count,
            degree,
            degree_power,
            overwrite);
    }
    gpu_check_cuda(cudaGetLastError(), name);

    const int p_grid = static_cast<int>(
        (p_count * degree + block_size - 1) / block_size);
    if (dnum == 1)
    {
        pre_rotated_keymul_dnum1_kernel<false><<<p_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_p0,
            destination_p1,
            digits_p,
            key_p0_ptrs,
            key_p1_ptrs,
            nullptr,
            nullptr,
            galois_elt,
            parameter_shard.rns_primes.data() + q_count,
            parameter_shard.rns_modulus_constants.data() + q_count,
            p_count,
            degree,
            degree_power,
            overwrite);
    }
    else if (lazy)
    {
        pre_rotated_keymul_batch_kernel<false, true><<<p_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_p0,
            destination_p1,
            digits_p,
            key_p0_ptrs,
            key_p1_ptrs,
            nullptr,
            nullptr,
            galois_elt,
            parameter_shard.rns_primes.data() + q_count,
            parameter_shard.rns_modulus_constants.data() + q_count,
            dnum,
            p_count,
            degree,
            degree_power,
            overwrite);
    }
    else
    {
        pre_rotated_keymul_batch_kernel<false, false><<<p_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_p0,
            destination_p1,
            digits_p,
            key_p0_ptrs,
            key_p1_ptrs,
            nullptr,
            nullptr,
            galois_elt,
            parameter_shard.rns_primes.data() + q_count,
            parameter_shard.rns_modulus_constants.data() + q_count,
            dnum,
            p_count,
            degree,
            degree_power,
            overwrite);
    }
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_hoisted_keymul_batch(
    GpuWord *destination_q_batch,
    GpuWord *destination_p_batch,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const HoistedKeymulBatchArgs &q_args,
    const HoistedKeymulBatchArgs &p_args,
    std::size_t batch_count,
    std::size_t dnum,
    bool key_pre_rotated,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name = "launch_double_hoist_hoisted_keymul_batch";
    if (batch_count == 0)
    {
        return;
    }
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q_batch == nullptr || destination_p_batch == nullptr ||
        digits_q == nullptr || digits_p == nullptr || source_q0 == nullptr ||
        batch_count > kMaxDoubleHoistFusedBabySteps ||
        dnum == 0 || dnum > kMaxHoistedKeymulBatchDigits)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        if (q_args.galois_elts[b] == 0 && source_q1 == nullptr)
        {
            throw std::invalid_argument(std::string(name) + ": identity step requires source_q1");
        }
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    constexpr unsigned int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const bool lazy = opt_flag(OptFlag::LazyBaby);
    const auto z_dim = static_cast<unsigned int>(batch_count);
    const dim3 q_grid(static_cast<unsigned int>((q_count * degree + block_size - 1) / block_size), 1, z_dim);
    const dim3 p_grid(static_cast<unsigned int>((p_count * degree + block_size - 1) / block_size), 1, z_dim);

#define POSEIDON_LAUNCH_HOISTED_BATCH(PRE, LAZY)                                                       \
    do                                                                                                 \
    {                                                                                                  \
        hoisted_baby_tile_batch_kernel<PRE, true, LAZY><<<q_grid, block_size, 0, gpu_execution_stream()>>>( \
            destination_q_batch, digits_q, source_q0, source_q1,                                       \
            parameter_shard.hybrid_p_mod_q.data(), q_args,                                             \
            parameter_shard.rns_primes.data(), parameter_shard.rns_modulus_constants.data(),           \
            dnum, q_count, degree, degree_power);                                                      \
        gpu_check_cuda(cudaGetLastError(), name);                                                      \
        hoisted_baby_tile_batch_kernel<PRE, false, LAZY><<<p_grid, block_size, 0, gpu_execution_stream()>>>( \
            destination_p_batch, digits_p, nullptr, nullptr,                                           \
            nullptr, p_args,                                                                           \
            parameter_shard.rns_primes.data() + q_count,                                               \
            parameter_shard.rns_modulus_constants.data() + q_count,                                    \
            dnum, p_count, degree, degree_power);                                                      \
        gpu_check_cuda(cudaGetLastError(), name);                                                      \
    } while (false)

    if (key_pre_rotated)
    {
        if (lazy) { POSEIDON_LAUNCH_HOISTED_BATCH(true, true); }
        else      { POSEIDON_LAUNCH_HOISTED_BATCH(true, false); }
    }
    else
    {
        if (lazy) { POSEIDON_LAUNCH_HOISTED_BATCH(false, true); }
        else      { POSEIDON_LAUNCH_HOISTED_BATCH(false, false); }
    }
#undef POSEIDON_LAUNCH_HOISTED_BATCH
}

void launch_double_hoist_hoisted_keymul_sum(
    GpuWord *destination_q0,
    GpuWord *destination_p0,
    GpuWord *destination_q1,
    GpuWord *destination_p1,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *source_q0,
    const HoistedKeymulBatchArgs &q_args,
    const HoistedKeymulBatchArgs &p_args,
    std::size_t batch_count,
    std::size_t dnum,
    bool key_pre_rotated,
    bool initialize,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name = "launch_double_hoist_hoisted_keymul_sum";
    if (batch_count == 0)
    {
        return;
    }
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || destination_p0 == nullptr ||
        destination_q1 == nullptr || destination_p1 == nullptr ||
        digits_q == nullptr || digits_p == nullptr || source_q0 == nullptr ||
        batch_count > kMaxDoubleHoistFusedBabySteps ||
        dnum == 0 || dnum > kMaxHoistedKeymulBatchDigits)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        if (q_args.galois_elts[b] == 0)
        {
            throw std::invalid_argument(std::string(name) + ": zero galois_elt is not supported");
        }
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    constexpr unsigned int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const auto q_grid = static_cast<unsigned int>((q_count * degree + block_size - 1) / block_size);
    const auto p_grid = static_cast<unsigned int>((p_count * degree + block_size - 1) / block_size);

    if (key_pre_rotated)
    {
        hoisted_keymul_sum_kernel<true, true><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_q0, destination_q1, digits_q, source_q0,
            parameter_shard.hybrid_p_mod_q.data(), q_args,
            parameter_shard.rns_primes.data(), parameter_shard.rns_modulus_constants.data(),
            batch_count, dnum, q_count, degree, degree_power, initialize);
        gpu_check_cuda(cudaGetLastError(), name);
        hoisted_keymul_sum_kernel<true, false><<<p_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_p0, destination_p1, digits_p, nullptr,
            nullptr, p_args,
            parameter_shard.rns_primes.data() + q_count,
            parameter_shard.rns_modulus_constants.data() + q_count,
            batch_count, dnum, p_count, degree, degree_power, initialize);
        gpu_check_cuda(cudaGetLastError(), name);
    }
    else
    {
        hoisted_keymul_sum_kernel<false, true><<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_q0, destination_q1, digits_q, source_q0,
            parameter_shard.hybrid_p_mod_q.data(), q_args,
            parameter_shard.rns_primes.data(), parameter_shard.rns_modulus_constants.data(),
            batch_count, dnum, q_count, degree, degree_power, initialize);
        gpu_check_cuda(cudaGetLastError(), name);
        hoisted_keymul_sum_kernel<false, false><<<p_grid, block_size, 0, gpu_execution_stream()>>>(
            destination_p0, destination_p1, digits_p, nullptr,
            nullptr, p_args,
            parameter_shard.rns_primes.data() + q_count,
            parameter_shard.rns_modulus_constants.data() + q_count,
            batch_count, dnum, p_count, degree, degree_power, initialize);
        gpu_check_cuda(cudaGetLastError(), name);
    }
}

void launch_double_hoist_lift_identity(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool accumulate)
{
    const char *name = "launch_double_hoist_lift_identity";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || destination_q1 == nullptr ||
        destination_p0 == nullptr || destination_p1 == nullptr ||
        source_q0 == nullptr || source_q1 == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null pointer");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const std::size_t total = 2 * q_count * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    lift_identity_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        destination_q0,
        destination_q1,
        source_q0,
        source_q1,
        parameter_shard.hybrid_p_mod_q.data(),
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        q_count,
        degree,
        log2_degree(degree, name),
        accumulate);
    gpu_check_cuda(cudaGetLastError(), name);

    if (!accumulate)
    {
        gpu_check_cuda(
            cudaMemsetAsync(destination_p0, 0, p_count * degree * sizeof(GpuWord),
                            gpu_execution_stream()),
            name);
        gpu_check_cuda(
            cudaMemsetAsync(destination_p1, 0, p_count * degree * sizeof(GpuWord),
                            gpu_execution_stream()),
            name);
    }
}

void launch_double_hoist_add_lifted_galois_c0(
    GpuWord *destination_q0,
    const GpuWord *source_q0,
    std::uint32_t galois_elt,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name = "launch_double_hoist_add_lifted_galois_c0";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || source_q0 == nullptr)
    {
        throw std::invalid_argument(std::string(name) + ": null pointer");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t total = q_count * degree;
    constexpr int block_size = 256;
    const int grid_size = static_cast<int>((total + block_size - 1) / block_size);
    add_lifted_galois_c0_kernel<<<grid_size, block_size, 0, gpu_execution_stream()>>>(
        destination_q0,
        source_q0,
        galois_elt,
        parameter_shard.hybrid_p_mod_q.data(),
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        q_count,
        degree,
        log2_degree(degree, name));
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_pre_rotated_giant_group_reduce(
    GpuWord *scratch_group_q,
    GpuWord *scratch_group_p,
    const GpuWord *inner_q_batch,
    const GpuWord *const *host_group_digit_q_ptrs,
    const GpuWord *const *host_group_digit_p_ptrs,
    const std::uint32_t *host_group_indices,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name =
        "launch_double_hoist_pre_rotated_giant_group_reduce";
    validate_parameter_shard(parameter_shard, degree, name);
    if (scratch_group_q == nullptr || scratch_group_p == nullptr ||
        inner_q_batch == nullptr ||
        host_group_digit_q_ptrs == nullptr ||
        host_group_digit_p_ptrs == nullptr ||
        host_group_indices == nullptr ||
        host_galois_elts == nullptr ||
        host_key_indices == nullptr ||
        key_q0_ptrs == nullptr || key_p0_ptrs == nullptr ||
        key_q1_ptrs == nullptr || key_p1_ptrs == nullptr ||
        active_group_count == 0 ||
        active_group_count > kMaxFusedGiantGroups ||
        dnum == 0 || storage_dnum < dnum)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    constexpr int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    GiantGroupKernelArguments q_group_args{};
    GiantGroupKernelArguments p_group_args{};
    for (std::size_t group = 0;
         group < active_group_count;
         ++group)
    {
        q_group_args.digit_ptrs[group] =
            host_group_digit_q_ptrs[group];
        p_group_args.digit_ptrs[group] =
            host_group_digit_p_ptrs[group];
        q_group_args.group_indices[group] =
            p_group_args.group_indices[group] =
                host_group_indices[group];
        q_group_args.galois_elts[group] =
            p_group_args.galois_elts[group] =
                host_galois_elts[group];
        q_group_args.key_indices[group] =
            p_group_args.key_indices[group] =
                host_key_indices[group];
    }
    const int q_grid = static_cast<int>(
        (active_group_count * q_count * degree +
         block_size - 1) /
        block_size);
    pre_rotated_giant_group_reduce_kernel<<<q_grid, block_size, 0, gpu_execution_stream()>>>(
        scratch_group_q,
        inner_q_batch,
        q_group_args,
        key_q0_ptrs,
        key_q1_ptrs,
        parameter_shard.hybrid_p_mod_q.data(),
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        active_group_count,
        dnum,
        storage_dnum,
        q_count,
        q_count,
        degree,
        degree_power,
        true);
    gpu_check_cuda(cudaGetLastError(), name);

    const int p_grid = static_cast<int>(
        (active_group_count * p_count * degree +
         block_size - 1) /
        block_size);
    pre_rotated_giant_group_reduce_kernel<<<p_grid, block_size, 0, gpu_execution_stream()>>>(
        scratch_group_p,
        inner_q_batch,
        p_group_args,
        key_p0_ptrs,
        key_p1_ptrs,
        nullptr,
        parameter_shard.rns_primes.data() + q_count,
        parameter_shard.rns_modulus_constants.data() + q_count,
        active_group_count,
        dnum,
        storage_dnum,
        p_count,
        q_count,
        degree,
        degree_power,
        false);
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_pre_rotated_giant_group_accumulate(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *inner_q_batch,
    std::size_t identity_group_index,
    const GpuWord *const *host_group_digit_q_ptrs,
    const GpuWord *const *host_group_digit_p_ptrs,
    const std::uint32_t *host_group_indices,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name =
        "launch_double_hoist_pre_rotated_giant_group_accumulate";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || destination_q1 == nullptr ||
        destination_p0 == nullptr || destination_p1 == nullptr ||
        inner_q_batch == nullptr ||
        host_group_digit_q_ptrs == nullptr ||
        host_group_digit_p_ptrs == nullptr ||
        host_group_indices == nullptr ||
        host_galois_elts == nullptr ||
        host_key_indices == nullptr ||
        key_q0_ptrs == nullptr || key_p0_ptrs == nullptr ||
        key_q1_ptrs == nullptr || key_p1_ptrs == nullptr ||
        active_group_count == 0 ||
        active_group_count > kMaxFusedGiantGroups ||
        dnum == 0 || storage_dnum < dnum)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    GiantGroupKernelArguments q_group_args{};
    GiantGroupKernelArguments p_group_args{};
    for (std::size_t group = 0;
         group < active_group_count;
         ++group)
    {
        q_group_args.digit_ptrs[group] =
            host_group_digit_q_ptrs[group];
        p_group_args.digit_ptrs[group] =
            host_group_digit_p_ptrs[group];
        q_group_args.group_indices[group] =
            p_group_args.group_indices[group] =
                host_group_indices[group];
        q_group_args.galois_elts[group] =
            p_group_args.galois_elts[group] =
                host_galois_elts[group];
        q_group_args.key_indices[group] =
            p_group_args.key_indices[group] =
                host_key_indices[group];
    }

    constexpr int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const int q_grid = static_cast<int>(
        (q_count * degree + block_size - 1) / block_size);
    pre_rotated_giant_group_accumulate_kernel<<<q_grid, block_size, 0, gpu_execution_stream()>>>(
        destination_q0,
        destination_q1,
        inner_q_batch,
        identity_group_index,
        q_group_args,
        key_q0_ptrs,
        key_q1_ptrs,
        parameter_shard.hybrid_p_mod_q.data(),
        parameter_shard.rns_primes.data(),
        parameter_shard.rns_modulus_constants.data(),
        active_group_count,
        dnum,
        storage_dnum,
        q_count,
        q_count,
        degree,
        degree_power,
        true);
    gpu_check_cuda(cudaGetLastError(), name);

    const int p_grid = static_cast<int>(
        (p_count * degree + block_size - 1) / block_size);
    pre_rotated_giant_group_accumulate_kernel<<<p_grid, block_size, 0, gpu_execution_stream()>>>(
        destination_p0,
        destination_p1,
        inner_q_batch,
        identity_group_index,
        p_group_args,
        key_p0_ptrs,
        key_p1_ptrs,
        nullptr,
        parameter_shard.rns_primes.data() + q_count,
        parameter_shard.rns_modulus_constants.data() + q_count,
        active_group_count,
        dnum,
        storage_dnum,
        p_count,
        q_count,
        degree,
        degree_power,
        false);
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_pre_rotated_giant_group_accumulate_qp_c0(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *group_q,
    const GpuWord *group_p,
    std::size_t identity_group_index,
    const GpuWord *const *host_group_digit_q_ptrs,
    const GpuWord *const *host_group_digit_p_ptrs,
    const std::uint32_t *host_group_indices,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuWord *inner_q_c1_batch,
    std::size_t self_digit_p_count)
{
    const char *name =
        "launch_double_hoist_pre_rotated_giant_group_accumulate_qp_c0";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_q0 == nullptr || destination_q1 == nullptr ||
        destination_p0 == nullptr || destination_p1 == nullptr ||
        group_q == nullptr || group_p == nullptr ||
        host_group_digit_q_ptrs == nullptr ||
        host_group_digit_p_ptrs == nullptr ||
        host_group_indices == nullptr ||
        host_galois_elts == nullptr ||
        host_key_indices == nullptr ||
        key_q0_ptrs == nullptr || key_p0_ptrs == nullptr ||
        key_q1_ptrs == nullptr || key_p1_ptrs == nullptr ||
        active_group_count == 0 ||
        active_group_count > kMaxFusedGiantGroups ||
        dnum == 0 || storage_dnum < dnum)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    GiantGroupKernelArguments q_group_args{};
    GiantGroupKernelArguments p_group_args{};
    for (std::size_t group = 0;
         group < active_group_count;
         ++group)
    {
        q_group_args.digit_ptrs[group] =
            host_group_digit_q_ptrs[group];
        p_group_args.digit_ptrs[group] =
            host_group_digit_p_ptrs[group];
        q_group_args.group_indices[group] =
            p_group_args.group_indices[group] =
                host_group_indices[group];
        q_group_args.galois_elts[group] =
            p_group_args.galois_elts[group] =
                host_galois_elts[group];
        q_group_args.key_indices[group] =
            p_group_args.key_indices[group] =
                host_key_indices[group];
    }

    constexpr int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const int q_grid = static_cast<int>(
        (q_count * degree + block_size - 1) / block_size);
    const bool has_self_digit =
        (inner_q_c1_batch != nullptr && self_digit_p_count != 0);
    auto launch_giant_q = [&](auto lazy_tag, auto dnum_tag, auto self_tag) {
        constexpr bool kLazy = decltype(lazy_tag)::value;
        constexpr int kFixedDnum = decltype(dnum_tag)::value;
        constexpr bool kHasSelf = decltype(self_tag)::value;
        pre_rotated_giant_group_accumulate_qp_c0_kernel<
            kLazy, kFixedDnum, kHasSelf>
            <<<q_grid, block_size, 0, gpu_execution_stream()>>>(
                destination_q0,
                destination_q1,
                group_q,
                identity_group_index,
                q_group_args,
                key_q0_ptrs,
                key_q1_ptrs,
                parameter_shard.rns_primes.data(),
                parameter_shard.rns_modulus_constants.data(),
                active_group_count,
                dnum,
                storage_dnum,
                q_count,
                degree,
                degree_power,
                inner_q_c1_batch,
                self_digit_p_count);
    };
    auto dispatch_giant_q = [&](auto lazy_tag, auto dnum_tag) {
        if (has_self_digit)
        {
            launch_giant_q(lazy_tag, dnum_tag, std::true_type{});
        }
        else
        {
            launch_giant_q(lazy_tag, dnum_tag, std::false_type{});
        }
    };
    const bool lazy_giant = opt_flag(OptFlag::LazyBaby);
    if (lazy_giant)
    {
        if (dnum == 1)
            dispatch_giant_q(std::true_type{}, std::integral_constant<int, 1>{});
        else if (dnum == 2)
            dispatch_giant_q(std::true_type{}, std::integral_constant<int, 2>{});
        else
            dispatch_giant_q(std::true_type{}, std::integral_constant<int, 0>{});
    }
    else
    {
        if (dnum == 1)
            dispatch_giant_q(std::false_type{}, std::integral_constant<int, 1>{});
        else if (dnum == 2)
            dispatch_giant_q(std::false_type{}, std::integral_constant<int, 2>{});
        else
            dispatch_giant_q(std::false_type{}, std::integral_constant<int, 0>{});
    }
    gpu_check_cuda(cudaGetLastError(), name);

    const int p_grid = static_cast<int>(
        (p_count * degree + block_size - 1) / block_size);
    auto launch_giant_p = [&](auto lazy_tag, auto dnum_tag) {
        constexpr bool kLazy = decltype(lazy_tag)::value;
        constexpr int kFixedDnum = decltype(dnum_tag)::value;
        pre_rotated_giant_group_accumulate_qp_c0_kernel<
            kLazy, kFixedDnum, false>
            <<<p_grid, block_size, 0, gpu_execution_stream()>>>(
                destination_p0,
                destination_p1,
                group_p,
                identity_group_index,
                p_group_args,
                key_p0_ptrs,
                key_p1_ptrs,
                parameter_shard.rns_primes.data() + q_count,
                parameter_shard.rns_modulus_constants.data() + q_count,
                active_group_count,
                dnum,
                storage_dnum,
                p_count,
                degree,
                degree_power);
    };
    if (lazy_giant)
    {
        if (dnum == 1)
            launch_giant_p(std::true_type{}, std::integral_constant<int, 1>{});
        else if (dnum == 2)
            launch_giant_p(std::true_type{}, std::integral_constant<int, 2>{});
        else
            launch_giant_p(std::true_type{}, std::integral_constant<int, 0>{});
    }
    else
    {
        if (dnum == 1)
            launch_giant_p(std::false_type{}, std::integral_constant<int, 1>{});
        else if (dnum == 2)
            launch_giant_p(std::false_type{}, std::integral_constant<int, 2>{});
        else
            launch_giant_p(std::false_type{}, std::integral_constant<int, 0>{});
    }
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_reduce_p_groups(
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *group_p,
    std::size_t group_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const char *name = "launch_double_hoist_reduce_p_groups";
    validate_parameter_shard(parameter_shard, degree, name);
    if (destination_p0 == nullptr || destination_p1 == nullptr ||
        group_p == nullptr || group_count == 0)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);
    constexpr int block_size = 256;
    const std::size_t q_count =
        parameter_shard.hybrid_base_q_count;
    const std::size_t p_count =
        parameter_shard.hybrid_base_p_count;
    const int p_reduce_grid = static_cast<int>(
        (2 * p_count * degree + block_size - 1) / block_size);
    reduce_qp_groups_kernel<<<p_reduce_grid, block_size, 0, gpu_execution_stream()>>>(
        destination_p0,
        group_p,
        parameter_shard.rns_primes.data() + q_count,
        group_count,
        p_count,
        degree);
    gpu_check_cuda(cudaGetLastError(), name);
}

void launch_double_hoist_qp_plain_mul_accumulate_groups(
    GpuWord *group_q,
    GpuWord *group_p,
    const GpuWord *baby_q,
    const GpuWord *baby_p,
    const GpuWord *const *diagonal_q_ptrs,
    const GpuWord *const *diagonal_p_ptrs,
    const std::uint32_t *diagonal_periods,
    const std::uint32_t *term_baby_indices,
    const std::uint32_t *group_term_offsets,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t tile_begin,
    std::size_t tile_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool compressed_plaintexts,
    bool initialize_accumulators)
{
    const char *name =
        "launch_double_hoist_qp_plain_mul_accumulate_groups";
    validate_parameter_shard(parameter_shard, degree, name);
    if (group_q == nullptr || group_p == nullptr ||
        baby_q == nullptr || baby_p == nullptr ||
        diagonal_q_ptrs == nullptr || diagonal_p_ptrs == nullptr ||
        (compressed_plaintexts && diagonal_periods == nullptr) ||
        term_baby_indices == nullptr || group_term_offsets == nullptr ||
        group_count == 0 || term_count == 0 || tile_count == 0)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    constexpr int block_size = 256;
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    bool use_group_tiled8 = true;
    if (const char *raw = std::getenv(
            "POSEIDON_DOUBLE_HOIST_QP_MAC_GROUP_TILED_8"))
    {
        const std::string value(raw);
        use_group_tiled8 = value != "0" &&
            value != "OFF" && value != "off" &&
            value != "false" && value != "FALSE";
    }
    use_group_tiled8 = use_group_tiled8 &&
        group_count > 1 && tile_count <= 8;
    bool use_component_fused = true;
    if (const char *raw = std::getenv(
            "POSEIDON_DOUBLE_HOIST_QP_MAC_COMPONENT_FUSED"))
    {
        const std::string value(raw);
        use_component_fused = value != "0" &&
            value != "OFF" && value != "off" &&
            value != "false" && value != "FALSE";
    }
    use_component_fused = use_component_fused && use_group_tiled8;

    auto launch_for_layout = [&](auto layout_tag) {
    constexpr bool kCompressed = decltype(layout_tag)::value;
    if (use_group_tiled8)
    {
        constexpr unsigned int kCoefficientTile = 32;
        const unsigned int group_tile = group_count <= 4 ? 4 : 8;
        const dim3 block(kCoefficientTile, group_tile);
        const dim3 q_grid(
            static_cast<unsigned int>(
                (degree + kCoefficientTile - 1) / kCoefficientTile),
            static_cast<unsigned int>(
                (use_component_fused ? 1 : 2) * q_count),
            static_cast<unsigned int>(
                (group_count + group_tile - 1) / group_tile));
        if (group_tile == 4)
        {
            if (use_component_fused)
            {
                qp_plain_mul_accumulate_group_component_fused_kernel<
                    4, kCompressed>
                    <<<q_grid, block, 0, gpu_execution_stream()>>>(
                        group_q,
                        baby_q,
                        diagonal_q_ptrs,
                        diagonal_periods,
                        term_baby_indices,
                        group_term_offsets,
                        parameter_shard.rns_primes.data(),
                        parameter_shard.rns_modulus_constants.data(),
                        group_count,
                        term_count,
                        q_count,
                        degree,
                        degree_power,
                        tile_begin,
                        tile_count,
                        initialize_accumulators,
                        opt_flag(OptFlag::LazyPlainMac));
            }
            else
            {
                qp_plain_mul_accumulate_group_tiled_kernel<4, kCompressed>
                    <<<q_grid, block, 0, gpu_execution_stream()>>>(
                    group_q,
                    baby_q,
                    diagonal_q_ptrs,
                    diagonal_periods,
                    term_baby_indices,
                    group_term_offsets,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    group_count,
                    term_count,
                    q_count,
                    degree,
                    degree_power,
                    tile_begin,
                    tile_count,
                    initialize_accumulators);
            }
        }
        else
        {
            if (use_component_fused)
            {
                qp_plain_mul_accumulate_group_component_fused_kernel<
                    8, kCompressed>
                    <<<q_grid, block, 0, gpu_execution_stream()>>>(
                        group_q,
                        baby_q,
                        diagonal_q_ptrs,
                        diagonal_periods,
                        term_baby_indices,
                        group_term_offsets,
                        parameter_shard.rns_primes.data(),
                        parameter_shard.rns_modulus_constants.data(),
                        group_count,
                        term_count,
                        q_count,
                        degree,
                        degree_power,
                        tile_begin,
                        tile_count,
                        initialize_accumulators,
                        opt_flag(OptFlag::LazyPlainMac));
            }
            else
            {
                qp_plain_mul_accumulate_group_tiled_kernel<8, kCompressed>
                    <<<q_grid, block, 0, gpu_execution_stream()>>>(
                    group_q,
                    baby_q,
                    diagonal_q_ptrs,
                    diagonal_periods,
                    term_baby_indices,
                    group_term_offsets,
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    group_count,
                    term_count,
                    q_count,
                    degree,
                    degree_power,
                    tile_begin,
                    tile_count,
                    initialize_accumulators);
            }
        }
    }
    else
    {
        const std::size_t q_total = group_count * 2 * q_count * degree;
        const int q_grid = static_cast<int>(
            (q_total + block_size - 1) / block_size);
        qp_plain_mul_accumulate_kernel<kCompressed>
            <<<q_grid, block_size, 0, gpu_execution_stream()>>>(
            group_q,
            baby_q,
            diagonal_q_ptrs,
            diagonal_periods,
            term_baby_indices,
            group_term_offsets,
            parameter_shard.rns_primes.data(),
            parameter_shard.rns_modulus_constants.data(),
            group_count,
            term_count,
            q_count,
            degree,
            degree_power,
            tile_begin,
            tile_count,
            initialize_accumulators);
    }
    gpu_check_cuda(cudaGetLastError(), name);

    if (use_group_tiled8)
    {
        constexpr unsigned int kCoefficientTile = 32;
        const unsigned int group_tile = group_count <= 4 ? 4 : 8;
        const dim3 block(kCoefficientTile, group_tile);
        const dim3 p_grid(
            static_cast<unsigned int>(
                (degree + kCoefficientTile - 1) / kCoefficientTile),
            static_cast<unsigned int>(
                (use_component_fused ? 1 : 2) * p_count),
            static_cast<unsigned int>(
                (group_count + group_tile - 1) / group_tile));
        if (group_tile == 4)
        {
            if (use_component_fused)
            {
                qp_plain_mul_accumulate_group_component_fused_kernel<
                    4, kCompressed>
                    <<<p_grid, block, 0, gpu_execution_stream()>>>(
                        group_p,
                        baby_p,
                        diagonal_p_ptrs,
                        diagonal_periods,
                        term_baby_indices,
                        group_term_offsets,
                        parameter_shard.rns_primes.data() + q_count,
                        parameter_shard.rns_modulus_constants.data() + q_count,
                        group_count,
                        term_count,
                        p_count,
                        degree,
                        degree_power,
                        tile_begin,
                        tile_count,
                        initialize_accumulators,
                        opt_flag(OptFlag::LazyPlainMac));
            }
            else
            {
                qp_plain_mul_accumulate_group_tiled_kernel<4, kCompressed>
                    <<<p_grid, block, 0, gpu_execution_stream()>>>(
                    group_p,
                    baby_p,
                    diagonal_p_ptrs,
                    diagonal_periods,
                    term_baby_indices,
                    group_term_offsets,
                    parameter_shard.rns_primes.data() + q_count,
                    parameter_shard.rns_modulus_constants.data() + q_count,
                    group_count,
                    term_count,
                    p_count,
                    degree,
                    degree_power,
                    tile_begin,
                    tile_count,
                    initialize_accumulators);
            }
        }
        else
        {
            if (use_component_fused)
            {
                qp_plain_mul_accumulate_group_component_fused_kernel<
                    8, kCompressed>
                    <<<p_grid, block, 0, gpu_execution_stream()>>>(
                        group_p,
                        baby_p,
                        diagonal_p_ptrs,
                        diagonal_periods,
                        term_baby_indices,
                        group_term_offsets,
                        parameter_shard.rns_primes.data() + q_count,
                        parameter_shard.rns_modulus_constants.data() + q_count,
                        group_count,
                        term_count,
                        p_count,
                        degree,
                        degree_power,
                        tile_begin,
                        tile_count,
                        initialize_accumulators,
                        opt_flag(OptFlag::LazyPlainMac));
            }
            else
            {
                qp_plain_mul_accumulate_group_tiled_kernel<8, kCompressed>
                    <<<p_grid, block, 0, gpu_execution_stream()>>>(
                    group_p,
                    baby_p,
                    diagonal_p_ptrs,
                    diagonal_periods,
                    term_baby_indices,
                    group_term_offsets,
                    parameter_shard.rns_primes.data() + q_count,
                    parameter_shard.rns_modulus_constants.data() + q_count,
                    group_count,
                    term_count,
                    p_count,
                    degree,
                    degree_power,
                    tile_begin,
                    tile_count,
                    initialize_accumulators);
            }
        }
    }
    else
    {
        const std::size_t p_total = group_count * 2 * p_count * degree;
        const int p_grid = static_cast<int>(
            (p_total + block_size - 1) / block_size);
        qp_plain_mul_accumulate_kernel<kCompressed>
            <<<p_grid, block_size, 0, gpu_execution_stream()>>>(
            group_p,
            baby_p,
            diagonal_p_ptrs,
            diagonal_periods,
            term_baby_indices,
            group_term_offsets,
            parameter_shard.rns_primes.data() + q_count,
            parameter_shard.rns_modulus_constants.data() + q_count,
            group_count,
            term_count,
            p_count,
            degree,
            degree_power,
            tile_begin,
            tile_count,
            initialize_accumulators);
    }
    gpu_check_cuda(cudaGetLastError(), name);
    };

    if (compressed_plaintexts)
    {
        launch_for_layout(std::true_type{});
    }
    else
    {
        launch_for_layout(std::false_type{});
    }
}

void launch_double_hoist_fused_baby_keyswitch_plain_accumulate(
    GpuWord *group_q,
    GpuWord *group_p,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const std::uint32_t *host_term_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    const GpuWord *const *diagonal_q_ptrs,
    const GpuWord *const *diagonal_p_ptrs,
    const std::uint32_t *diagonal_periods,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t tile_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool compressed_plaintexts,
    bool initialize_accumulators)
{
    const char *name =
        "launch_double_hoist_fused_baby_keyswitch_plain_accumulate";
    validate_parameter_shard(parameter_shard, degree, name);
    if (group_q == nullptr || group_p == nullptr ||
        digits_q == nullptr || digits_p == nullptr ||
        source_q0 == nullptr || source_q1 == nullptr ||
        host_galois_elts == nullptr || host_key_indices == nullptr ||
        host_term_indices == nullptr ||
        key_q0_ptrs == nullptr || key_p0_ptrs == nullptr ||
        key_q1_ptrs == nullptr || key_p1_ptrs == nullptr ||
        diagonal_q_ptrs == nullptr || diagonal_p_ptrs == nullptr ||
        (compressed_plaintexts && diagonal_periods == nullptr) ||
        group_count == 0 || group_count > kMaxFusedBabyGroups ||
        term_count == 0 || tile_count == 0 ||
        tile_count > kMaxDoubleHoistFusedBabySteps ||
        dnum == 0 || storage_dnum < dnum)
    {
        throw std::invalid_argument(std::string(name) + ": invalid argument");
    }
    gpu_check_cuda(cudaSetDevice(parameter_shard.device_id), name);

    BabyKeyMacKernelArguments arguments{};
    for (std::size_t group = 0; group < kMaxFusedBabyGroups; ++group)
    {
        for (std::size_t baby = 0;
             baby < kMaxDoubleHoistFusedBabySteps;
             ++baby)
        {
            arguments.term_indices[group][baby] =
                std::numeric_limits<std::uint32_t>::max();
        }
    }
    for (std::size_t baby = 0; baby < tile_count; ++baby)
    {
        arguments.galois_elts[baby] = host_galois_elts[baby];
        arguments.key_indices[baby] = host_key_indices[baby];
    }
    for (std::size_t group = 0; group < group_count; ++group)
    {
        for (std::size_t baby = 0; baby < tile_count; ++baby)
        {
            arguments.term_indices[group][baby] =
                host_term_indices[
                    group * kMaxDoubleHoistFusedBabySteps + baby];
        }
    }

    int block_size = 128;
    if (const char *raw = std::getenv(
            "POSEIDON_DOUBLE_HOIST_FUSED_BABY_BLOCK_SIZE"))
    {
        try
        {
            block_size = std::stoi(raw);
        }
        catch (const std::exception &)
        {
            throw std::invalid_argument(
                std::string(name) + ": invalid fused baby block size");
        }
        if (block_size != 64 && block_size != 128 && block_size != 256)
        {
            throw std::invalid_argument(
                std::string(name) +
                ": fused baby block size must be 64, 128, or 256");
        }
    }
    const unsigned int degree_power = log2_degree(degree, name);
    const std::size_t q_count = parameter_shard.hybrid_base_q_count;
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const int q_grid = static_cast<int>(
        (q_count * degree + block_size - 1) / block_size);
    const int p_grid = static_cast<int>(
        (p_count * degree + block_size - 1) / block_size);

    int shared_baby_mode = 2;
    if (const char *raw = std::getenv("POSEIDON_SHARED_BABY_MAC"))
    {
        if (*raw)
        {
            shared_baby_mode = std::atoi(raw);
        }
    }

    auto launch_for_layout = [&](auto layout_tag) {
        constexpr bool kCompressed = decltype(layout_tag)::value;
        auto launch_shared = [&](auto group_tile_tag, auto coeff_tiles_tag) {
            constexpr int kGroupTile = decltype(group_tile_tag)::value;
            constexpr int kCoeffTiles = decltype(coeff_tiles_tag)::value;
            const dim3 block(32, 8, 1);
            int raw_items = opt_flag_value(OptFlag::SharedBabyItems);
            if (raw_items == 0)
            {
                if (const char *env_items = std::getenv("POSEIDON_SHARED_BABY_ITEMS"))
                {
                    if (*env_items)
                    {
                        raw_items = std::atoi(env_items);
                    }
                }
            }
            int requested_items =
                (raw_items == 2 || raw_items == 4) ? raw_items : 1;
            while (requested_items > 1 &&
                   (degree % (32u * kCoeffTiles * static_cast<std::size_t>(requested_items))) != 0)
            {
                requested_items /= 2;
            }
            auto launch_shared_items = [&](auto items_tag) {
                constexpr int kItems = decltype(items_tag)::value;
                const unsigned int grid_x =
                    static_cast<unsigned int>(degree / (32 * kCoeffTiles * kItems));
                const dim3 q_grid2d(grid_x, static_cast<unsigned int>(q_count), 1);
                const dim3 p_grid2d(grid_x, static_cast<unsigned int>(p_count), 1);
                auto launch_shared_dnum = [&](auto lazy_tag, auto dnum_tag) {
                    constexpr bool kLazy = decltype(lazy_tag)::value;
                    constexpr int kFixedDnum = decltype(dnum_tag)::value;
                    shared_baby_keyswitch_plain_accumulate_kernel<
                        kGroupTile, kCoeffTiles, true, kCompressed, kLazy, kFixedDnum, kItems>
                        <<<q_grid2d, block, 0, gpu_execution_stream()>>>(
                            group_q, digits_q, source_q0, source_q1, arguments,
                            key_q0_ptrs, key_q1_ptrs, diagonal_q_ptrs,
                            diagonal_periods, parameter_shard.hybrid_p_mod_q.data(),
                            parameter_shard.rns_primes.data(),
                            parameter_shard.rns_modulus_constants.data(),
                            group_count, term_count, tile_count, dnum, storage_dnum,
                            q_count, degree, degree_power, initialize_accumulators);
                    shared_baby_keyswitch_plain_accumulate_kernel<
                        kGroupTile, kCoeffTiles, false, kCompressed, kLazy, kFixedDnum, kItems>
                        <<<p_grid2d, block, 0, gpu_execution_stream()>>>(
                            group_p, digits_p, nullptr, nullptr, arguments,
                            key_p0_ptrs, key_p1_ptrs, diagonal_p_ptrs,
                            diagonal_periods, nullptr,
                            parameter_shard.rns_primes.data() + q_count,
                            parameter_shard.rns_modulus_constants.data() + q_count,
                            group_count, term_count, tile_count, dnum, storage_dnum,
                            p_count, degree, degree_power, initialize_accumulators);
                };
                if (opt_flag(OptFlag::LazyBaby))
                {
                    if (dnum == 1)
                        launch_shared_dnum(std::true_type{}, std::integral_constant<int, 1>{});
                    else if (dnum == 2)
                        launch_shared_dnum(std::true_type{}, std::integral_constant<int, 2>{});
                    else
                        launch_shared_dnum(std::true_type{}, std::integral_constant<int, 0>{});
                }
                else
                {
                    if (dnum == 1)
                        launch_shared_dnum(std::false_type{}, std::integral_constant<int, 1>{});
                    else if (dnum == 2)
                        launch_shared_dnum(std::false_type{}, std::integral_constant<int, 2>{});
                    else
                        launch_shared_dnum(std::false_type{}, std::integral_constant<int, 0>{});
                }
            };
            if (requested_items == 4)
            {
                launch_shared_items(std::integral_constant<int, 4>{});
            }
            else if (requested_items == 2)
            {
                launch_shared_items(std::integral_constant<int, 2>{});
            }
            else
            {
                launch_shared_items(std::integral_constant<int, 1>{});
            }
        };
        auto launch_for_tile = [&](auto tile_tag) {
            constexpr int kTile = decltype(tile_tag)::value;
            if (opt_flag(OptFlag::LazyBaby))
            {
                fused_baby_keyswitch_plain_accumulate_kernel<kTile, true, kCompressed, true>
                <<<q_grid, block_size, 0, gpu_execution_stream()>>>(
                    group_q, digits_q, source_q0, source_q1, arguments,
                    key_q0_ptrs, key_q1_ptrs, diagonal_q_ptrs,
                    diagonal_periods, parameter_shard.hybrid_p_mod_q.data(),
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    group_count, term_count, tile_count, dnum, storage_dnum,
                    q_count, degree, degree_power, initialize_accumulators);
                fused_baby_keyswitch_plain_accumulate_kernel<kTile, false, kCompressed, true>
                <<<p_grid, block_size, 0, gpu_execution_stream()>>>(
                    group_p, digits_p, nullptr, nullptr, arguments,
                    key_p0_ptrs, key_p1_ptrs, diagonal_p_ptrs,
                    diagonal_periods, nullptr,
                    parameter_shard.rns_primes.data() + q_count,
                    parameter_shard.rns_modulus_constants.data() + q_count,
                    group_count, term_count, tile_count, dnum, storage_dnum,
                    p_count, degree, degree_power, initialize_accumulators);
            }
            else
            {
                fused_baby_keyswitch_plain_accumulate_kernel<kTile, true, kCompressed>
                <<<q_grid, block_size, 0, gpu_execution_stream()>>>(
                    group_q, digits_q, source_q0, source_q1, arguments,
                    key_q0_ptrs, key_q1_ptrs, diagonal_q_ptrs,
                    diagonal_periods, parameter_shard.hybrid_p_mod_q.data(),
                    parameter_shard.rns_primes.data(),
                    parameter_shard.rns_modulus_constants.data(),
                    group_count, term_count, tile_count, dnum, storage_dnum,
                    q_count, degree, degree_power, initialize_accumulators);
                fused_baby_keyswitch_plain_accumulate_kernel<kTile, false, kCompressed>
                <<<p_grid, block_size, 0, gpu_execution_stream()>>>(
                    group_p, digits_p, nullptr, nullptr, arguments,
                    key_p0_ptrs, key_p1_ptrs, diagonal_p_ptrs,
                    diagonal_periods, nullptr,
                    parameter_shard.rns_primes.data() + q_count,
                    parameter_shard.rns_modulus_constants.data() + q_count,
                    group_count, term_count, tile_count, dnum, storage_dnum,
                    p_count, degree, degree_power, initialize_accumulators);
            }
        };
        if (group_count == 1)
        {
            launch_for_tile(std::integral_constant<int, 1>{});
        }
        else if (group_count <= 4)
        {
            if (shared_baby_mode >= 2 && tile_count <= 8 && (degree % 64) == 0 && degree >= 64)
            {
                launch_shared(
                    std::integral_constant<int, 4>{},
                    std::integral_constant<int, 2>{});
            }
            else
            {
                launch_for_tile(std::integral_constant<int, 4>{});
            }
        }
        else
        {
            if (shared_baby_mode >= 1 && tile_count <= 8 && (degree % 32) == 0 && degree >= 32)
            {
                launch_shared(
                    std::integral_constant<int, 8>{},
                    std::integral_constant<int, 1>{});
            }
            else
            {
                launch_for_tile(std::integral_constant<int, 8>{});
            }
        }
        gpu_check_cuda(cudaGetLastError(), name);
    };
    if (compressed_plaintexts)
    {
        launch_for_layout(std::true_type{});
    }
    else
    {
        launch_for_layout(std::false_type{});
    }
}

}  // namespace kernel
}  // namespace gpu
}  // namespace poseidon
