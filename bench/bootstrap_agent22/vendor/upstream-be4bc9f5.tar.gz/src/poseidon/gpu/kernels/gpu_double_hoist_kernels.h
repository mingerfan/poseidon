#pragma once

#include "poseidon/gpu/gpu_memory.h"
#include "poseidon/gpu/gpu_parameter.h"

#include <cstddef>
#include <cstdint>

namespace poseidon
{
namespace gpu
{
namespace kernel
{

// The largest baby-step batch carried by the fused KeySwitch/plaintext-MAC
// launch. Keep this shared with the host-side argument packing so a complete
// 15-diagonal direct stage can be issued as one Q launch and one P launch.
inline constexpr std::size_t kMaxDoubleHoistFusedBabySteps = 16;
inline constexpr std::size_t kMaxDoubleHoistFusedBabyGroups = 8;
inline constexpr std::size_t kMaxHoistedKeymulBatchDigits = 4;

struct HoistedKeymulBatchArgs
{
    const GpuWord *key0[kMaxDoubleHoistFusedBabySteps * kMaxHoistedKeymulBatchDigits];
    const GpuWord *key1[kMaxDoubleHoistFusedBabySteps * kMaxHoistedKeymulBatchDigits];
    std::uint32_t galois_elts[kMaxDoubleHoistFusedBabySteps];
};

void launch_double_hoist_hoisted_keymul_batch(
    GpuWord *destination_q_batch,
    GpuWord *destination_p_batch,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const HoistedKeymulBatchArgs &q_args,
    const HoistedKeymulBatchArgs &p_args,
    std::size_t batch_count,
    std::size_t dnum,
    bool key_pre_rotated,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_double_hoist_hoisted_keymul_sum(
    GpuWord *destination_q0,
    GpuWord *destination_p0,
    GpuWord *destination_q1,
    GpuWord *destination_p1,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *source_q0,
    const HoistedKeymulBatchArgs &q_args,
    const HoistedKeymulBatchArgs &p_args,
    std::size_t batch_count,
    std::size_t dnum,
    bool key_pre_rotated,
    bool initialize,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_double_hoist_pre_rotated_keymul_digit(
    GpuWord *destination_q0,
    GpuWord *destination_p0,
    GpuWord *destination_q1,
    GpuWord *destination_p1,
    const GpuWord *digit_q,
    const GpuWord *digit_p,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::uint32_t galois_elt,
    bool overwrite,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_double_hoist_pre_rotated_keymul_batch(
    GpuWord *destination_q0,
    GpuWord *destination_p0,
    GpuWord *destination_q1,
    GpuWord *destination_p1,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t dnum,
    std::uint32_t galois_elt,
    bool overwrite,
    const GpuWord *lifted_c0_source_q,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_double_hoist_lift_identity(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool accumulate);

void launch_double_hoist_add_lifted_galois_c0(
    GpuWord *destination_q0,
    const GpuWord *source_q0,
    std::uint32_t galois_elt,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * Fuse all non-identity giant rotations into one Q launch and one P launch.
 * The grid spans group x limb x coefficient and writes the existing group QP
 * workspace. Reduction is deliberately deferred to the fused outer ModDown.
 */
void launch_double_hoist_pre_rotated_giant_group_reduce(
    GpuWord *scratch_group_q,
    GpuWord *scratch_group_p,
    const GpuWord *inner_q_batch,
    const GpuWord *const *host_group_digit_q_ptrs,
    const GpuWord *const *host_group_digit_p_ptrs,
    const std::uint32_t *host_group_indices,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * Produce one QP accumulator for all giant groups. Each thread owns one
 * (limb, coefficient) output, walks the non-identity groups in registers,
 * folds in the identity group, and performs a single global store per
 * ciphertext component. This avoids materializing one QP ciphertext per
 * giant group before the shared outer ModDown.
 */
void launch_double_hoist_pre_rotated_giant_group_accumulate(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *inner_q_batch,
    std::size_t identity_group_index,
    const GpuWord *const *host_group_digit_q_ptrs,
    const GpuWord *const *host_group_digit_p_ptrs,
    const std::uint32_t *host_group_indices,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

#ifdef __CUDACC__
__host__ __device__ __forceinline__
#else
inline
#endif
std::size_t compressed_diagonal_compact_index(
    std::uint32_t reversed,
    std::size_t period,
    unsigned int degree_power)
{
    if (period <= static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max()))
    {
        const std::uint32_t period32 = static_cast<std::uint32_t>(period);
        const std::uint32_t raw = reversed & (period32 - 1u);
        if (degree_power <= 5u)
        {
            return raw;
        }
        const unsigned int prefix_bits = degree_power - 5u;
        const std::uint32_t lane_span = period32 >> prefix_bits;
        if (lane_span <= 1u)
        {
            return raw;
        }
        const std::uint32_t prefix_mask = (1u << prefix_bits) - 1u;
        return ((raw & prefix_mask) * lane_span) | (raw >> prefix_bits);
    }
    const std::size_t raw = static_cast<std::size_t>(reversed) & (period - 1);
    if (degree_power <= 5)
    {
        return raw;
    }
    const unsigned int prefix_bits = degree_power - 5;
    const std::size_t lane_span = period >> prefix_bits;
    if (lane_span <= 1)
    {
        return raw;
    }
    const std::size_t prefix_mask = (std::size_t{1} << prefix_bits) - 1;
    return ((raw & prefix_mask) * lane_span) | (raw >> prefix_bits);
}

/**
 * Like launch_double_hoist_pre_rotated_giant_group_accumulate, but c0 of each
 * giant group and the identity group are read from the QP group accumulators
 * (group_q / group_p, [group][component] layout), so only c1 of the
 * non-identity groups needs the inner ModDown.
 */
void launch_double_hoist_pre_rotated_giant_group_accumulate_qp_c0(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *group_q,
    const GpuWord *group_p,
    std::size_t identity_group_index,
    const GpuWord *const *host_group_digit_q_ptrs,
    const GpuWord *const *host_group_digit_p_ptrs,
    const std::uint32_t *host_group_indices,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    std::size_t active_group_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuWord *inner_q_c1_batch = nullptr,
    std::size_t self_digit_p_count = 0);

void launch_double_hoist_reduce_p_groups(
    GpuWord *destination_p0,
    GpuWord *destination_p1,
    const GpuWord *group_p,
    std::size_t group_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_double_hoist_qp_plain_mul_accumulate_groups(
    GpuWord *group_q,
    GpuWord *group_p,
    const GpuWord *baby_q,
    const GpuWord *baby_p,
    const GpuWord *const *diagonal_q_ptrs,
    const GpuWord *const *diagonal_p_ptrs,
    const std::uint32_t *diagonal_periods,
    const std::uint32_t *term_baby_indices,
    const std::uint32_t *group_term_offsets,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t tile_begin,
    std::size_t tile_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool compressed_plaintexts,
    bool initialize_accumulators);

/**
 * Fuse inverse-pre-rotated baby KeySwitch with QP plaintext MAC. One thread
 * computes a baby result in registers, applies every giant-group diagonal
 * that consumes it, and writes only the final group accumulators.
 */
void launch_double_hoist_fused_baby_keyswitch_plain_accumulate(
    GpuWord *group_q,
    GpuWord *group_p,
    const GpuWord *digits_q,
    const GpuWord *digits_p,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const std::uint32_t *host_galois_elts,
    const std::uint32_t *host_key_indices,
    const std::uint32_t *host_term_indices,
    const GpuWord *const *key_q0_ptrs,
    const GpuWord *const *key_p0_ptrs,
    const GpuWord *const *key_q1_ptrs,
    const GpuWord *const *key_p1_ptrs,
    const GpuWord *const *diagonal_q_ptrs,
    const GpuWord *const *diagonal_p_ptrs,
    const std::uint32_t *diagonal_periods,
    std::size_t group_count,
    std::size_t term_count,
    std::size_t tile_count,
    std::size_t dnum,
    std::size_t storage_dnum,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool compressed_plaintexts,
    bool initialize_accumulators);

}  // namespace kernel
}  // namespace gpu
}  // namespace poseidon
