#pragma once
#include "poseidon/gpu/gpu_memory.h"

namespace poseidon::gpu::kernel {
enum class EvalModPairOp { Copy, SubtractPlain, Add, Subtract, Multiply, MultiplyPlain, Leaf,
                          Square, DoubleAddPlain, DoubleSubtractPlain, DoubleSubtract, Combine };

// Two independent ciphertexts with the same Q prefix. Pointers name each
// component explicitly; shortening Q never changes the physical c1/c2 stride.
struct EvalModPairArgs {
    GpuWord *out[2][3]{};
    const GpuWord *left[2][3]{};
    const GpuWord *right[2][3]{};
    const GpuWord *terms[4][2][2]{};
    const GpuWord *plain[4]{};
    const GpuWord *constant = nullptr;
    const GpuWord *moduli = nullptr;
    const GpuWide *ratios = nullptr;
    unsigned degree = 0, limbs = 0;
    unsigned left_components = 0, right_components = 0, components = 0, term_count = 0;
};
void launch_evalmod_pair(EvalModPairOp op, const EvalModPairArgs &args, int device);
void launch_evalmod_single(EvalModPairOp op, const EvalModPairArgs &args, int device);

enum class ComponentwiseOp { Subtract, Negate, Scalar, AddPlain, SubtractPlain };
struct ComponentwiseArgs {
    GpuWord *out[3]{};
    const GpuWord *left[3]{}, *right[3]{};
    const GpuWord *plain=nullptr, *moduli=nullptr;
    const GpuWide *ratios=nullptr;
    GpuWide scalar=0;
    unsigned coefficients=0,limbs=0,components=0;
};
void launch_componentwise(ComponentwiseOp op,const ComponentwiseArgs &args,int device);
// Used by offline graph inspection to verify that the optional path ran.
bool is_componentwise_kernel(const void *function);
} // namespace poseidon::gpu::kernel
