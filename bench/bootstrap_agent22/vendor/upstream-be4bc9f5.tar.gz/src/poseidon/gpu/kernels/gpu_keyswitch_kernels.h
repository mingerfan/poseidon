#pragma once

#include "poseidon/gpu/gpu_memory.h"
#include "poseidon/gpu/gpu_parameter.h"
#include "poseidon/gpu/gpu_rns_poly.h"

#include <cstddef>
#include <cstdint>

namespace poseidon
{
namespace gpu
{
namespace kernel
{

// Pair experiment: [batch=2][limb][N] inputs/ModUp, and
// [output_component=2][batch=2][limb][N] ModDown buffers. No hidden workspace.
void validate_hybrid_relinearize_pair_parameters(
    const GpuParameterShard &parameters, std::size_t degree);

void launch_hybrid_modup_decomposition_pair(
    GpuWord *modup_q, GpuWord *modup_p, GpuWord *weighted,
    const GpuWord *c2_coeff, std::size_t digit, std::size_t limb_begin,
    std::size_t limb_count, const GpuParameterShard &parameters,
    std::size_t degree, bool source_preweighted = false);

void launch_hybrid_modup_decomposition_batch(
    GpuWord *modup_q, GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t digit, std::size_t limb_begin, std::size_t limb_count,
    std::size_t batch_count,
    std::size_t source_batch_stride,
    std::size_t modup_q_batch_stride,
    std::size_t modup_p_batch_stride,
    const GpuParameterShard &parameters,
    std::size_t degree,
    bool source_preweighted = false);

void launch_copy_strided_q_limbs_batch(
    GpuWord *destination,
    const GpuWord *source,
    std::size_t limb_count,
    std::size_t degree,
    std::size_t batch_count,
    std::size_t destination_batch_stride,
    std::size_t source_batch_stride,
    int device_id);

void launch_hybrid_convert_p_to_q_preweighted_batch4(
    GpuWord *converted_q, const GpuWord *weighted_p,
    const GpuParameterShard &parameters, std::size_t degree);

void launch_hybrid_relinearize_pair_addback(
    GpuWord *destination00, GpuWord *destination01,
    GpuWord *destination10, GpuWord *destination11,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *accum_q, const GpuWord *converted_q,
    const GpuParameterShard &parameters, std::size_t degree);

// Joint single-ciphertext ModDown + post-op (0..5) + 1/2-prime rescale tail.
void launch_hybrid_relin_rescale_single_tail(
    GpuWord *tail_ntt,
    const GpuWord *accum_q0, const GpuWord *accum_q1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *plain,
    const GpuWord *extra0, const GpuWord *extra1,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &parameters, std::size_t degree);

// Joint paired ModDown + post-op (0=addback, 1=2x+plain, 2=2x-plain, 3=2x-cipher) + 1/2-prime rescale.
void launch_hybrid_relin_rescale_pair_tail(
    GpuWord *tail_ntt,
    const GpuWord *accum_q,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *plain,
    const GpuWord *extra00, const GpuWord *extra01,
    const GpuWord *extra10, const GpuWord *extra11,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &parameters, std::size_t degree);

void launch_hybrid_relin_rescale_pair_merge_correction(
    GpuWord *merged_coeff,
    const GpuWord *converted_coeff,
    const GpuWord *tail_coeff,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &parameters, std::size_t degree);

void launch_hybrid_relin_rescale_pair_apply(
    GpuWord *destination00, GpuWord *destination01,
    GpuWord *destination10, GpuWord *destination11,
    const GpuWord *accum_q,
    const GpuWord *source00, const GpuWord *source01,
    const GpuWord *source10, const GpuWord *source11,
    const GpuWord *plain,
    const GpuWord *extra00, const GpuWord *extra01,
    const GpuWord *extra10, const GpuWord *extra11,
    const GpuWord *correction_ntt,
    std::uint32_t drop_count, int post_op,
    const GpuParameterShard &parameters, std::size_t degree);

void launch_hybrid_modup_decomposition(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    const GpuWord *c2_ntt,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false);

void launch_hybrid_modup_decomposition_forward_ntt_first_stage(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_modup_decomposition_row_tiled8(
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * Materialize only the source digit after multiplication by the punctured-Q
 * inverse. The compact [decomp_limb_count, degree] buffer is consumed by the
 * split P=9 ModUp/Four-step phase1 path and is substantially smaller than a
 * full active-QP ModUp result.
 */
void launch_hybrid_preweight_modup_source_p9(
    GpuWord *weighted_source,
    const GpuWord *c2_coeff,
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * Forward NTT only the Q limbs outside the decomposition block and all P
 * limbs. Q limbs inside the block are already copied from the NTT source.
 */
void launch_hybrid_forward_ntt_qp_active(
    GpuWord *modup_q,
    GpuWord *modup_p,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_forward_ntt_qp_mul_accumulate_two_components(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    GpuWord *modup_q,
    GpuWord *modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool overwrite_accum,
    bool fuse_decomp_q,
    bool skip_first_ntt_stage);

void launch_hybrid_multiply_accumulate(
    GpuWord *accum_q,
    GpuWord *accum_p,
    const GpuWord *modup_q,
    const GpuWord *modup_p,
    const GpuWord *key_qp,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_multiply_accumulate_two_components(
    GpuWord *accum_q0,
    GpuWord *accum_p0,
    GpuWord *accum_q1,
    GpuWord *accum_p1,
    const GpuWord *modup_q,
    const GpuWord *modup_p,
    const GpuWord *c2_ntt,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    bool overwrite_accum);

void launch_hybrid_moddown(
    GpuWord *accum_q,
    const GpuWord *accum_p,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_convert_p_to_q(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

// POSEIDON_OPT_C1_NOPAD: one weighted P part (generic P > 9, N = 65536) to Q
// in NTT form. Returns false (nothing launched) when it does not apply.
bool launch_hybrid_convert_p_to_q_forward_ntt_single_preweighted(
    GpuWord *converted_q,
    const GpuWord *accum_p,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_convert_p_to_q_forward_ntt(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false);

// POSEIDON_OPT_MODUP_FOLD: inverse-degree table whose Q entries also carry the
// ModUp input weights; nullptr when the shard has no hybrid decomposition.
const GpuWord *hybrid_q_preweighted_inv_degree_table(
    const GpuParameterShard &parameter_shard);
// True when MODUP_FOLD and the preweighted ModUp path it relies on are on.
bool modup_fold_applicable(std::size_t degree);

// POSEIDON_OPT_PTOQ_PW: inverse-degree table whose P entries also carry the
// P->Q input weights; nullptr when the shard has no hybrid P basis.
const GpuWord *hybrid_p_preweighted_inv_degree_table(
    const GpuParameterShard &parameter_shard);

void launch_hybrid_preweight_p_two_components(
    GpuWord *accum_p0,
    GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *accum_p0,
    const GpuWord *accum_p1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false);

void launch_hybrid_forward_ntt_q_two_components(
    GpuWord *values0,
    GpuWord *values1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt(
    GpuWord *accum_q0,
    GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt_out_of_place(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt_out_of_place_batch(
    GpuWord *destination_q,
    const GpuWord *source_q,
    const GpuWord *converted_q,
    std::size_t batch_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

/**
 * P->Q basis conversion of both components into coefficient form (lazy
 * 96-bit accumulation, any P); the caller runs the Q forward NTT.
 */
void launch_hybrid_convert_p_to_q_coeff_lazy(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    const GpuWord *p_coeff0,
    const GpuWord *p_coeff1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false);

/** Most components launch_hybrid_apply_moddown_ntt_selected accepts. */
inline constexpr std::size_t kMaxSelectedModDownComponents = 64;

/**
 * ModDown apply (source - converted) * P^{-1} for scattered components:
 * converted slot k is component component_indices[k] of source/destination
 * (consecutive Q components of hybrid_base_q_count * degree words).
 */
void launch_hybrid_apply_moddown_ntt_selected(
    GpuWord *destination_q,
    const GpuWord *source_q,
    const GpuWord *converted_q,
    const std::uint32_t *component_indices,
    std::size_t component_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt_from_q_groups(
    GpuWord *destination_q0,
    GpuWord *destination_q1,
    const GpuWord *group_q,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    std::size_t group_count,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt_add_back(
    const GpuPolyShardView &destination_shard0,
    const GpuPolyShardView &destination_shard1,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuConstPolyShardView *add_source_shard0 = nullptr,
    const GpuConstPolyShardView *add_source_shard1 = nullptr);

void launch_hybrid_apply_moddown_ntt_c2s_split(
    const GpuPolyShardView &real_shard0,
    const GpuPolyShardView &real_shard1,
    const GpuPolyShardView &imag_shard0,
    const GpuPolyShardView &imag_shard1,
    const GpuConstPolyShardView &dft_shard0,
    const GpuConstPolyShardView &dft_shard1,
    const GpuConstPolyShardView &minus_i_plain_shard,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt_add_back_rescale_x2(
    const GpuPolyShardView &destination_shard0,
    const GpuPolyShardView &destination_shard1,
    const GpuConstPolyShardView &correction_ntt_shard0,
    const GpuConstPolyShardView &correction_ntt_shard1,
    const GpuWord *accum_q0,
    const GpuWord *accum_q1,
    const GpuWord *converted_q0,
    const GpuWord *converted_q1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    const GpuConstPolyShardView *add_source_shard0 = nullptr,
    const GpuConstPolyShardView *add_source_shard1 = nullptr);

// Joint ModDown/rescale: preserve the old centered two-prime remainder,
// but transform (P^-1 * R + remainder) only once on retained Q limbs.
void launch_hybrid_relin_rescale_x2_tail(
    GpuWord *tail0, GpuWord *tail1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuParameterShard &parameters, std::size_t degree);
void launch_hybrid_relin_rescale_x2_merge_correction(
    GpuWord *converted0, GpuWord *converted1,
    const GpuWord *tail_coeff0, const GpuWord *tail_coeff1,
    const GpuParameterShard &parameters, std::size_t degree);
void launch_hybrid_relin_rescale_x2_apply(
    GpuWord *out0, GpuWord *out1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *correction0, const GpuWord *correction1,
    const GpuParameterShard &parameters, std::size_t degree);

// Joint ModDown + single-prime rescale (with optional 2x ModDown scaling for Chebyshev 2*relin(prod)-corr).
void launch_hybrid_relin_rescale_x1_tail(
    GpuWord *tail0, GpuWord *tail1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuParameterShard &parameters, std::size_t degree,
    bool double_moddown = false);
void launch_hybrid_relin_rescale_x1_merge_correction(
    GpuWord *converted0, GpuWord *converted1,
    const GpuWord *tail_coeff0, const GpuWord *tail_coeff1,
    const GpuParameterShard &parameters, std::size_t degree,
    bool double_moddown = false);
void launch_hybrid_relin_rescale_x1_apply(
    GpuWord *out0, GpuWord *out1,
    const GpuWord *accum0, const GpuWord *accum1,
    const GpuWord *source0, const GpuWord *source1,
    const GpuWord *correction0, const GpuWord *correction1,
    const GpuParameterShard &parameters, std::size_t degree,
    bool double_moddown = false);

void launch_apply_galois_ntt_poly_shard(
    const GpuPolyShardView &destination_shard,
    const GpuConstPolyShardView &source_shard,
    std::uint32_t galois_elt,
    std::size_t degree);

inline constexpr std::size_t kMaxBatchKeySwitchItems = 16;

struct BatchMutPolyPtrs32
{
    GpuWord *ptrs[32];
};

struct BatchRotateDnum1Args
{
    GpuWord *dst_c0[kMaxBatchKeySwitchItems];
    GpuWord *dst_c1[kMaxBatchKeySwitchItems];
    const GpuWord *src_c0[kMaxBatchKeySwitchItems];
    const GpuWord *src_c1[kMaxBatchKeySwitchItems];
    const GpuWord *add_c0[kMaxBatchKeySwitchItems];
    const GpuWord *add_c1[kMaxBatchKeySwitchItems];
    const GpuWord *key_q0[kMaxBatchKeySwitchItems];
    const GpuWord *key_p0[kMaxBatchKeySwitchItems];
    const GpuWord *key_q1[kMaxBatchKeySwitchItems];
    const GpuWord *key_p1[kMaxBatchKeySwitchItems];
    std::uint32_t galois_elts[kMaxBatchKeySwitchItems];
};

void launch_hybrid_convert_p_to_q_preweighted_batch(
    GpuWord *converted_q,
    const GpuWord *weighted_p,
    std::size_t component_count,
    const GpuParameterShard &parameters,
    std::size_t degree);

void launch_hybrid_apply_moddown_ntt_multi_destinations(
    const BatchMutPolyPtrs32 &destinations,
    const GpuWord *source_q_base,
    std::size_t source_component_offset,
    const GpuWord *converted_q,
    std::size_t component_count,
    const GpuParameterShard &parameters,
    std::size_t degree);

void launch_batch_apply_galois_ntt_65536(
    GpuWord *permuted_batch,
    const BatchRotateDnum1Args &args,
    std::size_t batch_count,
    std::size_t limb_count,
    int device_id);

void launch_hybrid_modup_p_only_preweighted_batch_65536(
    GpuWord *modup_p_batch,
    const GpuWord *c1_coeff_batch,
    std::size_t batch_count,
    const GpuParameterShard &parameters);

void launch_batch_dnum1_keymul_shared_key_65536(
    GpuWord *accum_q_batch,
    GpuWord *accum_p_batch,
    const GpuWord *permuted_c1_batch,
    const GpuWord *modup_p_batch,
    const GpuWord *key_q0,
    const GpuWord *key_p0,
    const GpuWord *key_q1,
    const GpuWord *key_p1,
    std::size_t batch_count,
    const GpuParameterShard &parameters);

void launch_batch_dnum1_keymul_distinct_keys_65536(
    GpuWord *accum_q_batch,
    GpuWord *accum_p_batch,
    const GpuWord *permuted_c1_batch,
    const GpuWord *modup_p_batch,
    const BatchRotateDnum1Args &args,
    std::size_t batch_count,
    const GpuParameterShard &parameters);

void launch_batch_dnum1_keymul_sum_lazy_moddown_65536(
    GpuWord *accum_q_two,
    GpuWord *accum_p_two,
    const GpuWord *permuted_c1_batch,
    const GpuWord *modup_p_batch,
    const BatchRotateDnum1Args &args,
    std::size_t batch_count,
    const GpuParameterShard &parameters);

void launch_batch_dnum1_apply_moddown_65536(
    const BatchRotateDnum1Args &args,
    const GpuWord *accum_q_batch,
    const GpuWord *converted_q_batch,
    std::size_t batch_count,
    bool has_add_sources,
    const GpuParameterShard &parameters);

void launch_batch_dnum1_apply_moddown_sum_65536(
    GpuWord *dst_c0,
    GpuWord *dst_c1,
    const GpuWord *identity_c0,
    const GpuWord *identity_c1,
    const BatchRotateDnum1Args &args,
    const GpuWord *accum_q_two,
    const GpuWord *converted_q_two,
    std::size_t batch_count,
    const GpuParameterShard &parameters);

}  // namespace kernel
}  // namespace gpu
}  // namespace poseidon
