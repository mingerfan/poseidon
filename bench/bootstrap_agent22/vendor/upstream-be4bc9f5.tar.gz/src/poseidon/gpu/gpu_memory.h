#pragma once

#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>

#include <cuda_runtime_api.h>
#include <rmm/cuda_stream_view.hpp>
#include <rmm/mr/device/device_memory_resource.hpp>
#include <rmm/mr/device/per_device_resource.hpp>

namespace poseidon
{
namespace gpu
{

/**
 * @brief GPU residue word type.
 *
 * The GPU backend targets small RNS primes below 32 bits.
 * Therefore GPU-side ciphertext/plaintext/key residues are stored as uint32_t.
 *
 * Multiplication kernels may still use uint64_t as intermediate type.
 */
using GpuWord = std::uint32_t;
using GpuWide = std::uint64_t;

inline void gpu_check_cuda(cudaError_t status, const char *what)
{
    if (status != cudaSuccess)
    {
        throw std::runtime_error(
            std::string(what) + ": " + cudaGetErrorString(status));
    }
}

inline constexpr int kMaxExecutionOverrideDevices = 8;
inline thread_local cudaStream_t execution_stream_override = nullptr;
inline thread_local cudaStream_t
    execution_stream_override_by_device[kMaxExecutionOverrideDevices] = {};
inline void set_device_execution_stream_override(int device_id, cudaStream_t stream) noexcept
{
    if (device_id >= 0 && device_id < kMaxExecutionOverrideDevices)
    {
        execution_stream_override_by_device[device_id] = stream;
    }
}
inline cudaStream_t gpu_execution_stream() noexcept
{
    if (execution_stream_override)
    {
        return execution_stream_override;
    }
    int dev = 0;
    if (cudaGetDevice(&dev) == cudaSuccess &&
        dev >= 0 && dev < kMaxExecutionOverrideDevices &&
        execution_stream_override_by_device[dev] != nullptr)
    {
        return execution_stream_override_by_device[dev];
    }
    return cudaStreamPerThread;
}
class ScopedGpuExecutionStream {
public:
    explicit ScopedGpuExecutionStream(cudaStream_t stream) : previous_(execution_stream_override) {execution_stream_override=stream;}
    ~ScopedGpuExecutionStream() {execution_stream_override=previous_;}
    ScopedGpuExecutionStream(const ScopedGpuExecutionStream &)=delete;
    ScopedGpuExecutionStream &operator=(const ScopedGpuExecutionStream &)=delete;
private:
    cudaStream_t previous_;
};

// Allocation overrides are thread-local and per-device: GPU Prepare may
// allocate on another thread while a multi-GPU graph scopes separate private
// pools for device 0 and device 1 on the capturing host thread.
inline thread_local rmm::mr::device_memory_resource *
    execution_resource_override_by_device[kMaxExecutionOverrideDevices] = {};
class ScopedGpuMemoryResource {
public:
    explicit ScopedGpuMemoryResource(rmm::mr::device_memory_resource *resource, int device_id = 0)
        : device_id_(device_id),
          previous_((device_id >= 0 && device_id < kMaxExecutionOverrideDevices)
                        ? execution_resource_override_by_device[device_id]
                        : nullptr)
    {
        if (device_id_ >= 0 && device_id_ < kMaxExecutionOverrideDevices)
        {
            execution_resource_override_by_device[device_id_] = resource;
        }
    }
    ~ScopedGpuMemoryResource()
    {
        if (device_id_ >= 0 && device_id_ < kMaxExecutionOverrideDevices)
        {
            execution_resource_override_by_device[device_id_] = previous_;
        }
    }
    ScopedGpuMemoryResource(const ScopedGpuMemoryResource &) = delete;
    ScopedGpuMemoryResource &operator=(const ScopedGpuMemoryResource &) = delete;
private:
    int device_id_ = 0;
    rmm::mr::device_memory_resource *previous_ = nullptr;
};

std::shared_ptr<void> device_memory_resource_owner(
    rmm::mr::device_memory_resource *resource);
void register_device_memory_resource_owner(
    rmm::mr::device_memory_resource *resource,
    const std::shared_ptr<void> &owner);
void unregister_device_memory_resource_owner(
    rmm::mr::device_memory_resource *resource, const void *owner) noexcept;

/**
 * @brief Lightweight GPU memory owner.
 *
 * This class is intended to own one contiguous device buffer on one GPU.
 *
 * Memory is allocated through RAPIDS Memory Manager (RMM). The process should
 * install/configure the desired RMM device resource once during GPU backend
 * initialization. DeviceVector intentionally uses the current device resource
 * instead of constructing a pool locally.
 */
template <typename T>
class DeviceVector
{
public:
    DeviceVector() = default;

    DeviceVector(std::size_t size, int device_id)
    {
        allocate(size, device_id);
    }

    DeviceVector(const DeviceVector &) = delete;
    DeviceVector &operator=(const DeviceVector &) = delete;

    DeviceVector(DeviceVector &&other) noexcept
    {
        move_from(std::move(other));
    }

    DeviceVector &operator=(DeviceVector &&other) noexcept
    {
        if (this != &other)
        {
            try
            {
                release();
            }
            catch (...)
            {}
            move_from(std::move(other));
        }
        return *this;
    }

    ~DeviceVector()
    {
        try
        {
            release();
        }
        catch (...)
        {}
    }

    void allocate(std::size_t size, int device_id)
    {
        release();

        if (size != 0 && size > std::numeric_limits<std::size_t>::max() / sizeof(T))
        {
            throw std::overflow_error("DeviceVector allocation size overflow");
        }
        size_ = size;
        bytes_ = size * sizeof(T);
        device_id_ = device_id;

        if (size_ == 0)
        {
            return;
        }

        gpu_check_cuda(cudaSetDevice(device_id_), "cudaSetDevice");
        rmm::mr::device_memory_resource *override_res =
            (device_id_ >= 0 && device_id_ < kMaxExecutionOverrideDevices)
                ? execution_resource_override_by_device[device_id_]
                : nullptr;
        resource_ = override_res ? override_res
                                 : rmm::mr::get_current_device_resource();
        resource_owner_ = device_memory_resource_owner(resource_);
        ptr_ = static_cast<T *>(
            resource_->allocate(
                bytes_, rmm::cuda_stream_view{gpu_execution_stream()}));
    }

    void copy_from_host(const T *src, std::size_t count)
    {
        if (count > size_)
        {
            throw std::out_of_range("DeviceVector::copy_from_host count exceeds allocation");
        }
        if (count != 0 && src == nullptr)
        {
            throw std::invalid_argument("DeviceVector::copy_from_host source is null");
        }
        if (count == 0)
        {
            return;
        }

        gpu_check_cuda(cudaSetDevice(device_id_), "cudaSetDevice");
        gpu_check_cuda(
            cudaMemcpyAsync(ptr_, src, count * sizeof(T), cudaMemcpyHostToDevice,
                            gpu_execution_stream()),
            "cudaMemcpyAsync HostToDevice");
        gpu_check_cuda(
            cudaStreamSynchronize(gpu_execution_stream()),
            "cudaStreamSynchronize HostToDevice");
    }

    void copy_to_host(T *dst, std::size_t count) const
    {
        if (count > size_)
        {
            throw std::out_of_range("DeviceVector::copy_to_host count exceeds allocation");
        }
        if (count != 0 && dst == nullptr)
        {
            throw std::invalid_argument("DeviceVector::copy_to_host destination is null");
        }
        if (count == 0)
        {
            return;
        }

        gpu_check_cuda(cudaSetDevice(device_id_), "cudaSetDevice");
        gpu_check_cuda(
            cudaMemcpyAsync(dst, ptr_, count * sizeof(T), cudaMemcpyDeviceToHost,
                            gpu_execution_stream()),
            "cudaMemcpyAsync DeviceToHost");
        gpu_check_cuda(
            cudaStreamSynchronize(gpu_execution_stream()),
            "cudaStreamSynchronize DeviceToHost");
    }

    void fill_zero()
    {
        if (size_ == 0)
        {
            return;
        }

        gpu_check_cuda(cudaSetDevice(device_id_), "cudaSetDevice");
        gpu_check_cuda(
            cudaMemsetAsync(ptr_, 0, bytes_, gpu_execution_stream()),
            "cudaMemsetAsync");
    }

    void release()
    {
        if (ptr_ != nullptr)
        {
            gpu_check_cuda(cudaSetDevice(device_id_), "cudaSetDevice");
            resource_->deallocate(
                ptr_, bytes_, rmm::cuda_stream_view{gpu_execution_stream()});
        }
        ptr_ = nullptr;
        size_ = 0;
        bytes_ = 0;
        device_id_ = 0;
        resource_ = nullptr;
        resource_owner_.reset();
    }

    T *data()
    {
        return ptr_;
    }

    const T *data() const
    {
        return ptr_;
    }

    std::size_t size() const
    {
        return size_;
    }

    // A failed allocate may have recorded its requested size without obtaining
    // storage. Only live storage contributes to an allocator's byte counter.
    std::size_t allocated_bytes(
        const rmm::mr::device_memory_resource *resource = nullptr) const
    {
        return ptr_ != nullptr && (resource == nullptr || resource_ == resource)
                   ? bytes_ : 0;
    }

    bool empty() const
    {
        return size_ == 0;
    }

    int device_id() const
    {
        return device_id_;
    }

private:
    void move_from(DeviceVector &&other) noexcept
    {
        ptr_ = other.ptr_;
        size_ = other.size_;
        bytes_ = other.bytes_;
        device_id_ = other.device_id_;
        resource_ = other.resource_;
        resource_owner_ = std::move(other.resource_owner_);

        other.ptr_ = nullptr;
        other.size_ = 0;
        other.bytes_ = 0;
        other.device_id_ = 0;
        other.resource_ = nullptr;
    }

private:
    T *ptr_ = nullptr;
    std::size_t size_ = 0;
    std::size_t bytes_ = 0;
    int device_id_ = 0;
    rmm::mr::device_memory_resource *resource_ = nullptr;
    std::shared_ptr<void> resource_owner_;
};

/**
 * @brief Physical GPU memory block.
 *
 * This object only knows:
 * - which GPU device it belongs to;
 * - how large the buffer is;
 * - where the device pointer is.
 *
 * It does not know FHE semantics such as c0/c1, RNS limb range,
 * coefficient range, plaintext/key layout, or parameter level.
 */
struct GpuFieldData
{
    int device_id = 0;
    DeviceVector<GpuWord> buffer;

    GpuFieldData() = default;

    GpuFieldData(int dev, std::size_t elem_count)
        : device_id(dev), buffer(elem_count, dev)
    {}

    GpuWord *data()
    {
        return buffer.data();
    }

    const GpuWord *data() const
    {
        return buffer.data();
    }

    std::size_t size() const
    {
        return buffer.size();
    }

    bool empty() const
    {
        return buffer.empty();
    }
};

}  // namespace gpu
}  // namespace poseidon
