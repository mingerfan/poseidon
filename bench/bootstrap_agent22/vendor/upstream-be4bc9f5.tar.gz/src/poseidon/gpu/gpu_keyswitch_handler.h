#pragma once

#include "poseidon/gpu/gpu_ciphertext.h"
#include "poseidon/gpu/gpu_double_hoist.h"
#include "poseidon/gpu/gpu_key.h"
#include "poseidon/gpu/gpu_parameter.h"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

namespace poseidon
{
namespace gpu
{

enum class PairRelinPostOp : int
{
    AddBackOnly = 0,       // relin_val
    DoubleAddPlain = 1,    // 2 * relin_val + (c == 0 ? plain : 0)
    DoubleSubPlain = 2,    // 2 * relin_val - (c == 0 ? plain : 0)
    DoubleSubCipher = 3,   // 2 * relin_val - extra_cipher
    DoubleModDownOnly = 4, // 2 * switched + src_val (src_val already pre-doubled/adjusted)
    DoubleSubCipherPlain = 5 // 2 * relin_val - extra_cipher * plain
};

/**
 * @brief GPU key-switching operations.
 *
 * Current scope:
 * - CKKS HYBRID key-switching framework;
 * - single-GPU, full-coefficient, q-only input ciphertexts;
 * - key layout lookup and operation validation.
 *
 * The arithmetic pipeline is intentionally split from GpuEvaluator so the
 * eventual HYBRID ModUp/key-multiply/ModDown kernels have one owner.
 */
class GpuKeySwitchHandler
{
public:
    explicit GpuKeySwitchHandler(const GpuParameterData &params);
    ~GpuKeySwitchHandler();

    std::size_t retained_workspace_bytes(
        const rmm::mr::device_memory_resource *resource = nullptr) const;

    GpuKeySwitchHandler(const GpuKeySwitchHandler &) = delete;
    GpuKeySwitchHandler &operator=(const GpuKeySwitchHandler &) = delete;

    void relinearize_hybrid_ciphertext(
        GpuCiphertextView &destination_view,
        const GpuConstCiphertextView &source_view,
        const GpuConstEvaluationKeyView &relin_keys_view,
        const GpuEvaluationKeyData &relin_keys_data,
        const GpuLevelInfo &level_info) const;

    // Experimental batch2 path, enabled only by POSEIDON_GPU_RELIN_PAIR=1.
    // False means no GPU work or output writes occurred. Supported inputs are
    // two q-only size3 NTT ciphertexts, same Q/P/key/device, N=65536, 1<=P<=64.
    // Destinations are disjoint size2 buffers; source-source alias is allowed.
    // Warm up every shape before capturing a CUDA Graph.
    bool try_relinearize_hybrid_ciphertext_pair(
        GpuCiphertextView &destination0,
        GpuCiphertextView &destination1,
        const GpuConstCiphertextView &source0,
        const GpuConstCiphertextView &source1,
        const GpuConstEvaluationKeyView &relin_keys_view,
        const GpuEvaluationKeyData &relin_keys_data,
        const GpuLevelInfo &level_info) const;

    bool try_relinearize_hybrid_ciphertext_rescale_pair(
        GpuCiphertextView &destination0,
        GpuCiphertextView &destination1,
        const GpuConstCiphertextView &source0,
        const GpuConstCiphertextView &source1,
        const GpuConstEvaluationKeyView &relin_keys_view,
        const GpuEvaluationKeyData &relin_keys_data,
        const GpuLevelInfo &source_level_info,
        const GpuLevelInfo &destination_level_info,
        std::uint32_t drop_count,
        PairRelinPostOp post_op,
        const GpuWord *plain_ptr = nullptr,
        const GpuConstCiphertextView *extra0 = nullptr,
        const GpuConstCiphertextView *extra1 = nullptr) const;

    bool try_relinearize_hybrid_ciphertext_rescale_postop(
        GpuCiphertextView &destination,
        const GpuConstCiphertextView &source,
        const GpuConstEvaluationKeyView &relin_keys_view,
        const GpuEvaluationKeyData &relin_keys_data,
        const GpuLevelInfo &source_level_info,
        const GpuLevelInfo &destination_level_info,
        std::uint32_t drop_count,
        PairRelinPostOp post_op,
        const GpuWord *plain_ptr = nullptr,
        const GpuConstCiphertextView *extra = nullptr) const;

    void relinearize_hybrid_ciphertext_rescale_x1(
        GpuCiphertextView &destination_view,
        const GpuConstCiphertextView &source_view,
        const GpuConstEvaluationKeyView &relin_keys_view,
        const GpuEvaluationKeyData &relin_keys_data,
        const GpuLevelInfo &source_level_info,
        const GpuLevelInfo &destination_level_info,
        bool double_moddown = false) const;

    void relinearize_hybrid_ciphertext_rescale_x2(
        GpuCiphertextView &destination_view,
        const GpuConstCiphertextView &source_view,
        const GpuConstEvaluationKeyView &relin_keys_view,
        const GpuEvaluationKeyData &relin_keys_data,
        const GpuLevelInfo &source_level_info,
        const GpuLevelInfo &destination_level_info) const;

    void switch_key_hybrid_ciphertext(
        GpuCiphertextView &destination_view,
        const GpuConstRNSPolyView &switch_poly_ntt,
        const GpuConstEvaluationKeyView &switch_keys_view,
        const GpuEvaluationKeyData &switch_keys_data,
        std::size_t key_index,
        const GpuLevelInfo &level_info,
        std::shared_ptr<void> *workspace = nullptr,
        const GpuConstRNSPolyView *add_source0 = nullptr) const;

    /**
     * Decompose one Q/NTT polynomial once and retain every HYBRID digit in
     * contiguous Q/P NTT buffers.
     */
    void hoist_decompose_modup_ntt(
        const GpuConstRNSPolyView &switch_poly_ntt,
        const GpuLevelInfo &level_info,
        GpuHoistedDecomposition &destination,
        GpuHybridKeySwitchWorkspace &workspace,
        const GpuWord *precomputed_source_intt_q = nullptr,
        bool precomputed_source_preweighted = false) const;

    void hoist_decompose_modup_ntt_batch(
        const GpuWord *source_ntt_batch,
        std::size_t source_ntt_batch_stride,
        const GpuWord *source_intt_batch,
        bool source_preweighted,
        std::size_t batch_count,
        const GpuLevelInfo &level_info,
        DeviceVector<GpuWord> &digits_q_ntt_batch,
        DeviceVector<GpuWord> &digits_p_ntt_batch,
        DeviceVector<GpuWord> &modup_q_batch,
        DeviceVector<GpuWord> &modup_p_batch,
        bool skip_self_q_copy = false) const;

    void keyswitch_hoisted_batch_no_moddown(
        const GpuHoistedDecomposition &hoisted,
        const GpuWord *source_q0,
        const GpuWord *source_q1,
        const std::uint32_t *galois_elts,
        const std::size_t *key_indices,
        std::size_t batch_count,
        const GpuConstEvaluationKeyView &keys,
        const GpuEvaluationKeyData &key_storage,
        GpuQPCiphertextBuffer &destination,
        std::size_t destination_batch_begin,
        const GpuLevelInfo &level_info) const;

    void keyswitch_hoisted_sum_no_moddown(
        const GpuHoistedDecomposition &hoisted,
        const GpuWord *source_q0,
        const std::uint32_t *galois_elts,
        const std::size_t *key_indices,
        std::size_t batch_count,
        const GpuConstEvaluationKeyView &keys,
        const GpuEvaluationKeyData &key_storage,
        GpuQPCiphertextBuffer &destination,
        std::size_t destination_batch,
        const GpuLevelInfo &level_info) const;

    /**
     * Standard-key staged path. The automorphism is applied to each already
     * hoisted digit, then all key products are accumulated in QP without a
     * ModDown. initialize=true overwrites the selected destination batch.
     */
    void keyswitch_multsum_no_moddown(
        const GpuHoistedDecomposition &hoisted,
        std::uint32_t galois_elt,
        const GpuConstEvaluationKeyView &keys,
        const GpuEvaluationKeyData &key_storage,
        std::size_t key_index,
        GpuQPCiphertextBuffer &destination,
        std::size_t destination_batch,
        bool initialize,
        const GpuLevelInfo &level_info,
        GpuHybridKeySwitchWorkspace &workspace,
        const GpuWord *lifted_c0_source_q = nullptr) const;

    /**
     * Apply HYBRID P->Q ModDown to one QP ciphertext batch. P INTT and its
     * conversion scratch are persistent in workspace.
     */
    void moddown_qp_ciphertext_to_q(
        GpuQPCiphertextBuffer &source,
        std::size_t source_batch,
        GpuCiphertextData &destination,
        const GpuCiphertextMeta &destination_meta,
        const GpuLevelInfo &level_info,
        GpuHybridKeySwitchWorkspace &workspace,
        const GpuCiphertextData *add_source = nullptr) const;

    void moddown_qp_ciphertext_to_q_c2s_split(
        GpuQPCiphertextBuffer &source,
        std::size_t source_batch,
        const GpuCiphertextData &dft_result,
        const GpuPlaintextData &minus_i_plaintext,
        GpuCiphertextData &result_real,
        GpuCiphertextData &result_imag,
        const GpuLevelInfo &level_info,
        GpuHybridKeySwitchWorkspace &workspace) const;

    bool try_moddown_qp_ciphertext_to_q_rescale(
        GpuQPCiphertextBuffer &source,
        std::size_t source_batch,
        GpuCiphertextData &destination,
        const GpuCiphertextMeta &product_meta,
        const GpuLevelInfo &source_level_info,
        const GpuLevelInfo &destination_level_info,
        std::uint32_t drop_count,
        GpuHybridKeySwitchWorkspace &workspace) const;

    void moddown_qp_ciphertext_list_to_q(
        GpuQPCiphertextBuffer &source,
        std::size_t batch_count,
        std::vector<GpuCiphertextData> &destinations,
        const GpuCiphertextMeta &destination_meta,
        const GpuLevelInfo &level_info,
        GpuHybridKeySwitchWorkspace &workspace,
        DeviceVector<GpuWord> &batch_p_coeff,
        DeviceVector<GpuWord> &batch_converted_q) const;

    bool try_rotate_dnum1_batch(
        const std::vector<GpuCiphertextView> &destinations,
        const std::vector<GpuConstCiphertextView> &sources,
        const std::vector<const GpuConstCiphertextView *> *add_sources,
        const std::vector<std::uint32_t> &galois_elts,
        const std::vector<std::size_t> &key_indices,
        bool shared_key,
        const GpuConstEvaluationKeyView &galois_keys_view,
        const GpuEvaluationKeyData &galois_keys_data,
        const GpuLevelInfo &level_info) const;

    bool try_rotate_dnum1_distinct_sum(
        GpuCiphertextView &destination,
        const GpuConstCiphertextView *identity_source,
        const std::vector<GpuConstCiphertextView> &sources,
        const std::vector<std::uint32_t> &galois_elts,
        const std::vector<std::size_t> &key_indices,
        const GpuConstEvaluationKeyView &galois_keys_view,
        const GpuEvaluationKeyData &galois_keys_data,
        const GpuLevelInfo &level_info) const;

    /**
     * Apply the same HYBRID P->Q ModDown to a contiguous group batch. The
     * P-side INTT/convert/Q-side NTT are issued over all 2*batch components,
     * so giant groups no longer serialize complete ModDown pipelines.
     */
    void moddown_qp_ciphertext_batch_to_q(
        GpuQPCiphertextBuffer &source,
        std::size_t batch_count,
        GpuQCiphertextBatchBuffer &destination,
        const GpuLevelInfo &level_info,
        DeviceVector<GpuWord> &p_coeff,
        DeviceVector<GpuWord> &converted_q) const;

    /**
     * ModDown only component 1 of the listed groups: destination
     * q_component(g, 1) = ModDown(source group g, component 1). Component 0
     * and unlisted groups of destination are left untouched. Used when the
     * giant-step c0 stays in QP (POSEIDON_DOUBLE_HOIST_QP_C0).
     */
    void moddown_qp_c1_groups_to_q(
        GpuQPCiphertextBuffer &source,
        const std::vector<std::uint32_t> &groups,
        std::size_t destination_batch_count,
        GpuQCiphertextBatchBuffer &destination,
        const GpuLevelInfo &level_info,
        DeviceVector<GpuWord> &p_coeff,
        DeviceVector<GpuWord> &converted_q) const;

    /**
     * Final double-hoist ModDown. Only P is reduced explicitly; Q group
     * reduction is fused with subtraction and multiplication by P^{-1}.
     */
    void moddown_qp_groups_to_q(
        GpuQPCiphertextBuffer &source_groups,
        std::size_t group_count,
        DeviceVector<GpuWord> &reduced_p_ntt,
        GpuCiphertextData &destination,
        const GpuCiphertextMeta &destination_meta,
        const GpuLevelInfo &level_info,
        GpuHybridKeySwitchWorkspace &workspace) const;

private:
    void switch_key_hybrid_ciphertext_impl(
        GpuCiphertextView &destination_view,
        const GpuConstRNSPolyView &switch_poly_ntt,
        const GpuConstEvaluationKeyView &switch_keys_view,
        const GpuEvaluationKeyData &switch_keys_data,
        std::size_t key_index,
        const GpuLevelInfo &level_info,
        const GpuConstRNSPolyView *add_source0,
        const GpuConstRNSPolyView *add_source1,
        const GpuLevelInfo *rescale_destination_level = nullptr,
        std::shared_ptr<void> *workspace = nullptr,
        bool double_moddown = false) const;

    struct PersistentWorkspace;

    const GpuParameterData &params_;
    mutable std::unique_ptr<PersistentWorkspace> persistent_workspace_;
};

}  // namespace gpu
}  // namespace poseidon
