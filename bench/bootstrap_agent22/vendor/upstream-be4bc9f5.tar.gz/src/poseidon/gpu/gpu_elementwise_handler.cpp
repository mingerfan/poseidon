#include "poseidon/gpu/gpu_elementwise_handler.h"
#include "poseidon/gpu/kernels/gpu_elementwise_kernels.h"
#include "poseidon/gpu/kernels/gpu_evalmod_pair_kernels.h"
#include "poseidon/gpu/gpu_opt_flags.h"

#include <algorithm>
#include <array>
#include <cstdlib>
#include <stdexcept>
#include <string>

namespace poseidon
{
namespace gpu
{
namespace
{

constexpr const char *kFusedCiphertextMultiplyEnv =
    "POSEIDON_ELEMENTWISE_FUSED_CT_MUL";

bool use_fused_ciphertext_multiply()
{
    const char *raw = std::getenv(kFusedCiphertextMultiplyEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

template <typename LeftShard, typename RightShard>
bool same_shard_placement(const LeftShard &left, const RightShard &right)
{
    return left.device_id == right.device_id &&
           left.limb_begin == right.limb_begin &&
           left.limb_count == right.limb_count &&
           left.coeff_begin == right.coeff_begin &&
           left.coeff_count == right.coeff_count;
}

const GpuParameterShard *find_parameter_shard(
    const GpuLevelInfo &level_info,
    const GpuPolyShardView &shard)
{
    for (const auto &candidate : level_info.shards)
    {
        const bool same_device = candidate.device_id == shard.device_id;
        const bool covers_limb =
            shard.limb_begin >= candidate.limb_begin &&
            shard.limb_begin + shard.limb_count <=
                candidate.limb_begin + candidate.limb_count;

        if (same_device && covers_limb)
        {
            return &candidate;
        }
    }

    return nullptr;
}

bool can_fuse_two_component_add_shards(
    const GpuPolyShardView &dst0,
    const GpuPolyShardView &dst1,
    const GpuConstPolyShardView &lhs0,
    const GpuConstPolyShardView &lhs1,
    const GpuConstPolyShardView &rhs0,
    const GpuConstPolyShardView &rhs1)
{
    return same_shard_placement(dst0, dst1) &&
           same_shard_placement(dst0, lhs0) &&
           same_shard_placement(dst0, lhs1) &&
           same_shard_placement(dst0, rhs0) &&
           same_shard_placement(dst0, rhs1);
}

bool try_componentwise_batch(kernel::ComponentwiseOp op,GpuCiphertextView &out,
    const GpuConstCiphertextView &left,const GpuLevelInfo &level,
    const GpuConstCiphertextView *right=nullptr,const GpuConstPlaintextView *plain=nullptr,
    std::uint64_t scalar=0)
{
    // A Q-only ciphertext can use a parameter context that also contains P
    // for key switching. Eligibility follows the operands, not that context.
    if(!opt_flag(OptFlag::SmallKernels) || out.meta.p_count || left.meta.p_count ||
       (right && right->meta.p_count) || (plain && plain->meta.p_count) || out.polys.empty() ||
       out.polys.size()>3 || out.polys.size()!=left.polys.size() ||
       (right && right->polys.size()!=out.polys.size()) || out.polys[0].shards.size()!=1)
        return false;
    const auto &shape=out.polys[0].shards[0];
    const auto *parameters=find_parameter_shard(level,shape);
    if(!parameters || !shape.limb_count || !shape.coeff_count || shape.coeff_count>level.degree)
        return false;
    const auto offset=shape.limb_begin-parameters->limb_begin;
    if(offset+shape.limb_count>parameters->q_primes.size() ||
       offset+shape.limb_count>parameters->q_modulus_constants.size())return false;
    kernel::ComponentwiseArgs args;
    args.components=out.polys.size();args.coefficients=shape.coeff_count;args.limbs=shape.limb_count;
    args.scalar=scalar;args.moduli=parameters->q_primes.data()+offset;
    args.ratios=parameters->q_modulus_constants.data()+offset;
    for(std::size_t c=0;c<out.polys.size();++c) {
        if(out.polys[c].shards.size()!=1 || left.polys[c].shards.size()!=1 ||
           !same_shard_placement(shape,out.polys[c].shards[0]) ||
           !same_shard_placement(shape,left.polys[c].shards[0]))return false;
        args.out[c]=out.polys[c].shards[0].ptr;args.left[c]=left.polys[c].shards[0].ptr;
        if(right) {
            if(right->polys[c].shards.size()!=1 || !same_shard_placement(shape,right->polys[c].shards[0]))return false;
            args.right[c]=right->polys[c].shards[0].ptr;
        }
    }
    if(plain) {
        if(plain->poly.shards.size()!=1 || !same_shard_placement(shape,plain->poly.shards[0]))return false;
        args.plain=plain->poly.shards[0].ptr;
    }
    kernel::launch_componentwise(op,args,shape.device_id);return true;
}

}  // namespace

GpuElementwiseHandler::GpuElementwiseHandler(const GpuParameterData &params)
    : params_(params)
{}

void GpuElementwiseHandler::multiply_plain_sum(
    GpuCiphertextView &destination_view,
    const std::vector<GpuConstCiphertextView> &ciphertexts,
    const std::vector<GpuConstPlaintextView> &plaintexts,
    const GpuLevelInfo &level_info,
    bool accumulate) const
{
    if (ciphertexts.empty() || ciphertexts.size() > 9 ||
        ciphertexts.size() != plaintexts.size() ||
        destination_view.polys.size() != 2 ||
        destination_view.polys[0].shards.size() != 1 ||
        destination_view.polys[1].shards.size() != 1)
        throw std::invalid_argument("multiply_plain_sum: unsupported shape");
    const auto &dst0 = destination_view.polys[0].shards.front();
    const auto &dst1 = destination_view.polys[1].shards.front();
    if (!same_shard_placement(dst0, dst1))
        throw std::invalid_argument("multiply_plain_sum: destination shard mismatch");
    std::array<GpuConstPolyShardView, 9> c0{}, c1{}, plain{};
    for (std::size_t i = 0; i < ciphertexts.size(); ++i)
    {
        const auto &ct = ciphertexts[i];
        const auto &pt = plaintexts[i];
        if (ct.polys.size() != 2 || ct.polys[0].shards.size() != 1 ||
            ct.polys[1].shards.size() != 1 || pt.poly.shards.size() != 1 ||
            ct.meta.parms_id != level_info.parms_id ||
            pt.meta.parms_id != level_info.parms_id)
            throw std::invalid_argument("multiply_plain_sum: source shape mismatch");
        c0[i] = ct.polys[0].shards.front();
        c1[i] = ct.polys[1].shards.front();
        plain[i] = pt.poly.shards.front();
        if (!same_shard_placement(dst0, c0[i]) ||
            !same_shard_placement(dst0, c1[i]) ||
            !same_shard_placement(dst0, plain[i]))
            throw std::invalid_argument("multiply_plain_sum: source shard mismatch");
    }
    const auto *shard = find_parameter_shard(level_info, dst0);
    if (shard == nullptr)
        throw std::invalid_argument("multiply_plain_sum: parameter shard absent");
    if (ciphertexts.size() <= 4)
    {
        kernel::launch_multiply_plain_caccumulate_two_components_4(
            dst0, dst1, c0.data(), c1.data(), plain.data(), ciphertexts.size(),
            nullptr, accumulate, *shard, level_info.degree);
    }
    else
    {
        kernel::launch_multiply_plain_caccumulate_two_components_9(
            dst0, dst1, c0.data(), c1.data(), plain.data(), ciphertexts.size(),
            accumulate, *shard, level_info.degree);
    }
}

void GpuElementwiseHandler::double_sub_plain(
    GpuCiphertextView &destination, const GpuConstCiphertextView &source,
    const GpuConstPlaintextView &plaintext, const GpuConstCiphertextView *correction,
    const GpuLevelInfo &level) const
{
    const auto valid_io = [&](const auto &ct) {
        return ct.meta.parms_id == level.parms_id && ct.polys.size() >= 2 &&
            ct.polys[0].shards.size() == 1 && ct.polys[1].shards.size() == 1;
    };
    const auto valid_corr = [&](const auto &ct) {
        return ct.meta.parms_id == level.parms_id && ct.polys.size() == 2 &&
            ct.polys[0].shards.size() == 1 && ct.polys[1].shards.size() == 1;
    };
    if (!valid_io(destination) || !valid_io(source) || (correction && !valid_corr(*correction)) ||
        plaintext.meta.parms_id != level.parms_id || plaintext.poly.shards.size() != 1)
        throw std::invalid_argument("double_sub_plain: unsupported shape");
    const auto *parameters = find_parameter_shard(level, destination.polys[0].shards[0]);
    if (!parameters) throw std::invalid_argument("double_sub_plain: parameter shard absent");
    kernel::launch_double_sub_plain_two_components(
        destination.polys[0].shards[0], destination.polys[1].shards[0],
        source.polys[0].shards[0], source.polys[1].shards[0], plaintext.poly.shards[0],
        correction ? &correction->polys[0].shards[0] : nullptr,
        correction ? &correction->polys[1].shards[0] : nullptr, *parameters);
}

void GpuElementwiseHandler::multiply_double_sub_plain(
    GpuCiphertextView &destination,
    const GpuConstCiphertextView &left,
    const GpuConstCiphertextView &right,
    const GpuConstPlaintextView &plaintext,
    const GpuConstCiphertextView *correction,
    const GpuLevelInfo &level) const
{
    const auto valid_in = [&](const GpuConstCiphertextView &ct) {
        return ct.meta.parms_id == level.parms_id && ct.polys.size() == 2 &&
            ct.polys[0].shards.size() == 1 && ct.polys[1].shards.size() == 1;
    };
    const bool valid_dst =
        destination.meta.parms_id == level.parms_id && destination.polys.size() == 3 &&
        destination.polys[0].shards.size() == 1 && destination.polys[1].shards.size() == 1 &&
        destination.polys[2].shards.size() == 1;
    if (!valid_dst || !valid_in(left) || !valid_in(right) ||
        (correction && !valid_in(*correction)) ||
        plaintext.meta.parms_id != level.parms_id || plaintext.poly.shards.size() != 1)
        throw std::invalid_argument("multiply_double_sub_plain: unsupported shape");
    const auto *parameters = find_parameter_shard(level, destination.polys[0].shards[0]);
    if (!parameters) throw std::invalid_argument("multiply_double_sub_plain: parameter shard absent");
    kernel::launch_multiply_double_sub_plain_two_components(
        destination.polys[0].shards[0],
        destination.polys[1].shards[0],
        destination.polys[2].shards[0],
        left.polys[0].shards[0],
        left.polys[1].shards[0],
        right.polys[0].shards[0],
        right.polys[1].shards[0],
        plaintext.poly.shards[0],
        correction ? &correction->polys[0].shards[0] : nullptr,
        correction ? &correction->polys[1].shards[0] : nullptr,
        *parameters);
}

void GpuElementwiseHandler::multiply_add_ciphertext(
    GpuCiphertextView &destination,
    const GpuConstCiphertextView &left,
    const GpuConstCiphertextView &right,
    const GpuConstCiphertextView &addend,
    const GpuLevelInfo &level) const
{
    const auto valid_in = [&](const GpuConstCiphertextView &ct) {
        return ct.meta.parms_id == level.parms_id && ct.polys.size() == 2 &&
            ct.polys[0].shards.size() == 1 && ct.polys[1].shards.size() == 1;
    };
    const bool valid_addend =
        addend.meta.parms_id == level.parms_id &&
        (addend.polys.size() == 2 || addend.polys.size() == 3) &&
        addend.polys[0].shards.size() == 1 && addend.polys[1].shards.size() == 1 &&
        (addend.polys.size() == 2 || addend.polys[2].shards.size() == 1);
    const bool valid_dst =
        destination.meta.parms_id == level.parms_id && destination.polys.size() == 3 &&
        destination.polys[0].shards.size() == 1 && destination.polys[1].shards.size() == 1 &&
        destination.polys[2].shards.size() == 1;
    if (!valid_dst || !valid_in(left) || !valid_in(right) || !valid_addend)
        throw std::invalid_argument("multiply_add_ciphertext: unsupported shape");
    const auto *parameters = find_parameter_shard(level, destination.polys[0].shards[0]);
    if (!parameters) throw std::invalid_argument("multiply_add_ciphertext: parameter shard absent");
    kernel::launch_multiply_add_two_component_ciphertexts(
        destination.polys[0].shards[0],
        destination.polys[1].shards[0],
        destination.polys[2].shards[0],
        left.polys[0].shards[0],
        left.polys[1].shards[0],
        right.polys[0].shards[0],
        right.polys[1].shards[0],
        addend.polys[0].shards[0],
        addend.polys[1].shards[0],
        addend.polys.size() == 3 ? &addend.polys[2].shards[0] : nullptr,
        *parameters,
        level.degree);
}

// 最顶层的加法，支持不同component密文的求和，低位求和。
void GpuElementwiseHandler::add_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &left_view,
    const GpuConstCiphertextView &right_view,
    const GpuLevelInfo &level_info) const
{
    if (!(left_view.meta.parms_id == right_view.meta.parms_id) ||
        !(left_view.meta.parms_id == destination_view.meta.parms_id))
    {
        throw std::invalid_argument("add_ciphertext: parms_id mismatch");
    }

    if (left_view.meta.is_ntt_form != right_view.meta.is_ntt_form ||
        left_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("add_ciphertext: NTT form mismatch");
    }

    if (left_view.meta.degree != right_view.meta.degree ||
        left_view.meta.degree != destination_view.meta.degree ||
        left_view.meta.q_count != right_view.meta.q_count ||
        left_view.meta.q_count != destination_view.meta.q_count ||
        left_view.meta.p_count != right_view.meta.p_count ||
        left_view.meta.p_count != destination_view.meta.p_count)
    {
        throw std::invalid_argument("add_ciphertext: shape mismatch");
    }

    const auto common_count = std::min(left_view.polys.size(), right_view.polys.size());
    const auto result_count = std::max(left_view.polys.size(), right_view.polys.size());

    if (destination_view.polys.size() != result_count)
    {
        throw std::invalid_argument("add_ciphertext: destination component count mismatch");
    }

    std::size_t processed_common_count = 0;
    if (common_count >= 2)
    {
        bool can_fuse_c0_c1 =
            destination_view.polys[0].shards.size() ==
                destination_view.polys[1].shards.size() &&
            destination_view.polys[0].shards.size() ==
                left_view.polys[0].shards.size() &&
            destination_view.polys[0].shards.size() ==
                left_view.polys[1].shards.size() &&
            destination_view.polys[0].shards.size() ==
                right_view.polys[0].shards.size() &&
            destination_view.polys[0].shards.size() ==
                right_view.polys[1].shards.size();

        if (can_fuse_c0_c1)
        {
            for (std::size_t shard_index = 0;
                 shard_index < destination_view.polys[0].shards.size();
                 ++shard_index)
            {
                const auto &dst0 = destination_view.polys[0].shards[shard_index];
                const auto &dst1 = destination_view.polys[1].shards[shard_index];
                const auto &lhs0 = left_view.polys[0].shards[shard_index];
                const auto &lhs1 = left_view.polys[1].shards[shard_index];
                const auto &rhs0 = right_view.polys[0].shards[shard_index];
                const auto &rhs1 = right_view.polys[1].shards[shard_index];

                if (!can_fuse_two_component_add_shards(
                        dst0,
                        dst1,
                        lhs0,
                        lhs1,
                        rhs0,
                        rhs1) ||
                    find_parameter_shard(level_info, dst0) == nullptr)
                {
                    can_fuse_c0_c1 = false;
                    break;
                }
            }
        }

        if (can_fuse_c0_c1)
        {
            for (std::size_t shard_index = 0;
                 shard_index < destination_view.polys[0].shards.size();
                 ++shard_index)
            {
                const auto &dst0 = destination_view.polys[0].shards[shard_index];
                const auto &dst1 = destination_view.polys[1].shards[shard_index];
                const auto &lhs0 = left_view.polys[0].shards[shard_index];
                const auto &lhs1 = left_view.polys[1].shards[shard_index];
                const auto &rhs0 = right_view.polys[0].shards[shard_index];
                const auto &rhs1 = right_view.polys[1].shards[shard_index];
                const auto *parameter_shard = find_parameter_shard(level_info, dst0);

                kernel::launch_add_two_poly_shards(
                    dst0,
                    dst1,
                    lhs0,
                    lhs1,
                    rhs0,
                    rhs1,
                    *parameter_shard,
                    level_info.degree);
            }
            processed_common_count = 2;
        }
    }

    for (std::size_t i = processed_common_count; i < common_count; ++i)
    {
        add_poly(destination_view.polys[i], left_view.polys[i], right_view.polys[i], level_info);
    }

    if (left_view.polys.size() > right_view.polys.size())
    {
        for (std::size_t i = common_count; i < left_view.polys.size(); ++i)
        {
            copy_poly(destination_view.polys[i], left_view.polys[i], level_info);
        }
    }
    else
    {
        for (std::size_t i = common_count; i < right_view.polys.size(); ++i)
        {
            copy_poly(destination_view.polys[i], right_view.polys[i], level_info);
        }
    }
}

void GpuElementwiseHandler::sub_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &left_view,
    const GpuConstCiphertextView &right_view,
    const GpuLevelInfo &level_info) const
{
    if (!(left_view.meta.parms_id == right_view.meta.parms_id) ||
        !(left_view.meta.parms_id == destination_view.meta.parms_id))
    {
        throw std::invalid_argument("sub_ciphertext: parms_id mismatch");
    }

    if (left_view.meta.is_ntt_form != right_view.meta.is_ntt_form ||
        left_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("sub_ciphertext: NTT form mismatch");
    }

    if (left_view.meta.degree != right_view.meta.degree ||
        left_view.meta.degree != destination_view.meta.degree ||
        left_view.meta.q_count != right_view.meta.q_count ||
        left_view.meta.q_count != destination_view.meta.q_count ||
        left_view.meta.p_count != right_view.meta.p_count ||
        left_view.meta.p_count != destination_view.meta.p_count)
    {
        throw std::invalid_argument("sub_ciphertext: shape mismatch");
    }

    const auto common_count = std::min(left_view.polys.size(), right_view.polys.size());
    const auto result_count = std::max(left_view.polys.size(), right_view.polys.size());

    if (destination_view.polys.size() != result_count)
    {
        throw std::invalid_argument("sub_ciphertext: destination component count mismatch");
    }
    if(try_componentwise_batch(kernel::ComponentwiseOp::Subtract,destination_view,left_view,level_info,&right_view))return;

    for (std::size_t i = 0; i < common_count; ++i)
    {
        sub_poly(
            destination_view.polys[i],
            left_view.polys[i],
            right_view.polys[i],
            level_info);
    }

    if (left_view.polys.size() > right_view.polys.size())
    {
        for (std::size_t i = common_count; i < left_view.polys.size(); ++i)
        {
            copy_poly(
                destination_view.polys[i],
                left_view.polys[i],
                level_info);
        }
    }
    else
    {
        for (std::size_t i = common_count; i < right_view.polys.size(); ++i)
        {
            negate_poly(
                destination_view.polys[i],
                right_view.polys[i],
                level_info);
        }
    }
}

void GpuElementwiseHandler::negate_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &source_view,
    const GpuLevelInfo &level_info) const
{
    if (!(source_view.meta.parms_id == destination_view.meta.parms_id))
    {
        throw std::invalid_argument("negate_ciphertext: parms_id mismatch");
    }

    if (source_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("negate_ciphertext: NTT form mismatch");
    }

    if (source_view.meta.degree != destination_view.meta.degree ||
        source_view.meta.q_count != destination_view.meta.q_count ||
        source_view.meta.p_count != destination_view.meta.p_count)
    {
        throw std::invalid_argument("negate_ciphertext: shape mismatch");
    }

    const auto common_count = source_view.polys.size();

    if (destination_view.polys.size() != source_view.polys.size())
    {
        throw std::invalid_argument("negate_ciphertext: component count mismatch");
    }
    if(try_componentwise_batch(kernel::ComponentwiseOp::Negate,destination_view,source_view,level_info))return;

    for (std::size_t i = 0; i < common_count; ++i)
    {
        negate_poly(
            destination_view.polys[i],
            source_view.polys[i],
            level_info);
    }
}

void GpuElementwiseHandler::multiply_scalar_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &source_view,
    std::uint64_t scalar,
    const GpuLevelInfo &level_info) const
{
    if (!(source_view.meta.parms_id == destination_view.meta.parms_id) ||
        !(source_view.meta.parms_id == level_info.parms_id))
    {
        throw std::invalid_argument("multiply_scalar_ciphertext: parms_id mismatch");
    }
    if (source_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("multiply_scalar_ciphertext: NTT form mismatch");
    }
    if (source_view.meta.degree != destination_view.meta.degree ||
        source_view.meta.degree != level_info.degree ||
        source_view.meta.q_count != destination_view.meta.q_count ||
        source_view.meta.q_count != level_info.q_count ||
        source_view.meta.p_count != destination_view.meta.p_count ||
        source_view.meta.p_count != level_info.p_count)
    {
        throw std::invalid_argument("multiply_scalar_ciphertext: shape mismatch");
    }
    if (destination_view.polys.size() != source_view.polys.size())
    {
        throw std::invalid_argument("multiply_scalar_ciphertext: component count mismatch");
    }
    if(try_componentwise_batch(kernel::ComponentwiseOp::Scalar,destination_view,source_view,level_info,nullptr,nullptr,scalar))return;

    for (std::size_t i = 0; i < source_view.polys.size(); ++i)
    {
        const auto &dst_poly = destination_view.polys[i];
        const auto &src_poly = source_view.polys[i];
        if (dst_poly.shards.size() != src_poly.shards.size())
        {
            throw std::invalid_argument("multiply_scalar_ciphertext: shard count mismatch");
        }

        for (std::size_t shard_index = 0; shard_index < dst_poly.shards.size(); ++shard_index)
        {
            const auto &dst = dst_poly.shards[shard_index];
            const auto &src = src_poly.shards[shard_index];
            if (dst.device_id != src.device_id ||
                dst.limb_begin != src.limb_begin ||
                dst.limb_count != src.limb_count ||
                dst.coeff_begin != src.coeff_begin ||
                dst.coeff_count != src.coeff_count)
            {
                throw std::invalid_argument("multiply_scalar_ciphertext: shard placement mismatch");
            }

            const GpuParameterShard *parameter_shard =
                find_parameter_shard(level_info, dst);
            if (parameter_shard == nullptr)
            {
                throw std::invalid_argument("multiply_scalar_ciphertext: no matching parameter shard");
            }

            kernel::launch_multiply_scalar_poly_shard(
                dst,
                src,
                scalar,
                *parameter_shard,
                level_info.degree);
        }
    }
}

void GpuElementwiseHandler::add_plain_to_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &ciphertext_view,
    const GpuConstPlaintextView &plaintext_view,
    const GpuLevelInfo &level_info) const
{
     if (!(ciphertext_view.meta.parms_id == plaintext_view.meta.parms_id) ||
        !(ciphertext_view.meta.parms_id == destination_view.meta.parms_id))
    {
        throw std::invalid_argument("add_plain_to_ciphertext: parms_id mismatch");
    }

    if (ciphertext_view.meta.is_ntt_form != plaintext_view.meta.is_ntt_form ||
        ciphertext_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("add_plain_to_ciphertext: NTT form mismatch");
    }

    if (ciphertext_view.meta.degree != plaintext_view.meta.degree ||
        ciphertext_view.meta.degree != destination_view.meta.degree ||
        ciphertext_view.meta.q_count != plaintext_view.meta.q_count ||
        ciphertext_view.meta.q_count != destination_view.meta.q_count ||
        ciphertext_view.meta.p_count != plaintext_view.meta.p_count ||
        ciphertext_view.meta.p_count != destination_view.meta.p_count)
    {
        throw std::invalid_argument("add_plain_to_ciphertext: shape mismatch");
    }

    if (ciphertext_view.polys.empty())
    {
        throw std::invalid_argument("add_plain_to_ciphertext: empty ciphertext");
    }

    if (destination_view.polys.size() != ciphertext_view.polys.size())
    {
        throw std::invalid_argument(
            "add_plain_to_ciphertext: destination component count mismatch");
    }

    if(try_componentwise_batch(kernel::ComponentwiseOp::AddPlain,destination_view,ciphertext_view,level_info,nullptr,&plaintext_view))return;
    // CKKS rule:
    // destination.c0 = ciphertext.c0 + plaintext
    add_poly(
        destination_view.polys[0],
        ciphertext_view.polys[0],
        plaintext_view.poly,
        level_info);

    // destination.ci = ciphertext.ci for i > 0
    for (std::size_t i = 1; i < ciphertext_view.polys.size(); ++i)
    {
        copy_poly(
            destination_view.polys[i],
            ciphertext_view.polys[i],
            level_info);
    }
}

void GpuElementwiseHandler::sub_plain_from_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &ciphertext_view,
    const GpuConstPlaintextView &plaintext_view,
    const GpuLevelInfo &level_info) const
{
    if (!(ciphertext_view.meta.parms_id == plaintext_view.meta.parms_id) ||
        !(ciphertext_view.meta.parms_id == destination_view.meta.parms_id))
    {
        throw std::invalid_argument("sub_plain_from_ciphertext: parms_id mismatch");
    }

    if (ciphertext_view.meta.is_ntt_form != plaintext_view.meta.is_ntt_form ||
        ciphertext_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("sub_plain_from_ciphertext: NTT form mismatch");
    }

    if (ciphertext_view.meta.degree != plaintext_view.meta.degree ||
        ciphertext_view.meta.degree != destination_view.meta.degree ||
        ciphertext_view.meta.q_count != plaintext_view.meta.q_count ||
        ciphertext_view.meta.q_count != destination_view.meta.q_count ||
        ciphertext_view.meta.p_count != plaintext_view.meta.p_count ||
        ciphertext_view.meta.p_count != destination_view.meta.p_count)
    {
        throw std::invalid_argument("sub_plain_from_ciphertext: shape mismatch");
    }

    if (ciphertext_view.polys.empty())
    {
        throw std::invalid_argument("sub_plain_from_ciphertext: empty ciphertext");
    }

    if (destination_view.polys.size() != ciphertext_view.polys.size())
    {
        throw std::invalid_argument(
            "sub_plain_from_ciphertext: destination component count mismatch");
    }

    // CKKS rule:
    // destination.c0 = ciphertext.c0 - plaintext
    if(try_componentwise_batch(kernel::ComponentwiseOp::SubtractPlain,destination_view,ciphertext_view,level_info,nullptr,&plaintext_view))return;
    sub_poly(
        destination_view.polys[0],
        ciphertext_view.polys[0],
        plaintext_view.poly,
        level_info);

    // destination.ci = ciphertext.ci for i > 0
    for (std::size_t i = 1; i < ciphertext_view.polys.size(); ++i)
    {
        copy_poly(
            destination_view.polys[i],
            ciphertext_view.polys[i],
            level_info);
    }
}

namespace
{

GpuConstPolyShardView const_alias(const GpuPolyShardView &view)
{
    GpuConstPolyShardView result;
    result.device_id = view.device_id;
    result.ptr = view.ptr;
    result.limb_begin = view.limb_begin;
    result.limb_count = view.limb_count;
    result.coeff_begin = view.coeff_begin;
    result.coeff_count = view.coeff_count;
    return result;
}

}  // namespace

void GpuElementwiseHandler::add_plain_to_ciphertext_inplace(
    GpuCiphertextView &ciphertext_view,
    const GpuConstPlaintextView &plaintext_view,
    const GpuLevelInfo &level_info) const
{
    if (!(ciphertext_view.meta.parms_id == plaintext_view.meta.parms_id) ||
        !ciphertext_view.meta.is_ntt_form ||
        !plaintext_view.meta.is_ntt_form ||
        ciphertext_view.meta.degree != plaintext_view.meta.degree ||
        ciphertext_view.meta.q_count != plaintext_view.meta.q_count ||
        ciphertext_view.meta.p_count != plaintext_view.meta.p_count ||
        ciphertext_view.polys.empty() ||
        ciphertext_view.polys[0].shards.size() != plaintext_view.poly.shards.size())
    {
        throw std::invalid_argument(
            "add_plain_to_ciphertext_inplace: incompatible input");
    }

    for (std::size_t i = 0; i < ciphertext_view.polys[0].shards.size(); ++i)
    {
        const auto &dst = ciphertext_view.polys[0].shards[i];
        const auto &plain = plaintext_view.poly.shards[i];
        const auto *parameter_shard = find_parameter_shard(level_info, dst);
        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument(
                "add_plain_to_ciphertext_inplace: no parameter shard");
        }
        kernel::launch_add_poly_shard(
            dst,
            const_alias(dst),
            plain,
            *parameter_shard,
            level_info.degree);
    }
}

void GpuElementwiseHandler::sub_plain_from_ciphertext_inplace(
    GpuCiphertextView &ciphertext_view,
    const GpuConstPlaintextView &plaintext_view,
    const GpuLevelInfo &level_info) const
{
    if (!(ciphertext_view.meta.parms_id == plaintext_view.meta.parms_id) ||
        !ciphertext_view.meta.is_ntt_form ||
        !plaintext_view.meta.is_ntt_form ||
        ciphertext_view.meta.degree != plaintext_view.meta.degree ||
        ciphertext_view.meta.q_count != plaintext_view.meta.q_count ||
        ciphertext_view.meta.p_count != plaintext_view.meta.p_count ||
        ciphertext_view.polys.empty() ||
        ciphertext_view.polys[0].shards.size() != plaintext_view.poly.shards.size())
    {
        throw std::invalid_argument(
            "sub_plain_from_ciphertext_inplace: incompatible input");
    }

    for (std::size_t i = 0; i < ciphertext_view.polys[0].shards.size(); ++i)
    {
        const auto &dst = ciphertext_view.polys[0].shards[i];
        const auto &plain = plaintext_view.poly.shards[i];
        const auto *parameter_shard = find_parameter_shard(level_info, dst);
        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument(
                "sub_plain_from_ciphertext_inplace: no parameter shard");
        }
        kernel::launch_sub_poly_shard(
            dst,
            const_alias(dst),
            plain,
            *parameter_shard,
            level_info.degree);
    }
}

void GpuElementwiseHandler::multiply_plain_with_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &ciphertext_view,
    const GpuConstPlaintextView &plaintext_view,
    const GpuLevelInfo &level_info) const
{
    if (!(ciphertext_view.meta.parms_id == plaintext_view.meta.parms_id) ||
        !(ciphertext_view.meta.parms_id == destination_view.meta.parms_id))
    {
        throw std::invalid_argument("multiply_plain_with_ciphertext: parms_id mismatch");
    }

    if (ciphertext_view.meta.is_ntt_form != plaintext_view.meta.is_ntt_form ||
        ciphertext_view.meta.is_ntt_form != destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("multiply_plain_with_ciphertext: NTT form mismatch");
    }

    if (destination_view.polys.size() != ciphertext_view.polys.size())
    {
        throw std::invalid_argument(
            "multiply_plain_with_ciphertext: destination component count mismatch");
    }

    for (std::size_t i = 0; i < ciphertext_view.polys.size(); ++i)
    {
        multiply_plain_poly(
            destination_view.polys[i],
            ciphertext_view.polys[i],
            plaintext_view.poly,
            level_info);
    }
}

void GpuElementwiseHandler::multiply_plain_accumulate_with_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &ciphertext_view,
    const GpuConstPlaintextView &plaintext_view,
    const GpuLevelInfo &level_info) const
{
    if (!(destination_view.meta.parms_id == ciphertext_view.meta.parms_id) ||
        !(destination_view.meta.parms_id == plaintext_view.meta.parms_id) ||
        !destination_view.meta.is_ntt_form ||
        !ciphertext_view.meta.is_ntt_form ||
        !plaintext_view.meta.is_ntt_form ||
        destination_view.polys.size() < 2 ||
        ciphertext_view.polys.size() != 2)
    {
        throw std::invalid_argument(
            "multiply_plain_accumulate_with_ciphertext: incompatible input");
    }
    if (destination_view.polys[0].shards.size() != 1 ||
        destination_view.polys[1].shards.size() != 1 ||
        ciphertext_view.polys[0].shards.size() != 1 ||
        ciphertext_view.polys[1].shards.size() != 1 ||
        plaintext_view.poly.shards.size() != 1)
    {
        throw std::invalid_argument(
            "multiply_plain_accumulate_with_ciphertext: one shard required");
    }

    const auto &destination0 = destination_view.polys[0].shards.front();
    const auto *parameter_shard =
        find_parameter_shard(level_info, destination0);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "multiply_plain_accumulate_with_ciphertext: no parameter shard");
    }
    kernel::launch_multiply_plain_accumulate_two_components(
        destination0,
        destination_view.polys[1].shards.front(),
        ciphertext_view.polys[0].shards.front(),
        ciphertext_view.polys[1].shards.front(),
        plaintext_view.poly.shards.front(),
        *parameter_shard,
        level_info.degree);
}

/**
 * @brief 真正构建d0 d1 d2的位置，再根据计算需求调用底层的kernel算子
 */
void GpuElementwiseHandler::multiply_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &left_view,
    const GpuConstCiphertextView &right_view,
    const GpuLevelInfo &level_info) const
{
    if (!(left_view.meta.parms_id == right_view.meta.parms_id) ||
        !(left_view.meta.parms_id == destination_view.meta.parms_id) ||
        !(left_view.meta.parms_id == level_info.parms_id))
    {
        throw std::invalid_argument("multiply_ciphertext: parms_id mismatch");
    }

    if (!left_view.meta.is_ntt_form ||
        !right_view.meta.is_ntt_form ||
        !destination_view.meta.is_ntt_form)
    {
        throw std::invalid_argument("multiply_ciphertext: CKKS inputs must be in NTT form");
    }

    if (left_view.meta.degree != right_view.meta.degree ||
        left_view.meta.degree != destination_view.meta.degree ||
        left_view.meta.degree != level_info.degree ||
        left_view.meta.q_count != right_view.meta.q_count ||
        left_view.meta.q_count != destination_view.meta.q_count ||
        left_view.meta.q_count != level_info.q_count ||
        left_view.meta.p_count != right_view.meta.p_count ||
        left_view.meta.p_count != destination_view.meta.p_count ||
        left_view.meta.p_count != level_info.p_count)
    {
        throw std::invalid_argument("multiply_ciphertext: shape mismatch");
    }

    if (left_view.meta.p_count != 0)
    {
        throw std::invalid_argument("multiply_ciphertext: p limbs are not supported yet");
    }

    if (left_view.polys.empty() || right_view.polys.empty())
    {
        throw std::invalid_argument("multiply_ciphertext: empty ciphertext");
    }

    const std::size_t result_count =
        left_view.polys.size() + right_view.polys.size() - 1;
    if (destination_view.polys.size() != result_count)
    {
        throw std::invalid_argument(
            "multiply_ciphertext: destination component count mismatch");
    }

    if (use_fused_ciphertext_multiply() &&
        left_view.polys.size() == 2 &&
        right_view.polys.size() == 2 &&
        destination_view.polys.size() == 3)
    {
        const std::size_t shard_count =
            destination_view.polys[0].shards.size();
        bool compatible = shard_count != 0;
        for (const auto &poly : destination_view.polys)
        {
            compatible = compatible && poly.shards.size() == shard_count;
        }
        for (const auto &poly : left_view.polys)
        {
            compatible = compatible && poly.shards.size() == shard_count;
        }
        for (const auto &poly : right_view.polys)
        {
            compatible = compatible && poly.shards.size() == shard_count;
        }

        for (std::size_t shard_index = 0;
             compatible && shard_index < shard_count;
             ++shard_index)
        {
            const auto &dst0 = destination_view.polys[0].shards[shard_index];
            compatible =
                same_shard_placement(
                    dst0,
                    destination_view.polys[1].shards[shard_index]) &&
                same_shard_placement(
                    dst0,
                    destination_view.polys[2].shards[shard_index]) &&
                same_shard_placement(
                    dst0,
                    left_view.polys[0].shards[shard_index]) &&
                same_shard_placement(
                    dst0,
                    left_view.polys[1].shards[shard_index]) &&
                same_shard_placement(
                    dst0,
                    right_view.polys[0].shards[shard_index]) &&
                same_shard_placement(
                    dst0,
                    right_view.polys[1].shards[shard_index]);
        }

        if (compatible)
        {
            for (std::size_t shard_index = 0;
                 shard_index < shard_count;
                 ++shard_index)
            {
                const auto &dst0 =
                    destination_view.polys[0].shards[shard_index];
                const auto *parameter_shard =
                    find_parameter_shard(level_info, dst0);
                if (parameter_shard == nullptr)
                {
                    throw std::invalid_argument(
                        "multiply_ciphertext: no matching parameter shard");
                }
                kernel::launch_multiply_two_component_ciphertexts(
                    dst0,
                    destination_view.polys[1].shards[shard_index],
                    destination_view.polys[2].shards[shard_index],
                    left_view.polys[0].shards[shard_index],
                    left_view.polys[1].shards[shard_index],
                    right_view.polys[0].shards[shard_index],
                    right_view.polys[1].shards[shard_index],
                    *parameter_shard,
                    level_info.degree);
            }
            return;
        }
    }

    for (std::size_t dest_component = 0;
         dest_component < result_count;
         ++dest_component)
    {
        const std::size_t left_first =
            dest_component >= right_view.polys.size()
                ? dest_component - right_view.polys.size() + 1
                : 0;
        const std::size_t left_last =
            std::min(dest_component, left_view.polys.size() - 1);

        bool first_product = true;
        for (std::size_t left_component = left_first;
             left_component <= left_last;
             ++left_component)
        {
            const std::size_t right_component =
                dest_component - left_component;

            if (first_product)
            {
                multiply_plain_poly(
                    destination_view.polys[dest_component],
                    left_view.polys[left_component],
                    right_view.polys[right_component],
                    level_info);
                first_product = false;
            }
            else
            {
                multiply_accumulate_poly(
                    destination_view.polys[dest_component],
                    left_view.polys[left_component],
                    right_view.polys[right_component],
                    level_info);
            }
        }
    }
}

void GpuElementwiseHandler::square_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &source_view,
    const GpuLevelInfo &level_info) const
{
    if (!use_fused_ciphertext_multiply() ||
        source_view.polys.size() != 2 ||
        destination_view.polys.size() != 3)
    {
        multiply_ciphertext(
            destination_view,
            source_view,
            source_view,
            level_info);
        return;
    }
    if (!(source_view.meta.parms_id == destination_view.meta.parms_id) ||
        !(source_view.meta.parms_id == level_info.parms_id) ||
        !source_view.meta.is_ntt_form ||
        !destination_view.meta.is_ntt_form ||
        source_view.meta.degree != destination_view.meta.degree ||
        source_view.meta.degree != level_info.degree ||
        source_view.meta.q_count != destination_view.meta.q_count ||
        source_view.meta.q_count != level_info.q_count ||
        source_view.meta.p_count != 0 ||
        destination_view.meta.p_count != 0)
    {
        throw std::invalid_argument("square_ciphertext: input shape mismatch");
    }

    const std::size_t shard_count =
        destination_view.polys[0].shards.size();
    bool compatible = shard_count != 0;
    for (const auto &poly : destination_view.polys)
    {
        compatible = compatible && poly.shards.size() == shard_count;
    }
    for (const auto &poly : source_view.polys)
    {
        compatible = compatible && poly.shards.size() == shard_count;
    }
    for (std::size_t shard_index = 0;
         compatible && shard_index < shard_count;
         ++shard_index)
    {
        const auto &dst0 = destination_view.polys[0].shards[shard_index];
        compatible =
            same_shard_placement(
                dst0,
                destination_view.polys[1].shards[shard_index]) &&
            same_shard_placement(
                dst0,
                destination_view.polys[2].shards[shard_index]) &&
            same_shard_placement(
                dst0,
                source_view.polys[0].shards[shard_index]) &&
            same_shard_placement(
                dst0,
                source_view.polys[1].shards[shard_index]);
    }
    if (!compatible)
    {
        multiply_ciphertext(
            destination_view,
            source_view,
            source_view,
            level_info);
        return;
    }

    for (std::size_t shard_index = 0;
         shard_index < shard_count;
         ++shard_index)
    {
        const auto &dst0 =
            destination_view.polys[0].shards[shard_index];
        const auto *parameter_shard =
            find_parameter_shard(level_info, dst0);
        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument(
                "square_ciphertext: no matching parameter shard");
        }
        kernel::launch_square_two_component_ciphertext(
            dst0,
            destination_view.polys[1].shards[shard_index],
            destination_view.polys[2].shards[shard_index],
            source_view.polys[0].shards[shard_index],
            source_view.polys[1].shards[shard_index],
            *parameter_shard,
            level_info.degree);
    }
}

void GpuElementwiseHandler::add_poly(
    GpuRNSPolyView &destination_poly,
    const GpuConstRNSPolyView &left_poly,
    const GpuConstRNSPolyView &right_poly,
    const GpuLevelInfo &level_info) const
{
    if (destination_poly.shards.size() != left_poly.shards.size() ||
        destination_poly.shards.size() != right_poly.shards.size())
    {
        throw std::invalid_argument("add_poly: shard count mismatch");
    }

    for (std::size_t i = 0; i < destination_poly.shards.size(); ++i)
    {
        const auto &dst = destination_poly.shards[i];
        const auto &lhs = left_poly.shards[i];
        const auto &rhs = right_poly.shards[i];

        if (dst.device_id != lhs.device_id ||
            dst.device_id != rhs.device_id ||
            dst.limb_begin != lhs.limb_begin ||
            dst.limb_begin != rhs.limb_begin ||
            dst.limb_count != lhs.limb_count ||
            dst.limb_count != rhs.limb_count ||
            dst.coeff_begin != lhs.coeff_begin ||
            dst.coeff_begin != rhs.coeff_begin ||
            dst.coeff_count != lhs.coeff_count ||
            dst.coeff_count != rhs.coeff_count)
        {
            throw std::invalid_argument("add_poly: shard placement mismatch");
        }

        const GpuParameterShard *parameter_shard =
            find_parameter_shard(level_info, dst);

        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument("add_poly: no matching parameter shard");
        }

        kernel::launch_add_poly_shard(dst, lhs, rhs, *parameter_shard, level_info.degree);
    }
}

void GpuElementwiseHandler::sub_poly(
    GpuRNSPolyView &destination_poly,
    const GpuConstRNSPolyView &left_poly,
    const GpuConstRNSPolyView &right_poly,
    const GpuLevelInfo &level_info) const
{
    if (destination_poly.shards.size() != left_poly.shards.size() ||
        destination_poly.shards.size() != right_poly.shards.size())
    {
        throw std::invalid_argument("sub_poly: shard count mismatch");
    }

    for (std::size_t i = 0; i < destination_poly.shards.size(); ++i)
    {
        const auto &dst = destination_poly.shards[i];
        const auto &lhs = left_poly.shards[i];
        const auto &rhs = right_poly.shards[i];

        if (dst.device_id != lhs.device_id ||
            dst.device_id != rhs.device_id ||
            dst.limb_begin != lhs.limb_begin ||
            dst.limb_begin != rhs.limb_begin ||
            dst.limb_count != lhs.limb_count ||
            dst.limb_count != rhs.limb_count ||
            dst.coeff_begin != lhs.coeff_begin ||
            dst.coeff_begin != rhs.coeff_begin ||
            dst.coeff_count != lhs.coeff_count ||
            dst.coeff_count != rhs.coeff_count)
        {
            throw std::invalid_argument("sub_poly: shard placement mismatch");
        }

        const GpuParameterShard *parameter_shard =
            find_parameter_shard(level_info, dst);

        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument("sub_poly: no matching parameter shard");
        }

        kernel::launch_sub_poly_shard(dst, lhs, rhs, *parameter_shard, level_info.degree);
    }
}

void GpuElementwiseHandler::negate_poly(
    GpuRNSPolyView &destination_poly,
    const GpuConstRNSPolyView &source_poly,
    const GpuLevelInfo &level_info) const
{
    if (destination_poly.shards.size() != source_poly.shards.size())
    {
        throw std::invalid_argument("negate_poly: shard count mismatch");
    }

    for (std::size_t i = 0; i < destination_poly.shards.size(); ++i)
    {
        const auto &dst = destination_poly.shards[i];
        const auto &src = source_poly.shards[i];

        if (dst.device_id != src.device_id ||
            dst.limb_begin != src.limb_begin ||
            dst.limb_count != src.limb_count ||
            dst.coeff_begin != src.coeff_begin ||
            dst.coeff_count != src.coeff_count)
        {
            throw std::invalid_argument("negate_poly: shard placement mismatch");
        }

        const GpuParameterShard *parameter_shard =
            find_parameter_shard(level_info, dst);

        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument("negate_poly: no matching parameter shard");
        }

        kernel::launch_negate_poly_shard(dst, src, *parameter_shard, level_info.degree);
    }
}

void GpuElementwiseHandler::copy_poly(
    GpuRNSPolyView &destination_poly,
    const GpuConstRNSPolyView &source_poly,
    const GpuLevelInfo &level_info) const
{
    if (destination_poly.shards.size() != source_poly.shards.size())
    {
        throw std::invalid_argument("copy_poly: shard count mismatch");
    }

    for (std::size_t i = 0; i < destination_poly.shards.size(); ++i)
    {
        const auto &dst = destination_poly.shards[i];
        const auto &src = source_poly.shards[i];

        if (dst.device_id != src.device_id ||
            dst.limb_begin != src.limb_begin ||
            dst.limb_count != src.limb_count ||
            dst.coeff_begin != src.coeff_begin ||
            dst.coeff_count != src.coeff_count)
        {
            throw std::invalid_argument("copy_poly: shard placement mismatch");
        }

        (void)level_info;
        kernel::launch_copy_poly_shard(dst, src, level_info.degree);
    }
}

void GpuElementwiseHandler::multiply_plain_poly(
    GpuRNSPolyView &destination_poly,
    const GpuConstRNSPolyView &ciphertext_poly,
    const GpuConstRNSPolyView &plaintext_poly,
    const GpuLevelInfo &level_info) const
{
    if (destination_poly.shards.size() != ciphertext_poly.shards.size() ||
        destination_poly.shards.size() != plaintext_poly.shards.size())
    {
        throw std::invalid_argument("multiply_plain_poly: shard count mismatch");
    }

    for (std::size_t i = 0; i < destination_poly.shards.size(); ++i)
    {
        const auto &dst = destination_poly.shards[i];
        const auto &ct = ciphertext_poly.shards[i];
        const auto &plain = plaintext_poly.shards[i];

        if (dst.device_id != ct.device_id ||
            dst.device_id != plain.device_id ||
            dst.limb_begin != ct.limb_begin ||
            dst.limb_begin != plain.limb_begin ||
            dst.limb_count != ct.limb_count ||
            dst.limb_count != plain.limb_count ||
            dst.coeff_begin != ct.coeff_begin ||
            dst.coeff_begin != plain.coeff_begin ||
            dst.coeff_count != ct.coeff_count ||
            dst.coeff_count != plain.coeff_count)
        {
            throw std::invalid_argument("multiply_plain_poly: shard placement mismatch");
        }

        const GpuParameterShard *parameter_shard =
            find_parameter_shard(level_info, dst);

        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument("multiply_plain_poly: no matching parameter shard");
        }

        kernel::launch_dyadic_product_poly_shard(
            dst,
            ct,
            plain,
            *parameter_shard,
            level_info.degree);
    }
}

void GpuElementwiseHandler::multiply_accumulate_poly(
    GpuRNSPolyView &destination_poly,
    const GpuConstRNSPolyView &left_poly,
    const GpuConstRNSPolyView &right_poly,
    const GpuLevelInfo &level_info) const
{
    if (destination_poly.shards.size() != left_poly.shards.size() ||
        destination_poly.shards.size() != right_poly.shards.size())
    {
        throw std::invalid_argument("multiply_accumulate_poly: shard count mismatch");
    }

    for (std::size_t i = 0; i < destination_poly.shards.size(); ++i)
    {
        const auto &dst = destination_poly.shards[i];
        const auto &lhs = left_poly.shards[i];
        const auto &rhs = right_poly.shards[i];

        if (!same_shard_placement(dst, lhs) ||
            !same_shard_placement(dst, rhs))
        {
            throw std::invalid_argument("multiply_accumulate_poly: shard placement mismatch");
        }

        const GpuParameterShard *parameter_shard =
            find_parameter_shard(level_info, dst);

        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument("multiply_accumulate_poly: no matching parameter shard");
        }

        kernel::launch_multiply_accumulate_poly_shard(
            dst,
            lhs,
            rhs,
            *parameter_shard,
            level_info.degree);
    }
}

}  // namespace gpu
}  // namespace poseidon
