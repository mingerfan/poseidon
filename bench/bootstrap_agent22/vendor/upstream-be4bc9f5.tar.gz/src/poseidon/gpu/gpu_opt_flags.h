#pragma once

// A800 catch-up switches (2026-11-13). Every switch defaults to 0 (the
// committed behaviour) and is read from the environment. Host code reads a
// cached value; reload_opt_flags() re-reads the environment so one process
// can time several configurations after a single key/plaintext setup.

#include <atomic>
#include <cstdlib>

namespace poseidon::gpu
{

enum class OptFlag : int
{
    InplaceCheddarIntt = 0,   // POSEIDON_OPT_INPLACE_INTT: in-place INTT uses the Cheddar kernels
    ModupPreweight,           // POSEIDON_OPT_MODUP_PW: q^-1 weighting once per digit, hoisted indices
    ModupTile,                // POSEIDON_OPT_MODUP_TILE: targets per thread for the preweighted ModUp (4 or 8)
    PToQPreweight,            // POSEIDON_OPT_PTOQ_PW: P->Q weights folded into the P-part INTT (P > 9)
    LazyPlainMac,             // POSEIDON_OPT_LAZY_PMAC: lazy plaintext multiply-accumulate
    ShoupNtt,                 // POSEIDON_OPT_SHOUP_NTT: Shoup twiddle multiplication in the Cheddar N=65536 NTTs
    C1GroupNoPad,             // POSEIDON_OPT_C1_NOPAD: no padded copy for an odd giant-group count
    FusedRescale,             // POSEIDON_OPT_FUSED_RESCALE: rescale correction built/applied inside the NTT
    ModupFold,                // POSEIDON_OPT_MODUP_FOLD: ModUp q^-1 weights folded into the preceding INTT (needs MODUP_PW)
    LazyBaby,                 // POSEIDON_OPT_LAZY_BABY: lazy sums in the fused CtS level-1 baby keyswitch + plaintext MAC
    EvalModPair,              // POSEIDON_OPT_EVALMOD_PAIR: batch both degree-22 EvalMod DAGs
    SmallKernels,             // POSEIDON_OPT_SMALL_KERNELS: batch common componentwise operations
    BootRealOnly,             // POSEIDON_OPT_BOOT_REAL_ONLY: skip the imaginary EvalMod branch a final real projection discards
    ConvStreams,              // POSEIDON_OPT_CONV_STREAMS: N > 1 issues independent convolution groups on N CUDA streams
    ReluStreams,              // POSEIDON_OPT_RELU_STREAMS: N > 1 issues independent ReLU basis/tree work on N CUDA streams
    FusedBaby8,               // POSEIDON_OPT_FUSED_BABY8: extend fused baby KS + plain MAC up to 8 giant groups (C2S stages 2 & 3)
    RelinRescaleX1,           // POSEIDON_OPT_RELIN_RESCALE_X1: joint ModDown + single-prime rescale (including Chebyshev 2x ModDown)
    RelinRescalePair,         // POSEIDON_OPT_RELIN_RESCALE_PAIR: joint paired ModDown + post-op + 1/2-prime rescale in EvalMod
    PToQTile,                 // POSEIDON_OPT_PTOQ_TILE: max Q-targets per thread for single-component preweighted P->Q (4, 8, 12, 16)
    PToQDualTile,             // POSEIDON_OPT_PTOQ_DUAL_TILE: max Q-targets per thread for dual-component preweighted P->Q (4, 6, 8)
    FusedRelinRescale,        // POSEIDON_OPT_FUSED_RELIN_RESCALE: fuse relin_rescale (pair, x1, x2) merge+apply into Cheddar forward NTT phase1+phase2
    FusedModdown,             // POSEIDON_OPT_FUSED_MODDOWN: fuse ModDown apply into Cheddar forward NTT phase2 (1=!has_galois, 2=all)
    CoalescedNtt2,            // POSEIDON_OPT_COALESCED_NTT2: coalesced SMEM transpose for Radix-8 Cheddar NTT kernels
    SharedBabyItems,          // POSEIDON_OPT_SHARED_BABY_ITEMS: items (cache lines) per thread in shared_baby_keyswitch_plain_accumulate_kernel (1, 2, 4)
    VecBconv,                 // POSEIDON_OPT_VEC_BCONV: contiguous uint2 64-bit loads/stores in preweighted ModUp and P->Q
    UnifyP9,                  // POSEIDON_OPT_UNIFY_P9: route P=9 through generic preweighted BConv, Coalesced Radix-8 NTT, and FusedModdown
    Count
};

inline const char *opt_flag_env_name(OptFlag flag)
{
    switch (flag)
    {
    case OptFlag::InplaceCheddarIntt: return "POSEIDON_OPT_INPLACE_INTT";
    case OptFlag::ModupPreweight: return "POSEIDON_OPT_MODUP_PW";
    case OptFlag::ModupTile: return "POSEIDON_OPT_MODUP_TILE";
    case OptFlag::PToQPreweight: return "POSEIDON_OPT_PTOQ_PW";
    case OptFlag::LazyPlainMac: return "POSEIDON_OPT_LAZY_PMAC";
    case OptFlag::ShoupNtt: return "POSEIDON_OPT_SHOUP_NTT";
    case OptFlag::C1GroupNoPad: return "POSEIDON_OPT_C1_NOPAD";
    case OptFlag::FusedRescale: return "POSEIDON_OPT_FUSED_RESCALE";
    case OptFlag::ModupFold: return "POSEIDON_OPT_MODUP_FOLD";
    case OptFlag::LazyBaby: return "POSEIDON_OPT_LAZY_BABY";
    case OptFlag::EvalModPair: return "POSEIDON_OPT_EVALMOD_PAIR";
    case OptFlag::SmallKernels: return "POSEIDON_OPT_SMALL_KERNELS";
    case OptFlag::BootRealOnly: return "POSEIDON_OPT_BOOT_REAL_ONLY";
    case OptFlag::ConvStreams: return "POSEIDON_OPT_CONV_STREAMS";
    case OptFlag::ReluStreams: return "POSEIDON_OPT_RELU_STREAMS";
    case OptFlag::FusedBaby8: return "POSEIDON_OPT_FUSED_BABY8";
    case OptFlag::RelinRescaleX1: return "POSEIDON_OPT_RELIN_RESCALE_X1";
    case OptFlag::RelinRescalePair: return "POSEIDON_OPT_RELIN_RESCALE_PAIR";
    case OptFlag::PToQTile: return "POSEIDON_OPT_PTOQ_TILE";
    case OptFlag::PToQDualTile: return "POSEIDON_OPT_PTOQ_DUAL_TILE";
    case OptFlag::FusedRelinRescale: return "POSEIDON_OPT_FUSED_RELIN_RESCALE";
    case OptFlag::FusedModdown: return "POSEIDON_OPT_FUSED_MODDOWN";
    case OptFlag::CoalescedNtt2: return "POSEIDON_OPT_COALESCED_NTT2";
    case OptFlag::SharedBabyItems: return "POSEIDON_OPT_SHARED_BABY_ITEMS";
    case OptFlag::VecBconv: return "POSEIDON_OPT_VEC_BCONV";
    case OptFlag::UnifyP9: return "POSEIDON_OPT_UNIFY_P9";
    case OptFlag::Count: break;
    }
    return "";
}

inline std::atomic<int> g_opt_flag_values[static_cast<int>(OptFlag::Count)];
inline std::atomic<bool> g_opt_flags_loaded{false};

inline void reload_opt_flags()
{
    for (int i = 0; i < static_cast<int>(OptFlag::Count); ++i)
    {
        const char *raw = std::getenv(opt_flag_env_name(static_cast<OptFlag>(i)));
        const int value = (raw == nullptr || *raw == '\0') ? 0 : std::atoi(raw);
        g_opt_flag_values[i].store(value, std::memory_order_relaxed);
    }
    g_opt_flags_loaded.store(true, std::memory_order_release);
}

inline int opt_flag_value(OptFlag flag)
{
    if (!g_opt_flags_loaded.load(std::memory_order_acquire))
    {
        reload_opt_flags();
    }
    return g_opt_flag_values[static_cast<int>(flag)].load(std::memory_order_relaxed);
}

inline bool opt_flag(OptFlag flag)
{
    return opt_flag_value(flag) != 0;
}

}  // namespace poseidon::gpu
