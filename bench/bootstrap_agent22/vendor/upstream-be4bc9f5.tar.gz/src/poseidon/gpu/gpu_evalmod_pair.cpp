#include "poseidon/gpu/gpu_evaluator.h"
#include "poseidon/gpu/gpu_opt_flags.h"
#include "poseidon/gpu/gpu_scale_planner.h"
#include "poseidon/gpu/kernels/gpu_evalmod_pair_kernels.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <nvtx3/nvToolsExt.h>

namespace poseidon::gpu {
namespace {
using CT = GpuCiphertextData;
using Op = kernel::EvalModPairOp;

template<unsigned Branches>
void run_evalmod_chebyshev_dag(
    const GpuEvaluator &eval,
    const GpuParameterData &params,
    const std::array<const CT *,Branches> &sources,
    const GpuBootstrapData &data,
    const GpuRelinKeysData &keys,
    std::array<CT,Branches> &outputs)
{
    static_assert(Branches==1 || Branches==2);
    using Pack = std::array<CT,Branches>;
    using Inputs = std::array<const CT *,Branches>;

    const auto make_inputs=[](const Pack &p) {
        Inputs res{};
        for(unsigned b=0;b<Branches;++b)res[b]=&p[b];
        return res;
    };
    const auto empty_inputs=[]() {
        Inputs res{};
        for(unsigned b=0;b<Branches;++b)res[b]=nullptr;
        return res;
    };
    const auto set_scale=[](Pack &p,double scale) {
        if(scale>0)for(auto &ct:p)ct.meta.scale=scale;
    };
    const auto launch_op=[](Op op,const kernel::EvalModPairArgs &args,int dev) {
        if constexpr(Branches==2)kernel::launch_evalmod_pair(op,args,dev);
        else kernel::launch_evalmod_single(op,args,dev);
    };

    const auto &plan=data.eval_mod;
    const CT &first=*sources[0];
    const int device=first.fields_.at(0).device_id;
    const auto degree=first.meta.degree;
    const auto validate=[&](const CT &ct,std::size_t q) {
        if(ct.empty() || !ct.meta.is_ntt_form || ct.meta.p_count || ct.meta.degree!=degree ||
           ct.meta.q_count<q || ct.size()>3 || ct.meta.component_count!=ct.size())
            throw std::invalid_argument("EvalMod pair ciphertext shape mismatch");
        for(const auto &poly:ct.make_const_view().polys) {
            if(poly.shards.size()!=1)throw std::invalid_argument("EvalMod pair requires one full shard");
            const auto &s=poly.shards[0];
            if(s.device_id!=device || s.limb_begin || s.limb_count<q || s.coeff_begin || s.coeff_count!=degree)
                throw std::invalid_argument("EvalMod pair ciphertext shard mismatch");
        }
    };
    for(unsigned b=0;b<Branches;++b)validate(*sources[b],sources[b]->meta.q_count);

    const auto plain_ptr=[&](const GpuPlaintextData &plain,std::size_t q) {
        if(plain.empty() || !plain.meta.is_ntt_form || plain.meta.p_count ||
           plain.meta.degree!=degree || plain.meta.q_count<q)
            throw std::invalid_argument("EvalMod pair plaintext shape mismatch");
        const auto view=plain.make_const_view();
        if(view.poly.shards.size()!=1)throw std::invalid_argument("EvalMod pair plaintext shard count");
        const auto &s=view.poly.shards[0];
        if(s.device_id!=device || s.limb_begin || s.limb_count<q || s.coeff_begin || s.coeff_count!=degree)
            throw std::invalid_argument("EvalMod pair plaintext shard mismatch");
        return s.ptr;
    };
    const auto allocate=[&](std::size_t q,std::size_t components,double scale) {
        Pack result;
        for(auto &ct:result) {
            ct=CT::allocate_single_device(degree,q,components,device);
            ct.meta=first.meta;ct.meta.q_count=q;ct.meta.component_count=components;
            ct.meta.parms_id=params.get_level_by_q_count(q,0).parms_id;ct.meta.scale=scale;
        }
        return result;
    };
    const auto arguments=[&](Pack &out) {
        kernel::EvalModPairArgs args;
        const auto &level=params.get_level(out[0].meta.parms_id);
        if(level.shards.size()!=1 || level.shards[0].device_id!=device || level.shards[0].limb_begin)
            throw std::invalid_argument("EvalMod pair parameter shard mismatch");
        args.moduli=level.shards[0].q_primes.data();args.ratios=level.shards[0].q_modulus_constants.data();
        args.degree=degree;args.limbs=out[0].meta.q_count;args.components=out[0].size();
        for(unsigned b=0;b<Branches;++b) {
            const auto v=out[b].make_view();
            for(unsigned c=0;c<args.components;++c)args.out[b][c]=v.polys[c].shards[0].ptr;
        }
        return args;
    };
    const auto bind=[&](const Inputs &in,std::size_t q,const GpuWord *ptrs[2][3]) {
        for(unsigned b=0;b<Branches;++b) {
            validate(*in[b],q);const auto v=in[b]->make_const_view();
            for(unsigned c=0;c<v.polys.size();++c)ptrs[b][c]=v.polys[c].shards[0].ptr;
        }
    };
    const auto operation=[&](Op op,const Inputs &left,const Inputs &right,
                            std::size_t q,double scale,const GpuPlaintextData *plain=nullptr) {
        const unsigned components=op==Op::Multiply || op==Op::Square?3:
            (right[0]?std::max(left[0]->size(),right[0]->size()):left[0]->size());
        Pack out=allocate(q,components,scale);auto args=arguments(out);
        bind(left,q,args.left);args.left_components=left[0]->size();
        if(right[0]){bind(right,q,args.right);args.right_components=right[0]->size();}
        if(plain) {
            if(op==Op::MultiplyPlain)args.plain[0]=plain_ptr(*plain,q);
            else args.constant=plain_ptr(*plain,q);
        }
        launch_op(op,args,device);return out;
    };
    const auto binary=[&](Op op,const Pack &a,const Pack &b,double scale) {
        if(op==Op::Multiply && &a==&b)
            return operation(Op::Square,make_inputs(a),empty_inputs(),a[0].meta.q_count,scale);
        return operation(op,make_inputs(a),make_inputs(b),std::min(a[0].meta.q_count,b[0].meta.q_count),scale);
    };
    const auto multiply_plain_pack=[&](const Pack &a,const GpuPlaintextData &p,double scale) {
        return operation(Op::MultiplyPlain,make_inputs(a),empty_inputs(),p.meta.q_count,scale,&p);
    };
    const auto rescale_out=[&](const Pack &src,Pack &dst,std::uint32_t count) {
        if constexpr(Branches==2)eval.rescale_many_pair(src[0],src[1],dst[0],dst[1],count);
        else eval.rescale_many(src[0],dst[0],count);
    };
    const auto rescale_pack=[&](Pack &a,std::uint32_t count,double scale) {
        if(count)rescale_out(a,a,count);
        set_scale(a,scale);
    };
    const auto relin_pack=[&](Pack &a) {
        Pack out;
        if constexpr(Branches==2) {
            if(eval.try_relinearize_pair(a[0],a[1],keys,out[0],out[1]))return out;
        }
        for(unsigned b=0;b<Branches;++b)eval.relinearize(a[b],keys,out[b]);
        return out;
    };
    const auto try_relin_rescale_pack=[&](
        const Pack &src,std::uint32_t drop,PairRelinPostOp post_op,
        const GpuPlaintextData *plain,const Pack *extra,Pack &dst)->bool {
        if constexpr(Branches==2) {
            return eval.try_relinearize_rescale_pair(
                src[0],src[1],keys,drop,post_op,plain,
                extra?&(*extra)[0]:nullptr,extra?&(*extra)[1]:nullptr,
                dst[0],dst[1]);
        } else {
            return eval.try_relinearize_rescale_single(
                src[0],keys,drop,post_op,plain,
                extra?&(*extra)[0]:nullptr,dst[0]);
        }
    };
    const auto trim=[&](Pack &a,std::size_t q) {
        for(auto &ct:a) {
            if(q>ct.meta.q_count)throw std::invalid_argument("EvalMod pair output is below requested Q");
            ct.meta.q_count=q;ct.meta.parms_id=params.get_level_by_q_count(q,0).parms_id;
            for(auto &poly:ct.polys_){poly.q_count=q;poly.shards[0].limb_count=q;}
        }
    };
    nvtxRangePushA(Branches==2?"EvalMod paired DAG":"EvalMod single fast DAG");
    struct Range {~Range(){nvtxRangePop();}} range;
    std::size_t max_degree=1,max_node=plan.polynomial_blocks.size()-1;
    for(const auto &s:plan.basis_steps)max_degree=std::max(max_degree,std::size_t(s.output_degree));
    for(const auto &c:plan.polynomial_combine_steps)max_node=std::max(max_node,std::size_t(c.output_node));
    std::vector<Pack> basis(max_degree+1),nodes(max_node+1);
    const double target=plan.target_scale>0?plan.target_scale:data.eval_mod_target_scale;
    const double input_scale=plan.input_scale>0?plan.input_scale:target;
    if(!(target>0) || !std::isfinite(target) || !(input_scale>0) || !std::isfinite(input_scale))
        throw std::invalid_argument("EvalMod pair requires finite positive scales");
    const auto dynamic_drop_count=[&](const CT &sample,double pre_scale)->std::uint32_t {
        if(!(pre_scale>0.0) || !std::isfinite(pre_scale) || sample.meta.q_count<2)return 0;
        std::vector<std::uint64_t> active_moduli(sample.meta.q_count,0);
        parms_id_type cur=sample.meta.parms_id;
        while(true) {
            const auto &lvl=params.get_level(cur);
            if(lvl.q_count==0 || lvl.q_count>active_moduli.size() ||
               lvl.shards.empty() || lvl.shards.front().q_last==0)return 0;
            active_moduli[lvl.q_count-1]=lvl.shards.front().q_last;
            if(lvl.q_count==1)break;
            cur=params.get_next_level(cur).parms_id;
        }
        return plan_gpu_dynamic_rescale(pre_scale,target,active_moduli).rescale_count;
    };
    const auto *offset=plan.input_offset_plaintext.empty()?nullptr:&plan.input_offset_plaintext;
    basis[1]=operation(Op::Copy,sources,empty_inputs(),first.meta.q_count,input_scale,offset);
    for(const auto &step:plan.basis_steps) {
        const Pack *left=&basis.at(step.left_degree),*right=&basis.at(step.right_degree);
        Pack aligned;
        if(!step.operand_alignment_plaintext.empty()) {
            aligned=multiply_plain_pack(step.align_left_operand?*left:*right,
                step.operand_alignment_plaintext,step.operand_alignment_pre_rescale_scale);
            rescale_pack(aligned,step.operand_alignment_rescale_count,step.operand_alignment_output_scale);
            if(step.align_left_operand)left=&aligned;else right=&aligned;
        }
        auto product=binary(Op::Multiply,*left,*right,(*left)[0].meta.scale*(*right)[0].meta.scale);
        Pack out;
        bool fused_basis=false;
        if(opt_flag(OptFlag::RelinRescalePair)) {
            const auto drop=dynamic_drop_count(product[0],step.pre_rescale_scale);
            if(drop==1 || drop==2) {
                if(!step.correction_degree) {
                    fused_basis=try_relin_rescale_pack(
                        product,drop,PairRelinPostOp::DoubleSubPlain,
                        &step.correction_plaintext,nullptr,out);
                } else {
                    const auto &corr_basis=basis.at(step.correction_degree);
                    fused_basis=try_relin_rescale_pack(
                        product,drop,PairRelinPostOp::DoubleSubCipherPlain,
                        &step.correction_plaintext,&corr_basis,out);
                    if(!fused_basis) {
                        auto correction=multiply_plain_pack(corr_basis,
                            step.correction_plaintext,step.pre_rescale_scale);
                        fused_basis=try_relin_rescale_pack(
                            product,drop,PairRelinPostOp::DoubleSubCipher,
                            nullptr,&correction,out);
                        if(!fused_basis) {
                            out=relin_pack(product);set_scale(out,step.pre_rescale_scale);
                            out=binary(Op::DoubleSubtract,out,correction,step.pre_rescale_scale);
                            if(const auto d=dynamic_drop_count(out[0],out[0].meta.scale))
                                rescale_out(out,out,d);
                            fused_basis=true;
                        }
                    }
                }
            }
        }
        if(!fused_basis) {
            out=relin_pack(product);set_scale(out,step.pre_rescale_scale);
            if(!step.correction_degree)
                out=operation(Op::DoubleSubtractPlain,make_inputs(out),empty_inputs(),out[0].meta.q_count,
                    step.pre_rescale_scale,&step.correction_plaintext);
            else {
                auto correction=multiply_plain_pack(basis.at(step.correction_degree),
                    step.correction_plaintext,step.pre_rescale_scale);
                out=binary(Op::DoubleSubtract,out,correction,step.pre_rescale_scale);
            }
            if(const auto d=dynamic_drop_count(out[0],out[0].meta.scale))
                rescale_out(out,out,d);
        }
        set_scale(out,step.output_scale);basis.at(step.output_degree)=std::move(out);
    }
    for(std::size_t index=0;index<plan.polynomial_blocks.size();++index) {
        const auto &block=plan.polynomial_blocks[index];
        auto out=allocate(block.output_q_count,2,block.output_scale);auto args=arguments(out);
        for(const auto &term:block.terms) {
            if(!term.degree) {
                if(args.constant)throw std::invalid_argument("EvalMod pair repeated leaf constant");
                args.constant=plain_ptr(term.coefficient_plaintext,block.output_q_count);continue;
            }
            if(args.term_count>=4)throw std::invalid_argument("EvalMod pair leaf exceeds four terms");
            const auto &b=basis.at(term.degree);
            args.plain[args.term_count]=plain_ptr(term.coefficient_plaintext,block.output_q_count);
            for(unsigned branch=0;branch<Branches;++branch) {
                validate(b[branch],block.output_q_count);const auto v=b[branch].make_const_view();
                for(unsigned c=0;c<2;++c)args.terms[args.term_count][branch][c]=v.polys[c].shards[0].ptr;
            }
            ++args.term_count;
        }
        launch_op(Op::Leaf,args,device);nodes[index]=std::move(out);
    }
    std::vector<unsigned> uses(nodes.size());std::vector<bool> raw(nodes.size(),false);
    std::vector<unsigned> basis_uses(basis.size());
    for(const auto &c:plan.polynomial_combine_steps){++uses.at(c.quotient_node);++uses.at(c.remainder_node);++basis_uses.at(c.basis_degree);}
    for(const auto &c:plan.polynomial_combine_steps)
        if(c.remainder_node>=plan.polynomial_blocks.size() && uses[c.remainder_node]==1 &&
           !c.remainder_rescale_count && c.remainder_scale_plaintext.empty())raw[c.remainder_node]=true;
    std::vector<std::uint32_t> eager_combine_drop(nodes.size(),0);
    std::vector<double> eager_combine_scale(nodes.size(),0.0);
    std::vector<bool> node_prerescaled(nodes.size(),false);
    if(opt_flag(OptFlag::RelinRescalePair)) {
        for(const auto &parent:plan.polynomial_combine_steps) {
            if(parent.quotient_node!=parent.remainder_node) {
                if(parent.quotient_node>=plan.polynomial_blocks.size() &&
                   uses[parent.quotient_node]==1 && !raw[parent.quotient_node] &&
                   parent.quotient_node!=plan.polynomial_result_node &&
                   (parent.quotient_rescale_count==1 || parent.quotient_rescale_count==2)) {
                    eager_combine_drop[parent.quotient_node]=parent.quotient_rescale_count;
                    eager_combine_scale[parent.quotient_node]=parent.quotient_output_scale;
                }
                if(parent.remainder_node>=plan.polynomial_blocks.size() &&
                   uses[parent.remainder_node]==1 && !raw[parent.remainder_node] &&
                   parent.remainder_node!=plan.polynomial_result_node &&
                   (parent.remainder_rescale_count==1 || parent.remainder_rescale_count==2)) {
                    eager_combine_drop[parent.remainder_node]=parent.remainder_rescale_count;
                    eager_combine_scale[parent.remainder_node]=
                        parent.remainder_scale_plaintext.empty()?parent.remainder_aligned_scale:0.0;
                }
            }
        }
        const auto rn=plan.polynomial_result_node;
        if(rn>=plan.polynomial_blocks.size() && rn<nodes.size() && uses[rn]==0 && !raw[rn] &&
           (plan.polynomial_final_rescale_count==1 || plan.polynomial_final_rescale_count==2)) {
            eager_combine_drop[rn]=plan.polynomial_final_rescale_count;
            eager_combine_scale[rn]=plan.polynomial_output_scale;
        }
    }
    for(std::size_t i=0;i<basis.size();++i)if(!basis_uses[i])basis[i]=Pack{};
    for(const auto &c:plan.polynomial_combine_steps) {
        const Pack *quotient=&nodes.at(c.quotient_node);Pack q_rescaled;
        if(c.quotient_rescale_count && !node_prerescaled[c.quotient_node]) {
            rescale_out(*quotient,q_rescaled,c.quotient_rescale_count);
            set_scale(q_rescaled,c.quotient_output_scale);quotient=&q_rescaled;
        }
        if((*quotient)[0].size()!=2)throw std::invalid_argument("EvalMod pair raw quotient");
        const Pack *remainder=&nodes.at(c.remainder_node);Pack r_rescaled;
        if(c.remainder_rescale_count && !node_prerescaled[c.remainder_node]) {
            rescale_out(*remainder,r_rescaled,c.remainder_rescale_count);
            if(c.remainder_scale_plaintext.empty())set_scale(r_rescaled,c.remainder_aligned_scale);
            remainder=&r_rescaled;
        }
        std::size_t combine_q=std::min({(*quotient)[0].meta.q_count,
            basis.at(c.basis_degree)[0].meta.q_count,(*remainder)[0].meta.q_count});
        if(!c.product_scale_plaintext.empty())
            combine_q=std::min(combine_q,c.product_scale_plaintext.meta.q_count);
        if(!c.remainder_scale_plaintext.empty())
            combine_q=std::min(combine_q,c.remainder_scale_plaintext.meta.q_count);
        const auto rem_comps=(*remainder)[0].size();
        if(rem_comps<2 || rem_comps>3)
            throw std::invalid_argument("EvalMod pair combine remainder components");
        for(unsigned b=1;b<Branches;++b)
            if((*remainder)[b].size()!=rem_comps)
                throw std::invalid_argument("EvalMod pair combine remainder components");
        auto combined=allocate(combine_q,3,c.output_scale);
        auto args=arguments(combined);
        bind(make_inputs(*quotient),combine_q,args.left);
        bind(make_inputs(basis.at(c.basis_degree)),combine_q,args.right);
        args.term_count=static_cast<unsigned>(rem_comps);
        for(unsigned branch=0;branch<Branches;++branch) {
            validate((*remainder)[branch],combine_q);
            const auto rv=(*remainder)[branch].make_const_view();
            args.terms[0][branch][0]=rv.polys[0].shards[0].ptr;
            args.terms[0][branch][1]=rv.polys[1].shards[0].ptr;
            if(rem_comps==3)args.terms[1][branch][0]=rv.polys[2].shards[0].ptr;
        }
        if(!c.product_scale_plaintext.empty())
            args.plain[0]=plain_ptr(c.product_scale_plaintext,combine_q);
        if(!c.remainder_scale_plaintext.empty())
            args.plain[1]=plain_ptr(c.remainder_scale_plaintext,combine_q);
        launch_op(Op::Combine,args,device);
        if(!raw[c.output_node]) {
            const auto drop=eager_combine_drop[c.output_node];
            Pack fused_out;
            if((drop==1 || drop==2) &&
               try_relin_rescale_pack(
                   combined,drop,PairRelinPostOp::AddBackOnly,
                   nullptr,nullptr,fused_out)) {
                set_scale(fused_out,eager_combine_scale[c.output_node]);
                combined=std::move(fused_out);
                node_prerescaled[c.output_node]=true;
            } else {
                combined=relin_pack(combined);
                set_scale(combined,c.output_scale);
            }
        } else {
            set_scale(combined,c.output_scale);
        }
        nodes.at(c.output_node)=std::move(combined);
        if(!--uses[c.quotient_node])nodes[c.quotient_node]=Pack{};
        if(!--uses[c.remainder_node])nodes[c.remainder_node]=Pack{};
        if(!--basis_uses[c.basis_degree])basis[c.basis_degree]=Pack{};
    }
    auto accumulator=std::move(nodes.at(plan.polynomial_result_node));
    if(!node_prerescaled[plan.polynomial_result_node])
        rescale_pack(accumulator,plan.polynomial_final_rescale_count,plan.polynomial_output_scale);
    for(std::size_t i=0;i<plan.double_angle_constants.size();++i) {
        auto square=binary(Op::Multiply,accumulator,accumulator,
            accumulator[0].meta.scale*accumulator[0].meta.scale);
        const auto &constant=plan.double_angle_constants[i];
        const auto count=i<plan.double_angle_rescale_counts.size()?
            std::max(plan.double_angle_rescale_counts[i],std::uint32_t{1}):std::max(plan.logical_rescale_count,std::uint32_t{1});
        Pack fused_da;
        if(opt_flag(OptFlag::RelinRescalePair) && (count==1 || count==2) &&
           try_relin_rescale_pack(
               square,count,PairRelinPostOp::DoubleAddPlain,
               constant.empty()?nullptr:&constant,nullptr,fused_da)) {
            accumulator=std::move(fused_da);
            continue;
        }
        auto product=relin_pack(square);
        accumulator=operation(Op::DoubleAddPlain,make_inputs(product),empty_inputs(),
            product[0].meta.q_count,product[0].meta.scale,constant.empty()?nullptr:&constant);
        rescale_pack(accumulator,count,0);
    }
    if(plan.output_parms_id!=parms_id_zero)trim(accumulator,plan.output_q_count);
    set_scale(accumulator,plan.output_scale);
    for(unsigned b=0;b<Branches;++b)outputs[b]=std::move(accumulator[b]);
}
} // namespace

void GpuEvaluator::eval_mod_high_precision_pair(
    const CT &real,const CT &imag,const GpuBootstrapData &data,
    const GpuRelinKeysData &keys,CT &out_real,CT &out_imag) const
{
    const auto &plan=data.eval_mod;
    if(!plan.dynamic_rescale || plan.polynomial_degree!=22 ||
       plan.polynomial_basis!=GpuEvalModPolynomialBasis::Chebyshev ||
       plan.polynomial_blocks.empty() || plan.rescale_polynomial_terms_individually)
        throw std::invalid_argument("EvalMod pair requires the dynamic degree-22 Chebyshev block plan");
    for(const auto &block:plan.polynomial_blocks)
        if(block.rescale_count!=0 || block.output_q_count==0 || block.terms.empty() || block.terms.size()>5)
            throw std::invalid_argument("EvalMod pair requires unrescaled leaves with at most four nonconstant terms");
    for(const auto &step:plan.polynomial_combine_steps)
        if(!step.output_q_count || step.output_q_count!=step.product_q_count)
            throw std::invalid_argument("EvalMod pair requires the lazy dynamic combine plan");
    if(real.empty() || imag.empty() || real.size()!=2 || imag.size()!=2 ||
       real.meta.parms_id!=imag.meta.parms_id || real.meta.scale!=imag.meta.scale)
        throw std::invalid_argument("EvalMod pair input metadata mismatch");

    std::array<CT,2> outputs;
    run_evalmod_chebyshev_dag<2>(*this,params_,{&real,&imag},data,keys,outputs);
    out_real=std::move(outputs[0]);
    out_imag=std::move(outputs[1]);
}

bool GpuEvaluator::try_eval_mod_high_precision_fast(
    const CT &source,const GpuBootstrapData &data,
    const GpuRelinKeysData &keys,CT &out) const
{
    const auto &plan=data.eval_mod;
    if(!plan.dynamic_rescale || plan.polynomial_degree!=22 ||
       plan.polynomial_basis!=GpuEvalModPolynomialBasis::Chebyshev ||
       plan.polynomial_blocks.empty() || plan.basis_steps.empty() ||
       plan.rescale_polynomial_terms_individually)
        return false;
    if(plan.double_angle_constants.empty() && !data.double_angle_plaintexts.empty())
        return false;
    if(plan.input_offset_plaintext.empty() && !data.eval_mod_input_offset_plaintext.empty())
        return false;
    for(const auto &block:plan.polynomial_blocks)
        if(block.rescale_count!=0 || block.output_q_count==0 || block.terms.empty() || block.terms.size()>5)
            return false;
    for(const auto &step:plan.polynomial_combine_steps)
        if(!step.output_q_count || step.output_q_count!=step.product_q_count)
            return false;
    const double target=plan.target_scale>0?plan.target_scale:data.eval_mod_target_scale;
    const double input_scale=plan.input_scale>0?plan.input_scale:target;
    if(!(target>0) || !std::isfinite(target) || !(input_scale>0) || !std::isfinite(input_scale))
        return false;
    if(source.empty() || source.fields_.empty() || !source.meta.is_ntt_form ||
       source.meta.p_count!=0 || source.size()!=2 || source.meta.component_count!=2 ||
       source.meta.degree!=65536)
        return false;
    const int device=source.fields_.front().device_id;
    for(const auto &poly:source.make_const_view().polys) {
        if(poly.shards.size()!=1)return false;
        const auto &s=poly.shards[0];
        if(s.device_id!=device || s.limb_begin!=0 || s.limb_count<source.meta.q_count ||
           s.coeff_begin!=0 || s.coeff_count!=65536)
            return false;
    }
    const auto &src_level=params_.get_level(source.meta.parms_id);
    if(src_level.shards.size()!=1 || src_level.shards[0].device_id!=device || src_level.shards[0].limb_begin!=0)
        return false;

    std::array<CT,1> outputs;
    run_evalmod_chebyshev_dag<1>(*this,params_,{&source},data,keys,outputs);
    out=std::move(outputs[0]);
    return true;
}
} // namespace poseidon::gpu
