#include "poseidon/gpu/gpu_evaluator.h"
#include "poseidon/gpu/gpu_opt_flags.h"
#include "poseidon/gpu/gpu_scale_planner.h"
#include "poseidon/gpu/kernels/gpu_double_hoist_kernels.h"
#include "poseidon/gpu/kernels/gpu_elementwise_kernels.h"
#include "poseidon/gpu/kernels/gpu_keyswitch_kernels.h"
#include "poseidon/gpu/kernels/gpu_ntt_kernels.h"

#include "poseidon/advance/homomorphic_linear_transform.h"

#include <nvtx3/nvToolsExt.h>

#include <stdexcept>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <limits>
#include <map>
#include <functional>
#include <string>
#include <utility>

namespace poseidon
{
namespace gpu
{

namespace
{

class NvtxRange
{
public:
    explicit NvtxRange(const char *name)
    {
        nvtxRangePushA(name);
    }

    NvtxRange(const NvtxRange &) = delete;
    NvtxRange &operator=(const NvtxRange &) = delete;

    ~NvtxRange()
    {
        nvtxRangePop();
    }
};

bool same_scale(double a, double b)
{
    const double tolerance =
        1e-6 * std::max({1.0, std::abs(a), std::abs(b)});
    return std::abs(a - b) <= tolerance;
}

bool use_rescale_x2()
{
    const char *raw = std::getenv("POSEIDON_RESCALE_X2");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_relinearize_rescale_x2()
{
    const char *raw = std::getenv("POSEIDON_RELIN_RESCALE_X2");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_direct_giant_accumulate()
{
    const char *raw =
        std::getenv("POSEIDON_DOUBLE_HOIST_DIRECT_GIANT_ACCUMULATE");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

// The key a key switch at this ciphertext's level uses: its per-level
// override when the key carries one (level-aware special modulus), checked
// against the level's own P so a key and a level built for different special
// moduli never meet silently.
const GpuEvaluationKeyData &level_key_for(
    const GpuParameterData &params,
    const GpuEvaluationKeyData &keys,
    const GpuCiphertextMeta &meta,
    const char *name)
{
    const auto &selected = keys.for_level(meta.q_count);
    if (selected.meta.p_count == 0 || meta.q_count == 0)
    {
        return selected;  // empty input: the entry point's own validation reports it
    }
    const GpuLevelInfo *found = nullptr;
    try
    {
        found = &params.get_level(meta.parms_id);
    }
    catch (const std::out_of_range &)
    {
        return selected;
    }
    const auto &level = *found;
    if (!level.shards.empty() && level.shards.front().hybrid_base_p_count != 0 &&
        level.shards.front().hybrid_base_p_count != selected.meta.p_count)
    {
        throw std::invalid_argument(
            std::string(name) + ": key special modulus (P=" +
            std::to_string(selected.meta.p_count) + ") differs from level q" +
            std::to_string(meta.q_count) + " (P=" +
            std::to_string(level.shards.front().hybrid_base_p_count) + ")");
    }
    return selected;
}

// Keep c0 of every giant group in QP (Lattigo's layout): only c1 of the
// non-identity groups is moved down to Q for the giant key switch, and the
// giant accumulation reads c0 straight from the QP group accumulators. This
// removes group_count + 1 of the 2 * group_count inner ModDown components.
// On by default (Boot -7% on the 4090, same errors); POSEIDON_DOUBLE_HOIST_QP_C0=0
// restores the lifted path, whose rounding differs.
bool use_double_hoist_qp_c0()
{
    const char *raw = std::getenv("POSEIDON_DOUBLE_HOIST_QP_C0");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_qp_mac_direct_init()
{
    const char *raw =
        std::getenv("POSEIDON_DOUBLE_HOIST_QP_MAC_DIRECT_INIT");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_fused_baby_keyswitch_c0()
{
    const char *raw = std::getenv(
        "POSEIDON_DOUBLE_HOIST_FUSED_BABY_KEYSWITCH_C0");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_fused_baby_keyswitch_plain_mac()
{
    const char *raw = std::getenv(
        "POSEIDON_DOUBLE_HOIST_FUSED_BABY_KEYSWITCH_PLAIN_MAC");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_batched_giant_intt()
{
    const char *raw = std::getenv(
        "POSEIDON_DOUBLE_HOIST_BATCHED_GIANT_INTT");
    bool enabled = true;
    if (raw != nullptr && *raw != '\0')
    {
        const std::string value(raw);
        enabled = value != "0" &&
                  value != "OFF" &&
                  value != "off" &&
                  value != "false" &&
                  value != "FALSE";
    }
    if (!enabled)
    {
        return false;
    }

    const char *ntt_raw = std::getenv("POSEIDON_NTT_ALGO");
    if (ntt_raw == nullptr || *ntt_raw == '\0')
    {
        return true;
    }
    const std::string ntt_value(ntt_raw);
    return ntt_value == "fourstep" ||
           ntt_value == "four_step" ||
           ntt_value == "cheddar";
}

bool use_evalmod_inline_leaf()
{
    const char *raw = std::getenv("POSEIDON_EVALMOD_INLINE_LEAF");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_evalmod_lazy_relinearization()
{
    const char *raw = std::getenv("POSEIDON_EVALMOD_LAZY_RELIN");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_evalmod_caccum_leaf()
{
    const char *raw = std::getenv("POSEIDON_EVALMOD_CACCUM_LEAF");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_evalmod_d2d_free_dataflow()
{
    const char *raw = std::getenv("POSEIDON_EVALMOD_D2D_FREE_DATAFLOW");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_evalmod_zero_copy_moddrop()
{
    const char *raw = std::getenv("POSEIDON_EVALMOD_ZERO_COPY_MODDROP");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_evalmod_q_prefix_views()
{
    const char *raw = std::getenv("POSEIDON_EVALMOD_Q_PREFIX_VIEWS");
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }
    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

class EvalModStageEventRecorder
{
public:
    explicit EvalModStageEventRecorder(bool enabled)
        : enabled_(enabled)
    {
        if (!enabled_)
        {
            return;
        }
        try
        {
            for (auto &event : events_)
            {
                gpu_check_cuda(
                    cudaEventCreate(&event),
                    "EvalMod stage cudaEventCreate");
                ++created_count_;
            }
            record(0);
        }
        catch (...)
        {
            destroy_events();
            throw;
        }
    }

    EvalModStageEventRecorder(const EvalModStageEventRecorder &) = delete;
    EvalModStageEventRecorder &operator=(
        const EvalModStageEventRecorder &) = delete;

    ~EvalModStageEventRecorder()
    {
        destroy_events();
    }

    void record(std::size_t boundary)
    {
        if (!enabled_)
        {
            return;
        }
        if (boundary >= events_.size())
        {
            throw std::out_of_range("EvalMod stage boundary is out of range");
        }
        gpu_check_cuda(
            cudaEventRecord(events_[boundary]),
            "EvalMod stage cudaEventRecord");
    }

    void finish(GpuBootstrapWorkspace::EvalModStageTiming &timing)
    {
        if (!enabled_)
        {
            return;
        }
        record(6);
        gpu_check_cuda(
            cudaEventSynchronize(events_[6]),
            "EvalMod stage cudaEventSynchronize");

        timing.input_preparation_ms = elapsed(0, 1);
        timing.basis_generation_ms = elapsed(1, 2);
        timing.leaf_evaluation_ms = elapsed(2, 3);
        timing.bsgs_combine_ms = elapsed(3, 4);
        timing.double_angle_ms = elapsed(4, 5);
        timing.output_alignment_ms = elapsed(5, 6);
        timing.total_ms = elapsed(0, 6);
    }

private:
    double elapsed(std::size_t begin, std::size_t end) const
    {
        float milliseconds = 0.0F;
        gpu_check_cuda(
            cudaEventElapsedTime(
                &milliseconds,
                events_[begin],
                events_[end]),
            "EvalMod stage cudaEventElapsedTime");
        return static_cast<double>(milliseconds);
    }

    void destroy_events() noexcept
    {
        for (std::size_t index = 0; index < created_count_; ++index)
        {
            (void)cudaEventDestroy(events_[index]);
            events_[index] = nullptr;
        }
        created_count_ = 0;
    }

    bool enabled_{false};
    std::array<cudaEvent_t, 7> events_{};
    std::size_t created_count_{0};
};

class EvalModMultiplyEventRecorder
{
public:
    explicit EvalModMultiplyEventRecorder(bool enabled)
        : enabled_(enabled)
    {}

    EvalModMultiplyEventRecorder(const EvalModMultiplyEventRecorder &) = delete;
    EvalModMultiplyEventRecorder &operator=(
        const EvalModMultiplyEventRecorder &) = delete;

    ~EvalModMultiplyEventRecorder()
    {
        for (auto &entry : entries_)
        {
            if (entry.begin != nullptr)
            {
                (void)cudaEventDestroy(entry.begin);
            }
            if (entry.end != nullptr)
            {
                (void)cudaEventDestroy(entry.end);
            }
        }
    }

    void begin(
        std::string label,
        std::size_t q_count,
        std::size_t p_count,
        bool is_square)
    {
        if (!enabled_)
        {
            return;
        }
        if (active_)
        {
            throw std::logic_error(
                "EvalMod multiply timing ranges cannot overlap");
        }
        Entry entry;
        entry.timing.label = std::move(label);
        entry.timing.q_count = q_count;
        entry.timing.decomposition_count = p_count == 0
            ? 0
            : (q_count + p_count - 1) / p_count;
        entry.timing.is_square = is_square;
        gpu_check_cuda(
            cudaEventCreate(&entry.begin),
            "EvalMod multiply begin cudaEventCreate");
        try
        {
            gpu_check_cuda(
                cudaEventCreate(&entry.end),
                "EvalMod multiply end cudaEventCreate");
            gpu_check_cuda(
                cudaEventRecord(entry.begin),
                "EvalMod multiply begin cudaEventRecord");
            nvtxRangePushA(entry.timing.label.c_str());
            entries_.push_back(std::move(entry));
            entry.begin = nullptr;
            entry.end = nullptr;
            active_ = true;
        }
        catch (...)
        {
            if (entry.begin != nullptr)
            {
                (void)cudaEventDestroy(entry.begin);
            }
            if (entry.end != nullptr)
            {
                (void)cudaEventDestroy(entry.end);
            }
            throw;
        }
    }

    void end()
    {
        if (!enabled_)
        {
            return;
        }
        if (!active_ || entries_.empty())
        {
            throw std::logic_error(
                "EvalMod multiply timing range is not active");
        }
        gpu_check_cuda(
            cudaEventRecord(entries_.back().end),
            "EvalMod multiply end cudaEventRecord");
        nvtxRangePop();
        active_ = false;
    }

    void finish(
        std::vector<GpuBootstrapWorkspace::EvalModMultiplyTiming> &timings)
    {
        if (!enabled_)
        {
            return;
        }
        if (active_)
        {
            throw std::logic_error(
                "EvalMod multiply timing range was not closed");
        }
        timings.clear();
        timings.reserve(entries_.size());
        if (!entries_.empty())
        {
            gpu_check_cuda(
                cudaEventSynchronize(entries_.back().end),
                "EvalMod multiply cudaEventSynchronize");
        }
        for (const auto &entry : entries_)
        {
            float milliseconds = 0.0F;
            gpu_check_cuda(
                cudaEventElapsedTime(
                    &milliseconds,
                    entry.begin,
                    entry.end),
                "EvalMod multiply cudaEventElapsedTime");
            auto timing = entry.timing;
            timing.gpu_ms = static_cast<double>(milliseconds);
            timings.push_back(std::move(timing));
        }
    }

private:
    struct Entry
    {
        GpuBootstrapWorkspace::EvalModMultiplyTiming timing;
        cudaEvent_t begin{nullptr};
        cudaEvent_t end{nullptr};
    };

    bool enabled_{false};
    bool active_{false};
    std::vector<Entry> entries_;
};

bool same_logical_shard_layout(
    const GpuRNSPoly &reference,
    const GpuRNSPoly &candidate)
{
    if (reference.shards.size() != candidate.shards.size())
    {
        return false;
    }

    for (std::size_t i = 0; i < reference.shards.size(); ++i)
    {
        const auto &lhs = reference.shards[i];
        const auto &rhs = candidate.shards[i];
        if (lhs.limb_begin != rhs.limb_begin ||
            lhs.limb_count != rhs.limb_count ||
            lhs.coeff_begin != rhs.coeff_begin ||
            lhs.coeff_count != rhs.coeff_count)
        {
            return false;
        }
    }

    return true;
}

bool all_components_use_layout(
    const GpuCiphertextData &ciphertext,
    const GpuRNSPoly &reference)
{
    for (const auto &poly : ciphertext.polys_)
    {
        if (!same_logical_shard_layout(reference, poly))
        {
            return false;
        }
    }

    return true;
}

void validate_q_prefix_source(
    const char *name,
    const GpuCiphertextData &source,
    const GpuLevelInfo &source_level,
    const GpuLevelInfo &target_level)
{
    if (source.empty() || source.fields_.size() != 1)
    {
        throw std::invalid_argument(std::string(name) +
                                    ": requires single-device ciphertext storage");
    }
    if (!source.meta.is_ntt_form ||
        source.meta.p_count != 0 ||
        source.meta.component_count != source.size() ||
        source_level.q_count != source.meta.q_count ||
        target_level.p_count != 0 ||
        target_level.q_count == 0 ||
        target_level.q_count > source.meta.q_count ||
        target_level.degree != source.meta.degree)
    {
        throw std::invalid_argument(std::string(name) +
                                    ": incompatible Q-prefix metadata");
    }
    for (const auto &poly : source.polys_)
    {
        if (poly.degree != source.meta.degree ||
            poly.q_count != source.meta.q_count ||
            poly.p_count != 0 ||
            poly.shards.size() != 1)
        {
            throw std::invalid_argument(std::string(name) +
                                        ": unsupported component layout");
        }
        const auto &shard = poly.shards.front();
        if (shard.field_index != 0 ||
            shard.limb_begin != 0 ||
            shard.limb_count != source.meta.q_count ||
            shard.coeff_begin != 0 ||
            shard.coeff_count != source.meta.degree)
        {
            throw std::invalid_argument(std::string(name) +
                                        ": requires one full q shard");
        }
    }
}

GpuConstCiphertextView make_q_prefix_view(
    const GpuCiphertextData &source,
    const GpuLevelInfo &target_level)
{
    auto view = source.make_const_view();
    view.meta.parms_id = target_level.parms_id;
    view.meta.q_count = target_level.q_count;
    view.meta.p_count = 0;
    for (auto &poly : view.polys)
    {
        poly.shards.front().limb_count = target_level.q_count;
    }
    return view;
}

GpuRNSPoly make_q_prefix_layout(
    const GpuCiphertextData &source,
    const GpuLevelInfo &target_level)
{
    GpuRNSPoly layout = source.polys_.front();
    layout.q_count = target_level.q_count;
    layout.p_count = 0;
    layout.shards.front().limb_count = target_level.q_count;
    return layout;
}

bool ciphertext_storage_matches(
    const GpuCiphertextData &ciphertext,
    std::size_t degree,
    std::size_t q_count,
    std::size_t p_count,
    std::size_t component_count,
    int device_id,
    const GpuRNSPoly &reference_layout)
{
    if (ciphertext.empty() ||
        ciphertext.fields_.empty() ||
        ciphertext.size() != component_count)
    {
        return false;
    }
    if (ciphertext.fields_.front().device_id != device_id)
    {
        return false;
    }
    for (const auto &poly : ciphertext.polys_)
    {
        if (poly.degree != degree ||
            poly.q_count != q_count ||
            poly.p_count != p_count ||
            !same_logical_shard_layout(reference_layout, poly))
        {
            return false;
        }
    }
    return true;
}

void prepare_ciphertext_destination(
    GpuCiphertextData &destination,
    const GpuCiphertextData *alias_source0,
    const GpuCiphertextData *alias_source1,
    const GpuCiphertextMeta &meta,
    std::size_t component_count,
    int device_id,
    const GpuRNSPoly &reference_layout)
{
    const bool aliases_input =
        &destination == alias_source0 ||
        (alias_source1 != nullptr && &destination == alias_source1);
    if (aliases_input ||
        !ciphertext_storage_matches(
            destination,
            meta.degree,
            meta.q_count,
            meta.p_count,
            component_count,
            device_id,
            reference_layout))
    {
        destination =
            GpuCiphertextData::allocate_single_device_sharded(
                meta.degree,
                meta.q_count,
                component_count,
                device_id,
                reference_layout.shards,
                meta.p_count);
    }

    destination.meta = meta;
    destination.meta.component_count = component_count;
}

std::size_t checked_mul(std::size_t a, std::size_t b, const char *what)
{
    if (a != 0 && b > std::numeric_limits<std::size_t>::max() / a)
    {
        throw std::overflow_error(what);
    }
    return a * b;
}

void validate_ntt_ciphertext_input(
    const char *name,
    const GpuCiphertextData &source_ciphertext,
    bool expect_ntt_form)
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument(std::string(name) + ": empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument(std::string(name) + ": empty ciphertext storage");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument(std::string(name) + ": component metadata mismatch");
    }
    if (source_ciphertext.meta.is_ntt_form != expect_ntt_form)
    {
        throw std::invalid_argument(std::string(name) + ": NTT form mismatch");
    }
    if (source_ciphertext.meta.degree == 0 ||
        source_ciphertext.meta.q_count + source_ciphertext.meta.p_count == 0)
    {
        throw std::invalid_argument(std::string(name) + ": invalid ciphertext shape");
    }

    const auto &reference_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument(std::string(name) + ": shard layout mismatch");
    }
}

void zero_poly(
    GpuRNSPolyView &poly,
    const char *name)
{
    for (const auto &shard : poly.shards)
    {
        const std::size_t word_count = checked_mul(
            shard.limb_count,
            shard.coeff_count,
            "GpuEvaluator zero word count overflow");
        gpu_check_cuda(cudaSetDevice(shard.device_id), name);
        gpu_check_cuda(
            cudaMemsetAsync(
                shard.ptr,
                0,
                word_count * sizeof(GpuWord),
                gpu_execution_stream()),
            name);
    }
}

void copy_poly(
    GpuRNSPolyView &destination,
    const GpuConstRNSPolyView &source,
    const char *name)
{
    if (destination.shards.size() != source.shards.size())
    {
        throw std::invalid_argument(std::string(name) + ": shard count mismatch");
    }

    for (std::size_t i = 0; i < destination.shards.size(); ++i)
    {
        const auto &dst = destination.shards[i];
        const auto &src = source.shards[i];
        if (dst.device_id != src.device_id ||
            dst.limb_begin != src.limb_begin ||
            dst.limb_count != src.limb_count ||
            dst.coeff_begin != src.coeff_begin ||
            dst.coeff_count != src.coeff_count)
        {
            throw std::invalid_argument(std::string(name) + ": shard placement mismatch");
        }

        const std::size_t word_count = checked_mul(
            dst.limb_count,
            dst.coeff_count,
            "GpuEvaluator copy word count overflow");
        gpu_check_cuda(cudaSetDevice(dst.device_id), name);
        gpu_check_cuda(
            cudaMemcpyAsync(
                dst.ptr,
                src.ptr,
                word_count * sizeof(GpuWord),
                cudaMemcpyDeviceToDevice,
                gpu_execution_stream()),
            name);
    }
}

void copy_ciphertext_data(
    const GpuCiphertextData &source,
    GpuCiphertextData &destination,
    const char *name)
{
    if (source.empty())
    {
        throw std::invalid_argument(std::string(name) + ": empty source");
    }
    if (source.fields_.empty())
    {
        throw std::invalid_argument(std::string(name) + ": empty source storage");
    }
    if (source.meta.component_count != source.size())
    {
        throw std::invalid_argument(std::string(name) + ": component metadata mismatch");
    }

    const auto &reference_layout = source.polys_.at(0);
    if (!all_components_use_layout(source, reference_layout))
    {
        throw std::invalid_argument(std::string(name) + ": shard layout mismatch");
    }

    const int device_id = source.fields_.at(0).device_id;
    prepare_ciphertext_destination(
        destination,
        &source,
        nullptr,
        source.meta,
        source.meta.component_count,
        device_id,
        reference_layout);

    auto dst_view = destination.make_view();
    auto src_view = source.make_const_view();
    if (dst_view.polys.size() != src_view.polys.size())
    {
        throw std::invalid_argument(std::string(name) + ": component count mismatch");
    }
    for (std::size_t component = 0; component < src_view.polys.size(); ++component)
    {
        copy_poly(dst_view.polys[component], src_view.polys[component], name);
    }
    destination.meta = source.meta;
}

std::uint32_t galois_elt_from_rotation_step(
    std::size_t degree,
    int step)
{
    if (degree == 0 || degree > static_cast<std::size_t>(
            std::numeric_limits<std::uint32_t>::max() / 2))
    {
        throw std::invalid_argument("GpuEvaluator::rotate: invalid degree");
    }
    if ((degree & (degree - 1)) != 0)
    {
        throw std::invalid_argument("GpuEvaluator::rotate: degree must be a power of two");
    }

    const std::uint32_t n = static_cast<std::uint32_t>(degree);
    const std::uint32_t m32 = n << 1;
    const std::uint64_t m = static_cast<std::uint64_t>(m32);

    if (step == 0)
    {
        return m32 - 1;
    }

    const bool negative = step < 0;
    const std::int64_t signed_step = static_cast<std::int64_t>(step);
    const std::uint64_t abs_step = negative
        ? static_cast<std::uint64_t>(-signed_step)
        : static_cast<std::uint64_t>(signed_step);

    if (abs_step >= (static_cast<std::uint64_t>(n) >> 1))
    {
        throw std::invalid_argument("GpuEvaluator::rotate: step count too large");
    }

    std::uint32_t rotation_count = static_cast<std::uint32_t>(abs_step);
    if (negative)
    {
        rotation_count = (n >> 1) - rotation_count;
    }

    /* 与 Poseidon::util::GaloisTool::generator_ 保持一致。 */
    constexpr std::uint64_t generator = 5;
    std::uint64_t galois_elt = 1;
    while (rotation_count-- != 0)
    {
        galois_elt *= generator;
        galois_elt &= m - 1;
    }
    return static_cast<std::uint32_t>(galois_elt);
}

std::size_t galois_key_index(std::uint32_t galois_elt)
{
    if ((galois_elt & 1U) == 0U)
    {
        throw std::invalid_argument("GpuEvaluator::rotate: invalid Galois element");
    }
    return static_cast<std::size_t>((galois_elt - 1U) >> 1U);
}

std::uint32_t galois_elt_for_conjugation(std::size_t degree)
{
    if (degree == 0 || degree > static_cast<std::size_t>(
            std::numeric_limits<std::uint32_t>::max() / 2))
    {
        throw std::invalid_argument("GpuEvaluator::conjugate: invalid degree");
    }
    if ((degree & (degree - 1)) != 0)
    {
        throw std::invalid_argument("GpuEvaluator::conjugate: degree must be a power of two");
    }

    return static_cast<std::uint32_t>((static_cast<std::uint64_t>(degree) << 1) - 1);
}

}  // namespace

GpuLooseBsgsPlan make_gpu_loose_bsgs_plan(
    const GpuMatrixPlain &matrix)
{
    if (matrix.plain_vec.empty())
    {
        throw std::invalid_argument(
            "make_gpu_loose_bsgs_plan: empty diagonal matrix");
    }
    if (matrix.n1 == 0)
    {
        throw std::invalid_argument(
            "make_gpu_loose_bsgs_plan: invalid BSGS n1");
    }
    if (matrix.log_slots >=
        static_cast<std::uint32_t>(std::numeric_limits<int>::digits))
    {
        throw std::invalid_argument(
            "make_gpu_loose_bsgs_plan: log_slots exceeds int range");
    }

    const auto [index, unused_rot_n1, baby_steps] =
        poseidon::bsgs_index(
            matrix.plain_vec,
            1 << matrix.log_slots,
            static_cast<int>(matrix.n1));
    (void)unused_rot_n1;

    GpuLooseBsgsPlan plan;
    plan.baby_steps = baby_steps;
    plan.groups.reserve(index.size());
    for (const auto &giant_entry : index)
    {
        GpuLooseBsgsGroup group;
        group.giant_step = giant_entry.first;
        group.terms.reserve(giant_entry.second.size());
        for (const int baby_step : giant_entry.second)
        {
            const int diagonal_index = group.giant_step + baby_step;
            if (matrix.plain_vec.find(diagonal_index) ==
                matrix.plain_vec.end())
            {
                throw std::invalid_argument(
                    "make_gpu_loose_bsgs_plan: missing plaintext diagonal");
            }
            group.terms.push_back(
                GpuLooseBsgsTerm{baby_step, diagonal_index});
        }
        if (!group.terms.empty())
        {
            plan.groups.push_back(std::move(group));
        }
    }
    if (plan.groups.empty())
    {
        throw std::invalid_argument(
            "make_gpu_loose_bsgs_plan: no nonzero diagonal contribution");
    }
    return plan;
}

std::vector<GpuEvalModBasisStep> make_gpu_eval_mod_basis_plan(
    GpuEvalModPolynomialBasis basis,
    const std::vector<std::uint32_t> &requested_degrees,
    std::uint32_t preferred_giant_stride)
{
    std::vector<GpuEvalModBasisStep> steps;
    std::map<std::uint32_t, bool> available;
    available.emplace(0, true);
    available.emplace(1, true);

    std::function<void(std::uint32_t)> schedule_degree =
        [&](std::uint32_t degree) {
            if (degree <= 1 || available.count(degree) != 0)
            {
                return;
            }
            if (degree == std::numeric_limits<std::uint32_t>::max())
            {
                throw std::invalid_argument(
                    "make_gpu_eval_mod_basis_plan: degree is too large");
            }

            const bool is_power_of_two = (degree & (degree - 1U)) == 0U;
            std::uint32_t left_degree = 0;
            std::uint32_t right_degree = 0;
            std::uint32_t correction_degree = 0;
            bool used_preferred_giant_pair = false;
            if (basis == GpuEvalModPolynomialBasis::Chebyshev &&
                preferred_giant_stride > 0 &&
                degree > preferred_giant_stride &&
                degree % preferred_giant_stride == 0)
            {
                /*
                 * The flat-b8 plan requests T8,T16,... in ascending order.
                 * Prefer the most balanced pair of already-live giant bases,
                 * e.g. T24=2*T8*T16-T8 and T48=2*T24^2-1.  Keeping this
                 * opt-in avoids changing the production recursive DAG.
                 */
                for (std::uint32_t candidate_left = preferred_giant_stride;
                     candidate_left <= degree / 2;
                     candidate_left += preferred_giant_stride)
                {
                    const auto candidate_right = degree - candidate_left;
                    const auto candidate_correction =
                        candidate_right - candidate_left;
                    if (available.count(candidate_left) != 0 &&
                        available.count(candidate_right) != 0 &&
                        (candidate_correction == 0 ||
                         available.count(candidate_correction) != 0))
                    {
                        left_degree = candidate_left;
                        right_degree = candidate_right;
                        correction_degree = candidate_correction;
                        used_preferred_giant_pair = true;
                    }
                }
            }
            if (used_preferred_giant_pair)
            {
                // All dependencies were checked above and are already live.
            }
            else if (is_power_of_two)
            {
                left_degree = degree >> 1U;
                right_degree = left_degree;
            }
            else
            {
                std::uint32_t power_of_two = 1;
                const std::uint32_t split_limit = (degree + 1U) >> 1U;
                while (power_of_two < split_limit)
                {
                    power_of_two <<= 1U;
                }
                left_degree = power_of_two - 1U;
                right_degree = degree + 1U - power_of_two;
                if (basis == GpuEvalModPolynomialBasis::Chebyshev)
                {
                    correction_degree = left_degree > right_degree
                        ? left_degree - right_degree
                        : right_degree - left_degree;
                }
            }

            schedule_degree(left_degree);
            schedule_degree(right_degree);
            if (basis == GpuEvalModPolynomialBasis::Chebyshev &&
                correction_degree != 0)
            {
                schedule_degree(correction_degree);
            }

            steps.push_back(GpuEvalModBasisStep{
                degree,
                left_degree,
                right_degree,
                correction_degree});
            available.emplace(degree, true);
        };

    std::vector<std::uint32_t> sorted_degrees = requested_degrees;
    std::sort(sorted_degrees.begin(), sorted_degrees.end());
    sorted_degrees.erase(
        std::unique(sorted_degrees.begin(), sorted_degrees.end()),
        sorted_degrees.end());
    for (const auto degree : sorted_degrees)
    {
        schedule_degree(degree);
    }
    return steps;
}

GpuEvaluator::GpuEvaluator(const GpuParameterData &params)
    : params_(params),
      elementwise_handler_(params),
      keyswitch_handler_(params),
      ntt_handler_(params),
      modswitch_handler_(params)
{}

void GpuEvaluator::add(
    const GpuCiphertextData &left_ciphertext,
    const GpuCiphertextData &right_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (left_ciphertext.empty() || right_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::add: empty ciphertext");
    }

    if (!(left_ciphertext.meta.parms_id == right_ciphertext.meta.parms_id))
    {
        throw std::invalid_argument("GpuEvaluator::add: parms_id mismatch");
    }

    if (left_ciphertext.meta.is_ntt_form != right_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::add: NTT form mismatch");
    }

    if (left_ciphertext.meta.degree != right_ciphertext.meta.degree ||
        left_ciphertext.meta.q_count != right_ciphertext.meta.q_count ||
        left_ciphertext.meta.p_count != right_ciphertext.meta.p_count)
    {
        throw std::invalid_argument("GpuEvaluator::add: shape mismatch");
    }

    if (!same_scale(left_ciphertext.meta.scale, right_ciphertext.meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::add: scale mismatch (left=2^" +
            std::to_string(std::log2(left_ciphertext.meta.scale)) +
            ", right=2^" +
            std::to_string(std::log2(right_ciphertext.meta.scale)) +
            ", q=" + std::to_string(left_ciphertext.meta.q_count) + ")");
    }

    if (left_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::add: p limbs are not supported by add kernel yet");
    }

    const std::size_t result_components =
        std::max(left_ciphertext.size(), right_ciphertext.size());

    const int device_id = left_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = left_ciphertext.polys_.at(0);

    if (left_ciphertext.meta.component_count != left_ciphertext.size() ||
        right_ciphertext.meta.component_count != right_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::add: component metadata mismatch");
    }

    if (!all_components_use_layout(left_ciphertext, reference_layout) ||
        !all_components_use_layout(right_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::add: shard layout mismatch");
    }

    prepare_ciphertext_destination(
        destination_ciphertext,
        &left_ciphertext,
        &right_ciphertext,
        left_ciphertext.meta,
        result_components,
        device_id,
        reference_layout);

    auto left_view = left_ciphertext.make_const_view();
    auto right_view = right_ciphertext.make_const_view();
    auto destination_view = destination_ciphertext.make_view();

    const auto &level_info = params_.get_level(left_ciphertext.meta.parms_id);

    elementwise_handler_.add_ciphertext(
        destination_view,
        left_view,
        right_view,
        level_info);
}

void GpuEvaluator::sub(
    const GpuCiphertextData &left_ciphertext,
    const GpuCiphertextData &right_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (left_ciphertext.empty() || right_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::sub: empty ciphertext");
    }

    if (!(left_ciphertext.meta.parms_id == right_ciphertext.meta.parms_id))
    {
        throw std::invalid_argument("GpuEvaluator::sub: parms_id mismatch");
    }

    if (left_ciphertext.meta.is_ntt_form != right_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::sub: NTT form mismatch");
    }

    if (left_ciphertext.meta.degree != right_ciphertext.meta.degree ||
        left_ciphertext.meta.q_count != right_ciphertext.meta.q_count ||
        left_ciphertext.meta.p_count != right_ciphertext.meta.p_count)
    {
        throw std::invalid_argument("GpuEvaluator::sub: shape mismatch");
    }

    if (!same_scale(left_ciphertext.meta.scale, right_ciphertext.meta.scale))
    {
        throw std::invalid_argument("GpuEvaluator::sub: scale mismatch");
    }

    if (left_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::sub: p limbs are not supported by sub kernel yet");
    }

    const std::size_t result_components =
        std::max(left_ciphertext.size(), right_ciphertext.size());

    const int device_id = left_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = left_ciphertext.polys_.at(0);

    if (left_ciphertext.meta.component_count != left_ciphertext.size() ||
        right_ciphertext.meta.component_count != right_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::sub: component metadata mismatch");
    }

    if (!all_components_use_layout(left_ciphertext, reference_layout) ||
        !all_components_use_layout(right_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::sub: shard layout mismatch");
    }

    prepare_ciphertext_destination(
        destination_ciphertext,
        &left_ciphertext,
        &right_ciphertext,
        left_ciphertext.meta,
        result_components,
        device_id,
        reference_layout);

    auto left_view = left_ciphertext.make_const_view();
    auto right_view = right_ciphertext.make_const_view();
    auto destination_view = destination_ciphertext.make_view();

    const auto &level_info = params_.get_level(left_ciphertext.meta.parms_id);

    elementwise_handler_.sub_ciphertext(
        destination_view,
        left_view,
        right_view,
        level_info);
}

void GpuEvaluator::negate(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::negate: empty ciphertext");
    }

    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::negate: component metadata mismatch");
    }

    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::negate: p limbs are not supported by negate kernel yet");
    }

    const std::size_t result_components = source_ciphertext.size();

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);

    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::negate: shard layout mismatch");
    }

    prepare_ciphertext_destination(
        destination_ciphertext,
        &source_ciphertext,
        nullptr,
        source_ciphertext.meta,
        result_components,
        device_id,
        reference_layout);

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = destination_ciphertext.make_view();

    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    elementwise_handler_.negate_ciphertext(
        destination_view,
        source_view,
        level_info);
}

void GpuEvaluator::validate_plain_input(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext) const
{
    if (source_ciphertext.empty() || source_plaintext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: empty input");
    }

    if (!(source_ciphertext.meta.parms_id == source_plaintext.meta.parms_id))
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: parms_id mismatch");
    }

    if (source_ciphertext.meta.is_ntt_form != source_plaintext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: NTT form mismatch");
    }

    // CKKS add_plain usually expects both ciphertext and plaintext in NTT form.
    if (!source_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: CKKS input must be in NTT form");
    }

    if (source_ciphertext.meta.degree != source_plaintext.meta.degree ||
        source_ciphertext.meta.q_count != source_plaintext.meta.q_count ||
        source_ciphertext.meta.p_count != source_plaintext.meta.p_count)
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: shape mismatch");
    }

    if (!same_scale(source_ciphertext.meta.scale, source_plaintext.meta.scale))
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: scale mismatch");
    }

    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::plain arithmetic: p limbs are not supported by add_plain kernel yet");
    }

    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: component metadata mismatch");
    }

    const auto &reference_layout = source_ciphertext.polys_.at(0);

    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: ciphertext shard layout mismatch");
    }

    if (!same_logical_shard_layout(reference_layout, source_plaintext.poly_))
    {
        throw std::invalid_argument("GpuEvaluator::plain arithmetic: plaintext shard layout mismatch");
    }

}

void GpuEvaluator::add_plain(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_plain_input(source_ciphertext, source_plaintext);
    const std::size_t result_components = source_ciphertext.size();
    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);

    prepare_ciphertext_destination(
        destination_ciphertext,
        &source_ciphertext,
        nullptr,
        source_ciphertext.meta,
        result_components,
        device_id,
        reference_layout);

    auto ciphertext_view = source_ciphertext.make_const_view();
    auto plaintext_view = source_plaintext.make_const_view();
    auto destination_view = destination_ciphertext.make_view();

    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    elementwise_handler_.add_plain_to_ciphertext(
        destination_view,
        ciphertext_view,
        plaintext_view,
        level_info);
}

void GpuEvaluator::sub_plain(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_plain_input(source_ciphertext, source_plaintext);
    const std::size_t result_components = source_ciphertext.size();
    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);

    prepare_ciphertext_destination(
        destination_ciphertext,
        &source_ciphertext,
        nullptr,
        source_ciphertext.meta,
        result_components,
        device_id,
        reference_layout);

    auto ciphertext_view = source_ciphertext.make_const_view();
    auto plaintext_view = source_plaintext.make_const_view();
    auto destination_view = destination_ciphertext.make_view();

    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    elementwise_handler_.sub_plain_from_ciphertext(
        destination_view,
        ciphertext_view,
        plaintext_view,
        level_info);
}

void GpuEvaluator::add_plain_inplace(
    GpuCiphertextData &ciphertext, const GpuPlaintextData &plaintext) const
{
    validate_plain_input(ciphertext, plaintext);
    auto view = ciphertext.make_view();
    auto plain = plaintext.make_const_view();
    elementwise_handler_.add_plain_to_ciphertext_inplace(
        view, plain, params_.get_level(ciphertext.meta.parms_id));
}

void GpuEvaluator::sub_plain_inplace(
    GpuCiphertextData &ciphertext, const GpuPlaintextData &plaintext) const
{
    validate_plain_input(ciphertext, plaintext);
    auto view = ciphertext.make_view();
    auto plain = plaintext.make_const_view();
    elementwise_handler_.sub_plain_from_ciphertext_inplace(
        view, plain, params_.get_level(ciphertext.meta.parms_id));
}

void GpuEvaluator::multiply_plain(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty() || source_plaintext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::multiply_plain: empty input");
    }

    if (!(source_ciphertext.meta.parms_id == source_plaintext.meta.parms_id))
    {
        throw std::invalid_argument("GpuEvaluator::multiply_plain: parms_id mismatch");
    }

    if (source_ciphertext.meta.is_ntt_form != source_plaintext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::multiply_plain: NTT form mismatch");
    }

    if (!source_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::multiply_plain: CKKS input must be in NTT form");
    }

    if (source_ciphertext.meta.degree != source_plaintext.meta.degree ||
        source_ciphertext.meta.q_count != source_plaintext.meta.q_count ||
        source_ciphertext.meta.p_count != source_plaintext.meta.p_count)
    {
        throw std::invalid_argument("GpuEvaluator::multiply_plain: shape mismatch");
    }

    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain: p limbs are not supported yet");
    }

    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain: component metadata mismatch");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);

    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain: ciphertext shard layout mismatch");
    }

    if (!same_logical_shard_layout(reference_layout, source_plaintext.poly_))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain: plaintext shard layout mismatch");
    }

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            source_ciphertext.size(),
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);

    result.meta = source_ciphertext.meta;
    result.meta.component_count = source_ciphertext.size();
    result.meta.scale =
        source_ciphertext.meta.scale * source_plaintext.meta.scale;

    if (!(result.meta.scale > 0.0) || !std::isfinite(result.meta.scale))
    {
        throw std::invalid_argument("GpuEvaluator::multiply_plain: invalid result scale");
    }

    auto ciphertext_view = source_ciphertext.make_const_view();
    auto plaintext_view = source_plaintext.make_const_view();
    auto destination_view = result.make_view();

    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    elementwise_handler_.multiply_plain_with_ciphertext(
        destination_view,
        ciphertext_view,
        plaintext_view,
        level_info);

    destination_ciphertext = std::move(result);
}

void GpuEvaluator::multiply_plain_q_prefix(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_plaintext.empty() || source_plaintext.fields_.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_prefix: invalid plaintext storage");
    }
    if (!source_plaintext.meta.is_ntt_form ||
        source_plaintext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_prefix: plaintext must be q-only NTT");
    }

    const auto &source_level =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &target_level =
        params_.get_level(source_plaintext.meta.parms_id);
    validate_q_prefix_source(
        "GpuEvaluator::multiply_plain_q_prefix",
        source_ciphertext,
        source_level,
        target_level);
    if (source_plaintext.meta.degree != target_level.degree ||
        source_plaintext.meta.q_count != target_level.q_count ||
        source_plaintext.poly_.degree != target_level.degree ||
        source_plaintext.poly_.q_count != target_level.q_count ||
        source_plaintext.poly_.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_prefix: plaintext level mismatch");
    }

    const auto prefix_layout =
        make_q_prefix_layout(source_ciphertext, target_level);
    if (!same_logical_shard_layout(prefix_layout, source_plaintext.poly_))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_prefix: plaintext shard mismatch");
    }

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            target_level.degree,
            target_level.q_count,
            source_ciphertext.size(),
            source_ciphertext.fields_.front().device_id,
            prefix_layout.shards,
            0);
    result.meta = source_ciphertext.meta;
    result.meta.parms_id = target_level.parms_id;
    result.meta.q_count = target_level.q_count;
    result.meta.p_count = 0;
    result.meta.component_count = source_ciphertext.size();
    result.meta.scale =
        source_ciphertext.meta.scale * source_plaintext.meta.scale;
    if (!(result.meta.scale > 0.0) || !std::isfinite(result.meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_prefix: invalid result scale");
    }

    auto ciphertext_view =
        make_q_prefix_view(source_ciphertext, target_level);
    auto plaintext_view = source_plaintext.make_const_view();
    auto destination_view = result.make_view();
    elementwise_handler_.multiply_plain_with_ciphertext(
        destination_view,
        ciphertext_view,
        plaintext_view,
        target_level);
    destination_ciphertext = std::move(result);
}

void GpuEvaluator::multiply_plain_sum_q_prefix(
    const std::vector<const GpuCiphertextData *> &ciphertexts,
    const std::vector<const GpuPlaintextData *> &plaintexts,
    GpuCiphertextData &destination_ciphertext,
    bool accumulate) const
{
    if (ciphertexts.empty() || ciphertexts.size() > 9 ||
        ciphertexts.size() != plaintexts.size())
        throw std::invalid_argument("multiply_plain_sum_q_prefix: expected 1..9 terms");
    for (std::size_t i = 0; i < ciphertexts.size(); ++i)
        if (ciphertexts[i] == nullptr || plaintexts[i] == nullptr)
            throw std::invalid_argument("multiply_plain_sum_q_prefix: null term");
    const auto &first = *ciphertexts.front();
    const auto &target = params_.get_level(plaintexts.front()->meta.parms_id);
    const double result_scale = first.meta.scale * plaintexts.front()->meta.scale;
    if (!(result_scale > 0) || !std::isfinite(result_scale))
        throw std::invalid_argument("multiply_plain_sum_q_prefix: invalid scale");
    std::vector<GpuConstCiphertextView> ciphertext_views;
    std::vector<GpuConstPlaintextView> plaintext_views;
    ciphertext_views.reserve(ciphertexts.size());
    plaintext_views.reserve(plaintexts.size());
    for (std::size_t i = 0; i < ciphertexts.size(); ++i)
    {
        const auto &ct = *ciphertexts[i];
        const auto &pt = *plaintexts[i];
        validate_q_prefix_source("multiply_plain_sum_q_prefix", ct,
            params_.get_level(ct.meta.parms_id), target);
        if (ct.size() != 2 || pt.empty() || pt.fields_.size() != 1 ||
            !pt.meta.is_ntt_form || pt.meta.parms_id != target.parms_id ||
            pt.meta.degree != target.degree || pt.meta.q_count != target.q_count ||
            pt.meta.p_count != 0 || pt.poly_.degree != target.degree ||
            pt.poly_.q_count != target.q_count || pt.poly_.p_count != 0 ||
            ct.fields_.front().device_id != first.fields_.front().device_id ||
            !same_logical_shard_layout(make_q_prefix_layout(ct, target), pt.poly_))
            throw std::invalid_argument("multiply_plain_sum_q_prefix: term shape mismatch");
        const double product_scale = ct.meta.scale * pt.meta.scale;
        if (!(ct.meta.scale > 0) || !(pt.meta.scale > 0) ||
            !(product_scale > 0) || !std::isfinite(product_scale) ||
            std::abs(std::log2(product_scale / result_scale)) > 1e-8)
            throw std::invalid_argument("multiply_plain_sum_q_prefix: product scales differ");
        ciphertext_views.push_back(make_q_prefix_view(ct, target));
        plaintext_views.push_back(pt.make_const_view());
    }
    const auto layout = make_q_prefix_layout(first, target);
    if (accumulate)
    {
        const auto &dst = destination_ciphertext;
        if (dst.empty())
            throw std::invalid_argument("multiply_plain_sum_q_prefix: empty destination");
        validate_q_prefix_source("multiply_plain_sum_q_prefix destination", dst,
            params_.get_level(dst.meta.parms_id), target);
        if (dst.size() != 2 || dst.meta.parms_id != target.parms_id ||
            dst.fields_.front().device_id != first.fields_.front().device_id ||
            !same_logical_shard_layout(dst.polys_.front(), layout) ||
            !(dst.meta.scale > 0) || !std::isfinite(dst.meta.scale) ||
            std::abs(std::log2(dst.meta.scale / result_scale)) > 1e-8)
            throw std::invalid_argument("multiply_plain_sum_q_prefix: destination mismatch");
        auto destination_view = destination_ciphertext.make_view();
        elementwise_handler_.multiply_plain_sum(
            destination_view, ciphertext_views, plaintext_views, target, true);
        return;
    }
    auto result = GpuCiphertextData::allocate_single_device_sharded(
        target.degree, target.q_count, 2, first.fields_.front().device_id,
        layout.shards, 0);
    result.meta = first.meta;
    result.meta.parms_id = target.parms_id;
    result.meta.q_count = target.q_count;
    result.meta.p_count = 0;
    result.meta.component_count = 2;
    result.meta.scale = result_scale;
    auto destination_view = result.make_view();
    elementwise_handler_.multiply_plain_sum(
        destination_view, ciphertext_views, plaintext_views, target);
    destination_ciphertext = std::move(result);
}

void GpuEvaluator::double_sub_plain_q_prefix(
    const GpuCiphertextData &source, const GpuPlaintextData &plaintext,
    GpuCiphertextData &destination, const GpuCiphertextData *correction) const
{
    constexpr const char *name = "double_sub_plain_q_prefix";
    if (source.empty() || plaintext.empty() || (correction && correction->empty()))
        throw std::invalid_argument("double_sub_plain_q_prefix: empty input");
    const auto &level = params_.get_level(plaintext.meta.parms_id);
    validate_q_prefix_source(name, source, params_.get_level(source.meta.parms_id), level);
    const bool inplace_size3 = (&destination == &source && source.size() == 3);
    if ((!inplace_size3 && source.size() != 2) || source.meta.parms_id != level.parms_id ||
        plaintext.fields_.size() != 1 || !plaintext.meta.is_ntt_form ||
        plaintext.meta.degree != level.degree || plaintext.meta.q_count != level.q_count ||
        plaintext.meta.p_count != 0 || plaintext.poly_.degree != level.degree ||
        plaintext.poly_.q_count != level.q_count || plaintext.poly_.p_count != 0 ||
        !same_logical_shard_layout(source.polys_[0], plaintext.poly_))
        throw std::invalid_argument("double_sub_plain_q_prefix: source/plaintext mismatch");
    const auto layout = make_q_prefix_layout(source, level);
    GpuConstCiphertextView correction_view;
    double subtrahend_scale = plaintext.meta.scale;
    if (correction)
    {
        validate_q_prefix_source(name, *correction,
            params_.get_level(correction->meta.parms_id), level);
        if (correction->size() != 2 ||
            correction->fields_[0].device_id != source.fields_[0].device_id ||
            !same_logical_shard_layout(make_q_prefix_layout(*correction, level), layout) ||
            !(correction->meta.scale > 0) || !std::isfinite(correction->meta.scale))
            throw std::invalid_argument("double_sub_plain_q_prefix: correction mismatch");
        subtrahend_scale *= correction->meta.scale;
        correction_view = make_q_prefix_view(*correction, level);
    }
    if (!(source.meta.scale > 0) || !std::isfinite(source.meta.scale) ||
        !(plaintext.meta.scale > 0) || !std::isfinite(plaintext.meta.scale) ||
        !(subtrahend_scale > 0) || !std::isfinite(subtrahend_scale) ||
        std::abs(std::log2(subtrahend_scale / source.meta.scale)) > 1e-8)
        throw std::invalid_argument("double_sub_plain_q_prefix: scales differ");
    if (inplace_size3)
    {
        auto view = destination.make_view();
        elementwise_handler_.double_sub_plain(view, source.make_const_view(),
            plaintext.make_const_view(), correction ? &correction_view : nullptr, level);
        return;
    }
    auto result = GpuCiphertextData::allocate_single_device_sharded(
        level.degree, level.q_count, 2, source.fields_[0].device_id, layout.shards, 0);
    result.meta = source.meta;
    auto view = result.make_view();
    elementwise_handler_.double_sub_plain(view, source.make_const_view(),
        plaintext.make_const_view(), correction ? &correction_view : nullptr, level);
    destination = std::move(result);
}

void GpuEvaluator::multiply_double_sub_plain_q_prefix(
    const GpuCiphertextData &left_ciphertext,
    const GpuCiphertextData &right_ciphertext,
    const GpuPlaintextData &plaintext,
    GpuCiphertextData &destination,
    const GpuCiphertextData *correction) const
{
    constexpr const char *name = "multiply_double_sub_plain_q_prefix";
    if (left_ciphertext.empty() || right_ciphertext.empty() ||
        plaintext.empty() || (correction && correction->empty()))
    {
        throw std::invalid_argument(
            "multiply_double_sub_plain_q_prefix: empty input");
    }
    const auto &level = params_.get_level(plaintext.meta.parms_id);
    validate_q_prefix_source(
        name,
        left_ciphertext,
        params_.get_level(left_ciphertext.meta.parms_id),
        level);
    validate_q_prefix_source(
        name,
        right_ciphertext,
        params_.get_level(right_ciphertext.meta.parms_id),
        level);
    if (left_ciphertext.size() != 2 || right_ciphertext.size() != 2 ||
        left_ciphertext.meta.degree != level.degree ||
        right_ciphertext.meta.degree != level.degree ||
        left_ciphertext.fields_[0].device_id !=
            right_ciphertext.fields_[0].device_id ||
        plaintext.fields_.size() != 1 || !plaintext.meta.is_ntt_form ||
        plaintext.meta.degree != level.degree ||
        plaintext.meta.q_count != level.q_count ||
        plaintext.meta.p_count != 0 ||
        plaintext.poly_.degree != level.degree ||
        plaintext.poly_.q_count != level.q_count ||
        plaintext.poly_.p_count != 0)
    {
        throw std::invalid_argument(
            "multiply_double_sub_plain_q_prefix: operand shape mismatch");
    }

    const auto layout = make_q_prefix_layout(left_ciphertext, level);
    if (!same_logical_shard_layout(layout, plaintext.poly_) ||
        !same_logical_shard_layout(
            make_q_prefix_layout(right_ciphertext, level), plaintext.poly_))
    {
        throw std::invalid_argument(
            "multiply_double_sub_plain_q_prefix: shard layout mismatch");
    }

    GpuConstCiphertextView correction_view;
    double subtrahend_scale = plaintext.meta.scale;
    if (correction)
    {
        validate_q_prefix_source(
            name,
            *correction,
            params_.get_level(correction->meta.parms_id),
            level);
        if (correction->size() != 2 ||
            correction->fields_[0].device_id !=
                left_ciphertext.fields_[0].device_id ||
            !same_logical_shard_layout(
                make_q_prefix_layout(*correction, level), layout) ||
            !(correction->meta.scale > 0) ||
            !std::isfinite(correction->meta.scale))
        {
            throw std::invalid_argument(
                "multiply_double_sub_plain_q_prefix: correction mismatch");
        }
        subtrahend_scale *= correction->meta.scale;
        correction_view = make_q_prefix_view(*correction, level);
    }

    const double product_scale =
        left_ciphertext.meta.scale * right_ciphertext.meta.scale;
    if (!(left_ciphertext.meta.scale > 0) ||
        !(right_ciphertext.meta.scale > 0) ||
        !(product_scale > 0) || !std::isfinite(product_scale) ||
        !(plaintext.meta.scale > 0) || !std::isfinite(plaintext.meta.scale) ||
        !(subtrahend_scale > 0) || !std::isfinite(subtrahend_scale) ||
        std::abs(std::log2(subtrahend_scale / product_scale)) > 1e-8)
    {
        throw std::invalid_argument(
            "multiply_double_sub_plain_q_prefix: scales differ");
    }

    auto result = GpuCiphertextData::allocate_single_device_sharded(
        level.degree,
        level.q_count,
        3,
        left_ciphertext.fields_[0].device_id,
        layout.shards,
        0);
    result.meta = left_ciphertext.meta;
    result.meta.parms_id = level.parms_id;
    result.meta.q_count = level.q_count;
    result.meta.p_count = 0;
    result.meta.component_count = 3;
    result.meta.is_ntt_form = true;
    result.meta.scale = product_scale;

    auto left_view = make_q_prefix_view(left_ciphertext, level);
    auto right_view = make_q_prefix_view(right_ciphertext, level);
    auto dst_view = result.make_view();
    elementwise_handler_.multiply_double_sub_plain(
        dst_view,
        left_view,
        right_view,
        plaintext.make_const_view(),
        correction ? &correction_view : nullptr,
        level);
    destination = std::move(result);
}

void GpuEvaluator::multiply_add_q_prefix(
    const GpuCiphertextData &left_ciphertext,
    const GpuCiphertextData &right_ciphertext,
    const GpuCiphertextData &addend_ciphertext,
    GpuCiphertextData &destination_ciphertext,
    parms_id_type target_parms_id) const
{
    const auto &target_level = params_.get_level(target_parms_id);
    validate_q_prefix_source(
        "GpuEvaluator::multiply_add_q_prefix left",
        left_ciphertext,
        params_.get_level(left_ciphertext.meta.parms_id),
        target_level);
    validate_q_prefix_source(
        "GpuEvaluator::multiply_add_q_prefix right",
        right_ciphertext,
        params_.get_level(right_ciphertext.meta.parms_id),
        target_level);
    validate_q_prefix_source(
        "GpuEvaluator::multiply_add_q_prefix addend",
        addend_ciphertext,
        params_.get_level(addend_ciphertext.meta.parms_id),
        target_level);
    if (left_ciphertext.size() != 2 || right_ciphertext.size() != 2 ||
        (addend_ciphertext.size() != 2 && addend_ciphertext.size() != 3) ||
        left_ciphertext.meta.degree != right_ciphertext.meta.degree ||
        left_ciphertext.meta.degree != addend_ciphertext.meta.degree ||
        left_ciphertext.fields_.front().device_id !=
            right_ciphertext.fields_.front().device_id ||
        left_ciphertext.fields_.front().device_id !=
            addend_ciphertext.fields_.front().device_id)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_add_q_prefix: incompatible inputs");
    }

    const auto prefix_layout =
        make_q_prefix_layout(left_ciphertext, target_level);
    if (!same_logical_shard_layout(
            make_q_prefix_layout(right_ciphertext, target_level),
            prefix_layout) ||
        !same_logical_shard_layout(
            make_q_prefix_layout(addend_ciphertext, target_level),
            prefix_layout))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_add_q_prefix: shard layout mismatch");
    }

    const double product_scale =
        left_ciphertext.meta.scale * right_ciphertext.meta.scale;
    if (!(product_scale > 0.0) || !std::isfinite(product_scale) ||
        !(addend_ciphertext.meta.scale > 0.0) ||
        !std::isfinite(addend_ciphertext.meta.scale) ||
        !same_scale(product_scale, addend_ciphertext.meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_add_q_prefix: invalid or mismatched scale");
    }

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            target_level.degree,
            target_level.q_count,
            3,
            left_ciphertext.fields_.front().device_id,
            prefix_layout.shards,
            0);
    result.meta = left_ciphertext.meta;
    result.meta.parms_id = target_level.parms_id;
    result.meta.q_count = target_level.q_count;
    result.meta.p_count = 0;
    result.meta.component_count = 3;
    result.meta.is_ntt_form = true;
    result.meta.scale = product_scale;

    auto left_view = make_q_prefix_view(left_ciphertext, target_level);
    auto right_view = make_q_prefix_view(right_ciphertext, target_level);
    auto addend_view = make_q_prefix_view(addend_ciphertext, target_level);
    auto destination_view = result.make_view();
    elementwise_handler_.multiply_add_ciphertext(
        destination_view,
        left_view,
        right_view,
        addend_view,
        target_level);
    destination_ciphertext = std::move(result);
}

void GpuEvaluator::multiply_plain_accumulate(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty() || source_plaintext.empty() ||
        destination_ciphertext.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_accumulate: empty input");
    }
    if (!(source_ciphertext.meta.parms_id ==
          source_plaintext.meta.parms_id) ||
        !(source_ciphertext.meta.parms_id ==
          destination_ciphertext.meta.parms_id) ||
        !source_ciphertext.meta.is_ntt_form ||
        !source_plaintext.meta.is_ntt_form ||
        !destination_ciphertext.meta.is_ntt_form ||
        source_ciphertext.size() != 2 ||
        destination_ciphertext.size() != 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_accumulate: incompatible input");
    }
    const double product_scale =
        source_ciphertext.meta.scale * source_plaintext.meta.scale;
    if (!same_scale(product_scale, destination_ciphertext.meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_accumulate: scale mismatch");
    }
    if (!same_logical_shard_layout(
            source_ciphertext.polys_.front(),
            source_plaintext.poly_) ||
        !same_logical_shard_layout(
            source_ciphertext.polys_.front(),
            destination_ciphertext.polys_.front()) ||
        !all_components_use_layout(
            source_ciphertext,
            source_ciphertext.polys_.front()) ||
        !all_components_use_layout(
            destination_ciphertext,
            destination_ciphertext.polys_.front()))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_accumulate: shard mismatch");
    }

    auto destination_view = destination_ciphertext.make_view();
    auto ciphertext_view = source_ciphertext.make_const_view();
    auto plaintext_view = source_plaintext.make_const_view();
    const auto &level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    elementwise_handler_.multiply_plain_accumulate_with_ciphertext(
        destination_view,
        ciphertext_view,
        plaintext_view,
        level_info);
}

void GpuEvaluator::ntt_fwd(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_ntt_ciphertext_input(
        "GpuEvaluator::ntt_fwd",
        source_ciphertext,
        false);

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            source_ciphertext.size(),
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);

    result.meta = source_ciphertext.meta;
    result.meta.component_count = source_ciphertext.size();
    result.meta.is_ntt_form = true;

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result.make_view();

    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    ntt_handler_.forward_ciphertext(
        destination_view,
        source_view,
        level_info);

    destination_ciphertext = std::move(result);
}

void GpuEvaluator::ntt_inv(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_ntt_ciphertext_input(
        "GpuEvaluator::ntt_inv",
        source_ciphertext,
        true);

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            source_ciphertext.size(),
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);

    result.meta = source_ciphertext.meta;
    result.meta.component_count = source_ciphertext.size();
    result.meta.is_ntt_form = false;

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result.make_view();

    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    ntt_handler_.inverse_ciphertext(
        destination_view,
        source_view,
        level_info);

    destination_ciphertext = std::move(result);
}

/**
 * @brief 用户端顶层算子，进行必要的输入检查，构建结果临时缓存，调用multiply_ciphertext
 */
void GpuEvaluator::multiply(
    const GpuCiphertextData &left_ciphertext,
    const GpuCiphertextData &right_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (left_ciphertext.empty() || right_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::multiply: empty ciphertext");
    }
    if (left_ciphertext.fields_.empty() || right_ciphertext.fields_.empty())
    {
        throw std::invalid_argument("GpuEvaluator::multiply: empty ciphertext storage");
    }

    if (!(left_ciphertext.meta.parms_id == right_ciphertext.meta.parms_id))
    {
        throw std::invalid_argument("GpuEvaluator::multiply: parms_id mismatch");
    }
    if (!left_ciphertext.meta.is_ntt_form ||
        !right_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::multiply: CKKS inputs must be in NTT form");
    }
    if (left_ciphertext.meta.degree != right_ciphertext.meta.degree ||
        left_ciphertext.meta.q_count != right_ciphertext.meta.q_count ||
        left_ciphertext.meta.p_count != right_ciphertext.meta.p_count)
    {
        throw std::invalid_argument("GpuEvaluator::multiply: shape mismatch");
    }
    if (left_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument("GpuEvaluator::multiply: p limbs are not supported yet");
    }
    if (left_ciphertext.meta.component_count != left_ciphertext.size() ||
        right_ciphertext.meta.component_count != right_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::multiply: component metadata mismatch");
    }

    const int device_id = left_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = left_ciphertext.polys_.at(0);

    if (!all_components_use_layout(left_ciphertext, reference_layout) ||
        !all_components_use_layout(right_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::multiply: shard layout mismatch");
    }

    const std::size_t result_components =
        left_ciphertext.size() + right_ciphertext.size() - 1;

    GpuCiphertextMeta result_meta = left_ciphertext.meta;
    result_meta.component_count = result_components;
    result_meta.is_ntt_form = true;
    result_meta.scale =
        left_ciphertext.meta.scale * right_ciphertext.meta.scale;

    if (!(result_meta.scale > 0.0) || !std::isfinite(result_meta.scale))
    {
        throw std::invalid_argument("GpuEvaluator::multiply: invalid result scale");
    }

    const bool aliases_input =
        &destination_ciphertext == &left_ciphertext ||
        &destination_ciphertext == &right_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            left_ciphertext.meta.degree,
            left_ciphertext.meta.q_count,
            result_components,
            device_id,
            reference_layout.shards,
            left_ciphertext.meta.p_count);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            result_components,
            device_id,
            reference_layout);
    }

    auto left_view = left_ciphertext.make_const_view();
    auto right_view = right_ciphertext.make_const_view();
    auto destination_view = result->make_view();

    const auto &level_info = params_.get_level(left_ciphertext.meta.parms_id);

    elementwise_handler_.multiply_ciphertext(
        destination_view,
        left_view,
        right_view,
        level_info);

    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::multiply_q_prefix(
    const GpuCiphertextData &left_ciphertext,
    const GpuCiphertextData &right_ciphertext,
    GpuCiphertextData &destination_ciphertext,
    parms_id_type target_parms_id) const
{
    const auto &left_level =
        params_.get_level(left_ciphertext.meta.parms_id);
    const auto &right_level =
        params_.get_level(right_ciphertext.meta.parms_id);
    const auto &target_level = params_.get_level(target_parms_id);
    validate_q_prefix_source(
        "GpuEvaluator::multiply_q_prefix left",
        left_ciphertext,
        left_level,
        target_level);
    validate_q_prefix_source(
        "GpuEvaluator::multiply_q_prefix right",
        right_ciphertext,
        right_level,
        target_level);
    if (left_ciphertext.meta.degree != right_ciphertext.meta.degree ||
        left_ciphertext.fields_.front().device_id !=
            right_ciphertext.fields_.front().device_id)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_q_prefix: incompatible inputs");
    }

    const auto result_components =
        left_ciphertext.size() + right_ciphertext.size() - 1;
    const auto prefix_layout =
        make_q_prefix_layout(left_ciphertext, target_level);
    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            target_level.degree,
            target_level.q_count,
            result_components,
            left_ciphertext.fields_.front().device_id,
            prefix_layout.shards,
            0);
    result.meta = left_ciphertext.meta;
    result.meta.parms_id = target_level.parms_id;
    result.meta.q_count = target_level.q_count;
    result.meta.p_count = 0;
    result.meta.component_count = result_components;
    result.meta.is_ntt_form = true;
    result.meta.scale =
        left_ciphertext.meta.scale * right_ciphertext.meta.scale;
    if (!(result.meta.scale > 0.0) || !std::isfinite(result.meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_q_prefix: invalid result scale");
    }

    auto left_view = make_q_prefix_view(left_ciphertext, target_level);
    auto right_view = make_q_prefix_view(right_ciphertext, target_level);
    auto destination_view = result.make_view();
    elementwise_handler_.multiply_ciphertext(
        destination_view,
        left_view,
        right_view,
        target_level);
    destination_ciphertext = std::move(result);
}

void GpuEvaluator::square(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::square: empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::square: empty ciphertext storage");
    }
    if (!source_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument(
            "GpuEvaluator::square: CKKS input must be in NTT form");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::square: p limbs are not supported yet");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::square: component metadata mismatch");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument(
            "GpuEvaluator::square: shard layout mismatch");
    }

    const std::size_t result_components =
        source_ciphertext.size() * 2 - 1;
    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.component_count = result_components;
    result_meta.is_ntt_form = true;
    result_meta.scale =
        source_ciphertext.meta.scale * source_ciphertext.meta.scale;
    if (!(result_meta.scale > 0.0) || !std::isfinite(result_meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::square: invalid result scale");
    }

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            result_components,
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            result_components,
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    const auto &level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    elementwise_handler_.square_ciphertext(
        destination_view,
        source_view,
        level_info);
    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::rescale(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::rescale: empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument("GpuEvaluator::rescale: empty ciphertext storage");
    }
    if (!source_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument("GpuEvaluator::rescale: CKKS input must be in NTT form");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument("GpuEvaluator::rescale: p limbs are not supported yet");
    }
    if (source_ciphertext.meta.q_count < 2)
    {
        throw std::invalid_argument("GpuEvaluator::rescale: cannot drop the last q modulus");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::rescale: component metadata mismatch");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &destination_level_info =
        params_.get_next_level(source_ciphertext.meta.parms_id);

    if (source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info.q_count + 1 != source_level_info.q_count)
    {
        throw std::invalid_argument("GpuEvaluator::rescale: level q_count mismatch");
    }
    if (source_level_info.shards.empty() ||
        source_level_info.shards.front().q_last == 0)
    {
        throw std::invalid_argument("GpuEvaluator::rescale: missing source q_last parameter");
    }

    const std::size_t destination_q_count =
        source_ciphertext.meta.q_count - 1;
    const int device_id = source_ciphertext.fields_.at(0).device_id;

    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = source_ciphertext.meta.degree;

    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.parms_id = destination_level_info.parms_id;
    result_meta.q_count = destination_q_count;
    result_meta.p_count = 0;
    result_meta.component_count = source_ciphertext.size();
    result_meta.is_ntt_form = true;
    result_meta.scale =
        source_ciphertext.meta.scale /
        static_cast<double>(source_level_info.shards.front().q_last);

    if (!(result_meta.scale > 0.0) || !std::isfinite(result_meta.scale))
    {
        throw std::invalid_argument("GpuEvaluator::rescale: invalid result scale");
    }

    GpuRNSPoly reference_layout;
    reference_layout.degree = source_ciphertext.meta.degree;
    reference_layout.q_count = destination_q_count;
    reference_layout.p_count = 0;
    reference_layout.shards.push_back(destination_shard);

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            destination_q_count,
            source_ciphertext.size(),
            device_id,
            std::vector<GpuPolyShard>{destination_shard},
            0);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            source_ciphertext.size(),
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();

    modswitch_handler_.rescale_ciphertext(
        destination_view,
        source_view,
        source_level_info,
        destination_level_info);

    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::rescale_x2(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty() ||
        source_ciphertext.fields_.empty() ||
        !source_ciphertext.meta.is_ntt_form ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.meta.q_count < 3 ||
        source_ciphertext.meta.component_count != 2 ||
        source_ciphertext.size() != 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_x2: unsupported ciphertext shape");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &intermediate_level_info =
        params_.get_next_level(source_ciphertext.meta.parms_id);
    const auto &destination_level_info =
        params_.get_next_level(intermediate_level_info.parms_id);
    if (source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info.q_count + 2 != source_level_info.q_count ||
        source_level_info.shards.empty() ||
        source_level_info.shards.front().q_last_two_product == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_x2: level/constants mismatch");
    }

    const std::size_t destination_q_count =
        source_ciphertext.meta.q_count - 2;
    const int device_id = source_ciphertext.fields_.front().device_id;
    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = source_ciphertext.meta.degree;

    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.parms_id = destination_level_info.parms_id;
    result_meta.q_count = destination_q_count;
    result_meta.p_count = 0;
    result_meta.component_count = 2;
    result_meta.is_ntt_form = true;
    result_meta.scale =
        source_ciphertext.meta.scale /
        static_cast<double>(
            source_level_info.shards.front().q_last_two_product);
    if (!(result_meta.scale > 0.0) || !std::isfinite(result_meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_x2: invalid result scale");
    }

    GpuRNSPoly reference_layout;
    reference_layout.degree = source_ciphertext.meta.degree;
    reference_layout.q_count = destination_q_count;
    reference_layout.p_count = 0;
    reference_layout.shards.push_back(destination_shard);

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            destination_q_count,
            2,
            device_id,
            std::vector<GpuPolyShard>{destination_shard},
            0);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            2,
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    modswitch_handler_.rescale_ciphertext_x2(
        destination_view,
        source_view,
        source_level_info,
        destination_level_info);
    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::rescale_many(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext,
    std::uint32_t rescale_count) const
{
    if (rescale_count == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_many: rescale_count must be positive");
    }
    if (source_ciphertext.meta.q_count <= rescale_count)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_many: modulus chain is too short");
    }
    if (rescale_count == 1)
    {
        rescale(source_ciphertext, destination_ciphertext);
        return;
    }
    const bool can_use_x2 =
        source_ciphertext.meta.component_count == 2 &&
        source_ciphertext.size() == 2 &&
        use_rescale_x2();
    if (rescale_count == 2 && can_use_x2)
    {
        rescale_x2(source_ciphertext, destination_ciphertext);
        return;
    }

    if (source_ciphertext.empty() || source_ciphertext.fields_.empty() ||
        !source_ciphertext.meta.is_ntt_form ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_many: unsupported ciphertext shape");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const GpuLevelInfo *destination_level_info = &source_level_info;
    double result_scale = source_ciphertext.meta.scale;
    for (std::uint32_t index = 0; index < rescale_count; ++index)
    {
        if (destination_level_info->shards.empty() ||
            destination_level_info->shards.front().q_last == 0)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rescale_many: missing q_last parameter");
        }
        result_scale /= static_cast<double>(
            destination_level_info->shards.front().q_last);
        destination_level_info = &params_.get_next_level(
            destination_level_info->parms_id);
    }
    const std::size_t destination_q_count =
        source_ciphertext.meta.q_count - rescale_count;
    if (source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info->q_count != destination_q_count ||
        !(result_scale > 0.0) || !std::isfinite(result_scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_many: level or scale mismatch");
    }

    const int device_id = source_ciphertext.fields_.front().device_id;
    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = source_ciphertext.meta.degree;

    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.parms_id = destination_level_info->parms_id;
    result_meta.q_count = destination_q_count;
    result_meta.p_count = 0;
    result_meta.component_count = source_ciphertext.size();
    result_meta.is_ntt_form = true;
    result_meta.scale = result_scale;

    GpuRNSPoly reference_layout;
    reference_layout.degree = source_ciphertext.meta.degree;
    reference_layout.q_count = destination_q_count;
    reference_layout.p_count = 0;
    reference_layout.shards.push_back(destination_shard);

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            destination_q_count,
            source_ciphertext.size(),
            device_id,
            std::vector<GpuPolyShard>{destination_shard},
            0);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            source_ciphertext.size(),
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    modswitch_handler_.rescale_ciphertext_many(
        destination_view,
        source_view,
        source_level_info,
        *destination_level_info,
        rescale_count);
    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::rescale_many_pair(
    const GpuCiphertextData &source0,
    const GpuCiphertextData &source1,
    GpuCiphertextData &destination0,
    GpuCiphertextData &destination1,
    std::uint32_t rescale_count) const
{
    if (&destination0 == &destination1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_many_pair: destinations must be distinct");
    }
    if ((rescale_count == 1 || (rescale_count == 2 && use_rescale_x2())) &&
        !source0.empty() && !source1.empty() &&
        !source0.fields_.empty() && !source1.fields_.empty() &&
        source0.meta.is_ntt_form && source1.meta.is_ntt_form &&
        source0.meta.p_count == 0 && source1.meta.p_count == 0 &&
        source0.size() == 2 && source1.size() == 2 &&
        source0.meta.component_count == 2 && source1.meta.component_count == 2 &&
        source0.meta.parms_id == source1.meta.parms_id &&
        source0.meta.degree == 65536 && source1.meta.degree == 65536 &&
        source0.meta.q_count > rescale_count &&
        source1.meta.q_count == source0.meta.q_count &&
        (rescale_count == 1 || source0.meta.q_count - rescale_count >= 2) &&
        source0.fields_.front().device_id == source1.fields_.front().device_id)
    {
        const auto &source_level_info =
            params_.get_level(source0.meta.parms_id);
        const auto &step1_level_info =
            params_.get_next_level(source0.meta.parms_id);
        const auto &destination_level_info =
            rescale_count == 1
                ? step1_level_info
                : params_.get_next_level(step1_level_info.parms_id);
        const double divisor =
            rescale_count == 1
                ? (source_level_info.shards.empty()
                       ? 0.0
                       : static_cast<double>(
                             source_level_info.shards.front().q_last))
                : (source_level_info.shards.empty()
                       ? 0.0
                       : static_cast<double>(
                             source_level_info.shards.front().q_last_two_product));
        if (divisor > 0.0 &&
            source_level_info.q_count == source0.meta.q_count &&
            destination_level_info.q_count + rescale_count ==
                source_level_info.q_count)
        {
            const std::size_t destination_q_count = destination_level_info.q_count;
            const int device_id = source0.fields_.front().device_id;
            const double scale0 = source0.meta.scale / divisor;
            const double scale1 = source1.meta.scale / divisor;
            if (scale0 > 0.0 && std::isfinite(scale0) &&
                scale1 > 0.0 && std::isfinite(scale1))
            {
                GpuPolyShard destination_shard;
                destination_shard.field_index = 0;
                destination_shard.field_offset = 0;
                destination_shard.limb_begin = 0;
                destination_shard.limb_count = destination_q_count;
                destination_shard.coeff_begin = 0;
                destination_shard.coeff_count = 65536;

                GpuRNSPoly reference_layout;
                reference_layout.degree = 65536;
                reference_layout.q_count = destination_q_count;
                reference_layout.p_count = 0;
                reference_layout.shards.push_back(destination_shard);

                auto make_meta = [&](const GpuCiphertextData &src, double sc) {
                    GpuCiphertextMeta m = src.meta;
                    m.parms_id = destination_level_info.parms_id;
                    m.q_count = destination_q_count;
                    m.p_count = 0;
                    m.component_count = 2;
                    m.is_ntt_form = true;
                    m.scale = sc;
                    return m;
                };
                const auto meta0 = make_meta(source0, scale0);
                const auto meta1 = make_meta(source1, scale1);

                const bool alias0 =
                    (&destination0 == &source0) || (&destination0 == &source1);
                const bool alias1 =
                    (&destination1 == &source0) || (&destination1 == &source1);
                GpuCiphertextData local0, local1;
                GpuCiphertextData *res0 = &destination0;
                GpuCiphertextData *res1 = &destination1;
                if (alias0)
                {
                    local0 = GpuCiphertextData::allocate_single_device_sharded(
                        65536,
                        destination_q_count,
                        2,
                        device_id,
                        std::vector<GpuPolyShard>{destination_shard},
                        0);
                    local0.meta = meta0;
                    res0 = &local0;
                }
                else
                {
                    prepare_ciphertext_destination(
                        destination0,
                        nullptr,
                        nullptr,
                        meta0,
                        2,
                        device_id,
                        reference_layout);
                }
                if (alias1)
                {
                    local1 = GpuCiphertextData::allocate_single_device_sharded(
                        65536,
                        destination_q_count,
                        2,
                        device_id,
                        std::vector<GpuPolyShard>{destination_shard},
                        0);
                    local1.meta = meta1;
                    res1 = &local1;
                }
                else
                {
                    prepare_ciphertext_destination(
                        destination1,
                        nullptr,
                        nullptr,
                        meta1,
                        2,
                        device_id,
                        reference_layout);
                }

                auto src_view0 = source0.make_const_view();
                auto src_view1 = source1.make_const_view();
                auto dst_view0 = res0->make_view();
                auto dst_view1 = res1->make_view();
                if (modswitch_handler_.try_rescale_ciphertext_pair(
                        dst_view0,
                        dst_view1,
                        src_view0,
                        src_view1,
                        source_level_info,
                        destination_level_info,
                        rescale_count))
                {
                    if (alias0)
                    {
                        destination0 = std::move(local0);
                    }
                    if (alias1)
                    {
                        destination1 = std::move(local1);
                    }
                    return;
                }
            }
        }
    }

    if (&destination0 == &source1 || &destination1 == &source0)
    {
        GpuCiphertextData out0, out1;
        rescale_many(source0, out0, rescale_count);
        rescale_many(source1, out1, rescale_count);
        destination0 = std::move(out0);
        destination1 = std::move(out1);
        return;
    }
    rescale_many(source0, destination0, rescale_count);
    rescale_many(source1, destination1, rescale_count);
}

void GpuEvaluator::rescale_dynamic(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext,
    double min_scale) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::rescale_dynamic: empty ciphertext");
    }
    if (!source_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_dynamic: CKKS input must be in NTT form");
    }
    if (!(min_scale > 0.0) || !std::isfinite(min_scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_dynamic: invalid minimum scale");
    }
    if (!(source_ciphertext.meta.scale > 0.0) ||
        !std::isfinite(source_ciphertext.meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::rescale_dynamic: invalid input scale");
    }

    std::vector<std::uint64_t> active_moduli(
        source_ciphertext.meta.q_count,
        0);
    parms_id_type current_parms_id = source_ciphertext.meta.parms_id;
    while (true)
    {
        const auto &level_info = params_.get_level(current_parms_id);
        if (level_info.q_count == 0 ||
            level_info.q_count > active_moduli.size() ||
            level_info.shards.empty() ||
            level_info.shards.front().q_last == 0)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rescale_dynamic: incomplete active modulus chain");
        }
        active_moduli[level_info.q_count - 1] =
            level_info.shards.front().q_last;
        if (level_info.q_count == 1)
        {
            break;
        }
        current_parms_id = params_.get_next_level(current_parms_id).parms_id;
    }

    const auto plan = plan_gpu_dynamic_rescale(
        source_ciphertext.meta.scale,
        min_scale,
        active_moduli);

    if (plan.rescale_count == 0)
    {
        if (&source_ciphertext == &destination_ciphertext)
        {
            return;
        }
        copy_ciphertext_data(
            source_ciphertext,
            destination_ciphertext,
            "GpuEvaluator::rescale_dynamic no-op copy");
        return;
    }

    rescale_many(
        source_ciphertext,
        destination_ciphertext,
        plan.rescale_count);
    destination_ciphertext.meta.scale = plan.output_scale;
}

void GpuEvaluator::drop_modulus(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext,
    parms_id_type target_parms_id) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: empty ciphertext storage");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: p limbs are not supported yet");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: component metadata mismatch");
    }
    const auto &reference_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: shard layout mismatch");
    }
    if (reference_layout.shards.size() != 1 ||
        reference_layout.shards.front().limb_begin != 0 ||
        reference_layout.shards.front().limb_count != source_ciphertext.meta.q_count ||
        reference_layout.shards.front().coeff_begin != 0 ||
        reference_layout.shards.front().coeff_count != source_ciphertext.meta.degree)
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus: first implementation requires one full q shard");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &destination_level_info =
        params_.get_level(target_parms_id);

    if (source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info.p_count != 0 ||
        destination_level_info.q_count == 0 ||
        destination_level_info.q_count > source_level_info.q_count)
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: level q_count mismatch");
    }
    if (destination_level_info.degree != source_ciphertext.meta.degree)
    {
        throw std::invalid_argument("GpuEvaluator::drop_modulus: degree mismatch");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_level_info.q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = source_ciphertext.meta.degree;

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            destination_level_info.q_count,
            source_ciphertext.size(),
            device_id,
            std::vector<GpuPolyShard>{ destination_shard },
            0);

    result.meta = source_ciphertext.meta;
    result.meta.parms_id = destination_level_info.parms_id;
    result.meta.q_count = destination_level_info.q_count;
    result.meta.p_count = 0;
    result.meta.component_count = source_ciphertext.size();

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result.make_view();
    modswitch_handler_.drop_modulus_ciphertext(
        destination_view,
        source_view,
        source_level_info,
        destination_level_info);

    destination_ciphertext = std::move(result);
}

void GpuEvaluator::drop_modulus_inplace(
    GpuCiphertextData &ciphertext,
    parms_id_type target_parms_id) const
{
    if (ciphertext.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus_inplace: empty ciphertext");
    }
    if (ciphertext.fields_.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus_inplace: empty ciphertext storage");
    }
    if (ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus_inplace: p limbs are not supported");
    }
    if (ciphertext.meta.component_count != ciphertext.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus_inplace: component metadata mismatch");
    }

    const auto &source_level_info =
        params_.get_level(ciphertext.meta.parms_id);
    const auto &destination_level_info =
        params_.get_level(target_parms_id);
    if (source_level_info.q_count != ciphertext.meta.q_count ||
        destination_level_info.p_count != 0 ||
        destination_level_info.q_count == 0 ||
        destination_level_info.q_count > source_level_info.q_count)
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus_inplace: level q_count mismatch");
    }
    if (destination_level_info.degree != ciphertext.meta.degree)
    {
        throw std::invalid_argument(
            "GpuEvaluator::drop_modulus_inplace: degree mismatch");
    }

    for (const auto &poly : ciphertext.polys_)
    {
        if (poly.degree != ciphertext.meta.degree ||
            poly.q_count != ciphertext.meta.q_count ||
            poly.p_count != 0 ||
            poly.shards.size() != 1)
        {
            throw std::invalid_argument(
                "GpuEvaluator::drop_modulus_inplace: unsupported component layout");
        }
        const auto &shard = poly.shards.front();
        if (shard.limb_begin != 0 ||
            shard.limb_count != ciphertext.meta.q_count ||
            shard.coeff_begin != 0 ||
            shard.coeff_count != ciphertext.meta.degree)
        {
            throw std::invalid_argument(
                "GpuEvaluator::drop_modulus_inplace: requires one full q shard");
        }
    }

    ciphertext.meta.parms_id = destination_level_info.parms_id;
    ciphertext.meta.q_count = destination_level_info.q_count;
    ciphertext.meta.p_count = 0;
    for (auto &poly : ciphertext.polys_)
    {
        poly.q_count = destination_level_info.q_count;
        poly.p_count = 0;
        poly.shards.front().limb_count = destination_level_info.q_count;
    }
}

void GpuEvaluator::multiply_scalar(
    const GpuCiphertextData &source_ciphertext,
    std::uint64_t scalar,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::multiply_scalar: empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument("GpuEvaluator::multiply_scalar: empty ciphertext storage");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument("GpuEvaluator::multiply_scalar: p limbs are not supported yet");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::multiply_scalar: component metadata mismatch");
    }

    const auto &reference_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::multiply_scalar: shard layout mismatch");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);
    if (level_info.q_count != source_ciphertext.meta.q_count ||
        level_info.p_count != source_ciphertext.meta.p_count)
    {
        throw std::invalid_argument("GpuEvaluator::multiply_scalar: level shape mismatch");
    }

    // Each coefficient is read and written independently, so the existing
    // source storage is safe for an aliased scalar multiplication.
    if (&destination_ciphertext != &source_ciphertext)
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            &source_ciphertext,
            nullptr,
            source_ciphertext.meta,
            source_ciphertext.size(),
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = destination_ciphertext.make_view();
    elementwise_handler_.multiply_scalar_ciphertext(
        destination_view,
        source_view,
        scalar,
        level_info);
}

void GpuEvaluator::raise_modulus(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::raise_modulus: empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument("GpuEvaluator::raise_modulus: empty ciphertext storage");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument("GpuEvaluator::raise_modulus: p limbs are not supported yet");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument("GpuEvaluator::raise_modulus: component metadata mismatch");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &destination_level_info = params_.get_first_q_level();
    if (source_level_info.p_count != 0 ||
        destination_level_info.p_count != 0 ||
        source_level_info.degree != source_ciphertext.meta.degree ||
        source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info.degree != source_ciphertext.meta.degree ||
        source_level_info.q_count > destination_level_info.q_count)
    {
        throw std::invalid_argument("GpuEvaluator::raise_modulus: level shape mismatch");
    }

    const auto &source_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, source_layout) ||
        source_layout.shards.size() != 1 ||
        source_layout.shards.front().limb_begin != 0 ||
        source_layout.shards.front().limb_count != source_ciphertext.meta.q_count ||
        source_layout.shards.front().coeff_begin != 0 ||
        source_layout.shards.front().coeff_count != source_ciphertext.meta.degree)
    {
        throw std::invalid_argument(
            "GpuEvaluator::raise_modulus: first implementation requires one full q-prefix shard");
    }

    GpuCiphertextData coeff_source_storage;
    const GpuCiphertextData *coeff_source = &source_ciphertext;
    if (source_ciphertext.meta.is_ntt_form)
    {
        ntt_inv(source_ciphertext, coeff_source_storage);
        coeff_source = &coeff_source_storage;
    }

    const int device_id = coeff_source->fields_.at(0).device_id;
    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_level_info.q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = coeff_source->meta.degree;

    if (coeff_source->size() == 2 &&
        coeff_source->meta.degree == 65536 &&
        source_level_info.q_count < destination_level_info.q_count &&
        source_level_info.shards.size() == 1 &&
        destination_level_info.shards.size() == 1 &&
        source_level_info.shards.front().device_id == device_id &&
        destination_level_info.shards.front().device_id == device_id)
    {
        GpuCiphertextData ntt_raised =
            GpuCiphertextData::allocate_single_device_sharded(
                coeff_source->meta.degree,
                destination_level_info.q_count,
                2,
                device_id,
                std::vector<GpuPolyShard>{ destination_shard },
                0);
        ntt_raised.meta = coeff_source->meta;
        ntt_raised.meta.parms_id = destination_level_info.parms_id;
        ntt_raised.meta.q_count = destination_level_info.q_count;
        ntt_raised.meta.p_count = 0;
        ntt_raised.meta.component_count = 2;
        ntt_raised.meta.is_ntt_form = true;

        auto src_view = coeff_source->make_const_view();
        auto dst_view = ntt_raised.make_view();
        if (src_view.polys.size() == 2 && dst_view.polys.size() == 2 &&
            src_view.polys[0].shards.size() == 1 &&
            src_view.polys[1].shards.size() == 1 &&
            dst_view.polys[0].shards.size() == 1 &&
            dst_view.polys[1].shards.size() == 1 &&
            kernel::launch_fused_bootstrap_modraise_ntt_two_components_65536(
                dst_view.polys[0].shards.front().ptr,
                dst_view.polys[1].shards.front().ptr,
                src_view.polys[0].shards.front().ptr,
                src_view.polys[1].shards.front().ptr,
                source_level_info.q_count,
                destination_level_info.q_count,
                source_level_info.shards.front(),
                destination_level_info.shards.front()))
        {
            destination_ciphertext = std::move(ntt_raised);
            return;
        }
    }

    GpuCiphertextData coeff_raised =
        GpuCiphertextData::allocate_single_device_sharded(
            coeff_source->meta.degree,
            destination_level_info.q_count,
            coeff_source->size(),
            device_id,
            std::vector<GpuPolyShard>{ destination_shard },
            0);

    coeff_raised.meta = coeff_source->meta;
    coeff_raised.meta.parms_id = destination_level_info.parms_id;
    coeff_raised.meta.q_count = destination_level_info.q_count;
    coeff_raised.meta.p_count = 0;
    coeff_raised.meta.component_count = coeff_source->size();
    coeff_raised.meta.is_ntt_form = false;

    auto source_view = coeff_source->make_const_view();
    auto destination_view = coeff_raised.make_view();
    modswitch_handler_.raise_modulus_ciphertext(
        destination_view,
        source_view,
        source_level_info,
        destination_level_info);

    ntt_fwd(coeff_raised, destination_ciphertext);
}

void GpuEvaluator::bootstrap_prepare_modraise_input(
    const GpuCiphertextData &source_ciphertext,
    GpuCiphertextData &destination_ciphertext,
    parms_id_type q0_parms_id,
    double q0_over_message_ratio) const
{
    validate_ntt_ciphertext_input(
        "GpuEvaluator::bootstrap_prepare_modraise_input",
        source_ciphertext,
        true);
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_prepare_modraise_input: p limbs are not supported");
    }
    if (!(q0_over_message_ratio > 0.0) || !std::isfinite(q0_over_message_ratio))
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_prepare_modraise_input: invalid target scale");
    }

    const auto &q0_level_info = params_.get_level(q0_parms_id);
    if (q0_level_info.p_count != 0 ||
        q0_level_info.degree != source_ciphertext.meta.degree)
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_prepare_modraise_input: invalid q0 level");
    }

    if (source_ciphertext.meta.q_count < q0_level_info.q_count + 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_prepare_modraise_input: input needs one q modulus above q0 for scale normalization");
    }
    // Multiply before rescaling: rounding target/scale alone loses precision
    // when that ratio is small. The extra q gives the integer multiplier
    // another modulus worth of precision without lowering the input scale.
    //
    // One extra q stays the choice whenever its multiplier rounds within
    // kOneModulusRounding.  For an input scale far above q0/ratio (2^80
    // against 2^53) that multiplier is ~32 and rounds the scale by ~1.2%;
    // the output scale records it, but a Boot's raised-scale override then
    // discards it and the message comes back scaled.  There, further moduli
    // are divided out until the multiplier rounds within kPreciseRounding,
    // keeping it inside the exact integer range.  With no better choice the
    // most precise one is kept (bootstrap() refuses what it cannot use).
    constexpr double kOneModulusRounding = 1e-6;
    constexpr double kPreciseRounding = 1e-9;
    const double exact_integer_limit = std::ldexp(1.0, 53);
    std::size_t extra_moduli = 0;
    double scale_multiplier_double = 0.0;
    double rounding_error = std::numeric_limits<double>::infinity();
    double divisor = 1.0;
    for (std::size_t extra = 1;
         q0_level_info.q_count + extra <= source_ciphertext.meta.q_count; ++extra)
    {
        const auto &level =
            params_.get_level_by_q_count(q0_level_info.q_count + extra, 0);
        if (level.shards.empty() || level.shards.front().q_last == 0)
        {
            throw std::invalid_argument(
                "GpuEvaluator::bootstrap_prepare_modraise_input: missing q_last parameter");
        }
        divisor *= static_cast<double>(level.shards.front().q_last);
        const double exact =
            q0_over_message_ratio * divisor / source_ciphertext.meta.scale;
        if (!std::isfinite(exact) || exact > exact_integer_limit)
            break;
        const double rounded = std::round(exact);
        if (rounded < 1.0)
            continue;
        const double error = std::abs(rounded / exact - 1.0);
        if (error < rounding_error)
        {
            extra_moduli = extra;
            scale_multiplier_double = rounded;
            rounding_error = error;
        }
        if (error <= (extra == 1 ? kOneModulusRounding : kPreciseRounding))
            break;
    }
    if (extra_moduli == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_prepare_modraise_input: scale multiplier is outside the exact integer range [1, 2^53]");
    }
    const std::size_t normalization_q_count = q0_level_info.q_count + extra_moduli;
    const auto &normalization_level =
        params_.get_level_by_q_count(normalization_q_count, 0);

    const GpuCiphertextData *current = &source_ciphertext;
    GpuCiphertextData dropped;
    if (source_ciphertext.meta.q_count > normalization_q_count)
    {
        drop_modulus(source_ciphertext, dropped, normalization_level.parms_id);
        current = &dropped;
    }
    GpuCiphertextData scaled;
    multiply_scalar(*current, static_cast<std::uint64_t>(scale_multiplier_double), scaled);
    scaled.meta.scale = current->meta.scale * scale_multiplier_double;
    if (extra_moduli == 1)
        rescale(scaled, destination_ciphertext);
    else
        rescale_many(scaled, destination_ciphertext, static_cast<std::uint32_t>(extra_moduli));
}

/* GpuEvaluator::multiply(...) -> 输出 3 component: d0, d1, d2 */
void GpuEvaluator::relinearize(
    const GpuCiphertextData &source_ciphertext,
    const GpuRelinKeysData &relin_keys_in,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto &relin_keys = level_key_for(params_, relin_keys_in, source_ciphertext.meta, "GpuEvaluator::relinearize");
    if (source_ciphertext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::relinearize: empty ciphertext");
    }
    if (source_ciphertext.fields_.empty())
    {
        throw std::invalid_argument("GpuEvaluator::relinearize: empty ciphertext storage");
    }
    if (relin_keys.empty())
    {
        throw std::invalid_argument("GpuEvaluator::relinearize: empty relin keys");
    }
    if (!source_ciphertext.meta.is_ntt_form)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize: CKKS ciphertext must be in NTT form");
    }
    if (source_ciphertext.meta.component_count != source_ciphertext.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize: component metadata mismatch");
    }
    /* 重线性化只支持输入分量个数为3 */
    if (source_ciphertext.size() != 3)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize: first HYBRID implementation expects a size-3 ciphertext");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize: input ciphertext p limbs are not supported");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, reference_layout))
    {
        throw std::invalid_argument("GpuEvaluator::relinearize: shard layout mismatch");
    }

    /* 输出仍在同一层级，但重线性化后只保留2个密文分量 */
    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.component_count = 2;
    result_meta.is_ntt_form = true;

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            2,
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            2,
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    const auto &relin_keys_view =
        relin_keys.const_view(source_ciphertext.meta.q_count);
    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    /* 通过dnum分解的方式进行重线性化 */
    keyswitch_handler_.relinearize_hybrid_ciphertext(
        destination_view,
        source_view,
        relin_keys_view,
        relin_keys,
        level_info);

    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

bool GpuEvaluator::try_relinearize_pair(
    const GpuCiphertextData &source0,
    const GpuCiphertextData &source1,
    const GpuRelinKeysData &relin_keys_in,
    GpuCiphertextData &destination0,
    GpuCiphertextData &destination1) const
{
    const char *enabled = std::getenv("POSEIDON_GPU_RELIN_PAIR");
    if (enabled == nullptr || std::string(enabled) != "1") return false;
    if (&destination0 == &destination1)
        throw std::invalid_argument("try_relinearize_pair: outputs must be distinct");
    const auto supported = [](const GpuCiphertextData &ct) {
        if (ct.empty() || ct.fields_.size() != 1 || ct.size() != 3 ||
            ct.meta.component_count != 3 || ct.meta.degree != 65536 ||
            ct.meta.q_count == 0 || ct.meta.p_count != 0 || !ct.meta.is_ntt_form)
            return false;
        for (const auto &poly : ct.make_const_view().polys) {
            if (poly.shards.size() != 1) return false;
            const auto &s = poly.shards.front();
            if (s.device_id != ct.fields_.front().device_id || s.limb_begin != 0 ||
                s.limb_count != ct.meta.q_count || s.coeff_begin != 0 ||
                s.coeff_count != ct.meta.degree || s.ptr == nullptr)
                return false;
        }
        return true;
    };
    if (!supported(source0) || !supported(source1) ||
        source0.meta.parms_id != source1.meta.parms_id ||
        source0.meta.q_count != source1.meta.q_count ||
        source0.fields_.front().device_id != source1.fields_.front().device_id)
        return false;

    const auto &keys = level_key_for(
        params_, relin_keys_in, source0.meta, "GpuEvaluator::try_relinearize_pair");
    const auto &level = params_.get_level(source0.meta.parms_id);
    const auto &key_view = keys.const_view(source0.meta.q_count);
    const auto input0 = source0.make_const_view();
    const auto input1 = source1.make_const_view();
    const int device = source0.fields_.front().device_id;
    GpuCiphertextData result0 = GpuCiphertextData::allocate_single_device(
        source0.meta.degree, source0.meta.q_count, 2, device);
    GpuCiphertextData result1 = GpuCiphertextData::allocate_single_device(
        source1.meta.degree, source1.meta.q_count, 2, device);
    result0.meta = source0.meta;
    result1.meta = source1.meta;
    result0.meta.component_count = result1.meta.component_count = 2;
    auto output0 = result0.make_view();
    auto output1 = result1.make_view();
    if (!keyswitch_handler_.try_relinearize_hybrid_ciphertext_pair(
            output0, output1, input0, input1, key_view, keys, level))
        return false;
    destination0 = std::move(result0);
    destination1 = std::move(result1);
    return true;
}

bool GpuEvaluator::try_relinearize_rescale_pair(
    const GpuCiphertextData &source0,
    const GpuCiphertextData &source1,
    const GpuRelinKeysData &relin_keys_in,
    std::uint32_t drop_count,
    PairRelinPostOp post_op,
    const GpuPlaintextData *plain,
    const GpuCiphertextData *extra0,
    const GpuCiphertextData *extra1,
    GpuCiphertextData &destination0,
    GpuCiphertextData &destination1) const
{
    if (&destination0 == &destination1 || !opt_flag(OptFlag::RelinRescalePair))
        return false;
    if (drop_count != 1 && (drop_count != 2 || !use_rescale_x2()))
        return false;
    const auto supported = [&](const GpuCiphertextData &ct) {
        if (ct.empty() || ct.fields_.empty() || !ct.meta.is_ntt_form ||
            ct.meta.p_count != 0 || ct.meta.component_count != 3 || ct.size() != 3 ||
            ct.meta.degree != 65536 || ct.meta.q_count <= drop_count)
            return false;
        for (const auto &poly : ct.make_const_view().polys) {
            if (poly.shards.size() != 1) return false;
            const auto &s = poly.shards.front();
            if (s.device_id != ct.fields_.front().device_id || s.limb_begin != 0 ||
                s.limb_count != ct.meta.q_count || s.coeff_begin != 0 ||
                s.coeff_count != ct.meta.degree || s.ptr == nullptr)
                return false;
        }
        return true;
    };
    if (!supported(source0) || !supported(source1) ||
        source0.meta.parms_id != source1.meta.parms_id ||
        source0.meta.q_count != source1.meta.q_count ||
        source0.fields_.front().device_id != source1.fields_.front().device_id)
        return false;

    const int device = source0.fields_.front().device_id;
    const std::size_t q = source0.meta.q_count;
    const GpuWord *plain_ptr = nullptr;
    if (plain != nullptr && !plain->empty()) {
        if (!plain->meta.is_ntt_form || plain->meta.p_count != 0 ||
            plain->meta.degree != 65536 || plain->meta.q_count < q)
            return false;
        const auto pv = plain->make_const_view();
        if (pv.poly.shards.size() != 1) return false;
        const auto &ps = pv.poly.shards.front();
        if (ps.device_id != device || ps.limb_begin != 0 || ps.limb_count < q ||
            ps.coeff_begin != 0 || ps.coeff_count != 65536 || ps.ptr == nullptr)
            return false;
        plain_ptr = ps.ptr;
    }

    if (post_op == PairRelinPostOp::DoubleSubCipherPlain &&
        plain_ptr == nullptr)
        return false;

    GpuConstCiphertextView ext_view0, ext_view1;
    const GpuConstCiphertextView *ext_ptr0 = nullptr;
    const GpuConstCiphertextView *ext_ptr1 = nullptr;
    if (post_op == PairRelinPostOp::DoubleSubCipher ||
        post_op == PairRelinPostOp::DoubleSubCipherPlain) {
        if (extra0 == nullptr || extra1 == nullptr || extra0->empty() || extra1->empty() ||
            extra0->fields_.empty() || extra1->fields_.empty())
            return false;
        ext_view0 = extra0->make_const_view();
        ext_view1 = extra1->make_const_view();
        ext_ptr0 = &ext_view0;
        ext_ptr1 = &ext_view1;
    }

    const auto &keys = level_key_for(
        params_, relin_keys_in, source0.meta, "GpuEvaluator::try_relinearize_rescale_pair");
    if (keys.empty()) return false;
    const auto &source_level = params_.get_level(source0.meta.parms_id);
    if (source_level.q_count != q || source_level.shards.empty()) return false;
    const GpuLevelInfo *dest_level = &params_.get_next_level(source_level.parms_id);
    if (drop_count == 2) dest_level = &params_.get_next_level(dest_level->parms_id);
    const std::size_t retained = q - drop_count;
    if (dest_level->q_count != retained) return false;
    const double divisor = drop_count == 1
        ? static_cast<double>(source_level.shards.front().q_last)
        : static_cast<double>(source_level.shards.front().q_last_two_product);
    if (!(divisor > 0.0) || !std::isfinite(divisor)) return false;
    const double scale0 = source0.meta.scale / divisor;
    const double scale1 = source1.meta.scale / divisor;
    if (!(scale0 > 0.0) || !std::isfinite(scale0) ||
        !(scale1 > 0.0) || !std::isfinite(scale1))
        return false;

    const auto &key_view = keys.const_view(q);
    const auto input0 = source0.make_const_view();
    const auto input1 = source1.make_const_view();
    GpuCiphertextData result0 = GpuCiphertextData::allocate_single_device(
        65536, retained, 2, device);
    GpuCiphertextData result1 = GpuCiphertextData::allocate_single_device(
        65536, retained, 2, device);
    result0.meta = source0.meta;
    result1.meta = source1.meta;
    result0.meta.parms_id = result1.meta.parms_id = dest_level->parms_id;
    result0.meta.q_count = result1.meta.q_count = retained;
    result0.meta.component_count = result1.meta.component_count = 2;
    result0.meta.scale = scale0;
    result1.meta.scale = scale1;
    auto output0 = result0.make_view();
    auto output1 = result1.make_view();
    if (!keyswitch_handler_.try_relinearize_hybrid_ciphertext_rescale_pair(
            output0, output1, input0, input1, key_view, keys,
            source_level, *dest_level, drop_count, post_op,
            plain_ptr, ext_ptr0, ext_ptr1))
        return false;
    destination0 = std::move(result0);
    destination1 = std::move(result1);
    return true;
}

bool GpuEvaluator::try_relinearize_rescale_single(
    const GpuCiphertextData &source,
    const GpuRelinKeysData &relin_keys_in,
    std::uint32_t drop_count,
    PairRelinPostOp post_op,
    const GpuPlaintextData *plain,
    const GpuCiphertextData *extra,
    GpuCiphertextData &destination) const
{
    if (!opt_flag(OptFlag::RelinRescalePair) || !opt_flag(OptFlag::FusedRelinRescale))
        return false;
    if (drop_count != 1 && (drop_count != 2 || !use_rescale_x2()))
        return false;
    if (source.empty() || source.fields_.empty() || !source.meta.is_ntt_form ||
        source.meta.p_count != 0 || source.meta.component_count != 3 || source.size() != 3 ||
        source.meta.degree != 65536 || source.meta.q_count <= drop_count)
        return false;
    const int device = source.fields_.front().device_id;
    const std::size_t q = source.meta.q_count;
    for (const auto &poly : source.make_const_view().polys) {
        if (poly.shards.size() != 1) return false;
        const auto &s = poly.shards.front();
        if (s.device_id != device || s.limb_begin != 0 || s.limb_count != q ||
            s.coeff_begin != 0 || s.coeff_count != 65536 || s.ptr == nullptr)
            return false;
    }

    const GpuWord *plain_ptr = nullptr;
    if (plain != nullptr && !plain->empty()) {
        if (!plain->meta.is_ntt_form || plain->meta.p_count != 0 ||
            plain->meta.degree != 65536 || plain->meta.q_count < q)
            return false;
        const auto pv = plain->make_const_view();
        if (pv.poly.shards.size() != 1) return false;
        const auto &ps = pv.poly.shards.front();
        if (ps.device_id != device || ps.limb_begin != 0 || ps.limb_count < q ||
            ps.coeff_begin != 0 || ps.coeff_count != 65536 || ps.ptr == nullptr)
            return false;
        plain_ptr = ps.ptr;
    }
    if (post_op == PairRelinPostOp::DoubleSubCipherPlain && plain_ptr == nullptr)
        return false;

    GpuConstCiphertextView ext_view;
    const GpuConstCiphertextView *ext_ptr = nullptr;
    if (post_op == PairRelinPostOp::DoubleSubCipher ||
        post_op == PairRelinPostOp::DoubleSubCipherPlain) {
        if (extra == nullptr || extra->empty() || extra->fields_.empty())
            return false;
        ext_view = extra->make_const_view();
        ext_ptr = &ext_view;
    }

    const auto &keys = level_key_for(
        params_, relin_keys_in, source.meta, "GpuEvaluator::try_relinearize_rescale_single");
    if (keys.empty()) return false;
    const auto &source_level = params_.get_level(source.meta.parms_id);
    if (source_level.q_count != q || source_level.shards.empty()) return false;
    const GpuLevelInfo *dest_level = &params_.get_next_level(source_level.parms_id);
    if (drop_count == 2) dest_level = &params_.get_next_level(dest_level->parms_id);
    const std::size_t retained = q - drop_count;
    if (dest_level->q_count != retained) return false;
    const double divisor = drop_count == 1
        ? static_cast<double>(source_level.shards.front().q_last)
        : static_cast<double>(source_level.shards.front().q_last_two_product);
    if (!(divisor > 0.0) || !std::isfinite(divisor)) return false;
    const double scale = source.meta.scale / divisor;
    if (!(scale > 0.0) || !std::isfinite(scale))
        return false;

    const auto &key_view = keys.const_view(q);
    const auto input = source.make_const_view();
    GpuCiphertextData result = GpuCiphertextData::allocate_single_device(
        65536, retained, 2, device);
    result.meta = source.meta;
    result.meta.parms_id = dest_level->parms_id;
    result.meta.q_count = retained;
    result.meta.component_count = 2;
    result.meta.scale = scale;
    auto output = result.make_view();
    if (!keyswitch_handler_.try_relinearize_hybrid_ciphertext_rescale_postop(
            output, input, key_view, keys,
            source_level, *dest_level, drop_count, post_op,
            plain_ptr, ext_ptr))
        return false;
    destination = std::move(result);
    return true;
}

void GpuEvaluator::relinearize_rescale_x1_hybrid(
    const GpuCiphertextData &source_ciphertext,
    const GpuRelinKeysData &relin_keys_in,
    GpuCiphertextData &destination_ciphertext,
    bool double_moddown) const
{
    const auto &relin_keys = level_key_for(params_, relin_keys_in, source_ciphertext.meta, "GpuEvaluator::relinearize_rescale_x1_hybrid");
    if (source_ciphertext.empty() ||
        source_ciphertext.fields_.empty() ||
        relin_keys.empty() ||
        !source_ciphertext.meta.is_ntt_form ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.meta.component_count != 3 ||
        source_ciphertext.size() != 3 ||
        source_ciphertext.meta.q_count < 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x1_hybrid: unsupported ciphertext shape");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &source_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, source_layout))
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x1_hybrid: shard layout mismatch");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &destination_level_info =
        params_.get_next_level(source_ciphertext.meta.parms_id);
    if (source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info.q_count + 1 != source_level_info.q_count ||
        source_level_info.shards.empty() ||
        source_level_info.shards.front().q_last == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x1_hybrid: level/constants mismatch");
    }

    const std::size_t destination_q_count =
        source_ciphertext.meta.q_count - 1;
    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = source_ciphertext.meta.degree;

    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.parms_id = destination_level_info.parms_id;
    result_meta.q_count = destination_q_count;
    result_meta.p_count = 0;
    result_meta.component_count = 2;
    result_meta.is_ntt_form = true;
    result_meta.scale =
        source_ciphertext.meta.scale /
        static_cast<double>(
            source_level_info.shards.front().q_last);
    if (!(result_meta.scale > 0.0) || !std::isfinite(result_meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x1_hybrid: invalid result scale");
    }

    GpuRNSPoly reference_layout;
    reference_layout.degree = source_ciphertext.meta.degree;
    reference_layout.q_count = destination_q_count;
    reference_layout.p_count = 0;
    reference_layout.shards.push_back(destination_shard);

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            destination_q_count,
            2,
            device_id,
            std::vector<GpuPolyShard>{destination_shard},
            0);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            2,
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    const auto &relin_keys_view =
        relin_keys.const_view(source_ciphertext.meta.q_count);
    keyswitch_handler_.relinearize_hybrid_ciphertext_rescale_x1(
        destination_view,
        source_view,
        relin_keys_view,
        relin_keys,
        source_level_info,
        destination_level_info,
        double_moddown);

    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::relinearize_rescale_x2_hybrid(
    const GpuCiphertextData &source_ciphertext,
    const GpuRelinKeysData &relin_keys_in,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto &relin_keys = level_key_for(params_, relin_keys_in, source_ciphertext.meta, "GpuEvaluator::relinearize_rescale_x2_hybrid");
    if (source_ciphertext.empty() ||
        source_ciphertext.fields_.empty() ||
        relin_keys.empty() ||
        !source_ciphertext.meta.is_ntt_form ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.meta.component_count != 3 ||
        source_ciphertext.size() != 3 ||
        source_ciphertext.meta.q_count < 3)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x2_hybrid: unsupported ciphertext shape");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &source_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, source_layout))
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x2_hybrid: shard layout mismatch");
    }

    const auto &source_level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto &intermediate_level_info =
        params_.get_next_level(source_ciphertext.meta.parms_id);
    const auto &destination_level_info =
        params_.get_next_level(intermediate_level_info.parms_id);
    if (source_level_info.q_count != source_ciphertext.meta.q_count ||
        destination_level_info.q_count + 2 != source_level_info.q_count ||
        source_level_info.shards.empty() ||
        source_level_info.shards.front().q_last_two_product == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x2_hybrid: level/constants mismatch");
    }

    const std::size_t destination_q_count =
        source_ciphertext.meta.q_count - 2;
    GpuPolyShard destination_shard;
    destination_shard.field_index = 0;
    destination_shard.field_offset = 0;
    destination_shard.limb_begin = 0;
    destination_shard.limb_count = destination_q_count;
    destination_shard.coeff_begin = 0;
    destination_shard.coeff_count = source_ciphertext.meta.degree;

    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.parms_id = destination_level_info.parms_id;
    result_meta.q_count = destination_q_count;
    result_meta.p_count = 0;
    result_meta.component_count = 2;
    result_meta.is_ntt_form = true;
    result_meta.scale =
        source_ciphertext.meta.scale /
        static_cast<double>(
            source_level_info.shards.front().q_last_two_product);
    if (!(result_meta.scale > 0.0) || !std::isfinite(result_meta.scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::relinearize_rescale_x2_hybrid: invalid result scale");
    }

    GpuRNSPoly reference_layout;
    reference_layout.degree = source_ciphertext.meta.degree;
    reference_layout.q_count = destination_q_count;
    reference_layout.p_count = 0;
    reference_layout.shards.push_back(destination_shard);

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result = GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            destination_q_count,
            2,
            device_id,
            std::vector<GpuPolyShard>{destination_shard},
            0);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            nullptr,
            nullptr,
            result_meta,
            2,
            device_id,
            reference_layout);
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    const auto &relin_keys_view =
        relin_keys.const_view(source_ciphertext.meta.q_count);
    keyswitch_handler_.relinearize_hybrid_ciphertext_rescale_x2(
        destination_view,
        source_view,
        relin_keys_view,
        relin_keys,
        source_level_info,
        destination_level_info);

    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

/*顶层旋转操作入口*/
static void validate_rotate_input(const GpuCiphertextData &source_ciphertext)
{
    validate_ntt_ciphertext_input(
        "GpuEvaluator::rotate",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate: first implementation expects a size-2 ciphertext");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate: input ciphertext p limbs are not supported");
    }
    if (source_ciphertext.polys_.at(0).shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate: first implementation requires one full shard");
    }

}

void GpuEvaluator::rotate(
    const GpuCiphertextData &source_ciphertext,
    int step,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &destination_ciphertext) const
{
    rotate(source_ciphertext, step, galois_keys, destination_ciphertext, nullptr, 0);
}

void GpuEvaluator::rotate(
    const GpuCiphertextData &source_ciphertext,
    int step,
    const GpuGaloisKeysData &galois_keys_in,
    GpuCiphertextData &destination_ciphertext,
    GpuRotationHoistCache *hoist_cache,
    std::uintptr_t source_tag) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::rotate");
    validate_rotate_input(source_ciphertext);

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);
    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            2,
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);

    result.meta = source_ciphertext.meta;
    result.meta.component_count = 2;
    result.meta.is_ntt_form = true;

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result.make_view();

    /*step为0说明没有旋转，直接保持不变*/
    if (step == 0)
    {
        copy_poly(
            destination_view.polys[0],
            source_view.polys[0],
            "GpuEvaluator::rotate copy c0");
        copy_poly(
            destination_view.polys[1],
            source_view.polys[1],
            "GpuEvaluator::rotate copy c1");
        destination_ciphertext = std::move(result);
        return;
    }

    if (galois_keys.empty())
    {
        throw std::invalid_argument("GpuEvaluator::rotate: empty galois keys");
    }

    /*step不为0的情况，step表示左旋转位数，galois_elt_from_rotation_step负责把step转换成密文的Galois element形态。*/
    const std::uint32_t galois_elt = galois_elt_from_rotation_step(source_ciphertext.meta.degree, step);
    /*选择密钥，因为不同的step对应不同的旋转密钥，所以galois_key_index选择对应的高斯密钥*/
    const std::size_t key_index = galois_key_index(galois_elt);

    if (galois_keys.meta.galois_format ==
        GpuGaloisKeyFormat::InversePreRotated)
    {
        static const bool persistent_scratch = [] {
            const char *raw = std::getenv("POSEIDON_GPU_PERSISTENT_ROTATE_WORKSPACE");
            return raw != nullptr && std::string(raw) == "1";
        }();
        GpuDoubleHoistWorkspace local_staged;
        std::unique_lock<std::mutex> scratch_lock;
        if (persistent_scratch)
        {
            scratch_lock = std::unique_lock<std::mutex>(rotate_scratch_->mutex);
        }
        GpuDoubleHoistWorkspace &staged =
            persistent_scratch ? rotate_scratch_->workspace : local_staged;
        staged.outer_accumulator.ensure_capacity(
            device_id,
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            galois_keys.meta.p_count,
            1);
        // Runtime hoisting: the ModUp of c1 depends only on the source, so
        // rotations of the same source share one decomposition.
        GpuHoistedDecomposition *hoisted = &staged.source_hoist;
        if (hoist_cache != nullptr && source_tag != 0)
        {
            hoisted = &hoist_cache->decomposition;
            if (hoist_cache->source_tag != source_tag ||
                hoisted->parms_id != source_ciphertext.meta.parms_id ||
                hoisted->q_count != source_ciphertext.meta.q_count ||
                hoisted->device_id != device_id)
            {
                hoist_cache->source_tag = 0;
                keyswitch_handler_.hoist_decompose_modup_ntt(
                    source_view.polys[1],
                    level_info,
                    *hoisted,
                    staged.keyswitch);
                hoist_cache->source_tag = source_tag;
                ++hoist_cache->misses;
            }
            else
            {
                ++hoist_cache->hits;
            }
        }
        else
        {
            keyswitch_handler_.hoist_decompose_modup_ntt(
                source_view.polys[1],
                level_info,
                staged.source_hoist,
                staged.keyswitch);
        }
        const auto &key_view =
            galois_keys.const_view(source_ciphertext.meta.q_count);
        keyswitch_handler_.keyswitch_multsum_no_moddown(
            *hoisted,
            galois_elt,
            key_view,
            galois_keys,
            key_index,
            staged.outer_accumulator,
            0,
            true,
            level_info,
            staged.keyswitch);
        const GpuParameterShard *parameter_shard = nullptr;
        for (const auto &candidate : level_info.shards)
        {
            if (candidate.device_id == device_id &&
                candidate.hybrid_base_q_count ==
                    source_ciphertext.meta.q_count)
            {
                parameter_shard = &candidate;
                break;
            }
        }
        if (parameter_shard == nullptr)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rotate: HYBRID parameter shard is absent");
        }
        kernel::launch_double_hoist_add_lifted_galois_c0(
            staged.outer_accumulator.q_component(0, 0),
            source_view.polys[0].shards.front().ptr,
            galois_elt,
            *parameter_shard,
            source_ciphertext.meta.degree);
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            staged.outer_accumulator,
            0,
            result,
            source_ciphertext.meta,
            level_info,
            staged.keyswitch);
        destination_ciphertext = std::move(result);
        return;
    }

    GpuCiphertextData rotated_c1 =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            1,
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);
    rotated_c1.meta = source_ciphertext.meta;
    rotated_c1.meta.component_count = 1;
    rotated_c1.meta.is_ntt_form = true;

    auto rotated_c1_view = rotated_c1.make_view();

    kernel::launch_apply_galois_ntt_poly_shard(
        destination_view.polys[0].shards.front(),
        source_view.polys[0].shards.front(),
        galois_elt,
        source_ciphertext.meta.degree);
    kernel::launch_apply_galois_ntt_poly_shard(
        rotated_c1_view.polys[0].shards.front(),
        source_view.polys[1].shards.front(),
        galois_elt,
        source_ciphertext.meta.degree);

    /* c1 先清零，后续 switch-key 会把 rotated_c1 * galois_key 累加进去。 */
    zero_poly(destination_view.polys[1], "GpuEvaluator::rotate zero c1");

    auto rotated_c1_const_view = rotated_c1.make_const_view();
    const auto &galois_keys_view =
        galois_keys.const_view(source_ciphertext.meta.q_count);
    keyswitch_handler_.switch_key_hybrid_ciphertext(
        destination_view,
        rotated_c1_const_view.polys[0],
        galois_keys_view,
        galois_keys,
        key_index,
        level_info);

    destination_ciphertext = std::move(result);
}

void GpuEvaluator::switch_key(
    const GpuCiphertextData &source_ciphertext,
    const GpuEvaluationKeyData &switch_key,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_rotate_input(source_ciphertext);
    // Same special modulus as this level (level-aware Boot levels have their own P).
    const auto &resolved_key = level_key_for(
        params_, switch_key, source_ciphertext.meta, "GpuEvaluator::switch_key");
    if (resolved_key.empty())
    {
        throw std::invalid_argument("GpuEvaluator::switch_key: empty key");
    }
    NvtxRange range("SwitchKey");
    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);
    GpuCiphertextMeta result_meta = source_ciphertext.meta;
    result_meta.component_count = 2;
    result_meta.is_ntt_form = true;

    const bool aliases_input = &destination_ciphertext == &source_ciphertext;
    GpuCiphertextData local_result;
    GpuCiphertextData *result = &destination_ciphertext;
    if (aliases_input)
    {
        local_result =
            GpuCiphertextData::allocate_single_device_sharded(
                source_ciphertext.meta.degree,
                source_ciphertext.meta.q_count,
                2,
                device_id,
                source_ciphertext.polys_.at(0).shards,
                source_ciphertext.meta.p_count);
        local_result.meta = result_meta;
        result = &local_result;
    }
    else
    {
        prepare_ciphertext_destination(
            destination_ciphertext,
            &source_ciphertext,
            nullptr,
            result_meta,
            2,
            device_id,
            source_ciphertext.polys_.at(0));
    }

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result->make_view();
    keyswitch_handler_.switch_key_hybrid_ciphertext(
        destination_view,
        source_view.polys[1],
        resolved_key.const_view(source_ciphertext.meta.q_count),
        resolved_key,
        0,
        level_info,
        nullptr,
        &source_view.polys[0]);
    if (aliases_input)
    {
        destination_ciphertext = std::move(local_result);
    }
}

void GpuEvaluator::rotate_many_hoisted(
    const GpuCiphertextData &source_ciphertext,
    const std::vector<int> &steps,
    const GpuGaloisKeysData &galois_keys_in,
    GpuDoubleHoistWorkspace &workspace,
    std::vector<GpuCiphertextData> &destination_ciphertexts) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::rotate_many_hoisted");
    validate_ntt_ciphertext_input(
        "GpuEvaluator::rotate_many_hoisted",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2 ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.polys_.at(0).shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_many_hoisted: requires one-shard, size-2, Q-only input");
    }
    if (steps.empty())
    {
        destination_ciphertexts.clear();
        return;
    }
    if (galois_keys.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_many_hoisted: empty Galois keys");
    }

    const auto &level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto source_view = source_ciphertext.make_const_view();
    const auto &source0 = source_view.polys[0].shards.front();
    const GpuParameterShard *parameter_shard = nullptr;
    for (const auto &candidate : level_info.shards)
    {
        if (candidate.device_id == source0.device_id &&
            candidate.hybrid_base_q_count == source_ciphertext.meta.q_count)
        {
            parameter_shard = &candidate;
            break;
        }
    }
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_many_hoisted: HYBRID parameter shard is absent");
    }

    workspace.outer_accumulator.ensure_capacity(
        source0.device_id,
        source_ciphertext.meta.degree,
        source_ciphertext.meta.q_count,
        parameter_shard->hybrid_base_p_count,
        steps.size());
    keyswitch_handler_.hoist_decompose_modup_ntt(
        source_view.polys[1],
        level_info,
        workspace.source_hoist,
        workspace.keyswitch);
    const auto &key_view =
        galois_keys.const_view(source_ciphertext.meta.q_count);

    if (workspace.source_hoist.dnum <= kernel::kMaxHoistedKeymulBatchDigits)
    {
        std::vector<std::uint32_t> galois_elts(steps.size());
        std::vector<std::size_t> key_indices(steps.size());
        for (std::size_t index = 0; index < steps.size(); ++index)
        {
            if (steps[index] == 0)
            {
                throw std::invalid_argument(
                    "GpuEvaluator::rotate_many_hoisted: zero step is not supported");
            }
            const std::uint32_t galois_elt =
                galois_elt_from_rotation_step(
                    source_ciphertext.meta.degree, steps[index]);
            galois_elts[index] = galois_elt;
            key_indices[index] = galois_key_index(galois_elt);
        }
        keyswitch_handler_.keyswitch_hoisted_batch_no_moddown(
            workspace.source_hoist,
            source0.ptr,
            nullptr,
            galois_elts.data(),
            key_indices.data(),
            steps.size(),
            key_view,
            galois_keys,
            workspace.outer_accumulator,
            0,
            level_info);
    }
    else
    {
        for (std::size_t index = 0; index < steps.size(); ++index)
        {
            if (steps[index] == 0)
            {
                throw std::invalid_argument(
                    "GpuEvaluator::rotate_many_hoisted: zero step is not supported");
            }
            const std::uint32_t galois_elt =
                galois_elt_from_rotation_step(
                    source_ciphertext.meta.degree, steps[index]);
            const std::size_t key_index = galois_key_index(galois_elt);
            keyswitch_handler_.keyswitch_multsum_no_moddown(
                workspace.source_hoist,
                galois_elt,
                key_view,
                galois_keys,
                key_index,
                workspace.outer_accumulator,
                index,
                true,
                level_info,
                workspace.keyswitch);
            kernel::launch_double_hoist_add_lifted_galois_c0(
                workspace.outer_accumulator.q_component(index, 0),
                source0.ptr,
                galois_elt,
                *parameter_shard,
                source_ciphertext.meta.degree);
        }
    }

    keyswitch_handler_.moddown_qp_ciphertext_list_to_q(
        workspace.outer_accumulator,
        steps.size(),
        destination_ciphertexts,
        source_ciphertext.meta,
        level_info,
        workspace.keyswitch,
        workspace.batch_p_coeff,
        workspace.batch_converted_q);
}

void GpuEvaluator::rotate_many_hoisted_sum_with_identity(
    const GpuCiphertextData &source_ciphertext,
    const std::vector<int> &steps,
    const GpuGaloisKeysData &galois_keys_in,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_ntt_ciphertext_input(
        "GpuEvaluator::rotate_many_hoisted_sum_with_identity",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2 ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.polys_.at(0).shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_many_hoisted_sum_with_identity: "
            "requires one-shard, size-2, Q-only input");
    }
    if (steps.empty())
    {
        if (&destination_ciphertext != &source_ciphertext)
        {
            copy_ciphertext_data(
                source_ciphertext,
                destination_ciphertext,
                "GpuEvaluator::rotate_many_hoisted_sum_with_identity copy");
        }
        return;
    }
    const auto &galois_keys = level_key_for(
        params_,
        galois_keys_in,
        source_ciphertext.meta,
        "GpuEvaluator::rotate_many_hoisted_sum_with_identity");
    if (galois_keys.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_many_hoisted_sum_with_identity: empty Galois keys");
    }

    const auto &level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto source_view = source_ciphertext.make_const_view();
    const auto &source0 = source_view.polys[0].shards.front();
    const GpuParameterShard *parameter_shard = nullptr;
    for (const auto &candidate : level_info.shards)
    {
        if (candidate.device_id == source0.device_id &&
            candidate.hybrid_base_q_count == source_ciphertext.meta.q_count)
        {
            parameter_shard = &candidate;
            break;
        }
    }
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_many_hoisted_sum_with_identity: "
            "HYBRID parameter shard is absent");
    }

    workspace.outer_accumulator.ensure_capacity(
        source0.device_id,
        source_ciphertext.meta.degree,
        source_ciphertext.meta.q_count,
        parameter_shard->hybrid_base_p_count,
        1);
    keyswitch_handler_.hoist_decompose_modup_ntt(
        source_view.polys[1],
        level_info,
        workspace.source_hoist,
        workspace.keyswitch);

    if (workspace.source_hoist.dnum > kernel::kMaxHoistedKeymulBatchDigits)
    {
        std::vector<GpuCiphertextData> rotated;
        rotate_many_hoisted(
            source_ciphertext,
            steps,
            galois_keys,
            workspace,
            rotated);
        GpuCiphertextData sum;
        copy_ciphertext_data(
            source_ciphertext,
            sum,
            "GpuEvaluator::rotate_many_hoisted_sum_with_identity fallback copy");
        for (const auto &term : rotated)
        {
            add(sum, term, sum);
        }
        destination_ciphertext = std::move(sum);
        return;
    }

    const auto &key_view =
        galois_keys.const_view(source_ciphertext.meta.q_count);
    std::vector<std::uint32_t> galois_elts(steps.size());
    std::vector<std::size_t> key_indices(steps.size());
    for (std::size_t index = 0; index < steps.size(); ++index)
    {
        if (steps[index] == 0)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rotate_many_hoisted_sum_with_identity: "
                "zero step is not supported");
        }
        const std::uint32_t galois_elt =
            galois_elt_from_rotation_step(
                source_ciphertext.meta.degree, steps[index]);
        galois_elts[index] = galois_elt;
        key_indices[index] = galois_key_index(galois_elt);
    }

    keyswitch_handler_.keyswitch_hoisted_sum_no_moddown(
        workspace.source_hoist,
        source0.ptr,
        galois_elts.data(),
        key_indices.data(),
        steps.size(),
        key_view,
        galois_keys,
        workspace.outer_accumulator,
        0,
        level_info);

    if (&destination_ciphertext == &source_ciphertext)
    {
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.outer_accumulator,
            0,
            workspace.result_q,
            source_ciphertext.meta,
            level_info,
            workspace.keyswitch,
            &source_ciphertext);
        destination_ciphertext = std::move(workspace.result_q);
    }
    else
    {
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.outer_accumulator,
            0,
            destination_ciphertext,
            source_ciphertext.meta,
            level_info,
            workspace.keyswitch,
            &source_ciphertext);
    }
}

void GpuEvaluator::rotate_same_step_batch(
    const std::vector<const GpuCiphertextData *> &sources,
    int step,
    const GpuGaloisKeysData &galois_keys_in,
    std::vector<GpuCiphertextData> &destinations,
    const std::vector<const GpuCiphertextData *> *add_sources) const
{
    if (add_sources != nullptr && add_sources->size() != sources.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_same_step_batch: add_sources size mismatch");
    }
    if (sources.empty())
    {
        destinations.clear();
        return;
    }
    for (std::size_t i = 0; i < sources.size(); ++i)
    {
        if (sources[i] == nullptr ||
            (add_sources != nullptr && (*add_sources)[i] == nullptr))
        {
            throw std::invalid_argument(
                "GpuEvaluator::rotate_same_step_batch: null ciphertext pointer");
        }
        validate_rotate_input(*sources[i]);
    }
    const auto &first = *sources.front();
    const std::uint32_t galois_elt =
        step == 0 ? 1U : galois_elt_from_rotation_step(first.meta.degree, step);
    if (galois_elt == 1U)
    {
        std::vector<GpuCiphertextData> results(sources.size());
        for (std::size_t i = 0; i < sources.size(); ++i)
        {
            if (add_sources != nullptr)
            {
                add(*(*add_sources)[i], *sources[i], results[i]);
            }
            else
            {
                drop_modulus(*sources[i], results[i], sources[i]->meta.parms_id);
            }
        }
        destinations = std::move(results);
        return;
    }

    const auto &galois_keys = level_key_for(
        params_, galois_keys_in, first.meta, "GpuEvaluator::rotate_same_step_batch");
    if (galois_keys.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_same_step_batch: empty Galois keys");
    }

    bool can_batch = first.size() == 2 && first.meta.p_count == 0 &&
                     first.polys_.at(0).shards.size() == 1;
    const int device_id = first.fields_.at(0).device_id;
    for (std::size_t i = 0; can_batch && i < sources.size(); ++i)
    {
        const auto &src = *sources[i];
        if (src.meta.parms_id != first.meta.parms_id ||
            src.meta.q_count != first.meta.q_count ||
            src.meta.degree != first.meta.degree ||
            src.size() != 2 || src.meta.p_count != 0 ||
            src.fields_.at(0).device_id != device_id ||
            src.polys_.at(0).shards.size() != 1)
        {
            can_batch = false;
            break;
        }
        if (add_sources != nullptr)
        {
            const auto &extra = *(*add_sources)[i];
            validate_rotate_input(extra);
            if (extra.meta.parms_id != src.meta.parms_id ||
                extra.meta.q_count != src.meta.q_count ||
                extra.meta.degree != src.meta.degree ||
                extra.size() != 2 || extra.meta.p_count != 0 ||
                extra.fields_.at(0).device_id != device_id ||
                extra.polys_.at(0).shards.size() != 1 ||
                !(extra.meta.scale > 0.0) || !(src.meta.scale > 0.0) ||
                std::abs(std::log2(extra.meta.scale / src.meta.scale)) > 1e-8)
            {
                can_batch = false;
                break;
            }
        }
    }

    if (can_batch)
    {
        const auto &level_info = params_.get_level(first.meta.parms_id);
        const std::size_t key_index = galois_key_index(galois_elt);
        std::vector<GpuCiphertextData> results(sources.size());
        std::vector<GpuCiphertextView> dest_views;
        std::vector<GpuConstCiphertextView> source_views;
        std::vector<GpuConstCiphertextView> add_views_storage;
        std::vector<const GpuConstCiphertextView *> add_view_ptrs;
        dest_views.reserve(sources.size());
        source_views.reserve(sources.size());
        if (add_sources != nullptr)
        {
            add_views_storage.reserve(sources.size());
            add_view_ptrs.reserve(sources.size());
        }
        for (std::size_t i = 0; i < sources.size(); ++i)
        {
            results[i] = GpuCiphertextData::allocate_single_device_sharded(
                first.meta.degree,
                first.meta.q_count,
                2,
                device_id,
                first.polys_.at(0).shards,
                0);
            results[i].meta = sources[i]->meta;
            results[i].meta.component_count = 2;
            results[i].meta.is_ntt_form = true;
            dest_views.push_back(results[i].make_view());
            source_views.push_back(sources[i]->make_const_view());
            if (add_sources != nullptr)
            {
                add_views_storage.push_back((*add_sources)[i]->make_const_view());
            }
        }
        if (add_sources != nullptr)
        {
            for (const auto &v : add_views_storage)
            {
                add_view_ptrs.push_back(&v);
            }
        }
        std::vector<std::uint32_t> elts(sources.size(), galois_elt);
        std::vector<std::size_t> key_indices(sources.size(), key_index);
        if (keyswitch_handler_.try_rotate_dnum1_batch(
                dest_views,
                source_views,
                add_sources != nullptr ? &add_view_ptrs : nullptr,
                elts,
                key_indices,
                true,
                galois_keys.const_view(first.meta.q_count),
                galois_keys,
                level_info))
        {
            destinations = std::move(results);
            return;
        }
    }

    std::vector<GpuCiphertextData> fallback(sources.size());
    for (std::size_t i = 0; i < sources.size(); ++i)
    {
        GpuCiphertextData rotated;
        rotate(*sources[i], step, galois_keys_in, rotated);
        if (add_sources != nullptr)
        {
            add(*(*add_sources)[i], rotated, fallback[i]);
        }
        else
        {
            fallback[i] = std::move(rotated);
        }
    }
    destinations = std::move(fallback);
}

void GpuEvaluator::rotate_distinct_steps_batch(
    const std::vector<const GpuCiphertextData *> &sources,
    const std::vector<int> &steps,
    const GpuGaloisKeysData &galois_keys_in,
    std::vector<GpuCiphertextData> &destinations) const
{
    if (sources.size() != steps.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_distinct_steps_batch: steps size mismatch");
    }
    if (sources.empty())
    {
        destinations.clear();
        return;
    }
    for (const auto *src : sources)
    {
        if (src == nullptr)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rotate_distinct_steps_batch: null source");
        }
        validate_rotate_input(*src);
    }

    std::vector<GpuCiphertextData> results(sources.size());
    std::vector<std::size_t> active_indices;
    std::vector<const GpuCiphertextData *> active_sources;
    std::vector<std::uint32_t> elts;
    std::vector<std::size_t> key_indices;
    active_indices.reserve(sources.size());
    active_sources.reserve(sources.size());
    elts.reserve(sources.size());
    key_indices.reserve(sources.size());

    for (std::size_t i = 0; i < sources.size(); ++i)
    {
        const std::uint32_t elt = steps[i] == 0
            ? 1U
            : galois_elt_from_rotation_step(sources[i]->meta.degree, steps[i]);
        if (elt == 1U)
        {
            drop_modulus(*sources[i], results[i], sources[i]->meta.parms_id);
        }
        else
        {
            active_indices.push_back(i);
            active_sources.push_back(sources[i]);
            elts.push_back(elt);
            key_indices.push_back(galois_key_index(elt));
        }
    }

    if (active_sources.empty())
    {
        destinations = std::move(results);
        return;
    }

    const auto &first = *active_sources.front();
    const auto &galois_keys = level_key_for(
        params_, galois_keys_in, first.meta, "GpuEvaluator::rotate_distinct_steps_batch");
    if (galois_keys.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_distinct_steps_batch: empty Galois keys");
    }

    bool can_batch = first.size() == 2 && first.meta.p_count == 0 &&
                     first.polys_.at(0).shards.size() == 1;
    const int device_id = first.fields_.at(0).device_id;
    for (const auto *src : active_sources)
    {
        if (src->meta.parms_id != first.meta.parms_id ||
            src->meta.q_count != first.meta.q_count ||
            src->meta.degree != first.meta.degree ||
            src->size() != 2 || src->meta.p_count != 0 ||
            src->fields_.at(0).device_id != device_id ||
            src->polys_.at(0).shards.size() != 1)
        {
            can_batch = false;
            break;
        }
    }

    if (can_batch)
    {
        const auto &level_info = params_.get_level(first.meta.parms_id);
        std::vector<GpuCiphertextData> active_results(active_sources.size());
        std::vector<GpuCiphertextView> dest_views;
        std::vector<GpuConstCiphertextView> source_views;
        dest_views.reserve(active_sources.size());
        source_views.reserve(active_sources.size());
        for (std::size_t k = 0; k < active_sources.size(); ++k)
        {
            active_results[k] = GpuCiphertextData::allocate_single_device_sharded(
                first.meta.degree,
                first.meta.q_count,
                2,
                device_id,
                first.polys_.at(0).shards,
                0);
            active_results[k].meta = active_sources[k]->meta;
            active_results[k].meta.component_count = 2;
            active_results[k].meta.is_ntt_form = true;
            dest_views.push_back(active_results[k].make_view());
            source_views.push_back(active_sources[k]->make_const_view());
        }
        if (keyswitch_handler_.try_rotate_dnum1_batch(
                dest_views,
                source_views,
                nullptr,
                elts,
                key_indices,
                false,
                galois_keys.const_view(first.meta.q_count),
                galois_keys,
                level_info))
        {
            for (std::size_t k = 0; k < active_indices.size(); ++k)
            {
                results[active_indices[k]] = std::move(active_results[k]);
            }
            destinations = std::move(results);
            return;
        }
    }

    for (std::size_t idx : active_indices)
    {
        rotate(*sources[idx], steps[idx], galois_keys_in, results[idx]);
    }
    destinations = std::move(results);
}

void GpuEvaluator::rotate_distinct_steps_sum(
    const std::vector<const GpuCiphertextData *> &sources,
    const std::vector<int> &steps,
    const GpuGaloisKeysData &galois_keys_in,
    GpuCiphertextData &destination) const
{
    if (sources.empty() || sources.size() != steps.size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_distinct_steps_sum: invalid input size");
    }
    const auto *first_ptr = sources.front();
    if (first_ptr == nullptr)
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_distinct_steps_sum: null source");
    }
    const auto &first = *first_ptr;
    validate_rotate_input(first);

    std::vector<const GpuCiphertextData *> zero_sources;
    std::vector<const GpuCiphertextData *> active_sources;
    std::vector<int> active_steps;
    std::vector<std::uint32_t> elts;
    std::vector<std::size_t> key_indices;

    for (std::size_t i = 0; i < sources.size(); ++i)
    {
        const auto *src = sources[i];
        if (src == nullptr)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rotate_distinct_steps_sum: null source");
        }
        validate_rotate_input(*src);
        if (src->meta.parms_id != first.meta.parms_id ||
            src->meta.q_count != first.meta.q_count ||
            src->meta.degree != first.meta.degree ||
            !(src->meta.scale > 0.0) || !(first.meta.scale > 0.0) ||
            std::abs(std::log2(src->meta.scale / first.meta.scale)) > 1e-8)
        {
            throw std::invalid_argument(
                "GpuEvaluator::rotate_distinct_steps_sum: misaligned sources");
        }
        const std::uint32_t elt = steps[i] == 0
            ? 1U
            : galois_elt_from_rotation_step(src->meta.degree, steps[i]);
        if (elt == 1U)
        {
            zero_sources.push_back(src);
        }
        else
        {
            active_sources.push_back(src);
            active_steps.push_back(steps[i]);
            elts.push_back(elt);
            key_indices.push_back(galois_key_index(elt));
        }
    }

    GpuCiphertextData zero_sum_storage;
    const GpuCiphertextData *identity_ptr = nullptr;
    if (zero_sources.size() == 1)
    {
        identity_ptr = zero_sources[0];
    }
    else if (zero_sources.size() > 1)
    {
        add(*zero_sources[0], *zero_sources[1], zero_sum_storage);
        for (std::size_t i = 2; i < zero_sources.size(); ++i)
        {
            GpuCiphertextData next;
            add(zero_sum_storage, *zero_sources[i], next);
            zero_sum_storage = std::move(next);
        }
        identity_ptr = &zero_sum_storage;
    }

    if (active_sources.empty())
    {
        if (zero_sources.size() == 1)
        {
            drop_modulus(*zero_sources[0], destination, zero_sources[0]->meta.parms_id);
        }
        else
        {
            destination = std::move(zero_sum_storage);
        }
        return;
    }

    const auto &galois_keys = level_key_for(
        params_, galois_keys_in, first.meta, "GpuEvaluator::rotate_distinct_steps_sum");
    if (galois_keys.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::rotate_distinct_steps_sum: empty Galois keys");
    }

    bool can_batch = active_sources.size() <= kernel::kMaxBatchKeySwitchItems &&
                     first.size() == 2 && first.meta.p_count == 0 &&
                     first.polys_.at(0).shards.size() == 1;
    const int device_id = first.fields_.at(0).device_id;
    for (const auto *src : active_sources)
    {
        if (src->size() != 2 || src->meta.p_count != 0 ||
            src->fields_.at(0).device_id != device_id ||
            src->polys_.at(0).shards.size() != 1)
        {
            can_batch = false;
            break;
        }
    }

    if (can_batch)
    {
        const auto &level_info = params_.get_level(first.meta.parms_id);
        GpuCiphertextData result = GpuCiphertextData::allocate_single_device_sharded(
            first.meta.degree,
            first.meta.q_count,
            2,
            device_id,
            first.polys_.at(0).shards,
            0);
        result.meta = first.meta;
        result.meta.component_count = 2;
        result.meta.is_ntt_form = true;
        auto dest_view = result.make_view();
        GpuConstCiphertextView id_view{};
        if (identity_ptr != nullptr)
        {
            id_view = identity_ptr->make_const_view();
        }
        std::vector<GpuConstCiphertextView> source_views;
        source_views.reserve(active_sources.size());
        for (const auto *src : active_sources)
        {
            source_views.push_back(src->make_const_view());
        }
        if (keyswitch_handler_.try_rotate_dnum1_distinct_sum(
                dest_view,
                identity_ptr != nullptr ? &id_view : nullptr,
                source_views,
                elts,
                key_indices,
                galois_keys.const_view(first.meta.q_count),
                galois_keys,
                level_info))
        {
            destination = std::move(result);
            return;
        }
    }

    GpuCiphertextData sum;
    std::size_t start_idx = 0;
    if (identity_ptr != nullptr)
    {
        drop_modulus(*identity_ptr, sum, identity_ptr->meta.parms_id);
    }
    else
    {
        rotate(*active_sources[0], active_steps[0], galois_keys_in, sum);
        start_idx = 1;
    }
    for (std::size_t k = start_idx; k < active_sources.size(); ++k)
    {
        GpuCiphertextData rotated;
        GpuCiphertextData next;
        rotate(*active_sources[k], active_steps[k], galois_keys_in, rotated);
        add(sum, rotated, next);
        sum = std::move(next);
    }
    destination = std::move(sum);
}

void GpuEvaluator::rotate_inplace(
    GpuCiphertextData &ciphertext, int step,
    const GpuGaloisKeysData &galois_keys, GpuRotateWorkspace &workspace) const
{
    rotate_inplace(ciphertext, step, galois_keys, workspace, nullptr, 0);
}

void GpuEvaluator::rotate_inplace(
    GpuCiphertextData &ciphertext, int step,
    const GpuGaloisKeysData &galois_keys_in, GpuRotateWorkspace &workspace,
    const GpuRotationHoistCache *hoist_cache, std::uintptr_t source_tag) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, ciphertext.meta, "GpuEvaluator::rotate_inplace");
    validate_rotate_input(ciphertext);
    if (step == 0) return;
    if (galois_keys.empty())
        throw std::invalid_argument("GpuEvaluator::rotate_inplace: empty galois keys");
    const auto galois_elt = galois_elt_from_rotation_step(ciphertext.meta.degree, step);
    const auto key_index = galois_key_index(galois_elt);
    const int device_id = ciphertext.fields_.front().device_id;
    const auto &level_info = params_.get_level(ciphertext.meta.parms_id);
    auto source_view = ciphertext.make_const_view();
    auto destination_view = ciphertext.make_view();

    if (galois_keys.meta.galois_format == GpuGaloisKeyFormat::InversePreRotated)
    {
        auto &staged = workspace.pre_rotated;
        staged.outer_accumulator.ensure_capacity(device_id, ciphertext.meta.degree,
            ciphertext.meta.q_count, galois_keys.meta.p_count, 1);
        // The input is consumed here, so a cached decomposition is only read.
        const GpuHoistedDecomposition *hoisted = &staged.source_hoist;
        if (hoist_cache != nullptr && source_tag != 0 && hoist_cache->source_tag == source_tag &&
            hoist_cache->decomposition.parms_id == ciphertext.meta.parms_id &&
            hoist_cache->decomposition.q_count == ciphertext.meta.q_count &&
            hoist_cache->decomposition.device_id == device_id)
            hoisted = &hoist_cache->decomposition;
        else
            keyswitch_handler_.hoist_decompose_modup_ntt(source_view.polys[1],
                level_info, staged.source_hoist, staged.keyswitch);
        const auto &key_view = galois_keys.const_view(ciphertext.meta.q_count);
        keyswitch_handler_.keyswitch_multsum_no_moddown(*hoisted,
            galois_elt, key_view, galois_keys, key_index,
            staged.outer_accumulator, 0, true, level_info, staged.keyswitch);
        const GpuParameterShard *parameter_shard = nullptr;
        for (const auto &candidate : level_info.shards)
            if (candidate.device_id == device_id &&
                candidate.hybrid_base_q_count == ciphertext.meta.q_count)
            {
                parameter_shard = &candidate;
                break;
            }
        if (!parameter_shard)
            throw std::invalid_argument("GpuEvaluator::rotate_inplace: HYBRID parameter shard is absent");
        kernel::launch_double_hoist_add_lifted_galois_c0(
            staged.outer_accumulator.q_component(0, 0),
            source_view.polys[0].shards.front().ptr, galois_elt,
            *parameter_shard, ciphertext.meta.degree);
        const auto meta = ciphertext.meta;
        keyswitch_handler_.moddown_qp_ciphertext_to_q(staged.outer_accumulator,
            0, ciphertext, meta, level_info, staged.keyswitch);
        return;
    }

    auto &temporary = workspace.permutation;
    if (temporary.empty())
        temporary = GpuCiphertextData::allocate_single_device_sharded(
            ciphertext.meta.degree, ciphertext.meta.q_count, 1, device_id,
            ciphertext.polys_.front().shards, 0);
    if (temporary.meta.degree != ciphertext.meta.degree ||
        temporary.meta.q_count != ciphertext.meta.q_count ||
        temporary.size() != 1 || temporary.fields_.front().device_id != device_id)
        throw std::invalid_argument("GpuEvaluator::rotate_inplace: workspace shape mismatch");
    temporary.meta = ciphertext.meta;
    temporary.meta.component_count = 1;
    auto temporary_view = temporary.make_view();
    kernel::launch_apply_galois_ntt_poly_shard(temporary_view.polys[0].shards.front(),
        source_view.polys[0].shards.front(), galois_elt, ciphertext.meta.degree);
    copy_poly(destination_view.polys[0], temporary.make_const_view().polys[0],
              "GpuEvaluator::rotate_inplace copy c0");
    kernel::launch_apply_galois_ntt_poly_shard(temporary_view.polys[0].shards.front(),
        source_view.polys[1].shards.front(), galois_elt, ciphertext.meta.degree);
    zero_poly(destination_view.polys[1], "GpuEvaluator::rotate_inplace zero c1");
    auto temporary_const_view = temporary.make_const_view();
    const auto &key_view = galois_keys.const_view(ciphertext.meta.q_count);
    keyswitch_handler_.switch_key_hybrid_ciphertext(destination_view,
        temporary_const_view.polys[0], key_view, galois_keys, key_index,
        level_info, &workspace.key_switch);
}

void GpuEvaluator::conjugate(
    const GpuCiphertextData &source_ciphertext,
    const GpuGaloisKeysData &galois_keys_in,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::conjugate");
    validate_ntt_ciphertext_input(
        "GpuEvaluator::conjugate",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::conjugate: first implementation expects a size-2 ciphertext");
    }
    if (source_ciphertext.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::conjugate: input ciphertext p limbs are not supported");
    }
    if (source_ciphertext.polys_.at(0).shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::conjugate: first implementation requires one full shard");
    }
    if (galois_keys.empty())
    {
        throw std::invalid_argument("GpuEvaluator::conjugate: empty galois keys");
    }
    if (galois_keys.meta.galois_format ==
        GpuGaloisKeyFormat::InversePreRotated)
    {
        GpuDoubleHoistWorkspace staged;
        conjugate_pre_rotated(
            source_ciphertext,
            galois_keys,
            staged,
            destination_ciphertext);
        return;
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);
    const auto &level_info = params_.get_level(source_ciphertext.meta.parms_id);

    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            2,
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);

    result.meta = source_ciphertext.meta;
    result.meta.component_count = 2;
    result.meta.is_ntt_form = true;

    const std::uint32_t galois_elt =
        galois_elt_for_conjugation(source_ciphertext.meta.degree);
    const std::size_t key_index = galois_key_index(galois_elt);

    GpuCiphertextData conjugated_c1 =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            1,
            device_id,
            reference_layout.shards,
            source_ciphertext.meta.p_count);
    conjugated_c1.meta = source_ciphertext.meta;
    conjugated_c1.meta.component_count = 1;
    conjugated_c1.meta.is_ntt_form = true;

    auto source_view = source_ciphertext.make_const_view();
    auto destination_view = result.make_view();
    auto conjugated_c1_view = conjugated_c1.make_view();

    kernel::launch_apply_galois_ntt_poly_shard(
        destination_view.polys[0].shards.front(),
        source_view.polys[0].shards.front(),
        galois_elt,
        source_ciphertext.meta.degree);
    kernel::launch_apply_galois_ntt_poly_shard(
        conjugated_c1_view.polys[0].shards.front(),
        source_view.polys[1].shards.front(),
        galois_elt,
        source_ciphertext.meta.degree);

    zero_poly(destination_view.polys[1], "GpuEvaluator::conjugate zero c1");

    auto conjugated_c1_const_view = conjugated_c1.make_const_view();
    const auto &galois_keys_view =
        galois_keys.const_view(source_ciphertext.meta.q_count);
    keyswitch_handler_.switch_key_hybrid_ciphertext(
        destination_view,
        conjugated_c1_const_view.polys[0],
        galois_keys_view,
        galois_keys,
        key_index,
        level_info);

    destination_ciphertext = std::move(result);
}

void GpuEvaluator::conjugate_pre_rotated(
    const GpuCiphertextData &source_ciphertext,
    const GpuGaloisKeysData &galois_keys_in,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext,
    const GpuCiphertextData *add_source) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::conjugate_pre_rotated");
    validate_ntt_ciphertext_input(
        "GpuEvaluator::conjugate_pre_rotated",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2 ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.polys_.at(0).shards.size() != 1 ||
        galois_keys.meta.galois_format !=
            GpuGaloisKeyFormat::InversePreRotated)
    {
        throw std::invalid_argument(
            "GpuEvaluator::conjugate_pre_rotated: invalid input/key format");
    }

    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto source_view = source_ciphertext.make_const_view();
    const std::uint32_t galois_elt =
        galois_elt_for_conjugation(source_ciphertext.meta.degree);
    const std::size_t key_index = galois_key_index(galois_elt);

    workspace.outer_accumulator.ensure_capacity(
        device_id,
        source_ciphertext.meta.degree,
        source_ciphertext.meta.q_count,
        galois_keys.meta.p_count,
        1);
    keyswitch_handler_.hoist_decompose_modup_ntt(
        source_view.polys[1],
        level_info,
        workspace.source_hoist,
        workspace.keyswitch);
    const auto &key_view =
        galois_keys.const_view(source_ciphertext.meta.q_count);
    keyswitch_handler_.keyswitch_multsum_no_moddown(
        workspace.source_hoist,
        galois_elt,
        key_view,
        galois_keys,
        key_index,
        workspace.outer_accumulator,
        0,
        true,
        level_info,
        workspace.keyswitch,
        source_view.polys[0].shards.front().ptr);

    if (&destination_ciphertext == &source_ciphertext ||
        &destination_ciphertext == add_source)
    {
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.outer_accumulator,
            0,
            workspace.result_q,
            source_ciphertext.meta,
            level_info,
            workspace.keyswitch,
            add_source);
        destination_ciphertext = std::move(workspace.result_q);
    }
    else
    {
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.outer_accumulator,
            0,
            destination_ciphertext,
            source_ciphertext.meta,
            level_info,
            workspace.keyswitch,
            add_source);
    }
}

bool GpuEvaluator::try_conjugate_pre_rotated_c2s_split(
    const GpuCiphertextData &dft_result,
    const GpuPlaintextData &minus_i_plaintext,
    const GpuGaloisKeysData &galois_keys_in,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &result_real,
    GpuCiphertextData &result_imag) const
{
    if (&result_real == &result_imag ||
        &result_real == &dft_result ||
        &result_imag == &dft_result ||
        dft_result.empty() ||
        dft_result.fields_.size() != 1 ||
        dft_result.size() != 2 ||
        !dft_result.meta.is_ntt_form ||
        dft_result.meta.p_count != 0 ||
        dft_result.polys_[0].shards.size() != 1 ||
        !all_components_use_layout(dft_result, dft_result.polys_[0]) ||
        minus_i_plaintext.empty() ||
        !minus_i_plaintext.meta.is_ntt_form ||
        minus_i_plaintext.meta.p_count != 0 ||
        minus_i_plaintext.meta.degree != dft_result.meta.degree ||
        minus_i_plaintext.meta.q_count < dft_result.meta.q_count ||
        minus_i_plaintext.poly_.shards.size() != 1)
    {
        return false;
    }
    const double imag_scale =
        dft_result.meta.scale * minus_i_plaintext.meta.scale;
    if (!(dft_result.meta.scale > 0.0) || !std::isfinite(dft_result.meta.scale) ||
        !(imag_scale > 0.0) || !std::isfinite(imag_scale))
    {
        return false;
    }
    const auto &galois_keys = level_key_for(
        params_,
        galois_keys_in,
        dft_result.meta,
        "GpuEvaluator::try_conjugate_pre_rotated_c2s_split");
    if (galois_keys.empty() ||
        galois_keys.meta.galois_format != GpuGaloisKeyFormat::InversePreRotated ||
        galois_keys.meta.p_count == 0)
    {
        return false;
    }
    const auto &level_info = params_.get_level(dft_result.meta.parms_id);
    if (level_info.shards.size() != 1 ||
        level_info.q_count != dft_result.meta.q_count)
    {
        return false;
    }

    const int device_id = dft_result.fields_.front().device_id;
    const auto source_view = dft_result.make_const_view();
    const std::uint32_t galois_elt =
        galois_elt_for_conjugation(dft_result.meta.degree);
    const std::size_t key_index = galois_key_index(galois_elt);

    workspace.outer_accumulator.ensure_capacity(
        device_id,
        dft_result.meta.degree,
        dft_result.meta.q_count,
        galois_keys.meta.p_count,
        1);
    keyswitch_handler_.hoist_decompose_modup_ntt(
        source_view.polys[1],
        level_info,
        workspace.source_hoist,
        workspace.keyswitch);
    const auto &key_view =
        galois_keys.const_view(dft_result.meta.q_count);
    keyswitch_handler_.keyswitch_multsum_no_moddown(
        workspace.source_hoist,
        galois_elt,
        key_view,
        galois_keys,
        key_index,
        workspace.outer_accumulator,
        0,
        true,
        level_info,
        workspace.keyswitch,
        source_view.polys[0].shards.front().ptr);
    keyswitch_handler_.moddown_qp_ciphertext_to_q_c2s_split(
        workspace.outer_accumulator,
        0,
        dft_result,
        minus_i_plaintext,
        result_real,
        result_imag,
        level_info,
        workspace.keyswitch);
    return true;
}

void GpuEvaluator::multiply_by_diag_matrix_bsgs(
    const GpuCiphertextData &source_ciphertext,
    const GpuMatrixPlain &matrix,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &destination_ciphertext) const
{
    multiply_by_diag_matrix_bsgs(
        source_ciphertext,
        matrix,
        galois_keys,
        1,
        destination_ciphertext);
}

void GpuEvaluator::multiply_by_diag_matrix_bsgs(
    const GpuCiphertextData &source_ciphertext,
    const GpuMatrixPlain &matrix,
    const GpuGaloisKeysData &galois_keys_in,
    std::uint32_t rescale_count,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::multiply_by_diag_matrix_bsgs");
    validate_ntt_ciphertext_input(
        "GpuEvaluator::multiply_by_diag_matrix_bsgs",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs: first implementation expects a size-2 ciphertext");
    }
    if (matrix.plain_vec.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs: empty diagonal matrix");
    }
    if (matrix.n1 == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs: invalid BSGS n1");
    }

    const auto [index, unused_rot_n1, rot_n2] =
        poseidon::bsgs_index(
            matrix.plain_vec,
            1 << matrix.log_slots,
            static_cast<int>(matrix.n1));
    (void)unused_rot_n1;

    std::map<int, GpuCiphertextData> baby_rotations;
    for (const int step : rot_n2)
    {
        if (step == 0)
        {
            continue;
        }

        GpuCiphertextData rotated;
        rotate(source_ciphertext, step, galois_keys, rotated);
        baby_rotations.emplace(step, std::move(rotated));
    }

    GpuCiphertextData result_accumulator;
    GpuCiphertextData inner_sum;
    GpuCiphertextData product;
    GpuCiphertextData rotated_inner_sum;
    bool have_result = false;

    for (const auto &giant_entry : index)
    {
        const int giant_step = giant_entry.first;
        bool have_inner_sum = false;

        for (const int baby_step : giant_entry.second)
        {
            const int diagonal_index = giant_step + baby_step;
            const auto plaintext_it = matrix.plain_vec.find(diagonal_index);
            if (plaintext_it == matrix.plain_vec.end())
            {
                throw std::invalid_argument(
                    "GpuEvaluator::multiply_by_diag_matrix_bsgs: missing plaintext diagonal");
            }

            const GpuCiphertextData &rotated_source =
                baby_step == 0 ? source_ciphertext : baby_rotations.at(baby_step);

            multiply_plain(rotated_source, plaintext_it->second, product);

            if (!have_inner_sum)
            {
                inner_sum = std::move(product);
                have_inner_sum = true;
            }
            else
            {
                GpuCiphertextData updated_inner_sum;
                add(inner_sum, product, updated_inner_sum);
                inner_sum = std::move(updated_inner_sum);
            }
        }

        if (!have_inner_sum)
        {
            continue;
        }

        if (!have_result)
        {
            if (giant_step == 0)
            {
                result_accumulator = std::move(inner_sum);
            }
            else
            {
                rotate(inner_sum, giant_step, galois_keys, rotated_inner_sum);
                result_accumulator = std::move(rotated_inner_sum);
            }
            have_result = true;
        }
        else
        {
            if (giant_step == 0)
            {
                GpuCiphertextData updated_accumulator;
                add(result_accumulator, inner_sum, updated_accumulator);
                result_accumulator = std::move(updated_accumulator);
            }
            else
            {
                rotate(inner_sum, giant_step, galois_keys, rotated_inner_sum);
                GpuCiphertextData updated_accumulator;
                add(result_accumulator, rotated_inner_sum, updated_accumulator);
                result_accumulator = std::move(updated_accumulator);
            }
        }
    }

    if (!have_result)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs: no nonzero diagonal contribution");
    }

    if (rescale_count == 0)
    {
        destination_ciphertext = std::move(result_accumulator);
    }
    else
    {
        rescale_many(
            result_accumulator,
            destination_ciphertext,
            rescale_count);
    }
}

void GpuEvaluator::multiply_by_diag_matrix_bsgs_loose(
    const GpuCiphertextData &source_ciphertext,
    const GpuMatrixPlain &matrix,
    const GpuGaloisKeysData &galois_keys_in,
    std::uint32_t rescale_count,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::multiply_by_diag_matrix_bsgs_loose");
    validate_ntt_ciphertext_input(
        "GpuEvaluator::multiply_by_diag_matrix_bsgs_loose",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2 ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.polys_.at(0).shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_loose: "
            "requires one-shard, size-2, Q-only input");
    }

    const auto plan = make_gpu_loose_bsgs_plan(matrix);

    // Each non-zero baby rotation is a complete Q-basis ciphertext.  No
    // hoisted decomposition or lifted-QP accumulator is shared with another
    // task.  A future multi-GPU lowering can therefore place these rotations
    // independently and insert ordinary CopyCipher operations when needed.
    std::map<int, GpuCiphertextData> baby_rotations;
    for (const int step : plan.baby_steps)
    {
        if (step == 0)
        {
            continue;
        }
        GpuCiphertextData rotated;
        rotate(source_ciphertext, step, galois_keys, rotated);
        baby_rotations.emplace(step, std::move(rotated));
    }

    // Materialize one ordinary Q-basis result per giant group before the
    // final reduction.  Term products are reduced locally as a bounded-memory
    // reference executor; the public plan retains every independent term for
    // a scheduler that wants to distribute them further.
    std::vector<GpuCiphertextData> group_outputs;
    group_outputs.reserve(plan.groups.size());
    for (const auto &group : plan.groups)
    {
        GpuCiphertextData inner_sum;
        bool have_inner_sum = false;
        for (const auto &term : group.terms)
        {
            const auto plaintext_it =
                matrix.plain_vec.find(term.diagonal_index);
            if (plaintext_it == matrix.plain_vec.end())
            {
                throw std::invalid_argument(
                    "GpuEvaluator::multiply_by_diag_matrix_bsgs_loose: "
                    "missing plaintext diagonal");
            }
            const GpuCiphertextData &rotated_source =
                term.baby_step == 0
                    ? source_ciphertext
                    : baby_rotations.at(term.baby_step);

            GpuCiphertextData product;
            multiply_plain(rotated_source, plaintext_it->second, product);
            if (!have_inner_sum)
            {
                inner_sum = std::move(product);
                have_inner_sum = true;
            }
            else
            {
                GpuCiphertextData updated_inner_sum;
                add(inner_sum, product, updated_inner_sum);
                inner_sum = std::move(updated_inner_sum);
            }
        }
        if (!have_inner_sum)
        {
            throw std::logic_error(
                "GpuEvaluator::multiply_by_diag_matrix_bsgs_loose: "
                "empty giant group");
        }

        if (group.giant_step == 0)
        {
            group_outputs.push_back(std::move(inner_sum));
        }
        else
        {
            GpuCiphertextData rotated_group;
            rotate(inner_sum, group.giant_step, galois_keys, rotated_group);
            group_outputs.push_back(std::move(rotated_group));
        }
    }

    GpuCiphertextData result_accumulator = std::move(group_outputs.front());
    for (std::size_t index = 1; index < group_outputs.size(); ++index)
    {
        GpuCiphertextData updated_accumulator;
        add(
            result_accumulator,
            group_outputs[index],
            updated_accumulator);
        result_accumulator = std::move(updated_accumulator);
    }

    if (rescale_count == 0)
    {
        destination_ciphertext = std::move(result_accumulator);
    }
    else
    {
        rescale_many(
            result_accumulator,
            destination_ciphertext,
            rescale_count);
    }
}

void GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist(
    const GpuCiphertextData &source_ciphertext,
    const GpuMatrixPlainQP &matrix,
    const GpuGaloisKeysData &galois_keys_in,
    std::uint32_t rescale_count,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    if(workspace.parallel_matrix && !matrix.group_view)
    {
        if(rescale_count)throw std::invalid_argument("parallel matrix requires merge before rescale");
        if(workspace.parallel_matrix(source_ciphertext,matrix,
            [&](const GpuMatrixPlainQP &partial,GpuCiphertextData &output) {
                multiply_by_diag_matrix_bsgs_double_hoist(source_ciphertext,partial,
                    galois_keys_in,0,workspace,output);
            },destination_ciphertext))return;
    }
    const auto &galois_keys = level_key_for(params_, galois_keys_in, source_ciphertext.meta, "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist");
    validate_ntt_ciphertext_input(
        "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2 ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.polys_.at(0).shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist: "
            "requires one-shard, size-2, Q-only input");
    }
    const bool has_full_plaintexts = !matrix.plain_vec_qp.empty();
    const bool has_compressed_plaintexts =
        !matrix.compressed_plain_vec_qp.empty();
    // A group view reads its parent matrix's plaintexts through plan pointers.
    if ((matrix.group_view
             ? has_full_plaintexts || has_compressed_plaintexts
             : has_full_plaintexts == has_compressed_plaintexts) ||
        matrix.plan.terms.empty() ||
        matrix.plan.baby_steps.empty() ||
        matrix.plan.giant_steps.empty() ||
        matrix.plan.group_term_offsets.size() !=
            matrix.plan.giant_steps.size() + 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist: "
            "matrix plan is incomplete");
    }
    if (galois_keys.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist: "
            "empty Galois keys");
    }

    const auto &level_info =
        params_.get_level(source_ciphertext.meta.parms_id);
    const auto source_view = source_ciphertext.make_const_view();
    const auto &source_shard0 = source_view.polys[0].shards.front();
    const auto &source_shard1 = source_view.polys[1].shards.front();
    const GpuParameterShard *parameter_shard = nullptr;
    for (const auto &candidate : level_info.shards)
    {
        if (candidate.device_id == source_shard0.device_id &&
            candidate.hybrid_base_q_count ==
                source_ciphertext.meta.q_count)
        {
            parameter_shard = &candidate;
            break;
        }
    }
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count == 0)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist: "
            "HYBRID parameter shard is absent");
    }

    const std::size_t degree = source_ciphertext.meta.degree;
    const std::size_t q_count = source_ciphertext.meta.q_count;
    const std::size_t p_count =
        parameter_shard->hybrid_base_p_count;
    const std::size_t dnum = (q_count + p_count - 1) / p_count;
    const std::size_t group_count = matrix.plan.giant_steps.size();
    const std::size_t baby_count = matrix.plan.baby_steps.size();
    const bool requested_batched_giant_intt =
        use_double_hoist_batched_giant_intt() &&
        degree == 65536 &&
        group_count > 1;
    std::size_t requested_tile = workspace.baby_tile_size;
    if (const char *raw = std::getenv("POSEIDON_GPU_DOUBLE_HOIST_BABY_TILE"))
    {
        const auto parsed = std::strtoull(raw, nullptr, 10);
        if (parsed != 0)
        {
            requested_tile = static_cast<std::size_t>(parsed);
        }
    }
    if (dnum == 1)
    {
        if (const char *raw = std::getenv(
                "POSEIDON_GPU_DOUBLE_HOIST_DNUM1_BABY_TILE"))
        {
            const auto parsed = std::strtoull(raw, nullptr, 10);
            if (parsed != 0)
            {
                requested_tile = static_cast<std::size_t>(parsed);
            }
        }
        else
        {
            requested_tile = 8;
        }
    }
    requested_tile = std::max<std::size_t>(
        1,
        std::min(requested_tile, baby_count));
    workspace.baby_tile_size = requested_tile;

    const std::size_t qp_poly_bytes =
        (q_count + p_count) * degree * sizeof(GpuWord);
    const std::size_t estimated_workspace =
        dnum * qp_poly_bytes +
        requested_tile * 2 * qp_poly_bytes +
        group_count * 2 * qp_poly_bytes +
        2 * qp_poly_bytes +
        (4 * q_count + 4 * p_count) * degree * sizeof(GpuWord) +
        (requested_batched_giant_intt
             ? (group_count - 1) * q_count * degree * sizeof(GpuWord)
             : 0);
    std::size_t max_workspace_bytes = workspace.max_workspace_bytes;
    if (const char *raw =
            std::getenv("POSEIDON_GPU_DOUBLE_HOIST_MAX_WORKSPACE_MB"))
    {
        const auto parsed = std::strtoull(raw, nullptr, 10);
        if (parsed != 0)
        {
            max_workspace_bytes =
                static_cast<std::size_t>(parsed) * 1024 * 1024;
        }
    }
    if (max_workspace_bytes != 0 &&
        estimated_workspace > max_workspace_bytes)
    {
        throw std::runtime_error(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist: "
            "estimated workspace exceeds POSEIDON_GPU_DOUBLE_HOIST_MAX_WORKSPACE_MB");
    }

    workspace.last_counts = {};
    workspace.last_counts.workspace_peak_bytes = estimated_workspace;
    workspace.group_accumulators.ensure_capacity(
        source_shard0.device_id,
        degree,
        q_count,
        p_count,
        group_count);
    const bool direct_qp_mac_init =
        use_double_hoist_qp_mac_direct_init();
    if (!direct_qp_mac_init)
    {
        workspace.group_accumulators.q.fill_zero();
        workspace.group_accumulators.p.fill_zero();
    }

    keyswitch_handler_.hoist_decompose_modup_ntt(
        source_view.polys[1],
        level_info,
        workspace.source_hoist,
        workspace.keyswitch);
    workspace.last_counts.source_decompose_count = 1;

    const auto &galois_keys_view =
        galois_keys.const_view(q_count);
    const bool fused_baby_keyswitch_c0 =
        use_double_hoist_fused_baby_keyswitch_c0() &&
        dnum == 1 &&
        galois_keys.meta.galois_format ==
            GpuGaloisKeyFormat::InversePreRotated;
    const std::size_t max_fused_baby_groups =
        opt_flag(OptFlag::FusedBaby8)
            ? kernel::kMaxDoubleHoistFusedBabyGroups
            : std::size_t{4};
    bool fused_baby_keyswitch_plain_mac =
        use_double_hoist_fused_baby_keyswitch_plain_mac() &&
        degree == 65536 &&
        requested_tile <= kernel::kMaxDoubleHoistFusedBabySteps &&
        group_count <= max_fused_baby_groups &&
        galois_keys.meta.galois_format ==
            GpuGaloisKeyFormat::InversePreRotated;
    if (fused_baby_keyswitch_plain_mac)
    {
        std::vector<bool> term_seen(group_count * baby_count, false);
        for (const auto &term : matrix.plan.terms)
        {
            if (term.giant_index >= group_count ||
                term.baby_index >= baby_count)
            {
                fused_baby_keyswitch_plain_mac = false;
                break;
            }
            const std::size_t slot =
                static_cast<std::size_t>(term.giant_index) * baby_count +
                term.baby_index;
            if (term_seen[slot])
            {
                fused_baby_keyswitch_plain_mac = false;
                break;
            }
            term_seen[slot] = true;
        }
    }
    for (std::size_t tile_begin = 0;
         tile_begin < baby_count;
         tile_begin += requested_tile)
    {
        const std::size_t tile_count =
            std::min(requested_tile, baby_count - tile_begin);
        ++workspace.last_counts.baby_tile_count;
        if (fused_baby_keyswitch_plain_mac)
        {
            std::array<
                std::uint32_t,
                kernel::kMaxDoubleHoistFusedBabySteps> galois_elts{};
            std::array<
                std::uint32_t,
                kernel::kMaxDoubleHoistFusedBabySteps> key_indices{};
            std::array<
                std::uint32_t,
                kernel::kMaxDoubleHoistFusedBabyGroups *
                    kernel::kMaxDoubleHoistFusedBabySteps> term_indices{};
            term_indices.fill(std::numeric_limits<std::uint32_t>::max());

            for (std::size_t local = 0; local < tile_count; ++local)
            {
                const int step =
                    matrix.plan.baby_steps[tile_begin + local];
                if (step == 0)
                {
                    continue;
                }
                const std::uint32_t galois_elt =
                    galois_elt_from_rotation_step(degree, step);
                const std::size_t key_index =
                    galois_key_index(galois_elt);
                if (key_index > std::numeric_limits<std::uint32_t>::max() ||
                    galois_keys.galois_elts_by_key_index.size() <= key_index ||
                    galois_keys.galois_elts_by_key_index[key_index] !=
                        galois_elt)
                {
                    throw std::invalid_argument(
                        "fused baby KeySwitch/plain MAC key mismatch");
                }
                const std::size_t pointer_end =
                    (key_index + 1) *
                    galois_keys.meta.decomposition_count;
                if (galois_keys.galois_key_q0_ptrs.size() < pointer_end ||
                    galois_keys.galois_key_p0_ptrs.size() < pointer_end ||
                    galois_keys.galois_key_q1_ptrs.size() < pointer_end ||
                    galois_keys.galois_key_p1_ptrs.size() < pointer_end)
                {
                    throw std::invalid_argument(
                        "fused baby KeySwitch/plain MAC pointer table mismatch");
                }
                galois_elts[local] = galois_elt;
                key_indices[local] =
                    static_cast<std::uint32_t>(key_index);
                ++workspace.last_counts.keymul_count;
                ++workspace.last_counts.permute_count;
            }
            for (std::size_t term_index = 0;
                 term_index < matrix.plan.terms.size();
                 ++term_index)
            {
                const auto &term = matrix.plan.terms[term_index];
                if (term.baby_index < tile_begin ||
                    term.baby_index >= tile_begin + tile_count)
                {
                    continue;
                }
                const std::size_t local = term.baby_index - tile_begin;
                term_indices[
                    static_cast<std::size_t>(term.giant_index) *
                            kernel::kMaxDoubleHoistFusedBabySteps +
                        local] =
                        static_cast<std::uint32_t>(term_index);
            }
            kernel::launch_double_hoist_fused_baby_keyswitch_plain_accumulate(
                workspace.group_accumulators.q.data(),
                workspace.group_accumulators.p.data(),
                workspace.source_hoist.digits_q_ntt.data(),
                workspace.source_hoist.digits_p_ntt.data(),
                source_shard0.ptr,
                source_shard1.ptr,
                galois_elts.data(),
                key_indices.data(),
                term_indices.data(),
                galois_keys.galois_key_q0_ptrs.data(),
                galois_keys.galois_key_p0_ptrs.data(),
                galois_keys.galois_key_q1_ptrs.data(),
                galois_keys.galois_key_p1_ptrs.data(),
                matrix.plan.diagonal_q_ptrs.data(),
                matrix.plan.diagonal_p_ptrs.data(),
                matrix.plan.diagonal_periods.data(),
                group_count,
                matrix.plan.terms.size(),
                tile_count,
                dnum,
                galois_keys.meta.decomposition_count,
                *parameter_shard,
                degree,
                matrix.plan.compressed_plaintexts,
                direct_qp_mac_init && tile_begin == 0);
            continue;
        }
        workspace.baby_tile.ensure_capacity(
            source_shard0.device_id,
            degree,
            q_count,
            p_count,
            tile_count);

        if (workspace.source_hoist.dnum <= kernel::kMaxHoistedKeymulBatchDigits &&
            tile_count <= kernel::kMaxDoubleHoistFusedBabySteps)
        {
            std::array<std::uint32_t, kernel::kMaxDoubleHoistFusedBabySteps> tile_galois_elts{};
            std::array<std::size_t, kernel::kMaxDoubleHoistFusedBabySteps> tile_key_indices{};
            for (std::size_t local = 0; local < tile_count; ++local)
            {
                const int step = matrix.plan.baby_steps[tile_begin + local];
                if (step == 0)
                {
                    tile_galois_elts[local] = 0;
                    tile_key_indices[local] = 0;
                    continue;
                }
                const std::uint32_t galois_elt =
                    galois_elt_from_rotation_step(degree, step);
                tile_galois_elts[local] = galois_elt;
                tile_key_indices[local] = galois_key_index(galois_elt);
                ++workspace.last_counts.keymul_count;
                workspace.last_counts.permute_count +=
                    galois_keys.meta.galois_format ==
                            GpuGaloisKeyFormat::InversePreRotated
                        ? 1
                        : 2 * workspace.source_hoist.dnum + 1;
            }
            keyswitch_handler_.keyswitch_hoisted_batch_no_moddown(
                workspace.source_hoist,
                source_shard0.ptr,
                source_shard1.ptr,
                tile_galois_elts.data(),
                tile_key_indices.data(),
                tile_count,
                galois_keys_view,
                galois_keys,
                workspace.baby_tile,
                0,
                level_info);
        }
        else
        {
            for (std::size_t local = 0; local < tile_count; ++local)
            {
                const int step =
                    matrix.plan.baby_steps[tile_begin + local];
                if (step == 0)
                {
                    kernel::launch_double_hoist_lift_identity(
                        workspace.baby_tile.q_component(local, 0),
                        workspace.baby_tile.q_component(local, 1),
                        workspace.baby_tile.p_component(local, 0),
                        workspace.baby_tile.p_component(local, 1),
                        source_shard0.ptr,
                        source_shard1.ptr,
                        *parameter_shard,
                        degree,
                        false);
                    continue;
                }

                const std::uint32_t galois_elt =
                    galois_elt_from_rotation_step(degree, step);
                const std::size_t key_index =
                    galois_key_index(galois_elt);
                keyswitch_handler_.keyswitch_multsum_no_moddown(
                    workspace.source_hoist,
                    galois_elt,
                    galois_keys_view,
                    galois_keys,
                    key_index,
                    workspace.baby_tile,
                    local,
                    true,
                    level_info,
                    workspace.keyswitch,
                    fused_baby_keyswitch_c0
                        ? source_shard0.ptr
                        : nullptr);
                if (!fused_baby_keyswitch_c0)
                {
                    kernel::launch_double_hoist_add_lifted_galois_c0(
                        workspace.baby_tile.q_component(local, 0),
                        source_shard0.ptr,
                        galois_elt,
                        *parameter_shard,
                        degree);
                }
                ++workspace.last_counts.keymul_count;
                workspace.last_counts.permute_count +=
                    galois_keys.meta.galois_format ==
                            GpuGaloisKeyFormat::InversePreRotated
                        ? 1
                        : 2 * workspace.source_hoist.dnum + 1;
            }
        }

        kernel::launch_double_hoist_qp_plain_mul_accumulate_groups(
            workspace.group_accumulators.q.data(),
            workspace.group_accumulators.p.data(),
            workspace.baby_tile.q.data(),
            workspace.baby_tile.p.data(),
            matrix.plan.diagonal_q_ptrs.data(),
            matrix.plan.diagonal_p_ptrs.data(),
            matrix.plan.diagonal_periods.data(),
            matrix.plan.term_baby_indices.data(),
            matrix.plan.group_term_offsets_device.data(),
            group_count,
            matrix.plan.terms.size(),
            tile_begin,
            tile_count,
            *parameter_shard,
            degree,
            matrix.plan.compressed_plaintexts,
            direct_qp_mac_init && tile_begin == 0);
    }
    workspace.last_counts.qp_pmult_count = matrix.plan.terms.size();

    GpuCiphertextMeta product_meta = source_ciphertext.meta;
    product_meta.scale *= matrix.scale;
    bool have_outer = false;
    const bool grouped_outer_moddown =
        galois_keys.meta.galois_format ==
        GpuGaloisKeyFormat::InversePreRotated;
    const auto identity_it = std::find(
        matrix.plan.giant_steps.begin(),
        matrix.plan.giant_steps.end(),
        0);
    const bool direct_giant_accumulate =
        grouped_outer_moddown &&
        use_double_hoist_direct_giant_accumulate() &&
        identity_it != matrix.plan.giant_steps.end() &&
        group_count > 1;
    const std::size_t identity_group_index =
        identity_it == matrix.plan.giant_steps.end()
            ? group_count
            : static_cast<std::size_t>(
                  identity_it - matrix.plan.giant_steps.begin());
    const bool direct_identity_only =
        grouped_outer_moddown &&
        group_count == 1 &&
        identity_group_index == 0;
    const auto try_fused_outer_moddown_rescale =
        [&](GpuQPCiphertextBuffer &qp_buf) -> bool {
            if (!(rescale_count == 1 ||
                  (rescale_count == 2 && use_rescale_x2())))
            {
                return false;
            }
            if (level_info.q_count <= rescale_count)
            {
                return false;
            }
            const GpuLevelInfo *dest_level =
                &params_.get_next_level(level_info.parms_id);
            if (rescale_count == 2)
            {
                dest_level = &params_.get_next_level(dest_level->parms_id);
            }
            if (dest_level->q_count + rescale_count != level_info.q_count)
            {
                return false;
            }
            return keyswitch_handler_.try_moddown_qp_ciphertext_to_q_rescale(
                qp_buf,
                0,
                destination_ciphertext,
                product_meta,
                level_info,
                *dest_level,
                rescale_count,
                workspace.keyswitch);
        };
    if (direct_identity_only)
    {
        /*
         * A direct diagonal plan places every term in the identity giant
         * group. Its QP plaintext-MAC accumulator is already the final
         * linear-transform result, so a single ModDown is sufficient. Do not
         * run the generic identity path, which would ModDown, lift back to QP,
         * and ModDown a second time only to satisfy the outer BSGS pipeline.
         */
        if (try_fused_outer_moddown_rescale(workspace.group_accumulators))
        {
            workspace.last_counts.outer_moddown_count = 1;
            return;
        }
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.group_accumulators,
            0,
            workspace.result_q,
            product_meta,
            level_info,
            workspace.keyswitch);
        workspace.last_counts.outer_moddown_count = 1;
        if (rescale_count == 0)
        {
            destination_ciphertext = std::move(workspace.result_q);
        }
        else
        {
            rescale_many(
                workspace.result_q,
                destination_ciphertext,
                rescale_count);
        }
        return;
    }
    const bool qp_c0 = direct_giant_accumulate && use_double_hoist_qp_c0();
    if (grouped_outer_moddown)
    {
        if (qp_c0)
        {
            // Only c1 of the non-identity groups is decomposed for the giant
            // key switch; everything else stays in QP.
            std::vector<std::uint32_t> c1_groups;
            c1_groups.reserve(group_count);
            for (std::size_t group = 0; group < group_count; ++group)
            {
                if (matrix.plan.giant_steps[group] != 0)
                {
                    c1_groups.push_back(static_cast<std::uint32_t>(group));
                }
            }
            keyswitch_handler_.moddown_qp_c1_groups_to_q(
                workspace.group_accumulators,
                c1_groups,
                group_count,
                workspace.inner_q_batch,
                level_info,
                workspace.batch_p_coeff,
                workspace.batch_converted_q);
            workspace.last_counts.inner_moddown_count += c1_groups.size();
        }
        else
        {
            /*
             * All group accumulators have the same shape. Batch their P-side
             * INTT/P->Q/forward-NTT/ModDown instead of completing one full
             * pipeline before launching the next group.
             */
            keyswitch_handler_.moddown_qp_ciphertext_batch_to_q(
                workspace.group_accumulators,
                group_count,
                workspace.inner_q_batch,
                level_info,
                workspace.batch_p_coeff,
                workspace.batch_converted_q);
            workspace.last_counts.inner_moddown_count += group_count;
        }

        bool batched_giant_intt =
            requested_batched_giant_intt &&
            identity_group_index == 0;
        for (std::size_t group = 1;
             batched_giant_intt && group < group_count;
             ++group)
        {
            batched_giant_intt = matrix.plan.giant_steps[group] != 0;
        }
        const std::size_t batched_giant_count =
            batched_giant_intt ? group_count - 1 : 0;
        const std::size_t q_words = q_count * degree;
        const std::size_t p_words = p_count * degree;
        const GpuWord *giant_q_inverse =
            ((p_count != 9 || opt_flag(OptFlag::UnifyP9)) &&
             p_count <= 64 && kernel::modup_fold_applicable(degree))
                ? kernel::hybrid_q_preweighted_inv_degree_table(*parameter_shard)
                : nullptr;
        const bool batched_giant_hoist =
            batched_giant_intt &&
            degree == 65536 &&
            p_count > 0 && p_count <= 64 &&
            (p_count != 9 || opt_flag(OptFlag::UnifyP9)) &&
            parameter_shard->limb_begin == 0 &&
            parameter_shard->ntt_tables.size() >= (q_count + p_count) * 65536;
        if (batched_giant_intt)
        {
            const std::size_t required_words =
                batched_giant_count * q_words;
            if (workspace.outer_source_intt_q_batch.device_id() !=
                    source_shard0.device_id ||
                workspace.outer_source_intt_q_batch.size() < required_words)
            {
                workspace.outer_source_intt_q_batch.allocate(
                    required_words,
                    source_shard0.device_id);
            }

            GpuPolyShardView destination_intt;
            destination_intt.device_id = source_shard0.device_id;
            destination_intt.ptr =
                workspace.outer_source_intt_q_batch.data();
            destination_intt.limb_begin = 0;
            destination_intt.limb_count = q_count;
            destination_intt.coeff_begin = 0;
            destination_intt.coeff_count = degree;

            GpuConstPolyShardView source_ntt;
            source_ntt.device_id = source_shard0.device_id;
            source_ntt.ptr =
                workspace.inner_q_batch.q_component(1, 1);
            source_ntt.limb_begin = 0;
            source_ntt.limb_count = q_count;
            source_ntt.coeff_begin = 0;
            source_ntt.coeff_count = degree;

            kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
                destination_intt,
                source_ntt,
                *parameter_shard,
                degree,
                batched_giant_count,
                q_words,
                2 * q_words,
                giant_q_inverse);
            const bool skip_giant_q_copy = [&] {
                if (!qp_c0)
                {
                    return false;
                }
                const char *raw = std::getenv("POSEIDON_SKIP_GIANT_Q_COPY");
                return !(raw && *raw && std::string(raw) == "0");
            }();
            if (batched_giant_hoist)
            {
                keyswitch_handler_.hoist_decompose_modup_ntt_batch(
                    workspace.inner_q_batch.q_component(1, 1),
                    2 * q_words,
                    workspace.outer_source_intt_q_batch.data(),
                    giant_q_inverse != nullptr,
                    batched_giant_count,
                    level_info,
                    workspace.outer_digits_q_ntt_batch,
                    workspace.outer_digits_p_ntt_batch,
                    workspace.outer_modup_q_batch,
                    workspace.outer_modup_p_batch,
                    skip_giant_q_copy);
            }
        }

        const bool skip_giant_q_copy = [&] {
            if (!qp_c0 || !batched_giant_hoist)
            {
                return false;
            }
            const char *raw = std::getenv("POSEIDON_SKIP_GIANT_Q_COPY");
            return !(raw && *raw && std::string(raw) == "0");
        }();

        std::vector<const GpuWord *> digit_q_ptrs;
        std::vector<const GpuWord *> digit_p_ptrs;
        std::vector<std::uint32_t> group_indices;
        std::vector<std::uint32_t> galois_elts;
        std::vector<std::uint32_t> key_indices;
        digit_q_ptrs.reserve(group_count);
        digit_p_ptrs.reserve(group_count);
        group_indices.reserve(group_count);
        galois_elts.reserve(group_count);
        key_indices.reserve(group_count);
        if (!batched_giant_hoist && workspace.outer_group_hoists.size() < group_count)
        {
            workspace.outer_group_hoists.resize(group_count);
        }

        for (std::size_t group = 0; group < group_count; ++group)
        {
            const int giant_step = matrix.plan.giant_steps[group];
            if (giant_step == 0)
            {
                if (!direct_giant_accumulate)
                {
                    kernel::launch_double_hoist_lift_identity(
                        workspace.group_accumulators.q_component(group, 0),
                        workspace.group_accumulators.q_component(group, 1),
                        workspace.group_accumulators.p_component(group, 0),
                        workspace.group_accumulators.p_component(group, 1),
                        workspace.inner_q_batch.q_component(group, 0),
                        workspace.inner_q_batch.q_component(group, 1),
                        *parameter_shard,
                        degree,
                        false);
                }
                have_outer = true;
                continue;
            }

            const std::size_t non_identity_group = group - 1;
            const GpuWord *digit_q_ptr = nullptr;
            const GpuWord *digit_p_ptr = nullptr;
            if (batched_giant_hoist)
            {
                digit_q_ptr =
                    (skip_giant_q_copy && dnum == 1)
                        ? workspace.inner_q_batch.q_component(group, 1)
                        : workspace.outer_digits_q_ntt_batch.data() +
                              non_identity_group * dnum * q_words;
                digit_p_ptr = workspace.outer_digits_p_ntt_batch.data() +
                              non_identity_group * dnum * p_words;
            }
            else
            {
                GpuConstRNSPolyView inner_c1;
                inner_c1.poly_id = 1;
                inner_c1.shards.push_back(GpuConstPolyShardView{
                    source_shard0.device_id,
                    workspace.inner_q_batch.q_component(group, 1),
                    0,
                    q_count,
                    0,
                    degree});
                auto &group_hoist = workspace.outer_group_hoists[group];
                const GpuWord *precomputed_source_intt_q =
                    batched_giant_intt
                        ? workspace.outer_source_intt_q_batch.data() +
                              non_identity_group * q_words
                        : nullptr;
                keyswitch_handler_.hoist_decompose_modup_ntt(
                    inner_c1,
                    level_info,
                    group_hoist,
                    workspace.keyswitch,
                    precomputed_source_intt_q,
                    batched_giant_intt && giant_q_inverse != nullptr);
                digit_q_ptr = group_hoist.digits_q_ntt.data();
                digit_p_ptr = group_hoist.digits_p_ntt.data();
            }
            ++workspace.last_counts.outer_decompose_count;

            const std::uint32_t galois_elt =
                galois_elt_from_rotation_step(degree, giant_step);
            const std::size_t key_index =
                galois_key_index(galois_elt);
            if (key_index > std::numeric_limits<std::uint32_t>::max())
            {
                throw std::overflow_error(
                    "double-hoist giant key index exceeds uint32_t");
            }
            digit_q_ptrs.push_back(digit_q_ptr);
            digit_p_ptrs.push_back(digit_p_ptr);
            group_indices.push_back(static_cast<std::uint32_t>(group));
            galois_elts.push_back(galois_elt);
            key_indices.push_back(static_cast<std::uint32_t>(key_index));
        }

        const std::size_t active_group_count = group_indices.size();
        if (active_group_count != 0)
        {
            if (qp_c0)
            {
                workspace.outer_accumulator.ensure_capacity(
                    source_shard0.device_id,
                    degree,
                    q_count,
                    p_count,
                    1);
                kernel::launch_double_hoist_pre_rotated_giant_group_accumulate_qp_c0(
                    workspace.outer_accumulator.q_component(0, 0),
                    workspace.outer_accumulator.q_component(0, 1),
                    workspace.outer_accumulator.p_component(0, 0),
                    workspace.outer_accumulator.p_component(0, 1),
                    workspace.group_accumulators.q.data(),
                    workspace.group_accumulators.p.data(),
                    identity_group_index,
                    digit_q_ptrs.data(),
                    digit_p_ptrs.data(),
                    group_indices.data(),
                    galois_elts.data(),
                    key_indices.data(),
                    galois_keys.galois_key_q0_ptrs.data(),
                    galois_keys.galois_key_p0_ptrs.data(),
                    galois_keys.galois_key_q1_ptrs.data(),
                    galois_keys.galois_key_p1_ptrs.data(),
                    active_group_count,
                    dnum,
                    galois_keys.meta.decomposition_count,
                    *parameter_shard,
                    degree,
                    skip_giant_q_copy ? workspace.inner_q_batch.q.data() : nullptr,
                    skip_giant_q_copy ? p_count : 0);
            }
            else if (direct_giant_accumulate)
            {
                workspace.outer_accumulator.ensure_capacity(
                    source_shard0.device_id,
                    degree,
                    q_count,
                    p_count,
                    1);
                kernel::launch_double_hoist_pre_rotated_giant_group_accumulate(
                    workspace.outer_accumulator.q_component(0, 0),
                    workspace.outer_accumulator.q_component(0, 1),
                    workspace.outer_accumulator.p_component(0, 0),
                    workspace.outer_accumulator.p_component(0, 1),
                    workspace.inner_q_batch.q.data(),
                    identity_group_index,
                    digit_q_ptrs.data(),
                    digit_p_ptrs.data(),
                    group_indices.data(),
                    galois_elts.data(),
                    key_indices.data(),
                    galois_keys.galois_key_q0_ptrs.data(),
                    galois_keys.galois_key_p0_ptrs.data(),
                    galois_keys.galois_key_q1_ptrs.data(),
                    galois_keys.galois_key_p1_ptrs.data(),
                    active_group_count,
                    dnum,
                    galois_keys.meta.decomposition_count,
                    *parameter_shard,
                    degree);
            }
            else
            {
                kernel::launch_double_hoist_pre_rotated_giant_group_reduce(
                    workspace.group_accumulators.q.data(),
                    workspace.group_accumulators.p.data(),
                    workspace.inner_q_batch.q.data(),
                    digit_q_ptrs.data(),
                    digit_p_ptrs.data(),
                    group_indices.data(),
                    galois_elts.data(),
                    key_indices.data(),
                    galois_keys.galois_key_q0_ptrs.data(),
                    galois_keys.galois_key_p0_ptrs.data(),
                    galois_keys.galois_key_q1_ptrs.data(),
                    galois_keys.galois_key_p1_ptrs.data(),
                    active_group_count,
                    dnum,
                    galois_keys.meta.decomposition_count,
                    *parameter_shard,
                    degree);
            }
            have_outer = true;
            workspace.last_counts.keymul_count += active_group_count;
            workspace.last_counts.permute_count += active_group_count;
        }
    }
    else
    {
        workspace.outer_accumulator.ensure_capacity(
            source_shard0.device_id,
            degree,
            q_count,
            p_count,
            1);
        workspace.outer_accumulator.q.fill_zero();
        workspace.outer_accumulator.p.fill_zero();
        for (std::size_t group = 0; group < group_count; ++group)
        {
            keyswitch_handler_.moddown_qp_ciphertext_to_q(
                workspace.group_accumulators,
                group,
                workspace.inner_q,
                product_meta,
                level_info,
                workspace.keyswitch);
            ++workspace.last_counts.inner_moddown_count;

            const auto inner_view = workspace.inner_q.make_const_view();
            const auto &inner0 = inner_view.polys[0].shards.front();
            const auto &inner1 = inner_view.polys[1].shards.front();
            const int giant_step = matrix.plan.giant_steps[group];
            if (giant_step == 0)
            {
                kernel::launch_double_hoist_lift_identity(
                    workspace.outer_accumulator.q_component(0, 0),
                    workspace.outer_accumulator.q_component(0, 1),
                    workspace.outer_accumulator.p_component(0, 0),
                    workspace.outer_accumulator.p_component(0, 1),
                    inner0.ptr,
                    inner1.ptr,
                    *parameter_shard,
                    degree,
                    have_outer);
                have_outer = true;
                continue;
            }

            keyswitch_handler_.hoist_decompose_modup_ntt(
                inner_view.polys[1],
                level_info,
                workspace.outer_hoist,
                workspace.keyswitch);
            ++workspace.last_counts.outer_decompose_count;
            const std::uint32_t galois_elt =
                galois_elt_from_rotation_step(degree, giant_step);
            const std::size_t key_index =
                galois_key_index(galois_elt);
            keyswitch_handler_.keyswitch_multsum_no_moddown(
                workspace.outer_hoist,
                galois_elt,
                galois_keys_view,
                galois_keys,
                key_index,
                workspace.outer_accumulator,
                0,
                !have_outer,
                level_info,
                workspace.keyswitch);
            kernel::launch_double_hoist_add_lifted_galois_c0(
                workspace.outer_accumulator.q_component(0, 0),
                inner0.ptr,
                galois_elt,
                *parameter_shard,
                degree);
            have_outer = true;
            ++workspace.last_counts.keymul_count;
            workspace.last_counts.permute_count +=
                2 * workspace.outer_hoist.dnum + 1;
        }
    }
    if (!have_outer)
    {
        throw std::logic_error(
            "GpuEvaluator::multiply_by_diag_matrix_bsgs_double_hoist: "
            "outer accumulator is empty");
    }

    if (direct_giant_accumulate)
    {
        if (try_fused_outer_moddown_rescale(workspace.outer_accumulator))
        {
            workspace.last_counts.outer_moddown_count = 1;
            return;
        }
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.outer_accumulator,
            0,
            workspace.result_q,
            product_meta,
            level_info,
            workspace.keyswitch);
    }
    else if (grouped_outer_moddown)
    {
        keyswitch_handler_.moddown_qp_groups_to_q(
            workspace.group_accumulators,
            group_count,
            workspace.outer_reduced_p,
            workspace.result_q,
            product_meta,
            level_info,
            workspace.keyswitch);
    }
    else
    {
        if (try_fused_outer_moddown_rescale(workspace.outer_accumulator))
        {
            workspace.last_counts.outer_moddown_count = 1;
            return;
        }
        keyswitch_handler_.moddown_qp_ciphertext_to_q(
            workspace.outer_accumulator,
            0,
            workspace.result_q,
            product_meta,
            level_info,
            workspace.keyswitch);
    }
    workspace.last_counts.outer_moddown_count = 1;
    if (rescale_count == 0)
    {
        destination_ciphertext = std::move(workspace.result_q);
    }
    else
    {
        rescale_many(
            workspace.result_q,
            destination_ciphertext,
            rescale_count);
    }
}

void GpuEvaluator::dft(
    const GpuCiphertextData &source_ciphertext,
    const GpuLinearMatrixGroup &matrix_group,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &destination_ciphertext) const
{
    if (matrix_group.data().empty())
    {
        throw std::invalid_argument("GpuEvaluator::dft: empty matrix group");
    }

    const bool dynamic_rescale = matrix_group.rescale_min_scale() > 0.0;
    if (dynamic_rescale &&
        matrix_group.rescale_counts().size() != matrix_group.data().size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::dft: dynamic rescale plan size mismatch");
    }

    GpuCiphertextData product;
    GpuCiphertextData current;
    multiply_by_diag_matrix_bsgs(
        source_ciphertext,
        matrix_group.data().front(),
        galois_keys,
        dynamic_rescale ? 0 : std::max(matrix_group.step(), std::uint32_t{1}),
        dynamic_rescale ? product : current);
    if (dynamic_rescale)
    {
        rescale_dynamic(
            product,
            current,
            matrix_group.rescale_min_scale());
    }

    for (std::size_t i = 1; i < matrix_group.data().size(); ++i)
    {
        GpuCiphertextData next_product;
        GpuCiphertextData next;
        multiply_by_diag_matrix_bsgs(
            current,
            matrix_group.data()[i],
            galois_keys,
            dynamic_rescale ? 0 : std::max(matrix_group.step(), std::uint32_t{1}),
            dynamic_rescale ? next_product : next);
        if (dynamic_rescale)
        {
            rescale_dynamic(
                next_product,
                next,
                matrix_group.rescale_min_scale());
        }
        current = std::move(next);
    }

    destination_ciphertext = std::move(current);
}

void GpuEvaluator::dft_loose(
    const GpuCiphertextData &source_ciphertext,
    const GpuLinearMatrixGroup &matrix_group,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &destination_ciphertext) const
{
    if (matrix_group.data().empty())
    {
        throw std::invalid_argument("GpuEvaluator::dft_loose: empty matrix group");
    }

    const bool dynamic_rescale = matrix_group.rescale_min_scale() > 0.0;
    if (dynamic_rescale &&
        matrix_group.rescale_counts().size() != matrix_group.data().size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::dft_loose: dynamic rescale plan size mismatch");
    }

    GpuCiphertextData product;
    GpuCiphertextData current;
    multiply_by_diag_matrix_bsgs_loose(
        source_ciphertext,
        matrix_group.data().front(),
        galois_keys,
        dynamic_rescale ? 0 : std::max(matrix_group.step(), std::uint32_t{1}),
        dynamic_rescale ? product : current);
    if (dynamic_rescale)
    {
        rescale_dynamic(
            product,
            current,
            matrix_group.rescale_min_scale());
    }

    for (std::size_t i = 1; i < matrix_group.data().size(); ++i)
    {
        GpuCiphertextData next_product;
        GpuCiphertextData next;
        multiply_by_diag_matrix_bsgs_loose(
            current,
            matrix_group.data()[i],
            galois_keys,
            dynamic_rescale ? 0 : std::max(matrix_group.step(), std::uint32_t{1}),
            dynamic_rescale ? next_product : next);
        if (dynamic_rescale)
        {
            rescale_dynamic(
                next_product,
                next,
                matrix_group.rescale_min_scale());
        }
        current = std::move(next);
    }

    destination_ciphertext = std::move(current);
}

void GpuEvaluator::dft_double_hoist(
    const GpuCiphertextData &source_ciphertext,
    const GpuLinearMatrixGroupQP &matrix_group,
    const GpuGaloisKeysData &galois_keys,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    if (matrix_group.data().empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::dft_double_hoist: empty matrix group");
    }

    const bool dynamic_rescale = matrix_group.rescale_min_scale() > 0.0;
    if (dynamic_rescale &&
        matrix_group.rescale_counts().size() != matrix_group.data().size())
    {
        throw std::invalid_argument(
            "GpuEvaluator::dft_double_hoist: dynamic rescale plan size mismatch");
    }
    const bool fuse_dynamic_rescale =
        dynamic_rescale && !workspace.parallel_matrix;
    const auto try_plan_dft_rescale =
        [&](const GpuCiphertextData &in,
            double matrix_scale,
            GpuDynamicRescalePlan &out_plan) -> bool {
            if (!fuse_dynamic_rescale ||
                in.empty() ||
                !in.meta.is_ntt_form ||
                in.meta.q_count == 0 ||
                !std::isfinite(matrix_group.rescale_min_scale()))
            {
                return false;
            }
            const double prod_scale = in.meta.scale * matrix_scale;
            if (!(prod_scale > 0.0) || !std::isfinite(prod_scale))
            {
                return false;
            }
            std::vector<std::uint64_t> active_moduli(in.meta.q_count, 0);
            parms_id_type cur_id = in.meta.parms_id;
            while (true)
            {
                const auto &lvl = params_.get_level(cur_id);
                if (lvl.q_count == 0 ||
                    lvl.q_count > active_moduli.size() ||
                    lvl.shards.empty() ||
                    lvl.shards.front().q_last == 0)
                {
                    return false;
                }
                active_moduli[lvl.q_count - 1] = lvl.shards.front().q_last;
                if (lvl.q_count == 1)
                {
                    break;
                }
                cur_id = params_.get_next_level(cur_id).parms_id;
            }
            out_plan = plan_gpu_dynamic_rescale(
                prod_scale,
                matrix_group.rescale_min_scale(),
                active_moduli);
            return true;
        };

    GpuCiphertextData product;
    GpuCiphertextData current;
    workspace.matrix_counts.clear();
    workspace.matrix_rescale_trace.clear();
    GpuDynamicRescalePlan first_plan{};
    if (try_plan_dft_rescale(
            source_ciphertext,
            matrix_group.data().front().scale,
            first_plan))
    {
        multiply_by_diag_matrix_bsgs_double_hoist(
            source_ciphertext,
            matrix_group.data().front(),
            galois_keys,
            first_plan.rescale_count,
            workspace,
            current);
        if (first_plan.rescale_count > 0)
        {
            current.meta.scale = first_plan.output_scale;
        }
    }
    else
    {
        multiply_by_diag_matrix_bsgs_double_hoist(
            source_ciphertext,
            matrix_group.data().front(),
            galois_keys,
            dynamic_rescale ? 0 : std::max(matrix_group.step(), std::uint32_t{1}),
            workspace,
            dynamic_rescale ? product : current);
        if (dynamic_rescale)
        {
            rescale_dynamic(
                product,
                current,
                matrix_group.rescale_min_scale());
        }
    }
    workspace.matrix_counts.push_back(workspace.last_counts);
    workspace.matrix_rescale_trace.push_back(
        GpuDoubleHoistWorkspace::MatrixRescaleTrace{
            source_ciphertext.meta.q_count,
            current.meta.q_count,
            source_ciphertext.meta.scale,
            matrix_group.data().front().scale,
            source_ciphertext.meta.scale * matrix_group.data().front().scale,
            current.meta.scale,
            static_cast<std::uint32_t>(
                source_ciphertext.meta.q_count - current.meta.q_count)});
    for (std::size_t i = 1; i < matrix_group.data().size(); ++i)
    {
        const std::size_t input_q_count = current.meta.q_count;
        const double input_scale = current.meta.scale;
        GpuCiphertextData next_product;
        GpuCiphertextData next;
        GpuDynamicRescalePlan step_plan{};
        if (try_plan_dft_rescale(
                current,
                matrix_group.data()[i].scale,
                step_plan))
        {
            multiply_by_diag_matrix_bsgs_double_hoist(
                current,
                matrix_group.data()[i],
                galois_keys,
                step_plan.rescale_count,
                workspace,
                next);
            if (step_plan.rescale_count > 0)
            {
                next.meta.scale = step_plan.output_scale;
            }
        }
        else
        {
            multiply_by_diag_matrix_bsgs_double_hoist(
                current,
                matrix_group.data()[i],
                galois_keys,
                dynamic_rescale ? 0 : std::max(matrix_group.step(), std::uint32_t{1}),
                workspace,
                dynamic_rescale ? next_product : next);
            if (dynamic_rescale)
            {
                rescale_dynamic(
                    next_product,
                    next,
                    matrix_group.rescale_min_scale());
            }
        }
        workspace.matrix_counts.push_back(workspace.last_counts);
        workspace.matrix_rescale_trace.push_back(
            GpuDoubleHoistWorkspace::MatrixRescaleTrace{
                input_q_count,
                next.meta.q_count,
                input_scale,
                matrix_group.data()[i].scale,
                input_scale * matrix_group.data()[i].scale,
                next.meta.scale,
                static_cast<std::uint32_t>(input_q_count - next.meta.q_count)});
        current = std::move(next);
    }
    destination_ciphertext = std::move(current);
}

void GpuEvaluator::coeff_to_slot(
    const GpuCiphertextData &source_ciphertext,
    const GpuLinearMatrixGroup &matrix_group,
    const GpuPlaintextData &minus_i_plaintext,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &result_real,
    GpuCiphertextData &result_imag) const
{
    GpuCiphertextData dft_result;
    dft(source_ciphertext, matrix_group, galois_keys, dft_result);

    GpuCiphertextData conjugated;
    conjugate(dft_result, galois_keys, conjugated);

    add(dft_result, conjugated, result_real);

    GpuCiphertextData imag_difference;
    sub(dft_result, conjugated, imag_difference);
    multiply_plain(imag_difference, minus_i_plaintext, result_imag);
}

void GpuEvaluator::coeff_to_slot_loose(
    const GpuCiphertextData &source_ciphertext,
    const GpuLinearMatrixGroup &matrix_group,
    const GpuPlaintextData &minus_i_plaintext,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &result_real,
    GpuCiphertextData &result_imag) const
{
    GpuCiphertextData dft_result;
    dft_loose(
        source_ciphertext,
        matrix_group,
        galois_keys,
        dft_result);

    GpuCiphertextData conjugated;
    conjugate(dft_result, galois_keys, conjugated);
    add(dft_result, conjugated, result_real);

    GpuCiphertextData imag_difference;
    sub(dft_result, conjugated, imag_difference);
    multiply_plain(imag_difference, minus_i_plaintext, result_imag);
}

void GpuEvaluator::coeff_to_slot_double_hoist(
    const GpuCiphertextData &source_ciphertext,
    const GpuLinearMatrixGroupQP &matrix_group,
    const GpuPlaintextData &minus_i_plaintext,
    const GpuGaloisKeysData &galois_keys,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &result_real,
    GpuCiphertextData &result_imag,
    bool compute_imag) const
{
    GpuCiphertextData dft_result;
    dft_double_hoist(
        source_ciphertext,
        matrix_group,
        galois_keys,
        workspace,
        dft_result);

    const auto &conj_keys = level_key_for(
        params_, galois_keys, dft_result.meta, "GpuEvaluator::coeff_to_slot_double_hoist");
    GpuCiphertextData conjugated;
    if (conj_keys.meta.galois_format ==
        GpuGaloisKeyFormat::InversePreRotated)
    {
        if (try_conjugate_pre_rotated_c2s_split(
                dft_result,
                minus_i_plaintext,
                conj_keys,
                workspace,
                result_real,
                result_imag))
        {
            return;
        }
        conjugate_pre_rotated(
            dft_result,
            conj_keys,
            workspace,
            conjugated);
    }
    else
    {
        conjugate(dft_result, conj_keys, conjugated);
    }
    const auto &c2s_level = params_.get_level(dft_result.meta.parms_id);
    if (&result_real != &result_imag &&
        dft_result.size() == 2 && conjugated.size() == 2 &&
        dft_result.meta.p_count == 0 && conjugated.meta.p_count == 0 &&
        dft_result.polys_[0].shards.size() == 1 &&
        all_components_use_layout(dft_result, dft_result.polys_[0]) &&
        all_components_use_layout(conjugated, dft_result.polys_[0]) &&
        !minus_i_plaintext.empty() && minus_i_plaintext.meta.is_ntt_form &&
        minus_i_plaintext.meta.p_count == 0 &&
        minus_i_plaintext.meta.degree == dft_result.meta.degree &&
        minus_i_plaintext.meta.q_count >= dft_result.meta.q_count &&
        minus_i_plaintext.poly_.shards.size() == 1 &&
        c2s_level.shards.size() == 1)
    {
        const int dev = dft_result.fields_.front().device_id;
        GpuCiphertextMeta real_meta = dft_result.meta;
        GpuCiphertextMeta imag_meta = dft_result.meta;
        imag_meta.scale = dft_result.meta.scale * minus_i_plaintext.meta.scale;
        if (imag_meta.scale > 0.0 && std::isfinite(imag_meta.scale))
        {
            prepare_ciphertext_destination(
                result_real, &dft_result, &conjugated, real_meta, 2, dev, dft_result.polys_[0]);
            prepare_ciphertext_destination(
                result_imag, &dft_result, &conjugated, imag_meta, 2, dev, dft_result.polys_[0]);
            auto real_view = result_real.make_view();
            auto imag_view = result_imag.make_view();
            const auto dft_view = dft_result.make_const_view();
            const auto conj_view = conjugated.make_const_view();
            const auto minus_i_view = minus_i_plaintext.make_const_view();
            kernel::launch_c2s_split_real_imag_two_components(
                real_view.polys[0].shards.front(),
                real_view.polys[1].shards.front(),
                imag_view.polys[0].shards.front(),
                imag_view.polys[1].shards.front(),
                dft_view.polys[0].shards.front(),
                dft_view.polys[1].shards.front(),
                conj_view.polys[0].shards.front(),
                conj_view.polys[1].shards.front(),
                minus_i_view.poly.shards.front(),
                c2s_level.shards.front(),
                dft_result.meta.degree);
            return;
        }
    }
    add(dft_result, conjugated, result_real);
    if (!compute_imag)
        return;

    GpuCiphertextData imag_difference;
    sub(dft_result, conjugated, imag_difference);
    multiply_plain(imag_difference, minus_i_plaintext, result_imag);
}

void GpuEvaluator::slot_to_coeff(
    const GpuCiphertextData &source_real,
    const GpuCiphertextData &source_imag,
    const GpuLinearMatrixGroup &matrix_group,
    const GpuPlaintextData &plus_i_plaintext,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &result) const
{
    GpuCiphertextData scaled_imag;
    multiply_plain(source_imag, plus_i_plaintext, scaled_imag);

    GpuCiphertextData merged_slots;
    add(scaled_imag, source_real, merged_slots);

    dft(merged_slots, matrix_group, galois_keys, result);
}

void GpuEvaluator::slot_to_coeff_loose(
    const GpuCiphertextData &source_real,
    const GpuCiphertextData &source_imag,
    const GpuLinearMatrixGroup &matrix_group,
    const GpuPlaintextData &plus_i_plaintext,
    const GpuGaloisKeysData &galois_keys,
    GpuCiphertextData &result) const
{
    GpuCiphertextData scaled_imag;
    multiply_plain(source_imag, plus_i_plaintext, scaled_imag);
    GpuCiphertextData merged_slots;
    add(scaled_imag, source_real, merged_slots);
    dft_loose(
        merged_slots,
        matrix_group,
        galois_keys,
        result);
}

void GpuEvaluator::slot_to_coeff_double_hoist(
    const GpuCiphertextData &source_real,
    const GpuCiphertextData &source_imag,
    const GpuLinearMatrixGroupQP &matrix_group,
    const GpuPlaintextData &plus_i_plaintext,
    const GpuGaloisKeysData &galois_keys,
    GpuDoubleHoistWorkspace &workspace,
    GpuCiphertextData &result) const
{
    GpuCiphertextData scaled_imag;
    multiply_plain(source_imag, plus_i_plaintext, scaled_imag);
    GpuCiphertextData merged_slots;
    add(scaled_imag, source_real, merged_slots);
    dft_double_hoist(
        merged_slots,
        matrix_group,
        galois_keys,
        workspace,
        result);
}

namespace
{
// A profile's raised-scale override assumes ModRaise starts from exactly
// q0/ratio, the scale its CoeffToSlot constants were built for.  Whatever the
// integer normalization left over would scale the message by that factor,
// with no metadata left to record it.
void require_modraise_scale(const GpuCiphertextData &input, double q0_over_message_ratio,
                            const char *where)
{
    const double relative = std::abs(input.meta.scale / q0_over_message_ratio - 1.0);
    if (!(relative <= 1e-6))
    {
        throw std::runtime_error(
            std::string(where) + ": ModRaise input scale is " + std::to_string(relative) +
            " off q0/ratio; the raised-scale override would scale the message by as much");
    }
}
} // namespace

namespace
{

// ModRaise, with sparse-secret encapsulation when the profile has its keys:
// dense -> ephemeral at q0, raise, ephemeral -> dense at the top level.
void raise_modulus_encapsulated(
    const GpuEvaluator &evaluator,
    const GpuCiphertextData &input,
    const GpuBootstrapData &data,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &raised)
{
    if (!data.sparse_switch_to_ephemeral && !data.sparse_switch_to_dense)
    {
        evaluator.raise_modulus(input, raised);
        return;
    }
    if (!data.sparse_switch_to_ephemeral || !data.sparse_switch_to_dense)
    {
        throw std::invalid_argument(
            "GPU bootstrap sparse-secret encapsulation needs both switching keys");
    }
    NvtxRange range("SparseSecretEncapsulation");
    // The dense -> ephemeral key may live on its own q0 * P_low modulus.
    const GpuEvaluator &to_ephemeral =
        data.sparse_low_evaluator ? *data.sparse_low_evaluator : evaluator;
    to_ephemeral.switch_key(input, *data.sparse_switch_to_ephemeral, workspace.scratch4);
    evaluator.raise_modulus(workspace.scratch4, workspace.scratch5);
    evaluator.switch_key(workspace.scratch5, *data.sparse_switch_to_dense, raised);
}

// A profile whose EvalMod ends above its declared SlotToCoeff input drops the
// surplus Q limbs without a copy, before SlotToCoeff.
void drop_to_slot_to_coeff_input(
    const GpuEvaluator &evaluator,
    const GpuBootstrapData &data,
    GpuCiphertextData &ciphertext)
{
    if (data.slot_to_coeff_input_q_count == 0 ||
        ciphertext.meta.q_count == data.slot_to_coeff_input_q_count)
    {
        return;
    }
    if (ciphertext.meta.q_count < data.slot_to_coeff_input_q_count)
    {
        throw std::runtime_error(
            "GPU bootstrap EvalMod output is below the SlotToCoeff input level");
    }
    evaluator.drop_modulus_inplace(ciphertext, data.slot_to_coeff_input_parms_id);
}

} // namespace

void GpuEvaluator::bootstrap(
    const GpuCiphertextData &source_ciphertext,
    const GpuBootstrapData &bootstrap_data,
    const GpuRelinKeysData &relin_keys,
    const GpuGaloisKeysData &galois_keys,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto linear_transform_mode =
        bootstrap_data.allow_environment_linear_transform_override
            ? gpu_linear_transform_mode_from_environment(
                  bootstrap_data.linear_transform_mode)
            : bootstrap_data.linear_transform_mode;
    const bool use_double_hoist =
        linear_transform_mode == GpuLinearTransformMode::DoubleHoistBsgs;
    const bool use_loose_coupled =
        linear_transform_mode == GpuLinearTransformMode::LooseCoupledBsgs ||
        linear_transform_mode == GpuLinearTransformMode::NoHoistBsgs;
    if (linear_transform_mode ==
        GpuLinearTransformMode::SingleHoistBsgs)
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap: single_hoist mode is reserved for "
            "staged validation; select classic, double_hoist, "
            "loose_coupled, or no_hoist");
    }
    if ((!use_double_hoist &&
         bootstrap_data.coeff_to_slot_matrix.data().empty()) ||
        (use_double_hoist &&
         bootstrap_data.coeff_to_slot_matrix_qp.data().empty()))
    {
        throw std::invalid_argument("GpuEvaluator::bootstrap: empty CoeffToSlot matrix group");
    }
    if ((!use_double_hoist &&
         bootstrap_data.slot_to_coeff_matrix.data().empty()) ||
        (use_double_hoist &&
         bootstrap_data.slot_to_coeff_matrix_qp.data().empty()))
    {
        throw std::invalid_argument("GpuEvaluator::bootstrap: empty SlotToCoeff matrix group");
    }
    if (bootstrap_data.minus_i_plaintext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::bootstrap: empty minus-i plaintext");
    }
    if (bootstrap_data.plus_i_plaintext.empty())
    {
        throw std::invalid_argument("GpuEvaluator::bootstrap: empty plus-i plaintext");
    }
    if (!(bootstrap_data.q0_over_message_ratio > 0.0) ||
        !std::isfinite(bootstrap_data.q0_over_message_ratio))
    {
        throw std::invalid_argument("GpuEvaluator::bootstrap: invalid q0/message ratio");
    }

    // POSEIDON_OPT_BOOT_REAL_ONLY: the S2C-first profile returns
    // 32*Re(f(real) + i*f(imag)). Both CtS outputs hold real slots and f has
    // real coefficients, so i*f(imag) is purely imaginary and the projection
    // keeps exactly f(real); the imaginary CtS output and EvalMod are skipped.
    const bool real_only = opt_flag(OptFlag::BootRealOnly);
    if (real_only &&
        (!bootstrap_data.real_evalmod_projection_safe ||
         !bootstrap_data.slot_to_coeff_first || !bootstrap_data.project_real ||
         bootstrap_data.output_ratio != 32 || workspace.parallel_eval_mod))
        throw std::invalid_argument(
            "POSEIDON_OPT_BOOT_REAL_ONLY requires the single-GPU S2C-first real-projection profile");

    NvtxRange bootstrap_range("bootstrap_once");
    if(workspace.begin_parallel_bootstrap)
        workspace.begin_parallel_bootstrap(source_ciphertext);
    const GpuCiphertextData *raised_for_c2s = &workspace.raised;
    {
        NvtxRange range("ModRaise");
        const GpuCiphertextData *modraise_source = &workspace.modraise_input;
        if (bootstrap_data.slot_to_coeff_first)
        {
            if (source_ciphertext.meta.q_count != bootstrap_data.input_q_count ||
                !(source_ciphertext.meta.scale > 0.0) ||
                std::abs(std::log2(source_ciphertext.meta.scale / bootstrap_data.input_scale)) > 1e-8 ||
                !use_double_hoist)
                throw std::invalid_argument("S2C-first Boot requires its declared input Q/scale and double-hoist mode");
            dft_double_hoist(source_ciphertext,
                bootstrap_data.slot_to_coeff_matrix_qp, galois_keys,
                workspace.slot_to_coeff_double_hoist, workspace.scratch0);
            if (workspace.scratch0.meta.parms_id != bootstrap_data.q0_parms_id)
                throw std::runtime_error("S2C-first Boot S2C output level differs from q0");
            // Match the manual scheduler: scale the Q2 result by a rounded
            // integer, without consuming another Q before ModRaise.
            const double multiplier = std::round(
                bootstrap_data.q0_over_message_ratio / workspace.scratch0.meta.scale);
            if (!std::isfinite(multiplier) || multiplier < 1.0 || multiplier > std::ldexp(1.0, 53))
                throw std::runtime_error("S2C-first Boot preparation multiplier is outside [1, 2^53]");
            multiply_scalar(workspace.scratch0, static_cast<std::uint64_t>(multiplier),
                workspace.scratch0);
            workspace.scratch0.meta.scale *= multiplier;
            modraise_source = &workspace.scratch0;
        }
        else
        {
            bootstrap_prepare_modraise_input(
                source_ciphertext,
                workspace.modraise_input,
                bootstrap_data.q0_parms_id,
                bootstrap_data.q0_over_message_ratio);
            if (bootstrap_data.raised_scale_override > 0.0)
                require_modraise_scale(workspace.modraise_input,
                                       bootstrap_data.q0_over_message_ratio,
                                       "GpuEvaluator::bootstrap");
        }

        raise_modulus_encapsulated(
            *this, *modraise_source, bootstrap_data, workspace, workspace.raised);

        if (bootstrap_data.raised_scale_override > 0.0)
        {
            workspace.raised.meta.scale = bootstrap_data.raised_scale_override;
        }

        if (bootstrap_data.post_raise_integer_multiplier > 1)
        {
            multiply_scalar(
                workspace.raised,
                bootstrap_data.post_raise_integer_multiplier,
                workspace.raised_scaled);
            workspace.raised_scaled.meta.scale =
                workspace.raised.meta.scale * bootstrap_data.post_raise_scale_multiplier;
            raised_for_c2s = &workspace.raised_scaled;
        }
        else if (!bootstrap_data.post_raise_plaintext.empty())
        {
            multiply_plain(
                workspace.raised,
                bootstrap_data.post_raise_plaintext,
                workspace.raised_scaled);
            raised_for_c2s = &workspace.raised_scaled;
        }
    }

    {
        NvtxRange range("CtS");
        if (use_double_hoist)
        {
            coeff_to_slot_double_hoist(
                *raised_for_c2s,
                bootstrap_data.coeff_to_slot_matrix_qp,
                bootstrap_data.minus_i_plaintext,
                galois_keys,
                workspace.coeff_to_slot_double_hoist,
                workspace.coeff_to_slot_real,
                workspace.coeff_to_slot_imag,
                !real_only);
        }
        else if (use_loose_coupled)
        {
            coeff_to_slot_loose(
                *raised_for_c2s,
                bootstrap_data.coeff_to_slot_matrix,
                bootstrap_data.minus_i_plaintext,
                galois_keys,
                workspace.coeff_to_slot_real,
                workspace.coeff_to_slot_imag);
        }
        else
        {
            coeff_to_slot(
                *raised_for_c2s,
                bootstrap_data.coeff_to_slot_matrix,
                bootstrap_data.minus_i_plaintext,
                galois_keys,
                workspace.coeff_to_slot_real,
                workspace.coeff_to_slot_imag);
        }
    }

    {
        NvtxRange range("EvalMod");
        const auto evaluate_real = [&] {
            NvtxRange branch_range("EvalMod real");
            eval_mod_high_precision(
                workspace.coeff_to_slot_real,
                bootstrap_data,
                relin_keys,
                workspace,
                workspace.eval_mod_real);
        };
        if (real_only)
            evaluate_real();
        else if (workspace.parallel_eval_mod)
            workspace.parallel_eval_mod(workspace.coeff_to_slot_imag,
                evaluate_real, workspace.eval_mod_imag);
        else if (opt_flag(OptFlag::EvalModPair) &&
                 bootstrap_data.eval_mod.polynomial_degree == 22 &&
                 bootstrap_data.eval_mod.dynamic_rescale &&
                 bootstrap_data.eval_mod.polynomial_basis == GpuEvalModPolynomialBasis::Chebyshev &&
                 use_evalmod_lazy_relinearization() &&
                 !workspace.capture_eval_mod_trace && !workspace.capture_eval_mod_stage_timing)
        {
            // The paired DAG owns its intermediates. In an A/B sweep the
            // sequential evaluator's cached nodes otherwise stay resident
            // alongside both new branches, exceeding the 24 GB profile.
            if (!workspace.eval_mod_basis.empty() || !workspace.eval_mod_nodes.empty())
            {
                workspace.eval_mod_basis.clear();
                workspace.eval_mod_nodes.clear();
                workspace.scratch2 = GpuCiphertextData{};
                workspace.scratch3 = GpuCiphertextData{};
            }
            workspace.eval_mod_real = GpuCiphertextData{};
            workspace.eval_mod_imag = GpuCiphertextData{};
            eval_mod_high_precision_pair(workspace.coeff_to_slot_real,
                workspace.coeff_to_slot_imag, bootstrap_data, relin_keys,
                workspace.eval_mod_real, workspace.eval_mod_imag);
        }
        else
        {
            evaluate_real();
            NvtxRange branch_range("EvalMod imag");
            eval_mod_high_precision(
                workspace.coeff_to_slot_imag,
                bootstrap_data,
                relin_keys,
                workspace,
                workspace.eval_mod_imag);
        }
    }

    if (!bootstrap_data.slot_to_coeff_first && bootstrap_data.slot_to_coeff_input_scale > 0.0)
    {
        workspace.eval_mod_real.meta.scale =
            bootstrap_data.slot_to_coeff_input_scale;
        workspace.eval_mod_imag.meta.scale =
            bootstrap_data.slot_to_coeff_input_scale;
    }
    drop_to_slot_to_coeff_input(*this, bootstrap_data, workspace.eval_mod_real);
    if (!real_only)
        drop_to_slot_to_coeff_input(*this, bootstrap_data, workspace.eval_mod_imag);

    {
        NvtxRange range("StC");
        if (bootstrap_data.slot_to_coeff_first)
        {
            if (!bootstrap_data.project_real || bootstrap_data.output_ratio != 32)
                throw std::invalid_argument("manual S2C-first Boot requires real projection and ratio 32");
            if (real_only)
            {
                // Match the manual order. Scaling after conjugation would also
                // amplify its key-switch rounding noise by 16.
                multiply_scalar(workspace.eval_mod_real, 16, workspace.scratch0);
            }
            else
            {
                const auto &stc_level = params_.get_level(workspace.eval_mod_real.meta.parms_id);
                const bool can_fuse_stc =
                    workspace.eval_mod_real.size() == 2 &&
                    workspace.eval_mod_imag.size() == 2 &&
                    workspace.eval_mod_real.meta.parms_id == workspace.eval_mod_imag.meta.parms_id &&
                    workspace.eval_mod_real.meta.is_ntt_form &&
                    workspace.eval_mod_imag.meta.is_ntt_form &&
                    workspace.eval_mod_real.meta.p_count == 0 &&
                    workspace.eval_mod_imag.meta.p_count == 0 &&
                    workspace.eval_mod_real.polys_[0].shards.size() == 1 &&
                    all_components_use_layout(workspace.eval_mod_real, workspace.eval_mod_real.polys_[0]) &&
                    all_components_use_layout(workspace.eval_mod_imag, workspace.eval_mod_real.polys_[0]) &&
                    !bootstrap_data.plus_i_plaintext.empty() &&
                    bootstrap_data.plus_i_plaintext.meta.is_ntt_form &&
                    bootstrap_data.plus_i_plaintext.meta.p_count == 0 &&
                    bootstrap_data.plus_i_plaintext.meta.degree == workspace.eval_mod_real.meta.degree &&
                    bootstrap_data.plus_i_plaintext.meta.q_count >= workspace.eval_mod_real.meta.q_count &&
                    bootstrap_data.plus_i_plaintext.poly_.shards.size() == 1 &&
                    same_scale(workspace.eval_mod_real.meta.scale,
                               workspace.eval_mod_imag.meta.scale * bootstrap_data.plus_i_plaintext.meta.scale) &&
                    stc_level.shards.size() == 1;
                if (can_fuse_stc)
                {
                    const int dev = workspace.eval_mod_real.fields_.front().device_id;
                    prepare_ciphertext_destination(
                        workspace.scratch0,
                        &workspace.eval_mod_real,
                        &workspace.eval_mod_imag,
                        workspace.eval_mod_real.meta,
                        2,
                        dev,
                        workspace.eval_mod_real.polys_[0]);
                    auto dst_view = workspace.scratch0.make_view();
                    const auto real_view = workspace.eval_mod_real.make_const_view();
                    const auto imag_view = workspace.eval_mod_imag.make_const_view();
                    const auto plus_i_view = bootstrap_data.plus_i_plaintext.make_const_view();
                    kernel::launch_stc_merge_scale_two_components(
                        dst_view.polys[0].shards.front(),
                        dst_view.polys[1].shards.front(),
                        real_view.polys[0].shards.front(),
                        real_view.polys[1].shards.front(),
                        imag_view.polys[0].shards.front(),
                        imag_view.polys[1].shards.front(),
                        plus_i_view.poly.shards.front(),
                        16,
                        stc_level.shards.front(),
                        workspace.eval_mod_real.meta.degree);
                }
                else
                {
                    multiply_plain(workspace.eval_mod_imag, bootstrap_data.plus_i_plaintext,
                        workspace.scratch0);
                    add(workspace.eval_mod_real, workspace.scratch0, workspace.scratch1);
                    multiply_scalar(workspace.scratch1, 16, workspace.scratch0);
                }
            }
            const auto &conj_keys = level_key_for(
                params_, galois_keys, workspace.scratch0.meta, "GpuEvaluator::bootstrap");
            if (conj_keys.meta.galois_format == GpuGaloisKeyFormat::InversePreRotated)
            {
                conjugate_pre_rotated(
                    workspace.scratch0,
                    conj_keys,
                    workspace.slot_to_coeff_double_hoist,
                    destination_ciphertext,
                    &workspace.scratch0);
            }
            else
            {
                conjugate(workspace.scratch0, conj_keys, workspace.scratch1);
                add(workspace.scratch0, workspace.scratch1, destination_ciphertext);
            }
            destination_ciphertext.meta.scale *= bootstrap_data.output_scale_multiplier;
            if (std::abs(std::log2(destination_ciphertext.meta.scale /
                    bootstrap_data.slot_to_coeff_output_scale)) > 1e-8)
                throw std::runtime_error("manual S2C-first Boot output scale disagrees with its coefficient fold");
            destination_ciphertext.meta.scale = bootstrap_data.slot_to_coeff_output_scale;
            return;
        }
        else if (use_double_hoist)
        {
            slot_to_coeff_double_hoist(
                workspace.eval_mod_real,
                workspace.eval_mod_imag,
                bootstrap_data.slot_to_coeff_matrix_qp,
                bootstrap_data.plus_i_plaintext,
                galois_keys,
                workspace.slot_to_coeff_double_hoist,
                destination_ciphertext);
        }
        else if (use_loose_coupled)
        {
            slot_to_coeff_loose(
                workspace.eval_mod_real,
                workspace.eval_mod_imag,
                bootstrap_data.slot_to_coeff_matrix,
                bootstrap_data.plus_i_plaintext,
                galois_keys,
                destination_ciphertext);
        }
        else
        {
            slot_to_coeff(
                workspace.eval_mod_real,
                workspace.eval_mod_imag,
                bootstrap_data.slot_to_coeff_matrix,
                bootstrap_data.plus_i_plaintext,
                galois_keys,
                destination_ciphertext);
        }
    }

    if (bootstrap_data.slot_to_coeff_output_scale > 0.0)
    {
        destination_ciphertext.meta.scale =
            bootstrap_data.slot_to_coeff_output_scale;
    }

    if (bootstrap_data.project_real)
    {
        conjugate(destination_ciphertext, galois_keys, workspace.scratch0);
        add(destination_ciphertext, workspace.scratch0, workspace.scratch1);
        destination_ciphertext = std::move(workspace.scratch1);
    }

    if (bootstrap_data.output_ratio == 0 ||
        (bootstrap_data.project_real &&
         (bootstrap_data.output_ratio & 1U) != 0))
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap: invalid output ratio");
    }
    const std::uint32_t effective_ratio = bootstrap_data.project_real
        ? bootstrap_data.output_ratio / 2
        : bootstrap_data.output_ratio;
    if (effective_ratio > 1)
    {
        NvtxRange range("Output normalize");
        multiply_scalar(
            destination_ciphertext,
            effective_ratio,
            workspace.scratch0);
        destination_ciphertext = std::move(workspace.scratch0);
    }
}

void GpuEvaluator::bootstrap_raise(
    const GpuCiphertextData &source_ciphertext,
    const GpuBootstrapData &bootstrap_data,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    // Without the override the raised scale follows the input, and an
    // expanded Boot's later steps were planned for one fixed scale.
    if (!(bootstrap_data.raised_scale_override > 0.0))
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_raise: the profile has no raised_scale_override");
    }
    NvtxRange range("ModRaise");
    if (bootstrap_data.slot_to_coeff_first)
    {
        // The steps before this one ran SlotToCoeff down to q0 and the
        // rounded product that sets the scale (a mul_scalar step), as
        // bootstrap() does before raise_modulus.
        if (source_ciphertext.meta.parms_id != bootstrap_data.q0_parms_id)
        {
            throw std::invalid_argument(
                "GpuEvaluator::bootstrap_raise: an S2C-first Boot raises from q0");
        }
        raise_modulus_encapsulated(
            *this, source_ciphertext, bootstrap_data, workspace, destination_ciphertext);
    }
    else
    {
        bootstrap_prepare_modraise_input(
            source_ciphertext,
            workspace.modraise_input,
            bootstrap_data.q0_parms_id,
            bootstrap_data.q0_over_message_ratio);
        require_modraise_scale(workspace.modraise_input, bootstrap_data.q0_over_message_ratio,
                               "GpuEvaluator::bootstrap_raise");
        raise_modulus_encapsulated(
            *this, workspace.modraise_input, bootstrap_data, workspace, destination_ciphertext);
    }
    destination_ciphertext.meta.scale = bootstrap_data.raised_scale_override;
}

void GpuEvaluator::bootstrap_linear_layer(
    const GpuCiphertextData &source_ciphertext,
    const GpuBootstrapData &bootstrap_data,
    bool coeff_to_slot,
    std::size_t layer,
    const GpuGaloisKeysData &galois_keys,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto mode =
        bootstrap_data.allow_environment_linear_transform_override
            ? gpu_linear_transform_mode_from_environment(
                  bootstrap_data.linear_transform_mode)
            : bootstrap_data.linear_transform_mode;
    NvtxRange range(coeff_to_slot ? "CtS layer" : "StC layer");
    // One iteration of dft_double_hoist / dft_loose / dft.
    if (mode == GpuLinearTransformMode::DoubleHoistBsgs)
    {
        const auto &group = coeff_to_slot
            ? bootstrap_data.coeff_to_slot_matrix_qp
            : bootstrap_data.slot_to_coeff_matrix_qp;
        const bool dynamic_rescale = group.rescale_min_scale() > 0.0;
        GpuCiphertextData product;
        multiply_by_diag_matrix_bsgs_double_hoist(
            source_ciphertext,
            group.data().at(layer),
            galois_keys,
            dynamic_rescale ? 0 : std::max(group.step(), std::uint32_t{1}),
            coeff_to_slot ? workspace.coeff_to_slot_double_hoist
                          : workspace.slot_to_coeff_double_hoist,
            dynamic_rescale ? product : destination_ciphertext);
        if (dynamic_rescale)
        {
            rescale_dynamic(product, destination_ciphertext, group.rescale_min_scale());
        }
        return;
    }
    if (mode == GpuLinearTransformMode::SingleHoistBsgs)
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_linear_layer: single_hoist is not a bootstrap mode");
    }
    const auto &group = coeff_to_slot
        ? bootstrap_data.coeff_to_slot_matrix
        : bootstrap_data.slot_to_coeff_matrix;
    const bool dynamic_rescale = group.rescale_min_scale() > 0.0;
    const std::uint32_t rescale_count =
        dynamic_rescale ? 0 : std::max(group.step(), std::uint32_t{1});
    GpuCiphertextData product;
    GpuCiphertextData &target = dynamic_rescale ? product : destination_ciphertext;
    if (mode == GpuLinearTransformMode::LooseCoupledBsgs ||
        mode == GpuLinearTransformMode::NoHoistBsgs)
    {
        multiply_by_diag_matrix_bsgs_loose(
            source_ciphertext, group.data().at(layer), galois_keys, rescale_count, target);
    }
    else
    {
        multiply_by_diag_matrix_bsgs(
            source_ciphertext, group.data().at(layer), galois_keys, rescale_count, target);
    }
    if (dynamic_rescale)
    {
        rescale_dynamic(product, destination_ciphertext, group.rescale_min_scale());
    }
}

void GpuEvaluator::bootstrap_bsgs_group(
    const GpuCiphertextData &source_ciphertext,
    const GpuBootstrapData &bootstrap_data,
    bool coeff_to_slot,
    std::size_t layer,
    std::size_t group,
    const GpuGaloisKeysData &galois_keys,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    const auto &groups = coeff_to_slot
        ? bootstrap_data.coeff_to_slot_groups_qp
        : bootstrap_data.slot_to_coeff_groups_qp;
    if (groups.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::bootstrap_bsgs_group: the profile has no group views "
            "(a double-hoist profile builds them)");
    }
    NvtxRange range(coeff_to_slot ? "CtS group" : "StC group");
    multiply_by_diag_matrix_bsgs_double_hoist(
        source_ciphertext,
        groups.at(layer).at(group),
        galois_keys,
        0,
        coeff_to_slot ? workspace.coeff_to_slot_double_hoist
                      : workspace.slot_to_coeff_double_hoist,
        destination_ciphertext);
}

void GpuEvaluator::bootstrap_conjugate(
    const GpuCiphertextData &source_ciphertext,
    const GpuGaloisKeysData &galois_keys,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    // As coeff_to_slot_double_hoist chooses.
    if (galois_keys.meta.galois_format == GpuGaloisKeyFormat::InversePreRotated)
    {
        conjugate_pre_rotated(
            source_ciphertext,
            galois_keys,
            workspace.coeff_to_slot_double_hoist,
            destination_ciphertext);
    }
    else
    {
        conjugate(source_ciphertext, galois_keys, destination_ciphertext);
    }
}

void GpuEvaluator::bootstrap_set_scale(
    const GpuCiphertextData &source_ciphertext,
    double scale,
    GpuCiphertextData &destination_ciphertext) const
{
    if (!(scale > 0.0) || !std::isfinite(scale))
    {
        throw std::invalid_argument("GpuEvaluator::bootstrap_set_scale: invalid scale");
    }
    copy_ciphertext_data(
        source_ciphertext,
        destination_ciphertext,
        "GpuEvaluator::bootstrap_set_scale");
    destination_ciphertext.meta.scale = scale;
}

void GpuEvaluator::multiply_plain_q_view(
    const GpuCiphertextData &source_ciphertext,
    const GpuPlaintextData &source_plaintext,
    GpuCiphertextData &destination_ciphertext) const
{
    if (source_plaintext.meta.p_count == 0)
    {
        multiply_plain(source_ciphertext, source_plaintext, destination_ciphertext);
        return;
    }
    if (source_ciphertext.empty() || source_plaintext.empty() ||
        !(source_ciphertext.meta.parms_id == source_plaintext.meta.parms_id) ||
        !source_ciphertext.meta.is_ntt_form || !source_plaintext.meta.is_ntt_form ||
        source_ciphertext.meta.degree != source_plaintext.meta.degree ||
        source_ciphertext.meta.q_count != source_plaintext.meta.q_count ||
        source_ciphertext.meta.p_count != 0 ||
        source_ciphertext.meta.component_count != source_ciphertext.size() ||
        source_plaintext.poly_.shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_view: the plaintext's Q prefix does not "
            "match the ciphertext");
    }
    const int device_id = source_ciphertext.fields_.at(0).device_id;
    const auto &reference_layout = source_ciphertext.polys_.at(0);
    if (!all_components_use_layout(source_ciphertext, reference_layout) ||
        reference_layout.shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuEvaluator::multiply_plain_q_view: ciphertext shard layout mismatch");
    }
    GpuCiphertextData result =
        GpuCiphertextData::allocate_single_device_sharded(
            source_ciphertext.meta.degree,
            source_ciphertext.meta.q_count,
            source_ciphertext.size(),
            device_id,
            reference_layout.shards,
            0);
    result.meta = source_ciphertext.meta;
    result.meta.component_count = source_ciphertext.size();
    result.meta.scale = source_ciphertext.meta.scale * source_plaintext.meta.scale;
    // [Q|P] residues are stored Q first, so the Q prefix is the same pointer
    // with fewer limbs.
    auto plaintext_view = source_plaintext.make_const_view();
    plaintext_view.meta.p_count = 0;
    plaintext_view.poly.shards.front().limb_count = source_ciphertext.meta.q_count;
    auto ciphertext_view = source_ciphertext.make_const_view();
    auto destination_view = result.make_view();
    elementwise_handler_.multiply_plain_with_ciphertext(
        destination_view,
        ciphertext_view,
        plaintext_view,
        params_.get_level(source_ciphertext.meta.parms_id));
    destination_ciphertext = std::move(result);
}

void GpuEvaluator::eval_mod_high_precision(
    const GpuCiphertextData &source_ciphertext,
    const GpuBootstrapData &bootstrap_data,
    const GpuRelinKeysData &relin_keys,
    GpuBootstrapWorkspace &workspace,
    GpuCiphertextData &destination_ciphertext) const
{
    validate_ntt_ciphertext_input(
        "GpuEvaluator::eval_mod_high_precision",
        source_ciphertext,
        true);
    if (source_ciphertext.size() != 2)
    {
        throw std::invalid_argument(
            "GpuEvaluator::eval_mod_high_precision: expected a size-2 ciphertext");
    }
    if (opt_flag(OptFlag::EvalModPair) &&
        !workspace.capture_eval_mod_trace &&
        !workspace.capture_eval_mod_stage_timing &&
        try_eval_mod_high_precision_fast(
            source_ciphertext, bootstrap_data, relin_keys, destination_ciphertext))
    {
        return;
    }
    const double configured_target_scale =
        bootstrap_data.eval_mod.target_scale > 0.0
            ? bootstrap_data.eval_mod.target_scale
            : bootstrap_data.eval_mod_target_scale;
    const double configured_input_scale =
        bootstrap_data.eval_mod.input_scale > 0.0
            ? bootstrap_data.eval_mod.input_scale
            : configured_target_scale;
    const auto &configured_coefficients =
        !bootstrap_data.eval_mod.polynomial_coefficients.empty()
            ? bootstrap_data.eval_mod.polynomial_coefficients
            : bootstrap_data.eval_mod_polynomial_plaintexts;
    const auto &polynomial_terms = bootstrap_data.eval_mod.polynomial_terms;
    const auto &basis_steps = bootstrap_data.eval_mod.basis_steps;
    const auto &polynomial_blocks = bootstrap_data.eval_mod.polynomial_blocks;
    const auto &polynomial_combine_steps =
        bootstrap_data.eval_mod.polynomial_combine_steps;
    const auto &configured_double_angle_constants =
        !bootstrap_data.eval_mod.double_angle_constants.empty()
            ? bootstrap_data.eval_mod.double_angle_constants
            : bootstrap_data.double_angle_plaintexts;
    const auto &configured_double_angle_rescale_counts =
        bootstrap_data.eval_mod.double_angle_rescale_counts;
    const GpuPlaintextData &configured_input_offset =
        !bootstrap_data.eval_mod.input_offset_plaintext.empty()
            ? bootstrap_data.eval_mod.input_offset_plaintext
            : bootstrap_data.eval_mod_input_offset_plaintext;

    if (!(configured_target_scale > 0.0) ||
        !std::isfinite(configured_target_scale))
    {
        throw std::invalid_argument(
            "GpuEvaluator::eval_mod_high_precision: invalid target scale");
    }
    if (polynomial_blocks.empty() &&
        polynomial_terms.empty() &&
        configured_coefficients.empty())
    {
        throw std::invalid_argument(
            "GpuEvaluator::eval_mod_high_precision: empty polynomial plaintexts");
    }

    const double target_scale = configured_target_scale;
    const std::uint32_t logical_rescale_count =
        std::max(
            bootstrap_data.eval_mod.logical_rescale_count,
            std::uint32_t{1});

    if (workspace.capture_eval_mod_trace)
    {
        workspace.eval_mod_trace_offset_input = GpuCiphertextData{};
        workspace.eval_mod_trace_polynomial_output = GpuCiphertextData{};
        workspace.eval_mod_trace_double_angle_square_outputs.clear();
        workspace.eval_mod_trace_double_angle_relin_outputs.clear();
        workspace.eval_mod_trace_double_angle_rescaled_square_outputs.clear();
        workspace.eval_mod_trace_double_angle_outputs.clear();
        workspace.eval_mod_trace_double_angle_square_outputs.reserve(
            configured_double_angle_constants.size());
        workspace.eval_mod_trace_double_angle_relin_outputs.reserve(
            configured_double_angle_constants.size());
        workspace.eval_mod_trace_double_angle_rescaled_square_outputs.reserve(
            configured_double_angle_constants.size());
        workspace.eval_mod_trace_double_angle_outputs.reserve(
            configured_double_angle_constants.size());
    }
    if (workspace.capture_eval_mod_stage_timing)
    {
        workspace.eval_mod_stage_timing =
            GpuBootstrapWorkspace::EvalModStageTiming{};
        workspace.eval_mod_multiply_timings.clear();
    }
    EvalModStageEventRecorder stage_recorder(
        workspace.capture_eval_mod_stage_timing);
    EvalModMultiplyEventRecorder multiply_recorder(
        workspace.capture_eval_mod_stage_timing);
    const bool d2d_free_dataflow = use_evalmod_d2d_free_dataflow();
    const bool zero_copy_moddrop =
        d2d_free_dataflow &&
        use_evalmod_zero_copy_moddrop() &&
        !workspace.capture_eval_mod_trace;
    const bool q_prefix_views =
        zero_copy_moddrop && use_evalmod_q_prefix_views();

    /*
     * Pure ModDrop only discards an RNS-Q suffix.  If the ciphertext storage
     * is dead after the current consumer, retain its allocation and shorten
     * the logical prefix in place instead of materializing that prefix via a
     * synchronous D2D copy.  Physical component strides may remain larger
     * than the logical view; every GPU operator consumes the per-component
     * shard pointers and logical limb counts, so the retained padding is not
     * read.  General/shared inputs continue through drop_modulus().
     */
    auto drop_modulus_inplace =
        [&](GpuCiphertextData &ciphertext,
            parms_id_type target_parms_id) {
            if (!zero_copy_moddrop ||
                ciphertext.empty() ||
                ciphertext.fields_.empty() ||
                ciphertext.meta.p_count != 0 ||
                ciphertext.meta.component_count != ciphertext.size())
            {
                return false;
            }

            const auto &source_level =
                params_.get_level(ciphertext.meta.parms_id);
            const auto &target_level =
                params_.get_level(target_parms_id);
            if (source_level.q_count != ciphertext.meta.q_count ||
                target_level.p_count != 0 ||
                target_level.q_count == 0 ||
                target_level.q_count > source_level.q_count ||
                target_level.degree != ciphertext.meta.degree)
            {
                return false;
            }

            for (const auto &poly : ciphertext.polys_)
            {
                if (poly.degree != ciphertext.meta.degree ||
                    poly.q_count != ciphertext.meta.q_count ||
                    poly.p_count != 0 ||
                    poly.shards.size() != 1)
                {
                    return false;
                }
                const auto &shard = poly.shards.front();
                if (shard.limb_begin != 0 ||
                    shard.limb_count != ciphertext.meta.q_count ||
                    shard.coeff_begin != 0 ||
                    shard.coeff_count != ciphertext.meta.degree)
                {
                    return false;
                }
            }

            ciphertext.meta.parms_id = target_level.parms_id;
            ciphertext.meta.q_count = target_level.q_count;
            for (auto &poly : ciphertext.polys_)
            {
                poly.q_count = target_level.q_count;
                poly.p_count = 0;
                poly.shards.front().limb_count = target_level.q_count;
            }
            return true;
        };

    auto supports_q_prefix_multiply =
        [&](const GpuCiphertextData &left,
            const GpuCiphertextData &right,
            parms_id_type target_parms_id) {
            if (!q_prefix_views ||
                left.empty() || right.empty() ||
                left.fields_.empty() || right.fields_.empty() ||
                left.size() != 2 || right.size() != 2 ||
                left.meta.component_count != left.size() ||
                right.meta.component_count != right.size() ||
                !left.meta.is_ntt_form || !right.meta.is_ntt_form ||
                left.meta.p_count != 0 || right.meta.p_count != 0 ||
                left.meta.degree != right.meta.degree ||
                left.fields_.front().device_id != right.fields_.front().device_id)
            {
                return false;
            }

            const auto &target_level = params_.get_level(target_parms_id);
            if (target_level.p_count != 0 ||
                target_level.q_count == 0 ||
                target_level.degree != left.meta.degree ||
                target_level.q_count > left.meta.q_count ||
                target_level.q_count > right.meta.q_count)
            {
                return false;
            }

            auto supports_source =
                [&](const GpuCiphertextData &source) {
                    for (const auto &poly : source.polys_)
                    {
                        if (poly.degree != source.meta.degree ||
                            poly.q_count != source.meta.q_count ||
                            poly.p_count != 0 ||
                            poly.shards.size() != 1)
                        {
                            return false;
                        }
                        const auto &shard = poly.shards.front();
                        if (shard.limb_begin != 0 ||
                            shard.limb_count != source.meta.q_count ||
                            shard.coeff_begin != 0 ||
                            shard.coeff_count != source.meta.degree)
                        {
                            return false;
                        }
                    }
                    return true;
                };
            return supports_source(left) && supports_source(right);
        };

    auto multiply_q_prefix =
        [&](const GpuCiphertextData &left,
            const GpuCiphertextData &right,
            parms_id_type target_parms_id,
            GpuCiphertextData &output) {
            if (!supports_q_prefix_multiply(left, right, target_parms_id))
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: unsupported Q-prefix multiply");
            }

            const auto &target_level = params_.get_level(target_parms_id);
            auto left_view = left.make_const_view();
            auto right_view = right.make_const_view();
            auto trim_view =
                [&](GpuConstCiphertextView &view) {
                    view.meta.parms_id = target_level.parms_id;
                    view.meta.q_count = target_level.q_count;
                    view.meta.p_count = 0;
                    for (auto &poly : view.polys)
                    {
                        poly.shards.front().limb_count = target_level.q_count;
                    }
                };
            trim_view(left_view);
            trim_view(right_view);

            GpuRNSPoly prefix_layout = left.polys_.front();
            prefix_layout.q_count = target_level.q_count;
            prefix_layout.p_count = 0;
            prefix_layout.shards.front().limb_count = target_level.q_count;

            GpuCiphertextMeta result_meta = left.meta;
            result_meta.parms_id = target_level.parms_id;
            result_meta.q_count = target_level.q_count;
            result_meta.p_count = 0;
            result_meta.component_count = 3;
            result_meta.scale = left.meta.scale * right.meta.scale;
            if (!(result_meta.scale > 0.0) ||
                !std::isfinite(result_meta.scale))
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: invalid Q-prefix multiply scale");
            }

            prepare_ciphertext_destination(
                output,
                nullptr,
                nullptr,
                result_meta,
                3,
                left.fields_.front().device_id,
                prefix_layout);
            auto output_view = output.make_view();
            elementwise_handler_.multiply_ciphertext(
                output_view,
                left_view,
                right_view,
                target_level);
        };

    auto add_plain_inplace =
        [&](GpuCiphertextData &ciphertext,
            const GpuPlaintextData &plaintext,
            const char *name) {
            if (!d2d_free_dataflow)
            {
                GpuCiphertextData materialized;
                add_plain(ciphertext, plaintext, materialized);
                ciphertext = std::move(materialized);
                return;
            }
            if (ciphertext.empty() || plaintext.empty() ||
                !(ciphertext.meta.parms_id == plaintext.meta.parms_id) ||
                ciphertext.meta.is_ntt_form != plaintext.meta.is_ntt_form ||
                ciphertext.meta.degree != plaintext.meta.degree ||
                ciphertext.meta.q_count != plaintext.meta.q_count ||
                ciphertext.meta.p_count != plaintext.meta.p_count ||
                !same_scale(ciphertext.meta.scale, plaintext.meta.scale))
            {
                throw std::invalid_argument(std::string(name) +
                                            ": incompatible input");
            }
            auto ciphertext_view = ciphertext.make_view();
            auto plaintext_view = plaintext.make_const_view();
            const auto &level_info = params_.get_level(ciphertext.meta.parms_id);
            elementwise_handler_.add_plain_to_ciphertext_inplace(
                ciphertext_view,
                plaintext_view,
                level_info);
        };

    auto sub_plain_inplace =
        [&](GpuCiphertextData &ciphertext,
            const GpuPlaintextData &plaintext,
            const char *name) {
            if (!d2d_free_dataflow)
            {
                GpuCiphertextData materialized;
                sub_plain(ciphertext, plaintext, materialized);
                ciphertext = std::move(materialized);
                return;
            }
            if (ciphertext.empty() || plaintext.empty() ||
                !(ciphertext.meta.parms_id == plaintext.meta.parms_id) ||
                ciphertext.meta.is_ntt_form != plaintext.meta.is_ntt_form ||
                ciphertext.meta.degree != plaintext.meta.degree ||
                ciphertext.meta.q_count != plaintext.meta.q_count ||
                ciphertext.meta.p_count != plaintext.meta.p_count ||
                !same_scale(ciphertext.meta.scale, plaintext.meta.scale))
            {
                throw std::invalid_argument(std::string(name) +
                                            ": incompatible input");
            }
            auto ciphertext_view = ciphertext.make_view();
            auto plaintext_view = plaintext.make_const_view();
            const auto &level_info = params_.get_level(ciphertext.meta.parms_id);
            elementwise_handler_.sub_plain_from_ciphertext_inplace(
                ciphertext_view,
                plaintext_view,
                level_info);
        };

    /*
     * Dynamic C2S may finish above the EvalMod minimum scale. Keep that
     * physical input scale instead of relabeling it to target_scale: a metadata
     * relabel would amplify the decoded C2S error. Legacy setup leaves
     * input_scale unset and therefore retains the original target-scale path.
     */
    const bool legacy_horner =
        polynomial_blocks.empty() && polynomial_terms.empty();
    const GpuCiphertextData *x = nullptr;
    if (legacy_horner)
    {
        NvtxRange range("EvalMod input preparation");
        copy_ciphertext_data(
            source_ciphertext,
            workspace.scratch0,
            "GpuEvaluator::eval_mod_high_precision input copy");
        workspace.scratch0.meta.scale = configured_input_scale;

        x = &workspace.scratch0;
        if (!configured_input_offset.empty())
        {
            add_plain_inplace(
                workspace.scratch0,
                configured_input_offset,
                "GpuEvaluator::eval_mod_high_precision input offset");
        }

        if (workspace.capture_eval_mod_trace)
        {
            copy_ciphertext_data(
                *x,
                workspace.eval_mod_trace_offset_input,
                "GpuEvaluator::eval_mod_high_precision trace input copy");
            workspace.eval_mod_trace_offset_input.meta.scale = x->meta.scale;
        }
        stage_recorder.record(1);
    }

    /*
     * Keep the old Horner layout only for callers that still populate the
     * early polynomial_coefficients field. The high-precision path below uses
     * a setup-time fixed basis DAG and never performs CPU-side recursive
     * polynomial decomposition in the timed path.
     */
    if (legacy_horner)
    {
        stage_recorder.record(2);
        GpuCiphertextData accumulator;
        multiply_scalar(*x, 0, accumulator);
        accumulator.meta.scale = target_scale;

        const auto &coefficients = configured_coefficients;
        if (!coefficients.front().empty())
        {
            add_plain_inplace(
                accumulator,
                coefficients.front(),
                "GpuEvaluator::eval_mod_high_precision Horner constant");
            accumulator.meta.scale = target_scale;
        }

        for (std::size_t i = 1; i < coefficients.size(); ++i)
        {
            const GpuCiphertextData *x_at_level = x;
            GpuCiphertextData x_dropped;
            if (!(x->meta.parms_id == accumulator.meta.parms_id))
            {
                if (x->meta.q_count < accumulator.meta.q_count)
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: x level is below accumulator level");
                }
                drop_modulus(*x, x_dropped, accumulator.meta.parms_id);
                x_dropped.meta.scale = target_scale;
                x_at_level = &x_dropped;
            }

            multiply(accumulator, *x_at_level, workspace.scratch3);
            relinearize(workspace.scratch3, relin_keys, workspace.scratch4);
            rescale_many(
                workspace.scratch4,
                workspace.scratch5,
                logical_rescale_count);
            workspace.scratch5.meta.scale = target_scale;
            accumulator = std::move(workspace.scratch5);

            if (!coefficients[i].empty())
            {
                add_plain_inplace(
                    accumulator,
                    coefficients[i],
                    "GpuEvaluator::eval_mod_high_precision Horner coefficient");
                accumulator.meta.scale = target_scale;
            }
        }
        stage_recorder.record(3);
        stage_recorder.record(4);

        for (const auto &double_angle_plaintext : configured_double_angle_constants)
        {
            square(accumulator, workspace.scratch3);
            relinearize(workspace.scratch3, relin_keys, workspace.scratch4);
            rescale_many(
                workspace.scratch4,
                workspace.scratch5,
                logical_rescale_count);
            workspace.scratch5.meta.scale = target_scale;
            add(workspace.scratch5, workspace.scratch5, workspace.scratch2);

            if (!double_angle_plaintext.empty())
            {
                add_plain_inplace(
                    workspace.scratch2,
                    double_angle_plaintext,
                    "GpuEvaluator::eval_mod_high_precision Horner double-angle");
                accumulator = std::move(workspace.scratch2);
            }
            else
            {
                accumulator = std::move(workspace.scratch2);
            }
            accumulator.meta.scale = target_scale;
        }
        stage_recorder.record(5);

        destination_ciphertext = std::move(accumulator);
        destination_ciphertext.meta.scale = source_ciphertext.meta.scale;
        stage_recorder.finish(workspace.eval_mod_stage_timing);
        return;
    }

    std::uint32_t maximum_degree = 1;
    for (const auto &term : polynomial_terms)
    {
        maximum_degree = std::max(maximum_degree, term.degree);
        if (term.coefficient_plaintext.empty())
        {
            throw std::invalid_argument(
                "GpuEvaluator::eval_mod_high_precision: empty term plaintext");
        }
    }
    for (const auto &block : polynomial_blocks)
    {
        if (block.terms.empty())
        {
            throw std::invalid_argument(
                "GpuEvaluator::eval_mod_high_precision: empty polynomial block");
        }
        for (const auto &term : block.terms)
        {
            maximum_degree = std::max(maximum_degree, term.degree);
            if (term.coefficient_plaintext.empty())
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: empty block term plaintext");
            }
        }
    }
    for (const auto &combine : polynomial_combine_steps)
    {
        maximum_degree = std::max(maximum_degree, combine.basis_degree);
    }
    for (const auto &step : basis_steps)
    {
        maximum_degree = std::max(maximum_degree, step.output_degree);
        maximum_degree = std::max(maximum_degree, step.left_degree);
        maximum_degree = std::max(maximum_degree, step.right_degree);
        maximum_degree = std::max(maximum_degree, step.correction_degree);
    }

    std::vector<bool> basis_available(
        static_cast<std::size_t>(maximum_degree) + 1,
        false);
    basis_available[0] = true;
    basis_available[1] = true;
    for (const auto &step : basis_steps)
    {
        if (step.output_degree <= 1 ||
            step.left_degree == 0 ||
            step.right_degree == 0 ||
            !basis_available[step.left_degree] ||
            !basis_available[step.right_degree] ||
            basis_available[step.output_degree])
        {
            throw std::invalid_argument(
                "GpuEvaluator::eval_mod_high_precision: basis plan is not topologically valid");
        }
        if (bootstrap_data.eval_mod.polynomial_basis ==
                GpuEvalModPolynomialBasis::Chebyshev &&
            step.correction_degree != 0 &&
            !basis_available[step.correction_degree])
        {
            throw std::invalid_argument(
                "GpuEvaluator::eval_mod_high_precision: missing Chebyshev correction basis");
        }
        basis_available[step.output_degree] = true;
    }
    for (const auto &term : polynomial_terms)
    {
        if (term.degree != 0 && !basis_available[term.degree])
        {
            throw std::invalid_argument(
                "GpuEvaluator::eval_mod_high_precision: polynomial term is absent from basis plan");
        }
    }
    for (const auto &block : polynomial_blocks)
    {
        for (const auto &term : block.terms)
        {
            if (term.degree != 0 && !basis_available[term.degree])
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: block term is absent from basis plan");
            }
        }
    }
    for (const auto &combine : polynomial_combine_steps)
    {
        if (combine.basis_degree == 0 ||
            !basis_available[combine.basis_degree])
        {
            throw std::invalid_argument(
                "GpuEvaluator::eval_mod_high_precision: combine basis is absent from basis plan");
        }
    }

    const auto required_basis_slots =
        static_cast<std::size_t>(maximum_degree) + 1;
    if (workspace.eval_mod_basis.size() < required_basis_slots)
    {
        workspace.eval_mod_basis.resize(required_basis_slots);
    }
    if (d2d_free_dataflow)
    {
        NvtxRange range("EvalMod input preparation");
        copy_ciphertext_data(
            source_ciphertext,
            workspace.eval_mod_basis[1],
            "GpuEvaluator::eval_mod_high_precision basis T1 input copy");
        workspace.eval_mod_basis[1].meta.scale = configured_input_scale;
        if (!configured_input_offset.empty())
        {
            add_plain_inplace(
                workspace.eval_mod_basis[1],
                configured_input_offset,
                "GpuEvaluator::eval_mod_high_precision basis T1 input offset");
        }
    }
    else
    {
        NvtxRange range("EvalMod input preparation");
        copy_ciphertext_data(
            source_ciphertext,
            workspace.scratch0,
            "GpuEvaluator::eval_mod_high_precision input copy");
        workspace.scratch0.meta.scale = configured_input_scale;
        GpuCiphertextData *prepared_input = &workspace.scratch0;
        if (!configured_input_offset.empty())
        {
            add_plain(
                workspace.scratch0,
                configured_input_offset,
                workspace.scratch1);
            workspace.scratch1.meta.scale = configured_input_scale;
            prepared_input = &workspace.scratch1;
        }
        copy_ciphertext_data(
            *prepared_input,
            workspace.eval_mod_basis[1],
            "GpuEvaluator::eval_mod_high_precision basis T1 copy");
        workspace.eval_mod_basis[1].meta.scale = configured_input_scale;
    }
    x = &workspace.eval_mod_basis[1];
    if (workspace.capture_eval_mod_trace)
    {
        copy_ciphertext_data(
            *x,
            workspace.eval_mod_trace_offset_input,
            "GpuEvaluator::eval_mod_high_precision trace input copy");
        workspace.eval_mod_trace_offset_input.meta.scale = x->meta.scale;
    }
    stage_recorder.record(1);

    auto multiply_relinearize_rescale =
        [&](const GpuCiphertextData &left,
            const GpuCiphertextData &right,
            double expected_output_scale,
            std::uint32_t rescale_count,
            GpuCiphertextData &output) {
            const GpuCiphertextData *left_at_level = &left;
            const GpuCiphertextData *right_at_level = &right;
            if (!(left.meta.parms_id == right.meta.parms_id))
            {
                if (left.meta.q_count == right.meta.q_count)
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: equal q_count has different parms_id");
                }
                if (left.meta.q_count > right.meta.q_count)
                {
                    drop_modulus(left, workspace.scratch3, right.meta.parms_id);
                    left_at_level = &workspace.scratch3;
                }
                else
                {
                    drop_modulus(right, workspace.scratch4, left.meta.parms_id);
                    right_at_level = &workspace.scratch4;
                }
            }

            if (left_at_level == right_at_level)
            {
                square(*left_at_level, workspace.scratch5);
            }
            else
            {
                multiply(*left_at_level, *right_at_level, workspace.scratch5);
            }
            if (rescale_count == 2 &&
                use_rescale_x2() &&
                use_relinearize_rescale_x2())
            {
                relinearize_rescale_x2_hybrid(
                    workspace.scratch5,
                    relin_keys,
                    output);
            }
            else
            {
                relinearize(workspace.scratch5, relin_keys, workspace.scratch3);
                // rescale_dynamic is deliberately not used in the first GPU path.
                rescale_many(
                    workspace.scratch3,
                    output,
                    rescale_count);
            }
            if (expected_output_scale > 0.0)
            {
                output.meta.scale = expected_output_scale;
            }
        };

    auto multiply_plain_accumulate_first_two =
        [&](const GpuCiphertextData &source_ciphertext,
            const GpuPlaintextData &source_plaintext,
            GpuCiphertextData &destination_ciphertext) {
            if (source_ciphertext.empty() || source_plaintext.empty() ||
                destination_ciphertext.empty())
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: empty inline leaf accumulate input");
            }
            if (!(source_ciphertext.meta.parms_id ==
                  source_plaintext.meta.parms_id) ||
                !(source_ciphertext.meta.parms_id ==
                  destination_ciphertext.meta.parms_id) ||
                !source_ciphertext.meta.is_ntt_form ||
                !source_plaintext.meta.is_ntt_form ||
                !destination_ciphertext.meta.is_ntt_form ||
                source_ciphertext.size() != 2 ||
                destination_ciphertext.size() < 2)
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: incompatible inline leaf accumulate input");
            }
            const double product_scale =
                source_ciphertext.meta.scale * source_plaintext.meta.scale;
            if (!same_scale(product_scale, destination_ciphertext.meta.scale))
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: inline leaf accumulate scale mismatch");
            }
            if (!same_logical_shard_layout(
                    source_ciphertext.polys_.front(),
                    source_plaintext.poly_) ||
                !same_logical_shard_layout(
                    source_ciphertext.polys_.front(),
                    destination_ciphertext.polys_.front()) ||
                !all_components_use_layout(
                    source_ciphertext,
                    source_ciphertext.polys_.front()) ||
                !all_components_use_layout(
                    destination_ciphertext,
                    destination_ciphertext.polys_.front()))
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: inline leaf accumulate shard mismatch");
            }

            auto destination_view = destination_ciphertext.make_view();
            auto ciphertext_view = source_ciphertext.make_const_view();
            auto plaintext_view = source_plaintext.make_const_view();
            const auto &level_info =
                params_.get_level(source_ciphertext.meta.parms_id);
            elementwise_handler_.multiply_plain_accumulate_with_ciphertext(
                destination_view,
                ciphertext_view,
                plaintext_view,
                level_info);
        };

    {
        NvtxRange range("EvalMod Chebyshev basis generation");
        for (const auto &step : basis_steps)
        {
            auto &output = workspace.eval_mod_basis[step.output_degree];
            const GpuCiphertextData *basis_left =
                &workspace.eval_mod_basis[step.left_degree];
            const GpuCiphertextData *basis_right =
                &workspace.eval_mod_basis[step.right_degree];
            if (!step.operand_alignment_plaintext.empty())
            {
                const GpuCiphertextData &high_operand = step.align_left_operand
                    ? *basis_left
                    : *basis_right;
                multiply_plain(
                    high_operand,
                    step.operand_alignment_plaintext,
                    workspace.scratch0);
                workspace.scratch0.meta.scale =
                    step.operand_alignment_pre_rescale_scale;
                rescale_many(
                    workspace.scratch0,
                    workspace.scratch1,
                    step.operand_alignment_rescale_count);
                workspace.scratch1.meta.scale =
                    step.operand_alignment_output_scale;
                if (step.align_left_operand)
                {
                    basis_left = &workspace.scratch1;
                }
                else
                {
                    basis_right = &workspace.scratch1;
                }
            }
            if (bootstrap_data.eval_mod.dynamic_rescale)
            {
                bool use_basis_prefix_multiply = false;
                parms_id_type basis_prefix_parms_id = parms_id_zero;
                if (!(basis_left->meta.parms_id == basis_right->meta.parms_id))
                {
                    if (basis_left->meta.q_count == basis_right->meta.q_count)
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: dynamic basis equal q_count has different parms_id");
                    }
                    basis_prefix_parms_id =
                        basis_left->meta.q_count < basis_right->meta.q_count
                            ? basis_left->meta.parms_id
                            : basis_right->meta.parms_id;
                    use_basis_prefix_multiply =
                        supports_q_prefix_multiply(
                            *basis_left,
                            *basis_right,
                            basis_prefix_parms_id);
                    if (!use_basis_prefix_multiply &&
                        basis_left->meta.q_count > basis_right->meta.q_count)
                    {
                        drop_modulus(
                            *basis_left,
                            workspace.scratch0,
                            basis_right->meta.parms_id);
                        basis_left = &workspace.scratch0;
                    }
                    else if (!use_basis_prefix_multiply)
                    {
                        drop_modulus(
                            *basis_right,
                            workspace.scratch1,
                            basis_left->meta.parms_id);
                        basis_right = &workspace.scratch1;
                    }
                }

                const bool is_square =
                    !use_basis_prefix_multiply && basis_left == basis_right;
                const std::size_t multiply_q_count =
                    use_basis_prefix_multiply
                        ? params_.get_level(basis_prefix_parms_id).q_count
                        : basis_left->meta.q_count;
                if (workspace.capture_eval_mod_stage_timing)
                {
                    multiply_recorder.begin(
                        "EvalMod.mul.basis.T" +
                        std::to_string(step.output_degree) +
                            "=" + std::to_string(step.left_degree) +
                            "x" + std::to_string(step.right_degree) +
                            ".q" + std::to_string(multiply_q_count),
                        multiply_q_count,
                        relin_keys.meta.p_count,
                        is_square);
                }
                if (use_basis_prefix_multiply)
                {
                    multiply_q_prefix(
                        *basis_left,
                        *basis_right,
                        basis_prefix_parms_id,
                        workspace.scratch5);
                }
                else if (is_square)
                {
                    square(*basis_left, workspace.scratch5);
                }
                else
                {
                    multiply(*basis_left, *basis_right, workspace.scratch5);
                }
                relinearize(workspace.scratch5, relin_keys, workspace.scratch3);
                multiply_recorder.end();
                output = std::move(workspace.scratch3);
                output.meta.scale = step.pre_rescale_scale;

                if (bootstrap_data.eval_mod.polynomial_basis ==
                    GpuEvalModPolynomialBasis::Chebyshev)
                {
                    add(output, output, workspace.scratch3);
                    output = std::move(workspace.scratch3);
                    output.meta.scale = step.pre_rescale_scale;

                    if (step.correction_plaintext.empty())
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: missing dynamic Chebyshev correction plaintext");
                    }
                    if (step.correction_degree == 0)
                    {
                        sub_plain_inplace(
                            output,
                            step.correction_plaintext,
                            "GpuEvaluator::eval_mod_high_precision dynamic Chebyshev constant");
                        output.meta.scale = step.pre_rescale_scale;
                    }
                    else
                    {
                        const auto &correction_basis =
                            workspace.eval_mod_basis[step.correction_degree];
                        multiply_plain(
                            correction_basis,
                            step.correction_plaintext,
                            workspace.scratch4);
                        workspace.scratch4.meta.scale = step.pre_rescale_scale;

                        const GpuCiphertextData *left = &output;
                        const GpuCiphertextData *right = &workspace.scratch4;
                        if (!(left->meta.parms_id == right->meta.parms_id))
                        {
                            if (left->meta.q_count > right->meta.q_count)
                            {
                                if (!q_prefix_views ||
                                    !drop_modulus_inplace(
                                        output,
                                        right->meta.parms_id))
                                {
                                    drop_modulus(
                                        *left,
                                        workspace.scratch0,
                                        right->meta.parms_id);
                                    left = &workspace.scratch0;
                                }
                            }
                            else if (right->meta.q_count > left->meta.q_count)
                            {
                                if (!q_prefix_views ||
                                    !drop_modulus_inplace(
                                        workspace.scratch4,
                                        left->meta.parms_id))
                                {
                                    drop_modulus(
                                        *right,
                                        workspace.scratch1,
                                        left->meta.parms_id);
                                    right = &workspace.scratch1;
                                }
                            }
                else
                            {
                                throw std::invalid_argument(
                                    "GpuEvaluator::eval_mod_high_precision: dynamic Chebyshev correction parms_id mismatch");
                            }
                        }
                        sub(*left, *right, workspace.scratch5);
                        output = std::move(workspace.scratch5);
                        output.meta.scale = step.pre_rescale_scale;
                    }
                }

                if (d2d_free_dataflow)
                {
                    rescale_dynamic(output, output, target_scale);
                }
                else
                {
                    rescale_dynamic(output, workspace.scratch2, target_scale);
                    output = std::move(workspace.scratch2);
                }
                output.meta.scale = step.output_scale;
                continue;
            }

            if (workspace.capture_eval_mod_stage_timing)
            {
                multiply_recorder.begin(
                    "EvalMod.mul.basis.T" +
                        std::to_string(step.output_degree) +
                        "=" + std::to_string(step.left_degree) +
                        "x" + std::to_string(step.right_degree) +
                        ".q" + std::to_string(basis_left->meta.q_count),
                    basis_left->meta.q_count,
                    relin_keys.meta.p_count,
                    basis_left == basis_right);
            }
            multiply_relinearize_rescale(
                *basis_left,
                *basis_right,
                step.output_scale,
                step.rescale_count,
                output);
            multiply_recorder.end();

            if (bootstrap_data.eval_mod.polynomial_basis !=
                GpuEvalModPolynomialBasis::Chebyshev)
            {
                continue;
            }

            add(output, output, workspace.scratch3);
            output = std::move(workspace.scratch3);
            output.meta.scale = step.output_scale;

            if (step.correction_degree == 0)
            {
                if (step.correction_plaintext.empty())
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: missing Chebyshev constant correction");
                }
                sub_plain_inplace(
                    output,
                    step.correction_plaintext,
                    "GpuEvaluator::eval_mod_high_precision Chebyshev constant");
                output.meta.scale = step.output_scale;
                continue;
            }

            const GpuCiphertextData *correction =
                &workspace.eval_mod_basis[step.correction_degree];
            if (!step.correction_alignment_plaintext.empty())
            {
                multiply_plain(
                    *correction,
                    step.correction_alignment_plaintext,
                    workspace.scratch0);
                workspace.scratch0.meta.scale =
                    step.correction_alignment_pre_rescale_scale;
                rescale_many(
                    workspace.scratch0,
                    workspace.scratch1,
                    step.correction_alignment_rescale_count);
                workspace.scratch1.meta.scale = step.output_scale;
                correction = &workspace.scratch1;
            }
            if (!(output.meta.parms_id == correction->meta.parms_id))
            {
                if (output.meta.q_count > correction->meta.q_count)
                {
                    drop_modulus(output, workspace.scratch4, correction->meta.parms_id);
                    output = std::move(workspace.scratch4);
                }
                else if (correction->meta.q_count > output.meta.q_count)
                {
                    drop_modulus(
                        *correction,
                        workspace.scratch4,
                        output.meta.parms_id);
                    correction = &workspace.scratch4;
                }
                else
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: Chebyshev correction parms_id mismatch");
                }
            }
            if (!step.correction_alignment_plaintext.empty())
            {
                sub(output, *correction, workspace.scratch5);
                output = std::move(workspace.scratch5);
                output.meta.scale = step.output_scale;
                continue;
            }
            if (step.correction_plaintext.empty() ||
                step.correction_plaintext.meta.parms_id != output.meta.parms_id)
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: invalid Chebyshev correction scale plaintext");
            }
            multiply_plain(
                *correction,
                step.correction_plaintext,
                workspace.scratch3);
            workspace.scratch3.meta.scale = step.output_scale;
            sub(output, workspace.scratch3, workspace.scratch5);
            output = std::move(workspace.scratch5);
            output.meta.scale = step.output_scale;
        }
    }
    stage_recorder.record(2);

    std::function<bool(
        const std::vector<GpuEvalModPolynomialTerm> &,
        std::uint32_t,
        double,
        std::size_t,
        GpuCiphertextData &)> evaluate_term_block_caccum;

    auto evaluate_term_block =
        [&](const std::vector<GpuEvalModPolynomialTerm> &terms,
            std::uint32_t rescale_count,
            double expected_output_scale,
            std::size_t expected_output_q_count,
            GpuCiphertextData &block_output) {
            if (evaluate_term_block_caccum &&
                evaluate_term_block_caccum(
                    terms,
                    rescale_count,
                    expected_output_scale,
                    expected_output_q_count,
                    block_output))
            {
                return;
            }

            GpuCiphertextData block_accumulator;
            double block_scale = 0.0;

            auto accumulate_term = [&](GpuCiphertextData &term_ciphertext) {
                if (!(block_scale > 0.0))
                {
                    block_scale = term_ciphertext.meta.scale;
                }
                else if (!same_scale(block_scale, term_ciphertext.meta.scale))
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: polynomial term scale mismatch");
                }
                if (block_accumulator.empty())
                {
                    block_accumulator = std::move(term_ciphertext);
                    return;
                }

                const GpuCiphertextData *left = &block_accumulator;
                const GpuCiphertextData *right = &term_ciphertext;
                if (!(left->meta.parms_id == right->meta.parms_id))
                {
                    if (left->meta.q_count > right->meta.q_count)
                    {
                        drop_modulus(*left, workspace.scratch3, right->meta.parms_id);
                        left = &workspace.scratch3;
                    }
                    else if (right->meta.q_count > left->meta.q_count)
                    {
                        drop_modulus(*right, workspace.scratch4, left->meta.parms_id);
                        right = &workspace.scratch4;
                    }
                    else
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: term parms_id mismatch");
                    }
                }
                add(*left, *right, workspace.scratch5);
                block_accumulator = std::move(workspace.scratch5);
                block_accumulator.meta.scale = block_scale;
            };

            std::size_t previous_term_q_count = 0;
            for (const auto &term : terms)
            {
                if (term.degree == 0)
                {
                    continue;
                }
                if (!bootstrap_data.eval_mod.dynamic_rescale &&
                    term.coefficient_plaintext.meta.q_count <
                        previous_term_q_count)
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: block terms are not in setup-time q_count order");
                }
                previous_term_q_count =
                    term.coefficient_plaintext.meta.q_count;

                const auto &basis = workspace.eval_mod_basis[term.degree];
                const GpuCiphertextData *basis_at_level = &basis;
                if (!(basis.meta.parms_id ==
                      term.coefficient_plaintext.meta.parms_id))
                {
                    if (basis.meta.q_count <=
                        term.coefficient_plaintext.meta.q_count)
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: coefficient plaintext is above its basis level");
                    }
                    drop_modulus(
                        basis,
                        workspace.scratch3,
                        term.coefficient_plaintext.meta.parms_id);
                    basis_at_level = &workspace.scratch3;
                }
                if (!bootstrap_data.eval_mod
                         .rescale_polynomial_terms_individually &&
                    !block_accumulator.empty() &&
                    block_accumulator.meta.parms_id ==
                        basis_at_level->meta.parms_id)
                {
                    multiply_plain_accumulate(
                        *basis_at_level,
                        term.coefficient_plaintext,
                        block_accumulator);
                    continue;
                }
                multiply_plain(
                    *basis_at_level,
                    term.coefficient_plaintext,
                    workspace.scratch2);
                if (bootstrap_data.eval_mod.rescale_polynomial_terms_individually)
                {
                    rescale_many(
                        workspace.scratch2,
                        workspace.scratch4,
                        rescale_count);
                    workspace.scratch4.meta.scale = expected_output_scale;
                    workspace.scratch2 = std::move(workspace.scratch4);
                }
                accumulate_term(workspace.scratch2);
            }

            for (const auto &term : terms)
            {
                if (term.degree != 0)
                {
                    continue;
                }
                if (block_accumulator.empty())
                {
                    multiply_scalar(
                        workspace.eval_mod_basis[1],
                        0,
                        block_accumulator);
                    block_scale = term.coefficient_plaintext.meta.scale;
                    block_accumulator.meta.scale = block_scale;
                }
                if (!(block_accumulator.meta.parms_id ==
                      term.coefficient_plaintext.meta.parms_id))
                {
                    if (block_accumulator.meta.q_count <=
                        term.coefficient_plaintext.meta.q_count)
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: constant plaintext is above block level");
                    }
                    drop_modulus(
                        block_accumulator,
                        workspace.scratch3,
                        term.coefficient_plaintext.meta.parms_id);
                    block_accumulator = std::move(workspace.scratch3);
                }
                add_plain_inplace(
                    block_accumulator,
                    term.coefficient_plaintext,
                    "GpuEvaluator::eval_mod_high_precision leaf constant");
                block_accumulator.meta.scale = block_scale;
            }

            if (block_accumulator.empty())
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: polynomial block has no evaluable terms");
            }

            if (!bootstrap_data.eval_mod.rescale_polynomial_terms_individually &&
                rescale_count > 0)
            {
                rescale_many(
                    block_accumulator,
                    workspace.scratch2,
                    rescale_count);
                block_accumulator = std::move(workspace.scratch2);
            }
            if (expected_output_scale > 0.0)
            {
                block_accumulator.meta.scale = expected_output_scale;
            }
            if (expected_output_q_count > 0 &&
                block_accumulator.meta.q_count > expected_output_q_count)
            {
                const auto &target_level =
                    params_.get_level_by_q_count(expected_output_q_count, 0);
                drop_modulus(
                    block_accumulator,
                    workspace.scratch2,
                    target_level.parms_id);
                block_accumulator = std::move(workspace.scratch2);
                if (expected_output_scale > 0.0)
                {
                    block_accumulator.meta.scale = expected_output_scale;
                }
            }
            block_output = std::move(block_accumulator);
        };

    auto add_aligned =
        [&](const GpuCiphertextData &left_input,
            const GpuCiphertextData &right_input,
            double expected_output_scale,
            GpuCiphertextData &output) {
            const GpuCiphertextData *left = &left_input;
            const GpuCiphertextData *right = &right_input;
            if (!(left->meta.parms_id == right->meta.parms_id))
            {
                if (left->meta.q_count > right->meta.q_count)
                {
                    drop_modulus(*left, workspace.scratch3, right->meta.parms_id);
                    left = &workspace.scratch3;
                }
                else if (right->meta.q_count > left->meta.q_count)
                {
                    drop_modulus(*right, workspace.scratch4, left->meta.parms_id);
                    right = &workspace.scratch4;
                }
                else
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: combine parms_id mismatch");
                }
            }
            add(*left, *right, workspace.scratch5);
            if (expected_output_scale > 0.0)
            {
                workspace.scratch5.meta.scale = expected_output_scale;
            }
            output = std::move(workspace.scratch5);
        };

    evaluate_term_block_caccum =
        [&](const std::vector<GpuEvalModPolynomialTerm> &terms,
            std::uint32_t rescale_count,
            double expected_output_scale,
            std::size_t expected_output_q_count,
            GpuCiphertextData &block_output) {
            const bool dynamic_leaf =
                bootstrap_data.eval_mod.dynamic_rescale;
            if (!use_evalmod_caccum_leaf() ||
                (dynamic_leaf && !d2d_free_dataflow) ||
                bootstrap_data.eval_mod.rescale_polynomial_terms_individually ||
                (!dynamic_leaf && rescale_count != logical_rescale_count) ||
                (dynamic_leaf &&
                 (rescale_count != 0 || expected_output_q_count == 0)) ||
                terms.empty())
            {
                return false;
            }

            const GpuEvalModPolynomialTerm *first_nonconstant = nullptr;
            for (const auto &term : terms)
            {
                if (term.degree != 0)
                {
                    first_nonconstant = &term;
                    break;
                }
            }
            if (first_nonconstant == nullptr ||
                first_nonconstant->coefficient_plaintext.empty())
            {
                return false;
            }

            const auto &reference_plaintext =
                first_nonconstant->coefficient_plaintext;
            if (!reference_plaintext.meta.is_ntt_form ||
                reference_plaintext.meta.p_count != 0 ||
                reference_plaintext.poly_.shards.size() != 1 ||
                reference_plaintext.fields_.empty())
            {
                return false;
            }
            const std::size_t target_q_count =
                dynamic_leaf
                    ? expected_output_q_count
                    : reference_plaintext.meta.q_count;
            const auto &target_level =
                params_.get_level_by_q_count(target_q_count, 0);
            const auto target_parms_id = target_level.parms_id;
            if (first_nonconstant->degree >= workspace.eval_mod_basis.size() ||
                workspace.eval_mod_basis[first_nonconstant->degree].empty())
            {
                return false;
            }
            const double pre_rescale_scale =
                workspace.eval_mod_basis[first_nonconstant->degree].meta.scale *
                reference_plaintext.meta.scale;
            if (!(pre_rescale_scale > 0.0) ||
                !std::isfinite(pre_rescale_scale))
            {
                return false;
            }

            for (const auto &term : terms)
            {
                if (term.coefficient_plaintext.empty() ||
                    term.coefficient_plaintext.meta.q_count < target_q_count ||
                    term.coefficient_plaintext.meta.degree !=
                        source_ciphertext.meta.degree ||
                    term.coefficient_plaintext.meta.p_count != 0 ||
                    !term.coefficient_plaintext.meta.is_ntt_form ||
                    term.coefficient_plaintext.poly_.shards.size() != 1)
                {
                    return false;
                }
                if (term.degree == 0)
                {
                    if (!same_scale(
                            term.coefficient_plaintext.meta.scale,
                            pre_rescale_scale))
                    {
                        return false;
                    }
                    continue;
                }
                if (term.degree >= workspace.eval_mod_basis.size())
                {
                    return false;
                }
                const auto &basis = workspace.eval_mod_basis[term.degree];
                if (basis.empty() ||
                    basis.size() != 2 ||
                    !basis.meta.is_ntt_form ||
                    basis.meta.p_count != 0 ||
                    basis.meta.degree != source_ciphertext.meta.degree ||
                    basis.meta.q_count < target_q_count ||
                    basis.polys_[0].shards.size() != 1 ||
                    basis.polys_[1].shards.size() != 1)
                {
                    return false;
                }
                const double term_scale =
                    basis.meta.scale *
                    term.coefficient_plaintext.meta.scale;
                if (!same_scale(term_scale, pre_rescale_scale))
                {
                    return false;
                }
            }

            const int device_id = reference_plaintext.fields_.front().device_id;
            GpuPolyShard accumulator_shard;
            accumulator_shard.field_index = 0;
            accumulator_shard.field_offset = 0;
            accumulator_shard.limb_begin = 0;
            accumulator_shard.limb_count = target_q_count;
            accumulator_shard.coeff_begin = 0;
            accumulator_shard.coeff_count = source_ciphertext.meta.degree;
            auto accumulator =
                GpuCiphertextData::allocate_single_device_sharded(
                    source_ciphertext.meta.degree,
                    target_q_count,
                    2,
                    device_id,
                    std::vector<GpuPolyShard>{accumulator_shard},
                    0);
            accumulator.meta = source_ciphertext.meta;
            accumulator.meta.parms_id = target_parms_id;
            accumulator.meta.scale = pre_rescale_scale;
            accumulator.meta.q_count = target_q_count;
            accumulator.meta.p_count = 0;
            accumulator.meta.component_count = 2;
            accumulator.meta.is_ntt_form = true;

            auto accumulator_view = accumulator.make_view();
            if (accumulator_view.polys.size() != 2 ||
                accumulator_view.polys[0].shards.size() != 1 ||
                accumulator_view.polys[1].shards.size() != 1)
            {
                return false;
            }
            const auto &destination0 =
                accumulator_view.polys[0].shards.front();
            const auto &destination1 =
                accumulator_view.polys[1].shards.front();

            const GpuParameterShard *parameter_shard = nullptr;
            for (const auto &candidate : target_level.shards)
            {
                if (candidate.device_id == destination0.device_id &&
                    destination0.limb_begin >= candidate.limb_begin &&
                    destination0.limb_begin + destination0.limb_count <=
                        candidate.limb_begin + candidate.limb_count)
                {
                    parameter_shard = &candidate;
                    break;
                }
            }
            if (parameter_shard == nullptr)
            {
                return false;
            }

            constexpr std::size_t terms_per_launch = 4;
            std::array<GpuConstPolyShardView, terms_per_launch> c0_terms{};
            std::array<GpuConstPolyShardView, terms_per_launch> c1_terms{};
            std::array<GpuConstPolyShardView, terms_per_launch> plain_terms{};
            GpuConstPolyShardView constant_plaintext{};
            bool has_constant_plaintext = false;
            std::size_t batch_count = 0;
            bool wrote_accumulator = false;

            for (const auto &term : terms)
            {
                if (term.degree != 0)
                {
                    continue;
                }
                if (has_constant_plaintext)
                {
                    return false;
                }
                const auto plaintext_view =
                    term.coefficient_plaintext.make_const_view();
                constant_plaintext = plaintext_view.poly.shards.front();
                if (constant_plaintext.device_id != destination0.device_id ||
                    constant_plaintext.limb_begin != 0 ||
                    constant_plaintext.limb_count < target_q_count ||
                    constant_plaintext.coeff_begin != destination0.coeff_begin ||
                    constant_plaintext.coeff_count != destination0.coeff_count)
                {
                    return false;
                }
                constant_plaintext.limb_count = target_q_count;
                has_constant_plaintext = true;
            }

            const auto flush_batch = [&]() {
                if (batch_count == 0)
                {
                    return;
                }
                kernel::launch_multiply_plain_caccumulate_two_components_4(
                    destination0,
                    destination1,
                    c0_terms.data(),
                    c1_terms.data(),
                    plain_terms.data(),
                    batch_count,
                    !wrote_accumulator && has_constant_plaintext
                        ? &constant_plaintext
                        : nullptr,
                    wrote_accumulator,
                    *parameter_shard,
                    target_level.degree);
                wrote_accumulator = true;
                batch_count = 0;
            };

            for (const auto &term : terms)
            {
                if (term.degree == 0)
                {
                    continue;
                }
                const auto &basis = workspace.eval_mod_basis[term.degree];
                const auto basis_view = basis.make_const_view();
                const auto plaintext_view =
                    term.coefficient_plaintext.make_const_view();
                auto c0_view = basis_view.polys[0].shards.front();
                auto c1_view = basis_view.polys[1].shards.front();
                auto plain_view = plaintext_view.poly.shards.front();
                if (c0_view.device_id != destination0.device_id ||
                    c1_view.device_id != destination0.device_id ||
                    plain_view.device_id != destination0.device_id ||
                    c0_view.limb_begin != 0 ||
                    c1_view.limb_begin != 0 ||
                    plain_view.limb_begin != 0 ||
                    c0_view.coeff_begin != destination0.coeff_begin ||
                    c1_view.coeff_begin != destination0.coeff_begin ||
                    plain_view.coeff_begin != destination0.coeff_begin ||
                    c0_view.coeff_count != destination0.coeff_count ||
                    c1_view.coeff_count != destination0.coeff_count ||
                    plain_view.coeff_count != destination0.coeff_count ||
                    c0_view.limb_count < destination0.limb_count ||
                    c1_view.limb_count < destination0.limb_count ||
                    plain_view.limb_count < destination0.limb_count)
                {
                    return false;
                }
                c0_view.limb_count = destination0.limb_count;
                c1_view.limb_count = destination0.limb_count;
                plain_view.limb_count = destination0.limb_count;
                c0_terms[batch_count] = c0_view;
                c1_terms[batch_count] = c1_view;
                plain_terms[batch_count] = plain_view;
                ++batch_count;
                if (batch_count == terms_per_launch)
                {
                    flush_batch();
                }
            }
            flush_batch();

            if (!wrote_accumulator)
            {
                return false;
            }

            if (dynamic_leaf)
            {
                accumulator.meta.scale = expected_output_scale;
                block_output = std::move(accumulator);
            }
            else
            {
                rescale_many(
                    accumulator,
                    workspace.scratch2,
                    rescale_count);
                workspace.scratch2.meta.scale = expected_output_scale;
                block_output = std::move(workspace.scratch2);
            }
            return true;
        };

    auto accumulate_leaf_pre_rescale =
        [&](const GpuEvalModPolynomialBlock &block,
            GpuCiphertextData &accumulator_pre_rescale) {
            if (bootstrap_data.eval_mod.rescale_polynomial_terms_individually ||
                block.rescale_count != logical_rescale_count)
            {
                return false;
            }
            if (accumulator_pre_rescale.empty() ||
                accumulator_pre_rescale.size() < 3 ||
                !accumulator_pre_rescale.meta.is_ntt_form)
            {
                return false;
            }

            const double accumulator_scale =
                accumulator_pre_rescale.meta.scale;

            for (const auto &term : block.terms)
            {
                if (term.degree == 0)
                {
                    continue;
                }
                if (term.coefficient_plaintext.empty() ||
                    !(term.coefficient_plaintext.meta.parms_id ==
                      accumulator_pre_rescale.meta.parms_id))
                {
                    return false;
                }
                if (term.degree >= workspace.eval_mod_basis.size())
                {
                    return false;
                }

                const auto &basis = workspace.eval_mod_basis[term.degree];
                if (basis.empty())
                {
                    return false;
                }
                if (!(basis.meta.parms_id ==
                      term.coefficient_plaintext.meta.parms_id))
                {
                    if (basis.meta.q_count <=
                        term.coefficient_plaintext.meta.q_count)
                    {
                        return false;
                    }
                }
                const double term_scale =
                    basis.meta.scale *
                    term.coefficient_plaintext.meta.scale;
                if (!same_scale(term_scale, accumulator_scale))
                {
                    return false;
                }
            }

            for (const auto &term : block.terms)
            {
                if (term.degree != 0)
                {
                    continue;
                }
                if (term.coefficient_plaintext.empty() ||
                    !(term.coefficient_plaintext.meta.parms_id ==
                      accumulator_pre_rescale.meta.parms_id) ||
                    !same_scale(
                        term.coefficient_plaintext.meta.scale,
                        accumulator_scale))
                {
                    return false;
                }
            }

            bool accumulated_any = false;
            for (const auto &term : block.terms)
            {
                if (term.degree == 0)
                {
                    continue;
                }
                const auto &basis = workspace.eval_mod_basis[term.degree];
                const GpuCiphertextData *basis_at_level = &basis;
                if (!(basis.meta.parms_id ==
                      term.coefficient_plaintext.meta.parms_id))
                {
                    drop_modulus(
                        basis,
                        workspace.scratch3,
                        term.coefficient_plaintext.meta.parms_id);
                    basis_at_level = &workspace.scratch3;
                }
                multiply_plain_accumulate_first_two(
                    *basis_at_level,
                    term.coefficient_plaintext,
                    accumulator_pre_rescale);
                accumulated_any = true;
            }

            for (const auto &term : block.terms)
            {
                if (term.degree != 0)
                {
                    continue;
                }
                add_plain_inplace(
                    accumulator_pre_rescale,
                    term.coefficient_plaintext,
                    "GpuEvaluator::eval_mod_high_precision inline leaf constant");
                accumulator_pre_rescale.meta.scale = accumulator_scale;
                accumulated_any = true;
            }

            return accumulated_any;
        };

    auto multiply_inline_leaf_relinearize_rescale =
        [&](const GpuCiphertextData &left,
            const GpuCiphertextData &right,
            const GpuEvalModPolynomialBlock &leaf_block,
            double expected_output_scale,
            GpuCiphertextData &output) {
            if (!use_evalmod_inline_leaf())
            {
                return false;
            }

            const GpuCiphertextData *left_at_level = &left;
            const GpuCiphertextData *right_at_level = &right;
            if (!(left.meta.parms_id == right.meta.parms_id))
            {
                if (left.meta.q_count == right.meta.q_count)
                {
                    return false;
                }
                if (left.meta.q_count > right.meta.q_count)
                {
                    drop_modulus(left, workspace.scratch3, right.meta.parms_id);
                    left_at_level = &workspace.scratch3;
                }
                else
                {
                    drop_modulus(right, workspace.scratch4, left.meta.parms_id);
                    right_at_level = &workspace.scratch4;
                }
            }

            if (left_at_level == right_at_level)
            {
                square(*left_at_level, workspace.scratch5);
            }
            else
            {
                multiply(*left_at_level, *right_at_level, workspace.scratch5);
            }

            if (!accumulate_leaf_pre_rescale(
                    leaf_block,
                    workspace.scratch5))
            {
                return false;
            }

            if (logical_rescale_count == 2 &&
                use_rescale_x2() &&
                use_relinearize_rescale_x2())
            {
                relinearize_rescale_x2_hybrid(
                    workspace.scratch5,
                    relin_keys,
                    output);
            }
            else
            {
                relinearize(workspace.scratch5, relin_keys, workspace.scratch3);
                rescale_many(
                    workspace.scratch3,
                    output,
                    logical_rescale_count);
            }
            if (expected_output_scale > 0.0)
            {
                output.meta.scale = expected_output_scale;
            }
            return true;
        };

    GpuCiphertextData accumulator;
    if (polynomial_blocks.empty())
    {
        NvtxRange range("EvalMod fused leaf evaluation");
        evaluate_term_block(
            polynomial_terms,
            bootstrap_data.eval_mod.polynomial_rescale_count,
            target_scale,
            0,
            accumulator);
        stage_recorder.record(3);
    }
    else
    {
        std::uint32_t maximum_node =
            bootstrap_data.eval_mod.polynomial_result_node;
        maximum_node = std::max(
            maximum_node,
            static_cast<std::uint32_t>(polynomial_blocks.size() - 1));
        for (const auto &combine : polynomial_combine_steps)
        {
            maximum_node = std::max(maximum_node, combine.output_node);
            maximum_node = std::max(maximum_node, combine.quotient_node);
            maximum_node = std::max(maximum_node, combine.remainder_node);
        }
        if (workspace.eval_mod_nodes.size() <= maximum_node)
        {
            workspace.eval_mod_nodes.resize(
                static_cast<std::size_t>(maximum_node) + 1);
        }

        std::vector<std::size_t> node_use_counts(
            static_cast<std::size_t>(maximum_node) + 1,
            0);
        std::vector<std::size_t> basis_last_combine_use(
            workspace.eval_mod_basis.size(),
            std::numeric_limits<std::size_t>::max());
        for (std::size_t combine_index = 0;
             combine_index < polynomial_combine_steps.size();
             ++combine_index)
        {
            const auto &combine = polynomial_combine_steps[combine_index];
            if (combine.quotient_node < node_use_counts.size())
            {
                ++node_use_counts[combine.quotient_node];
            }
            if (combine.remainder_node < node_use_counts.size())
            {
                ++node_use_counts[combine.remainder_node];
            }
            if (combine.basis_degree < basis_last_combine_use.size())
            {
                basis_last_combine_use[combine.basis_degree] = combine_index;
            }
        }

        /*
         * A size-3 Q*T+R result may remain unrelinearized when it is consumed
         * only as the remainder of its parent. The parent product is also a
         * size-3 ciphertext, so the two raw ciphertexts can be added and one
         * HYBRID key-switch can relinearize their combined c2 component.
         *
         * Quotient children are deliberately excluded: multiplying a size-3
         * quotient by a size-2 basis would create a size-4 ciphertext and
         * require higher-power relinearization keys. Each candidate remainder
         * edge is checked independently below; an edge that needs an
         * intervening rescale or scale multiplication remains eagerly
         * relinearized. The validated plans are degree 22 with baby width 4,
         * degree 30 with baby width 8, and degree 58/59 with their existing
         * recursive splits.
         */
        const bool lazy_relinearization =
            use_evalmod_lazy_relinearization() &&
            bootstrap_data.eval_mod.dynamic_rescale &&
            (bootstrap_data.eval_mod.polynomial_degree == 22 ||
             bootstrap_data.eval_mod.polynomial_degree == 30 ||
             bootstrap_data.eval_mod.polynomial_degree == 58 ||
             bootstrap_data.eval_mod.polynomial_degree == 59) &&
            bootstrap_data.eval_mod.polynomial_basis ==
                GpuEvalModPolynomialBasis::Chebyshev;
        std::vector<bool> lazy_raw_output(
            static_cast<std::size_t>(maximum_node) + 1,
            false);
        if (lazy_relinearization)
        {
            for (const auto &parent : polynomial_combine_steps)
            {
                if (parent.remainder_node < polynomial_blocks.size() ||
                    parent.remainder_node >= lazy_raw_output.size() ||
                    parent.remainder_node >= node_use_counts.size() ||
                    node_use_counts[parent.remainder_node] != 1 ||
                    parent.remainder_rescale_count != 0 ||
                    !parent.remainder_scale_plaintext.empty())
                {
                    continue;
                }
                lazy_raw_output[parent.remainder_node] = true;
            }
        }

        std::vector<bool> inline_leaf_candidate(polynomial_blocks.size(), false);
        if (use_evalmod_inline_leaf() &&
            !bootstrap_data.eval_mod.dynamic_rescale)
        {
            for (const auto &combine : polynomial_combine_steps)
            {
                if (combine.remainder_node < polynomial_blocks.size() &&
                    combine.remainder_node < node_use_counts.size() &&
                    node_use_counts[combine.remainder_node] == 1)
                {
                    inline_leaf_candidate[combine.remainder_node] = true;
                }
            }
        }

        std::vector<bool> node_available(
            static_cast<std::size_t>(maximum_node) + 1,
            false);
        {
            NvtxRange range("EvalMod fused leaf evaluation");
            for (std::size_t i = 0; i < polynomial_blocks.size(); ++i)
            {
                if (i >= node_available.size())
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: block node id exceeds schedule");
                }
                if (inline_leaf_candidate[i])
                {
                    continue;
                }
                evaluate_term_block(
                    polynomial_blocks[i].terms,
                    polynomial_blocks[i].rescale_count,
                    polynomial_blocks[i].output_scale,
                    polynomial_blocks[i].output_q_count,
                    workspace.eval_mod_nodes[i]);
                node_available[i] = true;
                if (workspace.capture_eval_mod_trace)
                {
                    workspace.eval_mod_trace_polynomial_leaf_outputs.emplace_back();
                    copy_ciphertext_data(
                        workspace.eval_mod_nodes[i],
                        workspace.eval_mod_trace_polynomial_leaf_outputs.back(),
                        "GpuEvaluator::eval_mod_high_precision trace leaf copy");
                    workspace.eval_mod_trace_polynomial_leaf_outputs.back().meta.scale =
                        workspace.eval_mod_nodes[i].meta.scale;
                }
            }
        }
        stage_recorder.record(3);

        {
            NvtxRange range("EvalMod BSGS tree combine");
            for (std::size_t combine_index = 0;
                 combine_index < polynomial_combine_steps.size();
                 ++combine_index)
            {
                const auto &combine = polynomial_combine_steps[combine_index];
                const bool remainder_is_inline_leaf =
                    combine.remainder_node < inline_leaf_candidate.size() &&
                    inline_leaf_candidate[combine.remainder_node];
                if (!node_available[combine.quotient_node] ||
                    (!node_available[combine.remainder_node] &&
                     !remainder_is_inline_leaf) ||
                    node_available[combine.output_node])
                {
                    throw std::invalid_argument(
                        "GpuEvaluator::eval_mod_high_precision: polynomial combine plan is not topologically valid");
                }
                if (remainder_is_inline_leaf &&
                    !node_available[combine.remainder_node] &&
                    multiply_inline_leaf_relinearize_rescale(
                        workspace.eval_mod_nodes[combine.quotient_node],
                        workspace.eval_mod_basis[combine.basis_degree],
                        polynomial_blocks[combine.remainder_node],
                        combine.output_scale,
                        workspace.eval_mod_nodes[combine.output_node]))
                {
                    node_available[combine.output_node] = true;
                    continue;
                }
                if (!node_available[combine.remainder_node])
                {
                    evaluate_term_block(
                        polynomial_blocks[combine.remainder_node].terms,
                        polynomial_blocks[combine.remainder_node].rescale_count,
                        polynomial_blocks[combine.remainder_node].output_scale,
                        polynomial_blocks[combine.remainder_node].output_q_count,
                        workspace.eval_mod_nodes[combine.remainder_node]);
                    node_available[combine.remainder_node] = true;
                }
                if (bootstrap_data.eval_mod.dynamic_rescale)
                {
                    if (lazy_relinearization)
                    {
                        if (!node_available[combine.quotient_node] ||
                            !node_available[combine.remainder_node])
                        {
                            throw std::invalid_argument(
                                "GpuEvaluator::eval_mod_high_precision: lazy combine input is unavailable");
                        }
                        if (combine.output_q_count == 0 ||
                            combine.product_q_count == 0 ||
                            combine.output_q_count != combine.product_q_count ||
                            !(combine.product_scale > 0.0) ||
                            !std::isfinite(combine.product_scale))
                        {
                            throw std::invalid_argument(
                                "GpuEvaluator::eval_mod_high_precision: unsupported lazy dynamic combine plan");
                        }

                        const GpuCiphertextData *quotient =
                            &workspace.eval_mod_nodes[combine.quotient_node];
                        GpuCiphertextData *quotient_mutable =
                            zero_copy_moddrop &&
                                    combine.quotient_node < node_use_counts.size() &&
                                    node_use_counts[combine.quotient_node] == 1
                                ? &workspace.eval_mod_nodes[combine.quotient_node]
                                : nullptr;
                        if (quotient->size() != 2)
                        {
                            throw std::invalid_argument(
                                "GpuEvaluator::eval_mod_high_precision: lazy quotient must be relinearized");
                        }
                        if (combine.quotient_rescale_count > 0)
                        {
                            rescale_many(
                                *quotient,
                                workspace.scratch2,
                                combine.quotient_rescale_count);
                            workspace.scratch2.meta.scale =
                                combine.quotient_output_scale;
                            quotient = &workspace.scratch2;
                            quotient_mutable = &workspace.scratch2;
                        }

                        const GpuCiphertextData *basis =
                            &workspace.eval_mod_basis[combine.basis_degree];
                        GpuCiphertextData *basis_mutable =
                            zero_copy_moddrop &&
                                    combine.basis_degree < basis_last_combine_use.size() &&
                                    basis_last_combine_use[combine.basis_degree] == combine_index
                                ? &workspace.eval_mod_basis[combine.basis_degree]
                                : nullptr;
                        bool use_combine_prefix_multiply = false;
                        parms_id_type combine_prefix_parms_id = parms_id_zero;
                        if (!(quotient->meta.parms_id == basis->meta.parms_id))
                        {
                            if (quotient->meta.q_count == basis->meta.q_count)
                            {
                                throw std::invalid_argument(
                                    "GpuEvaluator::eval_mod_high_precision: lazy combine equal q_count has different parms_id");
                            }
                            combine_prefix_parms_id =
                                quotient->meta.q_count < basis->meta.q_count
                                    ? quotient->meta.parms_id
                                    : basis->meta.parms_id;
                            use_combine_prefix_multiply =
                                supports_q_prefix_multiply(
                                    *quotient,
                                    *basis,
                                    combine_prefix_parms_id);
                            if (!use_combine_prefix_multiply &&
                                quotient->meta.q_count > basis->meta.q_count)
                            {
                                if (quotient_mutable == nullptr ||
                                    !drop_modulus_inplace(
                                        *quotient_mutable,
                                        basis->meta.parms_id))
                                {
                                    drop_modulus(
                                        *quotient,
                                        workspace.scratch3,
                                        basis->meta.parms_id);
                                    quotient = &workspace.scratch3;
                                    quotient_mutable = &workspace.scratch3;
                                }
                            }
                            else if (!use_combine_prefix_multiply)
                            {
                                if (basis_mutable == nullptr ||
                                    !drop_modulus_inplace(
                                        *basis_mutable,
                                        quotient->meta.parms_id))
                                {
                                    drop_modulus(
                                        *basis,
                                        workspace.scratch4,
                                        quotient->meta.parms_id);
                                    basis = &workspace.scratch4;
                                    basis_mutable = &workspace.scratch4;
                                }
                            }
                        }

                        const bool is_square =
                            !use_combine_prefix_multiply && quotient == basis;
                        const std::size_t multiply_q_count =
                            use_combine_prefix_multiply
                                ? params_.get_level(combine_prefix_parms_id).q_count
                                : quotient->meta.q_count;
                        if (workspace.capture_eval_mod_stage_timing)
                        {
                            multiply_recorder.begin(
                                "EvalMod.mul.combine.lazy." +
                                    std::to_string(combine_index) +
                                    ".T" + std::to_string(combine.basis_degree) +
                                    ".q" + std::to_string(multiply_q_count),
                                multiply_q_count,
                                relin_keys.meta.p_count,
                                is_square);
                        }
                        if (use_combine_prefix_multiply)
                        {
                            multiply_q_prefix(
                                *quotient,
                                *basis,
                                combine_prefix_parms_id,
                                workspace.scratch5);
                        }
                        else if (is_square)
                        {
                            square(*quotient, workspace.scratch5);
                        }
                        else
                        {
                            multiply(*quotient, *basis, workspace.scratch5);
                        }
                        workspace.scratch5.meta.scale = combine.product_scale;

                        GpuCiphertextData product_scaled;
                        const GpuCiphertextData *product = &workspace.scratch5;
                        GpuCiphertextData *product_mutable = &workspace.scratch5;
                        if (!combine.product_scale_plaintext.empty())
                        {
                            multiply_plain(
                                *product,
                                combine.product_scale_plaintext,
                                product_scaled);
                            product_scaled.meta.scale =
                                combine.product_aligned_scale;
                            product = &product_scaled;
                            product_mutable = &product_scaled;
                        }

                        const GpuCiphertextData *remainder =
                            &workspace.eval_mod_nodes[combine.remainder_node];
                        GpuCiphertextData *remainder_mutable =
                            zero_copy_moddrop &&
                                    combine.remainder_node < node_use_counts.size() &&
                                    node_use_counts[combine.remainder_node] == 1
                                ? &workspace.eval_mod_nodes[combine.remainder_node]
                                : nullptr;
                        GpuCiphertextData remainder_rescaled;
                        GpuCiphertextData remainder_scaled;
                        GpuCiphertextData product_dropped;
                        GpuCiphertextData remainder_dropped;

                        if (combine.remainder_rescale_count > 0)
                        {
                            rescale_many(
                                *remainder,
                                remainder_rescaled,
                                combine.remainder_rescale_count);
                            if (combine.remainder_scale_plaintext.empty() &&
                                combine.remainder_aligned_scale > 0.0)
                            {
                                remainder_rescaled.meta.scale =
                                    combine.remainder_aligned_scale;
                            }
                            remainder = &remainder_rescaled;
                            remainder_mutable = &remainder_rescaled;
                        }
                        if (!combine.remainder_scale_plaintext.empty())
                        {
                            multiply_plain(
                                *remainder,
                                combine.remainder_scale_plaintext,
                                remainder_scaled);
                            remainder_scaled.meta.scale =
                                combine.remainder_aligned_scale;
                            remainder = &remainder_scaled;
                            remainder_mutable = &remainder_scaled;
                        }

                        if (!(product->meta.parms_id == remainder->meta.parms_id))
                        {
                            if (product->meta.q_count == remainder->meta.q_count)
                            {
                                throw std::invalid_argument(
                                    "GpuEvaluator::eval_mod_high_precision: lazy remainder equal q_count has different parms_id");
                            }
                            if (product->meta.q_count > remainder->meta.q_count)
                            {
                                if (product_mutable == nullptr ||
                                    !drop_modulus_inplace(
                                        *product_mutable,
                                        remainder->meta.parms_id))
                                {
                                    drop_modulus(
                                        *product,
                                        product_dropped,
                                        remainder->meta.parms_id);
                                    product_dropped.meta.scale = product->meta.scale;
                                    product = &product_dropped;
                                    product_mutable = &product_dropped;
                                }
                            }
                else
                            {
                                if (remainder_mutable == nullptr ||
                                    !drop_modulus_inplace(
                                        *remainder_mutable,
                                        product->meta.parms_id))
                                {
                                    drop_modulus(
                                        *remainder,
                                        remainder_dropped,
                                        product->meta.parms_id);
                                    remainder_dropped.meta.scale = remainder->meta.scale;
                                    remainder = &remainder_dropped;
                                    remainder_mutable = &remainder_dropped;
                                }
                            }
                        }

                        GpuCiphertextData combined_raw;
                        add(*product, *remainder, combined_raw);
                        combined_raw.meta.scale = combine.output_scale;
                        if (combined_raw.size() != 3)
                        {
                            throw std::invalid_argument(
                                "GpuEvaluator::eval_mod_high_precision: lazy combine did not produce size-3 output");
                        }

                        const bool defer_output =
                            combine.output_node < lazy_raw_output.size() &&
                            lazy_raw_output[combine.output_node];
                        if (defer_output)
                        {
                            workspace.eval_mod_nodes[combine.output_node] =
                                std::move(combined_raw);
                        }
                        else
                        {
                            relinearize(
                                combined_raw,
                                relin_keys,
                                workspace.eval_mod_nodes[combine.output_node]);
                            workspace.eval_mod_nodes[combine.output_node].meta.scale =
                                combine.output_scale;
                        }
                        multiply_recorder.end();
                        node_available[combine.output_node] = true;
                        if (workspace.capture_eval_mod_trace)
                        {
                            const GpuCiphertextData *trace_source =
                                &workspace.eval_mod_nodes[combine.output_node];
                            GpuCiphertextData trace_relinearized;
                            if (trace_source->size() == 3)
                            {
                                relinearize(
                                    *trace_source,
                                    relin_keys,
                                    trace_relinearized);
                                trace_relinearized.meta.scale =
                                    trace_source->meta.scale;
                                trace_source = &trace_relinearized;
                            }
                            workspace.eval_mod_trace_polynomial_combine_outputs.emplace_back();
                            copy_ciphertext_data(
                                *trace_source,
                                workspace.eval_mod_trace_polynomial_combine_outputs.back(),
                                "GpuEvaluator::eval_mod_high_precision trace lazy combine copy");
                            workspace.eval_mod_trace_polynomial_combine_outputs.back().meta.scale =
                                trace_source->meta.scale;
                        }
                        continue;
                    }
                    if (!node_available[combine.quotient_node])
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: dynamic combine quotient is unavailable");
                    }
                    if (combine.output_q_count == 0 ||
                        combine.product_q_count == 0 ||
                        !(combine.product_scale > 0.0) ||
                        !std::isfinite(combine.product_scale))
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: incomplete dynamic combine plan");
                    }

                    const GpuCiphertextData *quotient =
                        &workspace.eval_mod_nodes[combine.quotient_node];
                    if (combine.quotient_rescale_count > 0)
                    {
                        rescale_many(
                            *quotient,
                            workspace.scratch2,
                            combine.quotient_rescale_count);
                        workspace.scratch2.meta.scale =
                            combine.quotient_output_scale;
                        quotient = &workspace.scratch2;
                    }

                    const GpuCiphertextData *basis =
                        &workspace.eval_mod_basis[combine.basis_degree];
                    if (!(quotient->meta.parms_id == basis->meta.parms_id))
                    {
                        if (quotient->meta.q_count == basis->meta.q_count)
                        {
                            throw std::invalid_argument(
                                "GpuEvaluator::eval_mod_high_precision: dynamic combine equal q_count has different parms_id");
                        }
                        if (quotient->meta.q_count > basis->meta.q_count)
                        {
                            drop_modulus(
                                *quotient,
                                workspace.scratch3,
                                basis->meta.parms_id);
                            quotient = &workspace.scratch3;
                        }
                        else
                        {
                            drop_modulus(
                                *basis,
                                workspace.scratch4,
                                quotient->meta.parms_id);
                            basis = &workspace.scratch4;
                        }
                    }

                    const bool is_square = quotient == basis;
                    if (workspace.capture_eval_mod_stage_timing)
                    {
                        multiply_recorder.begin(
                            "EvalMod.mul.combine." +
                                std::to_string(combine_index) +
                                ".T" + std::to_string(combine.basis_degree) +
                                ".q" + std::to_string(quotient->meta.q_count),
                            quotient->meta.q_count,
                            relin_keys.meta.p_count,
                            is_square);
                    }
                    if (is_square)
                    {
                        square(*quotient, workspace.scratch5);
                    }
                    else
                    {
                        multiply(*quotient, *basis, workspace.scratch5);
                    }
                    relinearize(workspace.scratch5, relin_keys, workspace.scratch1);
                    multiply_recorder.end();
                    workspace.scratch1.meta.scale = combine.product_scale;

                    GpuCiphertextData product_scaled;
                    const GpuCiphertextData *product_base = &workspace.scratch1;
                    if (!combine.product_scale_plaintext.empty())
                    {
                        multiply_plain(
                            *product_base,
                            combine.product_scale_plaintext,
                            product_scaled);
                        product_scaled.meta.scale =
                            combine.product_aligned_scale;
                        product_base = &product_scaled;
                    }

                    if (node_available[combine.remainder_node])
                    {
                        const GpuCiphertextData *product = product_base;
                        const GpuCiphertextData *remainder =
                            &workspace.eval_mod_nodes[combine.remainder_node];
                        GpuCiphertextData remainder_rescaled;
                        GpuCiphertextData remainder_scaled;
                        GpuCiphertextData product_dropped;
                        GpuCiphertextData remainder_dropped;

                        if (combine.remainder_rescale_count > 0)
                        {
                            rescale_many(
                                *remainder,
                                remainder_rescaled,
                                combine.remainder_rescale_count);
                            if (combine.remainder_scale_plaintext.empty() &&
                                combine.remainder_aligned_scale > 0.0)
                            {
                                // The setup planner treats nearby CKKS scales as
                                // add-compatible, matching the CPU evaluator.  GPU
                                // add is intentionally strict, so preserve the
                                // same represented value while canonicalizing the
                                // metadata to the planner's common add scale.
                                remainder_rescaled.meta.scale =
                                    combine.remainder_aligned_scale;
                            }
                            remainder = &remainder_rescaled;
                        }
                        if (!combine.remainder_scale_plaintext.empty())
                        {
                            multiply_plain(
                                *remainder,
                                combine.remainder_scale_plaintext,
                                remainder_scaled);
                            remainder_scaled.meta.scale =
                                combine.remainder_aligned_scale;
                            remainder = &remainder_scaled;
                        }

                        if (!(product->meta.parms_id == remainder->meta.parms_id))
                        {
                            if (product->meta.q_count == remainder->meta.q_count)
                            {
                                throw std::invalid_argument(
                                    "GpuEvaluator::eval_mod_high_precision: dynamic remainder equal q_count has different parms_id");
                            }
                            if (product->meta.q_count > remainder->meta.q_count)
                            {
                                drop_modulus(
                                    *product,
                                    product_dropped,
                                    remainder->meta.parms_id);
                                product_dropped.meta.scale =
                                    product->meta.scale;
                                product = &product_dropped;
                            }
                else
                            {
                                drop_modulus(
                                    *remainder,
                                    remainder_dropped,
                                    product->meta.parms_id);
                                remainder_dropped.meta.scale =
                                    remainder->meta.scale;
                                remainder = &remainder_dropped;
                            }
                        }

                        add(*product, *remainder, workspace.scratch0);
                        workspace.scratch0.meta.scale = combine.output_scale;
                        workspace.eval_mod_nodes[combine.output_node] =
                            std::move(workspace.scratch0);
                    }
                    else
                    {
                        if (product_base == &product_scaled)
                        {
                            workspace.eval_mod_nodes[combine.output_node] =
                                std::move(product_scaled);
                        }
                        else
                        {
                            workspace.eval_mod_nodes[combine.output_node] =
                                std::move(workspace.scratch1);
                        }
                        workspace.eval_mod_nodes[combine.output_node].meta.scale =
                            combine.output_scale;
                    }

                    if (workspace.eval_mod_nodes[combine.output_node].meta.q_count >
                        combine.output_q_count)
                    {
                        const auto &target_level =
                            params_.get_level_by_q_count(combine.output_q_count, 0);
                        drop_modulus(
                            workspace.eval_mod_nodes[combine.output_node],
                            workspace.scratch2,
                            target_level.parms_id);
                        workspace.eval_mod_nodes[combine.output_node] =
                            std::move(workspace.scratch2);
                        workspace.eval_mod_nodes[combine.output_node].meta.scale =
                            combine.output_scale;
                    }
                }
                else
                {
                    if (workspace.capture_eval_mod_stage_timing)
                    {
                        const auto &quotient =
                            workspace.eval_mod_nodes[combine.quotient_node];
                        const auto &basis =
                            workspace.eval_mod_basis[combine.basis_degree];
                        multiply_recorder.begin(
                            "EvalMod.mul.combine." +
                                std::to_string(combine_index) +
                                ".T" + std::to_string(combine.basis_degree) +
                                ".q" + std::to_string(
                                    std::min(
                                        quotient.meta.q_count,
                                        basis.meta.q_count)),
                            std::min(
                                quotient.meta.q_count,
                                basis.meta.q_count),
                            relin_keys.meta.p_count,
                            &quotient == &basis);
                    }
                    multiply_relinearize_rescale(
                        workspace.eval_mod_nodes[combine.quotient_node],
                        workspace.eval_mod_basis[combine.basis_degree],
                        combine.output_scale,
                        logical_rescale_count,
                        workspace.scratch2);
                    multiply_recorder.end();
                    add_aligned(
                        workspace.scratch2,
                        workspace.eval_mod_nodes[combine.remainder_node],
                        combine.output_scale,
                        workspace.eval_mod_nodes[combine.output_node]);
                }
                node_available[combine.output_node] = true;
                if (workspace.capture_eval_mod_trace)
                {
                    workspace.eval_mod_trace_polynomial_combine_outputs.emplace_back();
                    copy_ciphertext_data(
                        workspace.eval_mod_nodes[combine.output_node],
                        workspace.eval_mod_trace_polynomial_combine_outputs.back(),
                        "GpuEvaluator::eval_mod_high_precision trace combine copy");
                    workspace.eval_mod_trace_polynomial_combine_outputs.back().meta.scale =
                        workspace.eval_mod_nodes[combine.output_node].meta.scale;
                }
            }

            const auto result_node =
                bootstrap_data.eval_mod.polynomial_result_node;
            if (!node_available[result_node])
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: polynomial result node is unavailable");
            }
            if (workspace.capture_eval_mod_trace)
            {
                copy_ciphertext_data(
                    workspace.eval_mod_nodes[result_node],
                    accumulator,
                    "GpuEvaluator::eval_mod_high_precision trace accumulator copy");
                accumulator.meta.scale =
                    workspace.eval_mod_nodes[result_node].meta.scale;
            }
            else
            {
                accumulator = std::move(workspace.eval_mod_nodes[result_node]);
            }
            if (bootstrap_data.eval_mod.dynamic_rescale)
            {
                const auto final_rescale_count =
                    bootstrap_data.eval_mod.polynomial_final_rescale_count;
                if (final_rescale_count > 0 && d2d_free_dataflow)
                {
                    rescale_many(
                        accumulator,
                        accumulator,
                        final_rescale_count);
                }
                else if (final_rescale_count > 0)
                {
                    rescale_many(
                        accumulator,
                        workspace.scratch2,
                        final_rescale_count);
                    accumulator = std::move(workspace.scratch2);
                }
                if (bootstrap_data.eval_mod.polynomial_output_scale > 0.0)
                {
                    accumulator.meta.scale =
                        bootstrap_data.eval_mod.polynomial_output_scale;
                }
            }
        }
    }
    stage_recorder.record(4);

    if (workspace.capture_eval_mod_trace)
    {
        copy_ciphertext_data(
            accumulator,
            workspace.eval_mod_trace_polynomial_output,
            "GpuEvaluator::eval_mod_high_precision trace polynomial copy");
        workspace.eval_mod_trace_polynomial_output.meta.scale =
            accumulator.meta.scale;
    }

    {
        NvtxRange range("EvalMod double-angle iterations");
        for (std::size_t double_angle_index = 0;
             double_angle_index < configured_double_angle_constants.size();
             ++double_angle_index)
        {
            const auto &double_angle_plaintext =
                configured_double_angle_constants[double_angle_index];
            const std::uint32_t double_angle_rescale_count =
                double_angle_index < configured_double_angle_rescale_counts.size()
                    ? std::max(
                          configured_double_angle_rescale_counts[double_angle_index],
                          std::uint32_t{1})
                    : logical_rescale_count;
            if (workspace.capture_eval_mod_stage_timing)
            {
                multiply_recorder.begin(
                    "EvalMod.mul.double_angle." +
                        std::to_string(double_angle_index) +
                        ".q" + std::to_string(accumulator.meta.q_count),
                    accumulator.meta.q_count,
                    relin_keys.meta.p_count,
                    true);
            }
            square(accumulator, workspace.scratch5);
            if (workspace.capture_eval_mod_trace)
            {
                workspace.eval_mod_trace_double_angle_square_outputs.emplace_back();
                copy_ciphertext_data(
                    workspace.scratch5,
                    workspace.eval_mod_trace_double_angle_square_outputs.back(),
                    "GpuEvaluator::eval_mod_high_precision trace square copy");
                workspace.eval_mod_trace_double_angle_square_outputs.back().meta.scale =
                    workspace.scratch5.meta.scale;
            }
            if (bootstrap_data.eval_mod.dynamic_rescale)
            {
                relinearize(workspace.scratch5, relin_keys, workspace.scratch2);
                multiply_recorder.end();
                if (workspace.capture_eval_mod_trace)
                {
                    workspace.eval_mod_trace_double_angle_relin_outputs.emplace_back();
                    copy_ciphertext_data(
                        workspace.scratch2,
                        workspace.eval_mod_trace_double_angle_relin_outputs.back(),
                        "GpuEvaluator::eval_mod_high_precision trace relin copy");
                    workspace.eval_mod_trace_double_angle_relin_outputs.back().meta.scale =
                        workspace.scratch2.meta.scale;
                }
                add(workspace.scratch2, workspace.scratch2, workspace.scratch3);
                const GpuCiphertextData *pre_rescale_double_angle =
                    &workspace.scratch3;
                if (!double_angle_plaintext.empty())
                {
                    if (!(workspace.scratch3.meta.parms_id ==
                          double_angle_plaintext.meta.parms_id))
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: dynamic "
                            "double-angle plaintext level mismatch at step " +
                            std::to_string(double_angle_index) +
                            " (cipher q=" +
                            std::to_string(workspace.scratch3.meta.q_count) +
                            ", plaintext q=" +
                            std::to_string(double_angle_plaintext.meta.q_count) +
                            ")");
                    }
                    add_plain_inplace(
                        workspace.scratch3,
                        double_angle_plaintext,
                        "GpuEvaluator::eval_mod_high_precision dynamic double-angle constant");
                }
                if (double_angle_rescale_count > 0)
                {
                    rescale_many(
                        *pre_rescale_double_angle,
                        workspace.scratch5,
                        double_angle_rescale_count);
                    accumulator = std::move(workspace.scratch5);
                }
                else
                {
                    if (d2d_free_dataflow)
                    {
                        accumulator = std::move(workspace.scratch3);
                    }
                    else
                    {
                        copy_ciphertext_data(
                            *pre_rescale_double_angle,
                            accumulator,
                            "GpuEvaluator::eval_mod_high_precision double-angle no-rescale copy");
                    }
                }
                if (workspace.capture_eval_mod_trace)
                {
                    workspace.eval_mod_trace_double_angle_rescaled_square_outputs.emplace_back();
                    copy_ciphertext_data(
                        accumulator,
                        workspace.eval_mod_trace_double_angle_rescaled_square_outputs.back(),
                        "GpuEvaluator::eval_mod_high_precision trace rescaled double-angle copy");
                    workspace.eval_mod_trace_double_angle_rescaled_square_outputs.back().meta.scale =
                        accumulator.meta.scale;
                }
            }
            else if (double_angle_rescale_count == 2 &&
                     use_rescale_x2() &&
                     use_relinearize_rescale_x2())
            {
                add(workspace.scratch5, workspace.scratch5, workspace.scratch3);
                if (!double_angle_plaintext.empty())
                {
                    if (!(workspace.scratch3.meta.parms_id ==
                          double_angle_plaintext.meta.parms_id))
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: double-angle plaintext level mismatch");
                    }
                    add_plain_inplace(
                        workspace.scratch3,
                        double_angle_plaintext,
                        "GpuEvaluator::eval_mod_high_precision double-angle constant");
                    relinearize_rescale_x2_hybrid(
                        workspace.scratch3,
                        relin_keys,
                        workspace.scratch5);
                }
                else
                {
                    relinearize_rescale_x2_hybrid(
                        workspace.scratch3,
                        relin_keys,
                        workspace.scratch5);
                }
                multiply_recorder.end();
            }
            else
            {
                relinearize(workspace.scratch5, relin_keys, workspace.scratch2);
                multiply_recorder.end();
                add(workspace.scratch2, workspace.scratch2, workspace.scratch3);

                if (!double_angle_plaintext.empty())
                {
                    if (!(workspace.scratch3.meta.parms_id ==
                          double_angle_plaintext.meta.parms_id))
                    {
                        throw std::invalid_argument(
                            "GpuEvaluator::eval_mod_high_precision: double-angle plaintext level mismatch");
                    }
                    add_plain_inplace(
                        workspace.scratch3,
                        double_angle_plaintext,
                        "GpuEvaluator::eval_mod_high_precision fallback double-angle constant");
                    rescale_many(
                        workspace.scratch3,
                        workspace.scratch5,
                        double_angle_rescale_count);
                }
                else
                {
                    rescale_many(
                        workspace.scratch3,
                        workspace.scratch5,
                        double_angle_rescale_count);
                }
            }
            if (!bootstrap_data.eval_mod.dynamic_rescale)
            {
                accumulator = std::move(workspace.scratch5);
            }
            if (workspace.capture_eval_mod_trace)
            {
                workspace.eval_mod_trace_double_angle_outputs.emplace_back();
                copy_ciphertext_data(
                    accumulator,
                    workspace.eval_mod_trace_double_angle_outputs.back(),
                    "GpuEvaluator::eval_mod_high_precision trace double-angle copy");
                workspace.eval_mod_trace_double_angle_outputs.back().meta.scale =
                    accumulator.meta.scale;
            }
        }
    }
    stage_recorder.record(5);

    /*
     * The CPU high-precision evaluator may finish at a lower Q prefix because
     * its recursive evaluator performs additional level alignment. Setup can
     * record that observable output parms_id without moving the recursive
     * control flow into the GPU hot path. Dropping a Q suffix is a contiguous,
     * coefficient-parallel operation and preserves the evaluated CKKS value.
     */
    {
        NvtxRange range("EvalMod output level alignment");
        if (bootstrap_data.eval_mod.output_parms_id != parms_id_zero &&
            accumulator.meta.parms_id != bootstrap_data.eval_mod.output_parms_id)
        {
            if (accumulator.meta.q_count < bootstrap_data.eval_mod.output_q_count)
            {
                throw std::invalid_argument(
                    "GpuEvaluator::eval_mod_high_precision: GPU polynomial schedule ended below the configured CPU output level");
            }
            if (!q_prefix_views ||
                !drop_modulus_inplace(
                    accumulator,
                    bootstrap_data.eval_mod.output_parms_id))
            {
                drop_modulus(
                    accumulator,
                    workspace.scratch2,
                    bootstrap_data.eval_mod.output_parms_id);
                accumulator = std::move(workspace.scratch2);
            }
        }
        if (bootstrap_data.eval_mod.output_scale > 0.0)
        {
            accumulator.meta.scale = bootstrap_data.eval_mod.output_scale;
        }

        destination_ciphertext = std::move(accumulator);
    }
    stage_recorder.finish(workspace.eval_mod_stage_timing);
    multiply_recorder.finish(workspace.eval_mod_multiply_timings);
}

}  // namespace gpu
}  // namespace poseidon
