#include "poseidon/gpu/gpu_keyswitch_handler.h"
#include "poseidon/gpu/kernels/gpu_double_hoist_kernels.h"
#include "poseidon/gpu/kernels/gpu_keyswitch_kernels.h"
#include "poseidon/gpu/kernels/gpu_ntt_kernels.h"
#include "poseidon/gpu/kernels/gpu_rescale_kernels.h"
#include "poseidon/gpu/gpu_opt_flags.h"

#include <nvtx3/nvToolsExt.h>

#include <algorithm>
#include <cstdlib>
#include <limits>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace poseidon
{
namespace gpu
{
namespace
{

constexpr std::size_t kRelinKeyPower2Index = 0;
constexpr std::size_t kSwitchKeyComponentCount = 2;
constexpr const char *kFuseDecompQEnv =
    "POSEIDON_KEYSWITCH_FUSE_DECOMP_Q";
constexpr const char *kFuseModupNttHeadEnv =
    "POSEIDON_KEYSWITCH_FUSE_MODUP_NTT_HEAD";
constexpr const char *kBconvRowTiledEnv =
    "POSEIDON_KEYSWITCH_BCONV_ROW_TILED";
constexpr const char *kBconvRowTiled8Env =
    "POSEIDON_KEYSWITCH_BCONV_ROW_TILED_8";
constexpr const char *kPToQRowTiled8Env =
    "POSEIDON_KEYSWITCH_P_TO_Q_ROW_TILED_8";
constexpr const char *kP9PreweightPEnv =
    "POSEIDON_KEYSWITCH_P9_PREWEIGHT_P";
constexpr const char *kP9PToQRowTiled8Env =
    "POSEIDON_KEYSWITCH_P9_P_TO_Q_ROW_TILED_8";
constexpr const char *kP9FourstepPInttEnv =
    "POSEIDON_KEYSWITCH_P9_FOURSTEP_P_INTT";
constexpr const char *kP9FourstepQpEnv =
    "POSEIDON_KEYSWITCH_P9_FOURSTEP_QP";
constexpr const char *kP9PToQFourstepEnv =
    "POSEIDON_KEYSWITCH_P9_P_TO_Q_FOURSTEP";
constexpr const char *kDoubleHoistP9ModupRowTiled8Env =
    "POSEIDON_DOUBLE_HOIST_P9_MODUP_ROW_TILED_8";
constexpr const char *kDoubleHoistP9PreweightPEnv =
    "POSEIDON_DOUBLE_HOIST_P9_PREWEIGHT_P";
constexpr const char *kDoubleHoistP9PToQRowTiled8Env =
    "POSEIDON_DOUBLE_HOIST_P9_P_TO_Q_ROW_TILED_8";
constexpr const char *kDoubleHoistP9QpFourstepEnv =
    "POSEIDON_DOUBLE_HOIST_P9_QP_FOURSTEP";
constexpr const char *kDoubleHoistP9PToQFourstepEnv =
    "POSEIDON_DOUBLE_HOIST_P9_P_TO_Q_FOURSTEP";
constexpr const char *kP9ModupFourstepPhase1FusedEnv =
    "POSEIDON_P9_MODUP_FOURSTEP_PHASE1_FUSED";
constexpr const char *kP9ModupFourstepCompactPreweightEnv =
    "POSEIDON_P9_MODUP_FOURSTEP_COMPACT_PREWEIGHT";
constexpr const char *kP9ModupFourstepGroupedTargetsEnv =
    "POSEIDON_P9_MODUP_FOURSTEP_GROUPED_TARGETS";
constexpr const char *kFourstepC2InttEnv =
    "POSEIDON_KEYSWITCH_FOURSTEP_C2_INTT";
constexpr const char *kFourstepAllNttEnv =
    "POSEIDON_KEYSWITCH_FOURSTEP_ALL_NTT";
constexpr const char *kFourstepPhase2MacEnv =
    "POSEIDON_KEYSWITCH_FOURSTEP_PHASE2_MAC";
constexpr const char *kFourstepFinalizeFusedEnv =
    "POSEIDON_KEYSWITCH_FOURSTEP_FINALIZE_FUSED";
constexpr const char *kPersistentRelinearizeEnv =
    "POSEIDON_KEYSWITCH_PERSISTENT_RELIN";

class NvtxRange
{
public:
    explicit NvtxRange(std::string name)
        : name_(std::move(name))
    {
        nvtxRangePushA(name_.c_str());
    }

    NvtxRange(const NvtxRange &) = delete;
    NvtxRange &operator=(const NvtxRange &) = delete;

    ~NvtxRange()
    {
        nvtxRangePop();
    }

private:
    std::string name_;
};

std::size_t checked_mul(std::size_t a, std::size_t b, const char *what)
{
    if (a != 0 && b > std::numeric_limits<std::size_t>::max() / a)
    {
        throw std::overflow_error(what);
    }
    return a * b;
}

bool use_fused_decomp_q()
{
    const char *raw = std::getenv(kFuseDecompQEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_persistent_relinearize()
{
    const char *raw = std::getenv(kPersistentRelinearizeEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_fused_modup_ntt_head()
{
    const char *raw = std::getenv(kFuseModupNttHeadEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_bconv_row_tiled()
{
    const char *raw = std::getenv(kBconvRowTiledEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return false;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_bconv_row_tiled8()
{
    const char *raw = std::getenv(kBconvRowTiled8Env);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p_to_q_row_tiled8()
{
    const char *raw = std::getenv(kPToQRowTiled8Env);
    if (raw == nullptr || *raw == '\0')
    {
        return false;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p9_preweight_p(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kP9PreweightPEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p9_p_to_q_row_tiled8(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kP9PToQRowTiled8Env);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p9_fourstep_p_intt(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kP9FourstepPInttEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p9_fourstep_qp(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9)
    {
        return false;
    }

    const char *raw = std::getenv(kP9FourstepQpEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

// Monolithic KeySwitch: the two-phase QP NTT (+ fused key MAC) for any
// special-prime count at N=65536 (POSEIDON_GPU_QP_FOURSTEP_ANY_P=0 keeps
// P!=9 on the stage-by-stage path).
bool use_fourstep_qp_any_p(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (base_p_size == 9)
    {
        return use_p9_fourstep_qp(degree, base_p_size);
    }
    if (degree != 65536 || base_p_size == 0)
    {
        return false;
    }
    static const bool any_p = [] {
        const char *raw = std::getenv("POSEIDON_GPU_QP_FOURSTEP_ANY_P");
        return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
    }();
    return any_p;
}

bool use_p9_p_to_q_fourstep(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kP9PToQFourstepEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_p9_modup_row_tiled8(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kDoubleHoistP9ModupRowTiled8Env);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_p9_preweight_p(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kDoubleHoistP9PreweightPEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_p9_p_to_q_row_tiled8(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kDoubleHoistP9PToQRowTiled8Env);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_p9_qp_fourstep(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size == 0)
    {
        return false;
    }
    if (base_p_size != 9)
    {
        // The two-phase QP NTT is generic in the limb counts; the P=9-only
        // kernels around it keep their own P=9 gates. Other special-prime
        // counts (e.g. Q50/P25) used the stage-by-stage NTT.
        // POSEIDON_GPU_QP_FOURSTEP_ANY_P=0 restores that.
        static const bool any_p = [] {
            const char *raw = std::getenv("POSEIDON_GPU_QP_FOURSTEP_ANY_P");
            return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
        }();
        return any_p;
    }

    const char *raw = std::getenv(kDoubleHoistP9QpFourstepEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_double_hoist_p9_p_to_q_fourstep(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9 || opt_flag(OptFlag::UnifyP9))
    {
        return false;
    }

    const char *raw = std::getenv(kDoubleHoistP9PToQFourstepEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p9_modup_fourstep_phase1_fused(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9)
    {
        return false;
    }

    const char *raw = std::getenv(kP9ModupFourstepPhase1FusedEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return false;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_p9_modup_fourstep_compact_preweight(
    std::size_t degree,
    std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size != 9)
    {
        return false;
    }

    const char *raw = std::getenv(kP9ModupFourstepCompactPreweightEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return false;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

unsigned int p9_modup_fourstep_grouped_targets()
{
    const char *raw = std::getenv(kP9ModupFourstepGroupedTargetsEnv);
    if (raw == nullptr || *raw == '\0' || std::string(raw) == "0")
    {
        return 1;
    }
    const std::string value(raw);
    if (value == "1")
    {
        return 1;
    }
    if (value == "2")
    {
        return 2;
    }
    if (value == "4")
    {
        return 4;
    }
    throw std::invalid_argument(
        "POSEIDON_P9_MODUP_FOURSTEP_GROUPED_TARGETS must be 0, 1, 2, or 4");
}

/*
 * POSEIDON_OPT_PTOQ_PW: for a generic P basis (P > 9) the P-part INTT before
 * a P->Q conversion multiplies by N^{-1} * pHat^{-1} instead of N^{-1}, so the
 * conversion kernel no longer reweights every source residue once per Q tile.
 * Returns the table when that applies to this view, nullptr otherwise.
 */
bool batch_moddown_enabled()
{
    static const bool enabled = [] {
        const char *raw = std::getenv("POSEIDON_OPT_BATCH_MODDOWN");
        return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
    }();
    return enabled;
}

bool conv_batch_rotate_enabled()
{
    static const bool enabled = [] {
        const char *raw = std::getenv("POSEIDON_OPT_CONV_BATCH_ROTATE");
        return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
    }();
    return enabled;
}

const GpuWord *p_to_q_fold_table(
    const GpuPolyShardView &p_view,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    if (!opt_flag(OptFlag::PToQPreweight) || degree != 65536 ||
        parameter_shard.hybrid_base_p_count <= 2 ||
        (parameter_shard.hybrid_base_p_count == 9 && !opt_flag(OptFlag::UnifyP9)) ||
        p_view.limb_begin != parameter_shard.limb_begin + parameter_shard.hybrid_base_q_count ||
        p_view.limb_count != parameter_shard.hybrid_base_p_count)
    {
        return nullptr;
    }
    return kernel::hybrid_p_preweighted_inv_degree_table(parameter_shard);
}

// One P-part INTT; true when its output already carries the P->Q weights.
bool inverse_p_part_for_p_to_q(
    const GpuPolyShardView &destination,
    const GpuConstPolyShardView &source,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const GpuWord *table = p_to_q_fold_table(destination, parameter_shard, degree);
    if (table != nullptr &&
        kernel::launch_inverse_ntt_poly_shard_scaled_65536(
            destination, source, parameter_shard, degree, table))
    {
        return true;
    }
    kernel::launch_inverse_ntt_poly_shard(destination, source, parameter_shard, degree);
    return false;
}

// Both components of a P part; the fold applies to both or to neither.
bool inverse_p_parts_for_p_to_q(
    const GpuPolyShardView &destination0,
    const GpuConstPolyShardView &source0,
    const GpuPolyShardView &destination1,
    const GpuConstPolyShardView &source1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree)
{
    const GpuWord *table0 = p_to_q_fold_table(destination0, parameter_shard, degree);
    const GpuWord *table1 = p_to_q_fold_table(destination1, parameter_shard, degree);
    if (table0 != nullptr && table0 == table1 &&
        destination0.ptr != source0.ptr && destination1.ptr != source1.ptr &&
        destination0.device_id == parameter_shard.device_id &&
        destination1.device_id == parameter_shard.device_id &&
        parameter_shard.limb_begin == 0 &&
        parameter_shard.fourstep_intt_tables.size() >=
            (parameter_shard.hybrid_base_q_count + parameter_shard.hybrid_base_p_count) * degree)
    {
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            destination0.ptr,
            destination1.ptr,
            source0.ptr,
            source1.ptr,
            parameter_shard.hybrid_base_q_count,
            parameter_shard.hybrid_base_p_count,
            parameter_shard,
            table0);
        return true;
    }
    const bool first = inverse_p_part_for_p_to_q(destination0, source0, parameter_shard, degree);
    const bool second = inverse_p_part_for_p_to_q(destination1, source1, parameter_shard, degree);
    if (first != second)
    {
        throw std::logic_error("inverse_p_parts_for_p_to_q: P->Q weight fold applied to one component only");
    }
    return first;
}

void launch_double_hoist_p_to_q_forward_ntt(
    GpuWord *converted_q0,
    GpuWord *converted_q1,
    GpuWord *p_coeff0,
    GpuWord *p_coeff1,
    const GpuParameterShard &parameter_shard,
    std::size_t degree,
    bool source_preweighted = false)
{
    const std::size_t p_count = parameter_shard.hybrid_base_p_count;
    const bool p9_preweight = !source_preweighted &&
        use_double_hoist_p9_preweight_p(degree, p_count);
    const bool preweight = p9_preweight || source_preweighted;
    const bool row_tiled8 =
        use_double_hoist_p9_p_to_q_row_tiled8(degree, p_count);
    const bool fourstep =
        use_double_hoist_p9_p_to_q_fourstep(degree, p_count);

    if (p9_preweight)
    {
        NvtxRange range("double_hoist.moddown.preweight_p9");
        kernel::launch_hybrid_preweight_p_two_components(
            p_coeff0,
            p_coeff1,
            parameter_shard,
            degree);
    }

    if (fourstep)
    {
        NvtxRange range("double_hoist.moddown.p_to_q.fourstep_p9");
        kernel::launch_hybrid_convert_p9_to_q_forward_ntt_two_components_fourstep_65536(
            converted_q0,
            converted_q1,
            p_coeff0,
            p_coeff1,
            parameter_shard,
            degree,
            preweight);
    }
    else if (row_tiled8)
    {
        NvtxRange range("double_hoist.moddown.p_to_q.row_tiled8");
        kernel::launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8(
            converted_q0,
            converted_q1,
            p_coeff0,
            p_coeff1,
            parameter_shard,
            degree,
            preweight);
    }
    else
    {
        NvtxRange range("double_hoist.moddown.p_to_q.generic");
        kernel::launch_hybrid_convert_p_to_q_forward_ntt(
            converted_q0,
            converted_q1,
            p_coeff0,
            p_coeff1,
            parameter_shard,
            degree,
            preweight);
    }
}

bool use_fourstep_c2_intt()
{
    const char *raw = std::getenv(kFourstepC2InttEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return false;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

// Small special modulus (3 <= P <= 8; P=2 and P=9 have tuned paths): run the
// key-switch finalize as two-component launches, i.e. one P-side inverse NTT
// for c0 and c1 together, one lazy P->Q conversion and one in-place Q NTT for
// both components, instead of per-component INTTs and the stage-by-stage Q
// NTT. On by default; POSEIDON_GPU_SMALL_P_FOURSTEP=0 restores the
// per-component path.
bool use_small_p_fourstep(std::size_t degree, std::size_t base_p_size)
{
    if (degree != 65536 || base_p_size < 3 ||
        (base_p_size == 9 && !opt_flag(OptFlag::UnifyP9)) || base_p_size > 64)
    {
        return false;
    }
    static const bool enabled = [] {
        const char *raw = std::getenv("POSEIDON_GPU_SMALL_P_FOURSTEP");
        return raw == nullptr || *raw == '\0' || std::string(raw) != "0";
    }();
    return enabled;
}

bool use_fourstep_all_ntt(
    std::size_t degree,
    std::size_t base_q_size,
    std::size_t base_p_size)
{
    const bool supported =
        degree == 65536 &&
        base_p_size == 2 &&
        base_q_size >= 2 &&
        (base_q_size & 1U) == 0;
    if (!supported)
    {
        return false;
    }

    const char *raw = std::getenv(kFourstepAllNttEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_fourstep_phase2_mac()
{
    const char *raw = std::getenv(kFourstepPhase2MacEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool use_fourstep_finalize_fused()
{
    const char *raw = std::getenv(kFourstepFinalizeFusedEnv);
    if (raw == nullptr || *raw == '\0')
    {
        return true;
    }

    const std::string value(raw);
    return value != "0" &&
           value != "OFF" &&
           value != "off" &&
           value != "false" &&
           value != "FALSE";
}

bool same_shard_placement(
    const GpuConstPolyShardView &lhs,
    const GpuConstPolyShardView &rhs)
{
    return lhs.device_id == rhs.device_id &&
           lhs.limb_begin == rhs.limb_begin &&
           lhs.limb_count == rhs.limb_count &&
           lhs.coeff_begin == rhs.coeff_begin &&
           lhs.coeff_count == rhs.coeff_count;
}

bool same_shard_placement(
    const GpuPolyShardView &lhs,
    const GpuConstPolyShardView &rhs)
{
    return lhs.device_id == rhs.device_id &&
           lhs.limb_begin == rhs.limb_begin &&
           lhs.limb_count == rhs.limb_count &&
           lhs.coeff_begin == rhs.coeff_begin &&
           lhs.coeff_count == rhs.coeff_count;
}

const GpuConstRNSPolyView &find_key_poly(
    const GpuConstEvaluationKeyView &key_view,
    const GpuEvaluationKeyData &key_data,
    std::size_t key_index,
    std::size_t decomposition_index,
    std::size_t component_index)
{
    for (std::size_t i = 0; i < key_data.poly_metadata_.size(); ++i)
    {
        const auto &metadata = key_data.poly_metadata_[i];
        if (metadata.key_index == key_index &&
            metadata.decomposition_index == decomposition_index &&
            metadata.component_index == component_index)
        {
            if (metadata.poly_id >= key_view.polys.size())
            {
                throw std::out_of_range(
                    "GpuKeySwitchHandler: key poly metadata poly_id is out of range");
            }
            return key_view.polys[metadata.poly_id];
        }
    }

    throw std::invalid_argument(
        "GpuKeySwitchHandler: missing key-switch key polynomial");
}

struct HybridKeyComponentView
{
    int device_id = 0;
    const GpuWord *q_ptr = nullptr;
    const GpuWord *p_ptr = nullptr;
};

HybridKeyComponentView make_hybrid_key_component_view(
    const GpuConstRNSPolyView &poly,
    const GpuConstEvaluationKeyView &level_view,
    const GpuEvaluationKeyData &storage)
{
    if (poly.shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler: zero-copy key view requires one full shard");
    }
    if (level_view.storage_q_count != storage.meta.q_count ||
        level_view.meta.q_count == 0 ||
        level_view.meta.q_count > level_view.storage_q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler: invalid zero-copy key Q prefix metadata");
    }

    const auto &shard = poly.shards.front();
    if (shard.ptr == nullptr ||
        shard.limb_begin != 0 ||
        shard.limb_count != storage.meta.q_count + storage.meta.p_count ||
        shard.coeff_begin != 0 ||
        shard.coeff_count != storage.meta.degree)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler: key must retain one full [Q_storage | P] allocation");
    }

    HybridKeyComponentView result;
    result.device_id = shard.device_id;
    result.q_ptr = shard.ptr;
    result.p_ptr = shard.ptr + storage.meta.q_count * storage.meta.degree;
    return result;
}

const GpuParameterShard *find_parameter_shard(
    const GpuLevelInfo &level_info,
    const GpuConstPolyShardView &shard)
{
    for (const auto &candidate : level_info.shards)
    {
        const bool same_device = candidate.device_id == shard.device_id;
        const bool covers_limb =
            shard.limb_begin >= candidate.limb_begin &&
            shard.limb_begin + shard.limb_count <=
                candidate.limb_begin + candidate.limb_count;

        if (same_device && covers_limb)
        {
            return &candidate;
        }
    }

    return nullptr;
}

void copy_poly_shard(
    const char *name,
    const GpuPolyShardView &destination,
    const GpuConstPolyShardView &source)
{
    if (!same_shard_placement(destination, source))
    {
        throw std::invalid_argument(std::string(name) + ": shard placement mismatch");
    }

    const std::size_t word_count = checked_mul(
        destination.limb_count,
        destination.coeff_count,
        "GpuKeySwitchHandler copy word count overflow");
    gpu_check_cuda(cudaSetDevice(destination.device_id), name);
    gpu_check_cuda(
        cudaMemcpyAsync(
            destination.ptr,
            source.ptr,
            word_count * sizeof(GpuWord),
            cudaMemcpyDeviceToDevice,
            gpu_execution_stream()),
        name);
}

void copy_initial_components(
    GpuCiphertextView &destination,
    const GpuConstCiphertextView &source)
{
    for (std::size_t component = 0; component < destination.polys.size(); ++component)
    {
        copy_poly_shard(
            "GpuKeySwitchHandler::copy_initial_components",
            destination.polys[component].shards.front(),
            source.polys[component].shards.front());
    }
}

struct HybridScratch
{
    int device_id = 0;
    std::size_t degree = 0;
    std::size_t base_q_size = 0;
    std::size_t base_p_size = 0;
    std::size_t q_word_count = 0;
    std::size_t p_word_count = 0;
    // POSEIDON_OPT_MODUP_FOLD: c2_intt already carries the ModUp weights.
    bool c2_preweighted = false;

    DeviceVector<GpuWord> c2_intt;
    DeviceVector<GpuWord> modup_q;
    DeviceVector<GpuWord> modup_p;
    DeviceVector<GpuWord> accum_q0;
    DeviceVector<GpuWord> accum_q1;
    DeviceVector<GpuWord> accum_p0;
    DeviceVector<GpuWord> accum_p1;
    DeviceVector<GpuWord> fourstep_q0;
    DeviceVector<GpuWord> fourstep_q1;
    DeviceVector<GpuWord> fourstep_p0;
    DeviceVector<GpuWord> fourstep_p1;
    DeviceVector<GpuWord> relin_rescale_dropped_ntt;
    DeviceVector<GpuWord> relin_rescale_dropped_coeff;
    DeviceVector<GpuWord> relin_rescale_correction;
    DeviceVector<GpuWord> relin_rescale_correction_ntt;

    GpuPolyShardView c2_intt_view()
    {
        GpuPolyShardView result;
        result.device_id = device_id;
        result.ptr = c2_intt.data();
        result.limb_begin = 0;
        result.limb_count = base_q_size;
        result.coeff_begin = 0;
        result.coeff_count = degree;
        return result;
    }
};

GpuPolyShardView make_scratch_q_view(
    GpuWord *ptr,
    const HybridScratch &scratch)
{
    GpuPolyShardView result;
    result.device_id = scratch.device_id;
    result.ptr = ptr;
    result.limb_begin = 0;
    result.limb_count = scratch.base_q_size;
    result.coeff_begin = 0;
    result.coeff_count = scratch.degree;
    return result;
}

GpuPolyShardView make_scratch_p_view(
    GpuWord *ptr,
    const HybridScratch &scratch)
{
    GpuPolyShardView result;
    result.device_id = scratch.device_id;
    result.ptr = ptr;
    result.limb_begin = scratch.base_q_size;
    result.limb_count = scratch.base_p_size;
    result.coeff_begin = 0;
    result.coeff_count = scratch.degree;
    return result;
}

GpuConstPolyShardView as_const_shard(const GpuPolyShardView &shard)
{
    GpuConstPolyShardView result;
    result.device_id = shard.device_id;
    result.ptr = shard.ptr;
    result.limb_begin = shard.limb_begin;
    result.limb_count = shard.limb_count;
    result.coeff_begin = shard.coeff_begin;
    result.coeff_count = shard.coeff_count;
    return result;
}

void validate_hybrid_parameter_shape(
    const char *name,
    const HybridScratch &scratch,
    const GpuParameterShard &parameter_shard)
{
    if (parameter_shard.hybrid_base_q_count != scratch.base_q_size ||
        parameter_shard.hybrid_base_p_count != scratch.base_p_size)
    {
        throw std::invalid_argument(
            std::string(name) + ": HYBRID parameter shape mismatch");
    }
}

HybridScratch allocate_hybrid_scratch(
    int device_id,
    std::size_t degree,
    std::size_t base_q_size,
    std::size_t base_p_size)
{
    HybridScratch scratch;
    scratch.device_id = device_id;
    scratch.degree = degree;
    scratch.base_q_size = base_q_size;
    scratch.base_p_size = base_p_size;
    scratch.q_word_count = checked_mul(
        base_q_size,
        degree,
        "GpuKeySwitchHandler q scratch size overflow");
    scratch.p_word_count = checked_mul(
        base_p_size,
        degree,
        "GpuKeySwitchHandler p scratch size overflow");

    scratch.c2_intt.allocate(scratch.q_word_count, device_id);
    scratch.modup_q.allocate(scratch.q_word_count, device_id);
    scratch.modup_p.allocate(scratch.p_word_count, device_id);
    /* 累加后ksk0和ksk1对应的结果 */
    scratch.accum_q0.allocate(scratch.q_word_count, device_id);
    scratch.accum_q1.allocate(scratch.q_word_count, device_id);
    scratch.accum_p0.allocate(scratch.p_word_count, device_id);
    scratch.accum_p1.allocate(scratch.p_word_count, device_id);

    if (use_fourstep_all_ntt(degree, base_q_size, base_p_size))
    {
        scratch.fourstep_q0.allocate(scratch.q_word_count, device_id);
        scratch.fourstep_q1.allocate(scratch.q_word_count, device_id);
        scratch.fourstep_p0.allocate(scratch.p_word_count, device_id);
        scratch.fourstep_p1.allocate(scratch.p_word_count, device_id);
    }
    else if (use_p9_fourstep_p_intt(degree, base_p_size) ||
             use_p9_p_to_q_fourstep(
                 degree,
                 base_p_size) ||
             use_fourstep_qp_any_p(degree, base_p_size))
    {
        if (use_fourstep_qp_any_p(degree, base_p_size))
        {
            scratch.fourstep_q0.allocate(scratch.q_word_count, device_id);
        }
        scratch.fourstep_p0.allocate(scratch.p_word_count, device_id);
        scratch.fourstep_p1.allocate(scratch.p_word_count, device_id);
    }
    return scratch;
}

void ensure_hybrid_scratch(
    HybridScratch &scratch,
    int device_id,
    std::size_t degree,
    std::size_t base_q_size,
    std::size_t base_p_size)
{
    const std::size_t q_word_count = checked_mul(
        base_q_size,
        degree,
        "GpuKeySwitchHandler persistent q scratch size overflow");
    const std::size_t p_word_count = checked_mul(
        base_p_size,
        degree,
        "GpuKeySwitchHandler persistent p scratch size overflow");

    const auto ensure_capacity =
        [device_id](DeviceVector<GpuWord> &buffer, std::size_t word_count)
        {
            if (buffer.size() < word_count ||
                (!buffer.empty() && buffer.device_id() != device_id))
            {
                buffer.allocate(word_count, device_id);
            }
        };

    ensure_capacity(scratch.c2_intt, q_word_count);
    ensure_capacity(scratch.modup_q, q_word_count);
    ensure_capacity(scratch.modup_p, p_word_count);
    ensure_capacity(scratch.accum_q0, q_word_count);
    ensure_capacity(scratch.accum_q1, q_word_count);
    ensure_capacity(scratch.accum_p0, p_word_count);
    ensure_capacity(scratch.accum_p1, p_word_count);

    if (use_fourstep_all_ntt(degree, base_q_size, base_p_size))
    {
        ensure_capacity(scratch.fourstep_q0, q_word_count);
        ensure_capacity(scratch.fourstep_q1, q_word_count);
        ensure_capacity(scratch.fourstep_p0, p_word_count);
        ensure_capacity(scratch.fourstep_p1, p_word_count);
    }
    else if (use_p9_fourstep_p_intt(degree, base_p_size) ||
             use_p9_p_to_q_fourstep(
                 degree,
                 base_p_size) ||
             use_fourstep_qp_any_p(degree, base_p_size))
    {
        if (use_fourstep_qp_any_p(degree, base_p_size))
        {
            ensure_capacity(scratch.fourstep_q0, q_word_count);
        }
        ensure_capacity(scratch.fourstep_p0, p_word_count);
        ensure_capacity(scratch.fourstep_p1, p_word_count);
    }
    scratch.device_id = device_id;
    scratch.degree = degree;
    scratch.base_q_size = base_q_size;
    scratch.base_p_size = base_p_size;
    scratch.q_word_count = q_word_count;
    scratch.p_word_count = p_word_count;
}

void ensure_hybrid_relin_rescale_x1_scratch(
    HybridScratch &scratch)
{
    if (scratch.degree == 0 || scratch.base_q_size < 2)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler relin-rescale_x1 scratch requires q_count >= 2");
    }
    const auto ensure_capacity =
        [&scratch](DeviceVector<GpuWord> &buffer, std::size_t word_count)
        {
            if (buffer.size() < word_count ||
                (!buffer.empty() && buffer.device_id() != scratch.device_id))
            {
                buffer.allocate(word_count, scratch.device_id);
            }
        };
    const std::size_t dropped_words = 2 * scratch.degree;
    const std::size_t correction_words =
        2 * (scratch.base_q_size - 1) * scratch.degree;
    ensure_capacity(scratch.relin_rescale_dropped_ntt, dropped_words);
    ensure_capacity(scratch.relin_rescale_dropped_coeff, dropped_words);
    ensure_capacity(scratch.relin_rescale_correction_ntt, correction_words);
}

void ensure_hybrid_relin_rescale_x2_scratch(
    HybridScratch &scratch)
{
    if (scratch.degree == 0 || scratch.base_q_size < 3)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler relin-rescale_x2 scratch requires q_count >= 3");
    }
    const auto ensure_capacity =
        [&scratch](DeviceVector<GpuWord> &buffer, std::size_t word_count)
        {
            if (buffer.size() < word_count ||
                (!buffer.empty() && buffer.device_id() != scratch.device_id))
            {
                buffer.allocate(word_count, scratch.device_id);
            }
        };
    const std::size_t dropped_words = 2 * 2 * scratch.degree;
    const std::size_t correction_words =
        2 * (scratch.base_q_size - 2) * scratch.degree;
    ensure_capacity(scratch.relin_rescale_dropped_ntt, dropped_words);
    ensure_capacity(scratch.relin_rescale_dropped_coeff, dropped_words);
    ensure_capacity(scratch.relin_rescale_correction, correction_words);
    ensure_capacity(scratch.relin_rescale_correction_ntt, correction_words);
}

void inverse_ntt_switch_poly(
    HybridScratch &scratch,
    const GpuConstRNSPolyView &switch_poly_ntt,
    const GpuLevelInfo &level_info)
{
    const bool fourstep = use_fourstep_c2_intt() || use_fourstep_all_ntt(
        scratch.degree,
        scratch.base_q_size,
        scratch.base_p_size);
    NvtxRange range(fourstep
        ? "keyswitch.intt_switch_poly.fourstep"
        : "keyswitch.intt_switch_poly.fused3");
    const auto &source_shard = switch_poly_ntt.shards.front();
    auto destination_shard = scratch.c2_intt_view();
    const auto *parameter_shard = find_parameter_shard(level_info, source_shard);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::inverse_ntt_switch_poly: no matching parameter shard");
    }

    // POSEIDON_OPT_MODUP_FOLD: when every digit will take the generic
    // (preweighted) ModUp below, the INTT multiplies by N^{-1} * qHat^{-1}.
    scratch.c2_preweighted = false;
    {
        const std::size_t p = scratch.base_p_size;
        const bool fourstep_all = use_fourstep_all_ntt(scratch.degree, scratch.base_q_size, p);
        const bool fourstep_qp = use_fourstep_qp_any_p(scratch.degree, p);
        const bool fused_phase1 =
            use_p9_modup_fourstep_compact_preweight(scratch.degree, p) ||
            use_p9_modup_fourstep_phase1_fused(scratch.degree, p);
        const bool generic_modup = (fourstep_all || fourstep_qp) && !fused_phase1 &&
            !fourstep_all && (p != 9 || opt_flag(OptFlag::UnifyP9));
        const GpuWord *table = generic_modup && kernel::modup_fold_applicable(scratch.degree)
            ? kernel::hybrid_q_preweighted_inv_degree_table(*parameter_shard)
            : nullptr;
        if (table != nullptr &&
            kernel::launch_inverse_ntt_poly_shard_scaled_65536(
                destination_shard, source_shard, *parameter_shard, scratch.degree, table))
        {
            scratch.c2_preweighted = true;
            return;
        }
    }
    if (fourstep)
    {
        kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
            destination_shard,
            source_shard,
            *parameter_shard,
            scratch.degree);
    }
    else
    {
        kernel::launch_inverse_ntt_poly_shard(
            destination_shard,
            source_shard,
            *parameter_shard,
            scratch.degree);
    }
}

/* 处理单个dnum分量的计算函数 */
void process_hybrid_decomposition_block(
    std::size_t decomp_index,
    std::size_t decomp_limb_begin,
    std::size_t decomp_limb_count,
    HybridScratch &scratch,
    const GpuConstRNSPolyView &switch_poly_ntt,
    const HybridKeyComponentView &key_component0,
    const HybridKeyComponentView &key_component1,
    const GpuLevelInfo &level_info,
    bool fuse_decomp_q,
    bool fuse_modup_ntt_head,
    bool bconv_row_tiled,
    bool bconv_row_tiled8)
{
    NvtxRange block_range(
        "keyswitch.dnum[" + std::to_string(decomp_index) + "]");
    const auto &switch_poly_shard = switch_poly_ntt.shards.front();
    if (key_component0.device_id != key_component1.device_id ||
        key_component0.device_id != switch_poly_shard.device_id)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::process_hybrid_decomposition_block: key device placement mismatch");
    }

    const auto *parameter_shard = find_parameter_shard(
        level_info,
        switch_poly_shard);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::process_hybrid_decomposition_block: no matching parameter shard");
    }
    validate_hybrid_parameter_shape(
        "GpuKeySwitchHandler::process_hybrid_decomposition_block",
        scratch,
        *parameter_shard);

    const bool fourstep_all_ntt = use_fourstep_all_ntt(
        scratch.degree,
        scratch.base_q_size,
        scratch.base_p_size);
    const bool p9_fourstep_qp = use_fourstep_qp_any_p(
        scratch.degree,
        scratch.base_p_size);
    if (fourstep_all_ntt || p9_fourstep_qp)
    {
        const bool fuse_phase2_mac = use_fourstep_phase2_mac();
        const bool compact_preweight =
            use_p9_modup_fourstep_compact_preweight(
                scratch.degree,
                scratch.base_p_size);
        const bool fuse_modup_phase1 = compact_preweight ||
            use_p9_modup_fourstep_phase1_fused(
                scratch.degree,
                scratch.base_p_size);
        if (fuse_modup_phase1)
        {
            const bool source_preweighted =
                compact_preweight && decomp_limb_count > 1;
            const unsigned int target_limb_tile = source_preweighted
                ? p9_modup_fourstep_grouped_targets()
                : 1;
            const GpuWord *modup_source = scratch.c2_intt.data();
            if (source_preweighted)
            {
                NvtxRange preweight_range(
                    "keyswitch.dnum.modup.compact_preweight_p9");
                kernel::launch_hybrid_preweight_modup_source_p9(
                    scratch.modup_p.data(),
                    scratch.c2_intt.data(),
                    decomp_index,
                    decomp_limb_begin,
                    decomp_limb_count,
                    *parameter_shard,
                    scratch.degree);
                modup_source = scratch.modup_p.data();
            }
            NvtxRange range(
                source_preweighted
                    ? "keyswitch.dnum.modup_fourstep_phase1.compact_preweight_p9"
                    : "keyswitch.dnum.modup_fourstep_phase1.fused_p9");
            kernel::launch_hybrid_modup_p9_forward_ntt_qp_active_phase1_fourstep_65536(
                scratch.fourstep_q0.data(),
                scratch.fourstep_p0.data(),
                modup_source,
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                *parameter_shard,
                scratch.degree,
                source_preweighted,
                target_limb_tile);
        }
        else if (fourstep_all_ntt)
        {
            NvtxRange range("keyswitch.dnum.modup.row_tiled8.coeff");
            kernel::launch_hybrid_modup_decomposition_row_tiled8(
                scratch.modup_q.data(),
                scratch.modup_p.data(),
                scratch.c2_intt.data(),
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                *parameter_shard,
                scratch.degree);
        }
        else if (scratch.base_p_size == 9 && !opt_flag(OptFlag::UnifyP9))
        {
            NvtxRange range("keyswitch.dnum.modup.p9.row_tiled8.coeff");
            kernel::launch_hybrid_modup_decomposition_row_tiled8(
                scratch.modup_q.data(),
                scratch.modup_p.data(),
                scratch.c2_intt.data(),
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                *parameter_shard,
                scratch.degree);
        }
        else
        {
            NvtxRange range("keyswitch.dnum.modup.generic.coeff");
            kernel::launch_hybrid_modup_decomposition(
                scratch.modup_q.data(),
                scratch.modup_p.data(),
                scratch.c2_intt.data(),
                switch_poly_shard.ptr,
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                *parameter_shard,
                scratch.degree,
                scratch.c2_preweighted);
        }

        if (fuse_phase2_mac)
        {
            NvtxRange range(
                "keyswitch.dnum.fourstep_forward_ntt_qp_active.phase2_mac");
            kernel::launch_forward_ntt_qp_active_fourstep_mul_accumulate_two_components_65536(
                scratch.fourstep_q0.data(),
                scratch.fourstep_p0.data(),
                fuse_modup_phase1
                    ? scratch.fourstep_q0.data()
                    : scratch.modup_q.data(),
                fuse_modup_phase1
                    ? scratch.fourstep_p0.data()
                    : scratch.modup_p.data(),
                scratch.accum_q0.data(),
                scratch.accum_p0.data(),
                scratch.accum_q1.data(),
                scratch.accum_p1.data(),
                switch_poly_shard.ptr,
                key_component0.q_ptr,
                key_component0.p_ptr,
                key_component1.q_ptr,
                key_component1.p_ptr,
                decomp_limb_begin,
                decomp_limb_count,
                decomp_index == 0,
                *parameter_shard,
                scratch.degree,
                fuse_modup_phase1);
        }
        else
        {
            {
                NvtxRange range(
                    "keyswitch.dnum.fourstep_forward_ntt_qp_active");
                kernel::launch_forward_ntt_qp_active_fourstep_65536(
                    scratch.fourstep_q0.data(),
                    scratch.fourstep_p0.data(),
                    fuse_modup_phase1
                        ? scratch.fourstep_q0.data()
                        : scratch.modup_q.data(),
                    fuse_modup_phase1
                        ? scratch.fourstep_p0.data()
                        : scratch.modup_p.data(),
                    decomp_limb_begin,
                    decomp_limb_count,
                    *parameter_shard,
                    scratch.degree,
                    fuse_modup_phase1);
            }
            {
                NvtxRange range(
                    "keyswitch.dnum.fourstep_multiply_accumulate.c01");
                kernel::launch_hybrid_multiply_accumulate_two_components(
                    scratch.accum_q0.data(),
                    scratch.accum_p0.data(),
                    scratch.accum_q1.data(),
                    scratch.accum_p1.data(),
                    scratch.fourstep_q0.data(),
                    scratch.fourstep_p0.data(),
                    switch_poly_shard.ptr,
                    key_component0.q_ptr,
                    key_component0.p_ptr,
                    key_component1.q_ptr,
                    key_component1.p_ptr,
                    *parameter_shard,
                    scratch.degree,
                    decomp_limb_begin,
                    decomp_limb_count,
                    decomp_index == 0);
            }
        }
        return;
    }

    /* Compatibility fallback for parameter shapes not supported by the
       N=65536, P=2 four-step pipeline, or for an explicit env rollback. */
    /* 将dnum片段进行模升，每个片段扩展到完整的32+6=38个模数 */
    {
        NvtxRange range(!fuse_modup_ntt_head
            ? "keyswitch.dnum.modup"
            : (bconv_row_tiled8
                ? "keyswitch.dnum.modup_forward_ntt_head.row_tiled8"
                : (bconv_row_tiled
                    ? "keyswitch.dnum.modup_forward_ntt_head.row_tiled"
                    : "keyswitch.dnum.modup_forward_ntt_head")));
        if (fuse_modup_ntt_head)
        {
            if (bconv_row_tiled8)
            {
                kernel::launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled8(
                    scratch.modup_q.data(),
                    scratch.modup_p.data(),
                    scratch.c2_intt.data(),
                    decomp_index,
                    decomp_limb_begin,
                    decomp_limb_count,
                    *parameter_shard,
                    scratch.degree);
            }
            else if (bconv_row_tiled)
            {
                kernel::launch_hybrid_modup_decomposition_forward_ntt_first_stage_row_tiled(
                    scratch.modup_q.data(),
                    scratch.modup_p.data(),
                    scratch.c2_intt.data(),
                    decomp_index,
                    decomp_limb_begin,
                    decomp_limb_count,
                    *parameter_shard,
                    scratch.degree);
            }
            else
            {
                kernel::launch_hybrid_modup_decomposition_forward_ntt_first_stage(
                    scratch.modup_q.data(),
                    scratch.modup_p.data(),
                    scratch.c2_intt.data(),
                    decomp_index,
                    decomp_limb_begin,
                    decomp_limb_count,
                    *parameter_shard,
                    scratch.degree);
            }
        }
        else
        {
            kernel::launch_hybrid_modup_decomposition(
                scratch.modup_q.data(),
                scratch.modup_p.data(),
                scratch.c2_intt.data(),
                switch_poly_shard.ptr,
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                *parameter_shard,
                scratch.degree);
        }
    }

    /* 当前dnum块内的Q limb直接复用原始c2的NTT值；新模升产生的Q/P limb在最后一段NTT中直接完成IP乘加。 */
    {
        NvtxRange range("keyswitch.dnum.forward_ntt_qp_mul_accum.c01");
        kernel::launch_hybrid_forward_ntt_qp_mul_accumulate_two_components(
            scratch.accum_q0.data(),
            scratch.accum_p0.data(),
            scratch.accum_q1.data(),
            scratch.accum_p1.data(),
            scratch.modup_q.data(),
            scratch.modup_p.data(),
            switch_poly_shard.ptr,
            key_component0.q_ptr,
            key_component0.p_ptr,
            key_component1.q_ptr,
            key_component1.p_ptr,
            decomp_limb_begin,
            decomp_limb_count,
            *parameter_shard,
            scratch.degree,
            decomp_index == 0,
            fuse_decomp_q,
            fuse_modup_ntt_head);
    }
}

void finalize_hybrid_relinearize(
    GpuCiphertextView &destination,
    HybridScratch &scratch,
    const GpuLevelInfo &level_info,
    const GpuConstRNSPolyView *add_source0,
    const GpuConstRNSPolyView *add_source1)
{
    NvtxRange finalize_range("keyswitch.finalize");
    const auto &destination_shard0 = destination.polys[0].shards.front();
    const auto &destination_shard1 = destination.polys[1].shards.front();
    const GpuConstPolyShardView *add_source_shard0 =
        add_source0 == nullptr ? nullptr : &add_source0->shards.front();
    const GpuConstPolyShardView *add_source_shard1 =
        add_source1 == nullptr ? nullptr : &add_source1->shards.front();
    /* 查找参数表，为后续计算做准备 */
    const auto *parameter_shard = find_parameter_shard(
        level_info,
        as_const_shard(destination_shard0));
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize: no matching parameter shard");
    }
    validate_hybrid_parameter_shape(
        "GpuKeySwitchHandler::finalize_hybrid_relinearize",
        scratch,
        *parameter_shard);

    auto accum_p0_view = make_scratch_p_view(scratch.accum_p0.data(), scratch);
    auto accum_p1_view = make_scratch_p_view(scratch.accum_p1.data(), scratch);

    if (use_fourstep_all_ntt(
            scratch.degree,
            scratch.base_q_size,
            scratch.base_p_size))
    {
        auto p_coeff0_view = make_scratch_p_view(
            scratch.fourstep_p0.data(),
            scratch);
        auto p_coeff1_view = make_scratch_p_view(
            scratch.fourstep_p1.data(),
            scratch);
        {
            NvtxRange range("keyswitch.finalize.fourstep_intt_p0");
            kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
                p_coeff0_view,
                as_const_shard(accum_p0_view),
                *parameter_shard,
                scratch.degree);
        }
        {
            NvtxRange range("keyswitch.finalize.fourstep_intt_p1");
            kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
                p_coeff1_view,
                as_const_shard(accum_p1_view),
                *parameter_shard,
                scratch.degree);
        }

        if (use_fourstep_finalize_fused())
        {
            NvtxRange range(
                "keyswitch.finalize.convert_p_to_q_fourstep_q01");
            kernel::launch_hybrid_convert_p_to_q_forward_ntt_two_components_fourstep_65536(
                scratch.fourstep_q0.data(),
                scratch.fourstep_q1.data(),
                scratch.fourstep_p0.data(),
                scratch.fourstep_p1.data(),
                *parameter_shard,
                scratch.degree);
        }
        else
        {
            {
                NvtxRange range("keyswitch.finalize.convert_p_to_q.coeff");
                kernel::launch_hybrid_convert_p_to_q(
                    scratch.c2_intt.data(),
                    scratch.modup_q.data(),
                    scratch.fourstep_p0.data(),
                    scratch.fourstep_p1.data(),
                    *parameter_shard,
                    scratch.degree);
            }

            auto q_coeff0_view = make_scratch_q_view(
                scratch.c2_intt.data(),
                scratch);
            auto q_coeff1_view = make_scratch_q_view(
                scratch.modup_q.data(),
                scratch);
            auto q_ntt0_view = make_scratch_q_view(
                scratch.fourstep_q0.data(),
                scratch);
            auto q_ntt1_view = make_scratch_q_view(
                scratch.fourstep_q1.data(),
                scratch);
            {
                NvtxRange range("keyswitch.finalize.fourstep_forward_ntt_q0");
                kernel::launch_forward_ntt_poly_shard_fourstep_65536(
                    q_ntt0_view,
                    as_const_shard(q_coeff0_view),
                    *parameter_shard,
                    scratch.degree);
            }
            {
                NvtxRange range("keyswitch.finalize.fourstep_forward_ntt_q1");
                kernel::launch_forward_ntt_poly_shard_fourstep_65536(
                    q_ntt1_view,
                    as_const_shard(q_coeff1_view),
                    *parameter_shard,
                    scratch.degree);
            }
        }

        {
            NvtxRange range("keyswitch.finalize.fourstep_apply_moddown_add_back");
            kernel::launch_hybrid_apply_moddown_ntt_add_back(
                destination_shard0,
                destination_shard1,
                scratch.accum_q0.data(),
                scratch.accum_q1.data(),
                scratch.fourstep_q0.data(),
                scratch.fourstep_q1.data(),
                *parameter_shard,
                scratch.degree,
                add_source_shard0,
                add_source_shard1);
        }
        return;
    }

    if (use_small_p_fourstep(scratch.degree, scratch.base_p_size) &&
        parameter_shard->limb_begin == 0 &&
        scratch.fourstep_p0.size() >= scratch.p_word_count &&
        scratch.fourstep_p1.size() >= scratch.p_word_count)
    {
        NvtxRange range("keyswitch.finalize.small_p_fourstep");
        // POSEIDON_OPT_PTOQ_PW: the P weights ride on the INTT's N^{-1}.
        const GpuWord *small_p_table = opt_flag(OptFlag::PToQPreweight)
            ? kernel::hybrid_p_preweighted_inv_degree_table(*parameter_shard)
            : nullptr;
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            scratch.fourstep_p0.data(),
            scratch.fourstep_p1.data(),
            scratch.accum_p0.data(),
            scratch.accum_p1.data(),
            scratch.base_q_size,
            scratch.base_p_size,
            *parameter_shard,
            small_p_table);
        kernel::launch_hybrid_convert_p_to_q_coeff_lazy(
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            scratch.fourstep_p0.data(),
            scratch.fourstep_p1.data(),
            *parameter_shard,
            scratch.degree,
            small_p_table != nullptr);
        kernel::launch_forward_ntt_two_components_inplace_fourstep_65536(
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            scratch.base_q_size,
            *parameter_shard);
        kernel::launch_hybrid_apply_moddown_ntt_add_back(
            destination_shard0,
            destination_shard1,
            scratch.accum_q0.data(),
            scratch.accum_q1.data(),
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            *parameter_shard,
            scratch.degree,
            add_source_shard0,
            add_source_shard1);
        return;
    }

    /* 只把P部分转回系数域，Q部分保持在NTT域 */
    const bool p9_fourstep_intt = use_p9_fourstep_p_intt(
        scratch.degree,
        scratch.base_p_size);
    const bool p9_preweight =
        use_p9_preweight_p(scratch.degree, scratch.base_p_size);
    bool p_folded = false;
    GpuWord *p_coeff0 = scratch.accum_p0.data();
    GpuWord *p_coeff1 = scratch.accum_p1.data();
    if (p9_fourstep_intt)
    {
        p_coeff0 = scratch.fourstep_p0.data();
        p_coeff1 = scratch.fourstep_p1.data();
        auto p_coeff0_view = make_scratch_p_view(p_coeff0, scratch);
        auto p_coeff1_view = make_scratch_p_view(p_coeff1, scratch);
        {
            NvtxRange range("keyswitch.finalize.intt_p0.fourstep_p9");
            kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
                p_coeff0_view,
                as_const_shard(accum_p0_view),
                *parameter_shard,
                scratch.degree);
        }
        {
            NvtxRange range("keyswitch.finalize.intt_p1.fourstep_p9");
            kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
                p_coeff1_view,
                as_const_shard(accum_p1_view),
                *parameter_shard,
                scratch.degree);
        }
    }
    else if (!p9_preweight &&
             p_to_q_fold_table(accum_p0_view, *parameter_shard, scratch.degree) != nullptr)
    {
        NvtxRange range("keyswitch.finalize.intt_p01.preweighted");
        p_folded = inverse_p_parts_for_p_to_q(
            accum_p0_view,
            as_const_shard(accum_p0_view),
            accum_p1_view,
            as_const_shard(accum_p1_view),
            *parameter_shard,
            scratch.degree);
    }
    else
    {
        {
            NvtxRange range("keyswitch.finalize.intt_p0");
            kernel::launch_inverse_ntt_poly_shard(
                accum_p0_view,
                as_const_shard(accum_p0_view),
                *parameter_shard,
                scratch.degree);
        }
        {
            NvtxRange range("keyswitch.finalize.intt_p1");
            kernel::launch_inverse_ntt_poly_shard(
                accum_p1_view,
                as_const_shard(accum_p1_view),
                *parameter_shard,
                scratch.degree);
        }
    }
    const bool p_source_preweighted = p9_preweight || p_folded;

    const bool p_to_q_row_tiled8 =
        use_p_to_q_row_tiled8() ||
        use_p9_p_to_q_row_tiled8(
            scratch.degree,
            scratch.base_p_size);
    const bool p_to_q_fourstep = use_p9_p_to_q_fourstep(
        scratch.degree,
        scratch.base_p_size);
    if (p9_preweight)
    {
        NvtxRange range("keyswitch.finalize.preweight_p9");
        kernel::launch_hybrid_preweight_p_two_components(
            p_coeff0,
            p_coeff1,
            *parameter_shard,
            scratch.degree);
    }

    if (p_to_q_fourstep)
    {
        NvtxRange range(
            "keyswitch.finalize.convert_p_to_q_forward_ntt.fourstep_p9");
        kernel::launch_hybrid_convert_p9_to_q_forward_ntt_two_components_fourstep_65536(
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            p_coeff0,
            p_coeff1,
            *parameter_shard,
            scratch.degree,
            p_source_preweighted);
    }
    else if (p_to_q_row_tiled8)
    {
        NvtxRange range(
            "keyswitch.finalize.convert_p_to_q_forward_ntt.row_tiled8");
        kernel::launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8(
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            p_coeff0,
            p_coeff1,
            *parameter_shard,
            scratch.degree,
            p_source_preweighted);
    }
    else
    {
        NvtxRange range("keyswitch.finalize.convert_p_to_q_forward_ntt");
        kernel::launch_hybrid_convert_p_to_q_forward_ntt(
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            p_coeff0,
            p_coeff1,
            *parameter_shard,
            scratch.degree,
            p_source_preweighted);
    }

#if 0
    /* Legacy rollback path: separate P->Q conversion and Q forward NTT. */
    {
        auto converted_q0_view =
            make_scratch_q_view(scratch.c2_intt.data(), scratch);
        auto converted_q1_view =
            make_scratch_q_view(scratch.modup_q.data(), scratch);

        {
            NvtxRange range("keyswitch.finalize.convert_p_to_q");
            kernel::launch_hybrid_convert_p_to_q(
                scratch.c2_intt.data(),
                scratch.modup_q.data(),
                scratch.accum_p0.data(),
                scratch.accum_p1.data(),
                *parameter_shard,
                scratch.degree);
        }

#if 1
        /* Batched Q NTT rollback variant. */
        {
            NvtxRange range("keyswitch.finalize.forward_ntt_q_batched");
            kernel::launch_hybrid_forward_ntt_q_two_components(
                scratch.c2_intt.data(),
                scratch.modup_q.data(),
                *parameter_shard,
                scratch.degree);
        }
#else
        /* Separate-component Q NTT rollback variant. */
        {
            {
                NvtxRange range("keyswitch.finalize.forward_ntt_q0");
                kernel::launch_forward_ntt_poly_shard(
                    converted_q0_view,
                    as_const_shard(converted_q0_view),
                    *parameter_shard,
                    scratch.degree);
            }
            {
                NvtxRange range("keyswitch.finalize.forward_ntt_q1");
                kernel::launch_forward_ntt_poly_shard(
                    converted_q1_view,
                    as_const_shard(converted_q1_view),
                    *parameter_shard,
                    scratch.degree);
            }
        }
#endif
    }
#endif

    /* 在NTT域完成模降，并直接和d0/d1累加，避免额外读写accum_q0/accum_q1 */
    {
        NvtxRange range("keyswitch.finalize.apply_moddown_ntt_add_back");
        kernel::launch_hybrid_apply_moddown_ntt_add_back(
            destination_shard0,
            destination_shard1,
            scratch.accum_q0.data(),
            scratch.accum_q1.data(),
            scratch.c2_intt.data(),
            scratch.modup_q.data(),
            *parameter_shard,
            scratch.degree,
            add_source_shard0,
            add_source_shard1);
    }
}

void finalize_hybrid_relinearize_rescale_x1(
    GpuCiphertextView &destination,
    HybridScratch &scratch,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info,
    const GpuConstRNSPolyView *add_source0,
    const GpuConstRNSPolyView *add_source1,
    bool double_moddown)
{
    NvtxRange finalize_range("keyswitch.finalize_rescale_x1");
    if (add_source0 == nullptr || add_source1 == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x1: add-source components are required");
    }
    if (scratch.base_q_size < 2 ||
        scratch.degree != 65536 ||
        destination_level_info.q_count + 1 != scratch.base_q_size ||
        destination.meta.q_count != destination_level_info.q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x1: level mismatch");
    }

    const auto &destination_shard0 = destination.polys[0].shards.front();
    const auto &destination_shard1 = destination.polys[1].shards.front();
    const auto &add_source_full0 = add_source0->shards.front();
    const auto &add_source_full1 = add_source1->shards.front();
    const auto *parameter_shard = find_parameter_shard(
        source_level_info,
        add_source_full0);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x1: no matching parameter shard");
    }
    validate_hybrid_parameter_shape(
        "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x1",
        scratch,
        *parameter_shard);
    if (parameter_shard->q_last == 0 ||
        parameter_shard->half_q_last_mod_q.size() < destination_level_info.q_count ||
        parameter_shard->inv_q_last_mod_q.size() < destination_level_info.q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x1: missing rescale_x1 constants");
    }

    ensure_hybrid_relin_rescale_x1_scratch(scratch);

    auto p0 = make_scratch_p_view(scratch.accum_p0.data(), scratch);
    auto p1 = make_scratch_p_view(scratch.accum_p1.data(), scratch);
    const bool use_p_out_of_place =
        scratch.fourstep_p0.size() >= scratch.p_word_count &&
        scratch.fourstep_p1.size() >= scratch.p_word_count;
    auto p_dst0 = use_p_out_of_place ? make_scratch_p_view(scratch.fourstep_p0.data(), scratch) : p0;
    auto p_dst1 = use_p_out_of_place ? make_scratch_p_view(scratch.fourstep_p1.data(), scratch) : p1;
    bool folded = false;
    if (p_to_q_fold_table(p_dst0, *parameter_shard, scratch.degree))
        folded = inverse_p_parts_for_p_to_q(p_dst0, as_const_shard(p0),
            p_dst1, as_const_shard(p1), *parameter_shard, scratch.degree);
    else if (use_p_out_of_place && scratch.degree == 65536 && parameter_shard->limb_begin == 0)
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            p_dst0.ptr, p_dst1.ptr, p0.ptr, p1.ptr,
            scratch.base_q_size, scratch.base_p_size, *parameter_shard);
    else {
        kernel::launch_inverse_ntt_poly_shard(p_dst0, as_const_shard(p0), *parameter_shard, scratch.degree);
        kernel::launch_inverse_ntt_poly_shard(p_dst1, as_const_shard(p1), *parameter_shard, scratch.degree);
    }
    kernel::launch_hybrid_convert_p_to_q_coeff_lazy(
        scratch.c2_intt.data(), scratch.modup_q.data(),
        p_dst0.ptr, p_dst1.ptr, *parameter_shard, scratch.degree, folded);

    GpuPolyShardView tails[2], tail_coeffs[2], corrections[2];
    const auto retained = destination_level_info.q_count;
    for (std::size_t c = 0; c < 2; ++c) {
        tails[c] = {scratch.device_id, scratch.relin_rescale_dropped_ntt.data() + c * scratch.degree,
                    scratch.base_q_size - 1, 1, 0, scratch.degree};
        tail_coeffs[c] = {scratch.device_id, scratch.relin_rescale_dropped_coeff.data() + c * scratch.degree,
                         scratch.base_q_size - 1, 1, 0, scratch.degree};
        corrections[c] = {scratch.device_id, scratch.relin_rescale_correction_ntt.data() + c * retained * scratch.degree,
                          0, retained, 0, scratch.degree};
    }
    kernel::launch_hybrid_relin_rescale_x1_tail(tails[0].ptr, tails[1].ptr,
        scratch.accum_q0.data(), scratch.accum_q1.data(), add_source_full0.ptr, add_source_full1.ptr,
        *parameter_shard, scratch.degree, double_moddown);
    const bool can_two_comp_ntt =
        scratch.degree == 65536 &&
        parameter_shard->limb_begin == 0 &&
        parameter_shard->fourstep_intt_tables.data() != nullptr &&
        parameter_shard->fourstep_intt_tables.size() >= scratch.base_q_size * scratch.degree &&
        parameter_shard->ntt_tables.size() >= retained * scratch.degree;
    if (can_two_comp_ntt) {
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            tail_coeffs[0].ptr, tail_coeffs[1].ptr,
            tails[0].ptr, tails[1].ptr,
            scratch.base_q_size - 1, 1, *parameter_shard);
        kernel::RelinRescaleBatchArgs4 rr_args{};
        rr_args.dst[0] = destination_shard0.ptr;
        rr_args.dst[1] = destination_shard1.ptr;
        rr_args.r_coeff[0] = scratch.c2_intt.data();
        rr_args.r_coeff[1] = scratch.modup_q.data();
        rr_args.tail_coeff[0] = tail_coeffs[0].ptr;
        rr_args.tail_coeff[1] = tail_coeffs[1].ptr;
        rr_args.accum_q[0] = scratch.accum_q0.data();
        rr_args.accum_q[1] = scratch.accum_q1.data();
        rr_args.source[0] = add_source_full0.ptr;
        rr_args.source[1] = add_source_full1.ptr;
        if (!kernel::launch_fused_relin_rescale_batch_65536(
                rr_args,
                scratch.relin_rescale_dropped_ntt.data(),
                scratch.relin_rescale_correction_ntt.data(),
                2,
                1,
                double_moddown ? 4 : 0,
                *parameter_shard))
        {
            kernel::launch_hybrid_relin_rescale_x1_merge_correction(
                scratch.c2_intt.data(), scratch.modup_q.data(), tail_coeffs[0].ptr, tail_coeffs[1].ptr,
                *parameter_shard, scratch.degree, double_moddown);
            kernel::launch_forward_ntt_two_components_inplace_fourstep_65536(
                scratch.c2_intt.data(), scratch.modup_q.data(), retained, *parameter_shard);
            kernel::launch_hybrid_relin_rescale_x1_apply(destination_shard0.ptr, destination_shard1.ptr,
                scratch.accum_q0.data(), scratch.accum_q1.data(), add_source_full0.ptr, add_source_full1.ptr,
                scratch.c2_intt.data(), scratch.modup_q.data(), *parameter_shard, scratch.degree, double_moddown);
        }
    } else {
        for (std::size_t c = 0; c < 2; ++c)
            kernel::launch_inverse_ntt_poly_shard(tail_coeffs[c], as_const_shard(tails[c]),
                *parameter_shard, scratch.degree);
        kernel::launch_hybrid_relin_rescale_x1_merge_correction(
            scratch.c2_intt.data(), scratch.modup_q.data(), tail_coeffs[0].ptr, tail_coeffs[1].ptr,
            *parameter_shard, scratch.degree, double_moddown);
        const GpuWord *merged[2] = {scratch.c2_intt.data(), scratch.modup_q.data()};
        for (std::size_t c = 0; c < 2; ++c) {
            GpuConstPolyShardView coefficients{scratch.device_id, merged[c], 0, retained, 0, scratch.degree};
            kernel::launch_forward_ntt_poly_shard(corrections[c], coefficients, *parameter_shard, scratch.degree);
        }
        kernel::launch_hybrid_relin_rescale_x1_apply(destination_shard0.ptr, destination_shard1.ptr,
            scratch.accum_q0.data(), scratch.accum_q1.data(), add_source_full0.ptr, add_source_full1.ptr,
            corrections[0].ptr, corrections[1].ptr, *parameter_shard, scratch.degree, double_moddown);
    }
}

void finalize_hybrid_relinearize_rescale_x2(
    GpuCiphertextView &destination,
    HybridScratch &scratch,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info,
    const GpuConstRNSPolyView *add_source0,
    const GpuConstRNSPolyView *add_source1)
{
    NvtxRange finalize_range("keyswitch.finalize_rescale_x2");
    if (add_source0 == nullptr || add_source1 == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x2: add-source components are required");
    }
    if (scratch.base_q_size < 3 ||
        destination_level_info.q_count + 2 != scratch.base_q_size ||
        destination.meta.q_count != destination_level_info.q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x2: level mismatch");
    }

    const auto &destination_shard0 = destination.polys[0].shards.front();
    const auto &destination_shard1 = destination.polys[1].shards.front();
    const auto &add_source_full0 = add_source0->shards.front();
    const auto &add_source_full1 = add_source1->shards.front();
    const auto *parameter_shard = find_parameter_shard(
        source_level_info,
        add_source_full0);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x2: no matching parameter shard");
    }
    validate_hybrid_parameter_shape(
        "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x2",
        scratch,
        *parameter_shard);
    if (parameter_shard->q_last_two_product == 0 ||
        parameter_shard->inv_q_last_two_product_mod_q.size() <
            destination_level_info.q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::finalize_hybrid_relinearize_rescale_x2: missing rescale_x2 constants");
    }

    ensure_hybrid_relin_rescale_x2_scratch(scratch);

    const char *joint_mode = std::getenv("POSEIDON_GPU_RELIN_RESCALE_MERGED");
    if (joint_mode && std::string(joint_mode) == "1" && scratch.degree == 65536)
    {
        NvtxRange joint_range("keyswitch.finalize_rescale_x2.merged_correction");
        // K = P^-1*(A - NTT(R)) + S, with exactly the existing P->Q
        // conversion. Recover its dropped residues without an R-tail NTT.
        // Then out = (P^-1*A + S - NTT(P^-1*R + centered(K mod M)))/M.
        // In particular this is NOT a single rounding by P*M.
        auto p0 = make_scratch_p_view(scratch.accum_p0.data(), scratch);
        auto p1 = make_scratch_p_view(scratch.accum_p1.data(), scratch);
        const bool use_p_out_of_place =
            scratch.fourstep_p0.size() >= scratch.p_word_count &&
            scratch.fourstep_p1.size() >= scratch.p_word_count;
        auto p_dst0 = use_p_out_of_place ? make_scratch_p_view(scratch.fourstep_p0.data(), scratch) : p0;
        auto p_dst1 = use_p_out_of_place ? make_scratch_p_view(scratch.fourstep_p1.data(), scratch) : p1;
        bool folded = false;
        if (p_to_q_fold_table(p_dst0, *parameter_shard, scratch.degree))
            folded = inverse_p_parts_for_p_to_q(p_dst0, as_const_shard(p0),
                p_dst1, as_const_shard(p1), *parameter_shard, scratch.degree);
        else if (use_p_out_of_place && scratch.degree == 65536 && parameter_shard->limb_begin == 0)
            kernel::launch_inverse_ntt_two_components_fourstep_65536(
                p_dst0.ptr, p_dst1.ptr, p0.ptr, p1.ptr,
                scratch.base_q_size, scratch.base_p_size, *parameter_shard);
        else {
            kernel::launch_inverse_ntt_poly_shard(p_dst0, as_const_shard(p0), *parameter_shard, scratch.degree);
            kernel::launch_inverse_ntt_poly_shard(p_dst1, as_const_shard(p1), *parameter_shard, scratch.degree);
        }
        kernel::launch_hybrid_convert_p_to_q_coeff_lazy(
            scratch.c2_intt.data(), scratch.modup_q.data(),
            p_dst0.ptr, p_dst1.ptr, *parameter_shard, scratch.degree, folded);

        GpuPolyShardView tails[2], tail_coeffs[2], corrections[2];
        const auto retained = destination_level_info.q_count;
        for (std::size_t c = 0; c < 2; ++c) {
            tails[c] = {scratch.device_id, scratch.relin_rescale_dropped_ntt.data() + c * 2 * scratch.degree,
                        scratch.base_q_size - 2, 2, 0, scratch.degree};
            tail_coeffs[c] = {scratch.device_id, scratch.relin_rescale_dropped_coeff.data() + c * 2 * scratch.degree,
                             scratch.base_q_size - 2, 2, 0, scratch.degree};
            corrections[c] = {scratch.device_id, scratch.relin_rescale_correction_ntt.data() + c * retained * scratch.degree,
                              0, retained, 0, scratch.degree};
        }
        kernel::launch_hybrid_relin_rescale_x2_tail(tails[0].ptr, tails[1].ptr,
            scratch.accum_q0.data(), scratch.accum_q1.data(), add_source_full0.ptr, add_source_full1.ptr,
            *parameter_shard, scratch.degree);
        const bool can_two_comp_ntt =
            parameter_shard->limb_begin == 0 &&
            parameter_shard->fourstep_intt_tables.data() != nullptr &&
            parameter_shard->fourstep_intt_tables.size() >= scratch.base_q_size * scratch.degree &&
            parameter_shard->ntt_tables.size() >= retained * scratch.degree;
        if (can_two_comp_ntt) {
            kernel::launch_inverse_ntt_two_components_fourstep_65536(
                tail_coeffs[0].ptr, tail_coeffs[1].ptr,
                tails[0].ptr, tails[1].ptr,
                scratch.base_q_size - 2, 2, *parameter_shard);
            kernel::RelinRescaleBatchArgs4 rr_args{};
            rr_args.dst[0] = destination_shard0.ptr;
            rr_args.dst[1] = destination_shard1.ptr;
            rr_args.r_coeff[0] = scratch.c2_intt.data();
            rr_args.r_coeff[1] = scratch.modup_q.data();
            rr_args.tail_coeff[0] = tail_coeffs[0].ptr;
            rr_args.tail_coeff[1] = tail_coeffs[1].ptr;
            rr_args.accum_q[0] = scratch.accum_q0.data();
            rr_args.accum_q[1] = scratch.accum_q1.data();
            rr_args.source[0] = add_source_full0.ptr;
            rr_args.source[1] = add_source_full1.ptr;
            if (!kernel::launch_fused_relin_rescale_batch_65536(
                    rr_args,
                    scratch.relin_rescale_dropped_ntt.data(),
                    scratch.relin_rescale_correction_ntt.data(),
                    2,
                    2,
                    0,
                    *parameter_shard))
            {
                kernel::launch_hybrid_relin_rescale_x2_merge_correction(
                    scratch.c2_intt.data(), scratch.modup_q.data(), tail_coeffs[0].ptr, tail_coeffs[1].ptr,
                    *parameter_shard, scratch.degree);
                kernel::launch_forward_ntt_two_components_inplace_fourstep_65536(
                    scratch.c2_intt.data(), scratch.modup_q.data(), retained, *parameter_shard);
                kernel::launch_hybrid_relin_rescale_x2_apply(destination_shard0.ptr, destination_shard1.ptr,
                    scratch.accum_q0.data(), scratch.accum_q1.data(), add_source_full0.ptr, add_source_full1.ptr,
                    scratch.c2_intt.data(), scratch.modup_q.data(), *parameter_shard, scratch.degree);
            }
        } else {
            for (std::size_t c = 0; c < 2; ++c)
                kernel::launch_inverse_ntt_poly_shard(tail_coeffs[c], as_const_shard(tails[c]),
                    *parameter_shard, scratch.degree);
            kernel::launch_hybrid_relin_rescale_x2_merge_correction(
                scratch.c2_intt.data(), scratch.modup_q.data(), tail_coeffs[0].ptr, tail_coeffs[1].ptr,
                *parameter_shard, scratch.degree);
            const GpuWord *merged[2] = {scratch.c2_intt.data(), scratch.modup_q.data()};
            for (std::size_t c = 0; c < 2; ++c) {
                GpuConstPolyShardView coefficients{scratch.device_id, merged[c], 0, retained, 0, scratch.degree};
                kernel::launch_forward_ntt_poly_shard(corrections[c], coefficients, *parameter_shard, scratch.degree);
            }
            kernel::launch_hybrid_relin_rescale_x2_apply(destination_shard0.ptr, destination_shard1.ptr,
                scratch.accum_q0.data(), scratch.accum_q1.data(), add_source_full0.ptr, add_source_full1.ptr,
                corrections[0].ptr, corrections[1].ptr, *parameter_shard, scratch.degree);
        }
        return;
    }

    auto accum_p0_view = make_scratch_p_view(scratch.accum_p0.data(), scratch);
    auto accum_p1_view = make_scratch_p_view(scratch.accum_p1.data(), scratch);

    const GpuWord *converted_q0 = nullptr;
    const GpuWord *converted_q1 = nullptr;
    if (use_fourstep_all_ntt(
            scratch.degree,
            scratch.base_q_size,
            scratch.base_p_size))
    {
        auto p_coeff0_view = make_scratch_p_view(
            scratch.fourstep_p0.data(),
            scratch);
        auto p_coeff1_view = make_scratch_p_view(
            scratch.fourstep_p1.data(),
            scratch);
        {
            NvtxRange range("keyswitch.finalize_rescale_x2.fourstep_intt_p0");
            kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
                p_coeff0_view,
                as_const_shard(accum_p0_view),
                *parameter_shard,
                scratch.degree);
        }
        {
            NvtxRange range("keyswitch.finalize_rescale_x2.fourstep_intt_p1");
            kernel::launch_inverse_ntt_poly_shard_fourstep_65536(
                p_coeff1_view,
                as_const_shard(accum_p1_view),
                *parameter_shard,
                scratch.degree);
        }
        if (use_fourstep_finalize_fused())
        {
            NvtxRange range(
                "keyswitch.finalize_rescale_x2.convert_p_to_q_fourstep_q01");
            kernel::launch_hybrid_convert_p_to_q_forward_ntt_two_components_fourstep_65536(
                scratch.fourstep_q0.data(),
                scratch.fourstep_q1.data(),
                scratch.fourstep_p0.data(),
                scratch.fourstep_p1.data(),
                *parameter_shard,
                scratch.degree);
        }
        else
        {
            {
                NvtxRange range(
                    "keyswitch.finalize_rescale_x2.convert_p_to_q.coeff");
                kernel::launch_hybrid_convert_p_to_q(
                    scratch.c2_intt.data(),
                    scratch.modup_q.data(),
                    scratch.fourstep_p0.data(),
                    scratch.fourstep_p1.data(),
                    *parameter_shard,
                    scratch.degree);
            }
            auto q_coeff0_view = make_scratch_q_view(
                scratch.c2_intt.data(),
                scratch);
            auto q_coeff1_view = make_scratch_q_view(
                scratch.modup_q.data(),
                scratch);
            auto q_ntt0_view = make_scratch_q_view(
                scratch.fourstep_q0.data(),
                scratch);
            auto q_ntt1_view = make_scratch_q_view(
                scratch.fourstep_q1.data(),
                scratch);
            {
                NvtxRange range(
                    "keyswitch.finalize_rescale_x2.fourstep_forward_ntt_q0");
                kernel::launch_forward_ntt_poly_shard_fourstep_65536(
                    q_ntt0_view,
                    as_const_shard(q_coeff0_view),
                    *parameter_shard,
                    scratch.degree);
            }
            {
                NvtxRange range(
                    "keyswitch.finalize_rescale_x2.fourstep_forward_ntt_q1");
                kernel::launch_forward_ntt_poly_shard_fourstep_65536(
                    q_ntt1_view,
                    as_const_shard(q_coeff1_view),
                    *parameter_shard,
                    scratch.degree);
            }
        }
        converted_q0 = scratch.fourstep_q0.data();
        converted_q1 = scratch.fourstep_q1.data();
    }
    else
    {
        bool p_folded = false;
        if (p_to_q_fold_table(accum_p0_view, *parameter_shard, scratch.degree) != nullptr)
        {
            NvtxRange range("keyswitch.finalize_rescale_x2.intt_p01.preweighted");
            p_folded = inverse_p_parts_for_p_to_q(
                accum_p0_view,
                as_const_shard(accum_p0_view),
                accum_p1_view,
                as_const_shard(accum_p1_view),
                *parameter_shard,
                scratch.degree);
        }
        else
        {
        {
            NvtxRange range("keyswitch.finalize_rescale_x2.intt_p0");
            kernel::launch_inverse_ntt_poly_shard(
                accum_p0_view,
                as_const_shard(accum_p0_view),
                *parameter_shard,
                scratch.degree);
        }
        {
            NvtxRange range("keyswitch.finalize_rescale_x2.intt_p1");
            kernel::launch_inverse_ntt_poly_shard(
                accum_p1_view,
                as_const_shard(accum_p1_view),
                *parameter_shard,
                scratch.degree);
        }
        }
        if (use_p_to_q_row_tiled8())
        {
            NvtxRange range(
                "keyswitch.finalize_rescale_x2.convert_p_to_q_forward_ntt.row_tiled8");
            kernel::launch_hybrid_convert_p_to_q_forward_ntt_row_tiled8(
                scratch.c2_intt.data(),
                scratch.modup_q.data(),
                scratch.accum_p0.data(),
                scratch.accum_p1.data(),
                *parameter_shard,
                scratch.degree,
                p_folded);
        }
        else
        {
            NvtxRange range(
                "keyswitch.finalize_rescale_x2.convert_p_to_q_forward_ntt");
            kernel::launch_hybrid_convert_p_to_q_forward_ntt(
                scratch.c2_intt.data(),
                scratch.modup_q.data(),
                scratch.accum_p0.data(),
                scratch.accum_p1.data(),
                *parameter_shard,
                scratch.degree,
                p_folded);
        }
        converted_q0 = scratch.c2_intt.data();
        converted_q1 = scratch.modup_q.data();
    }

    GpuPolyShardView dropped_ntt0{
        scratch.device_id,
        scratch.relin_rescale_dropped_ntt.data(),
        scratch.base_q_size - 2,
        2,
        0,
        scratch.degree};
    GpuPolyShardView dropped_ntt1{
        scratch.device_id,
        scratch.relin_rescale_dropped_ntt.data() + 2 * scratch.degree,
        scratch.base_q_size - 2,
        2,
        0,
        scratch.degree};
    GpuConstPolyShardView add_tail0{
        add_source_full0.device_id,
        add_source_full0.ptr + (scratch.base_q_size - 2) * scratch.degree,
        scratch.base_q_size - 2,
        2,
        0,
        scratch.degree};
    GpuConstPolyShardView add_tail1{
        add_source_full1.device_id,
        add_source_full1.ptr + (scratch.base_q_size - 2) * scratch.degree,
        scratch.base_q_size - 2,
        2,
        0,
        scratch.degree};

    {
        NvtxRange range("keyswitch.finalize_rescale_x2.build_dropped_ntt");
        kernel::launch_hybrid_apply_moddown_ntt_add_back(
            dropped_ntt0,
            dropped_ntt1,
            scratch.accum_q0.data(),
            scratch.accum_q1.data(),
            converted_q0,
            converted_q1,
            *parameter_shard,
            scratch.degree,
            &add_tail0,
            &add_tail1);
    }

    GpuPolyShardView dropped_coeff0{
        scratch.device_id,
        scratch.relin_rescale_dropped_coeff.data(),
        scratch.base_q_size - 2,
        2,
        0,
        scratch.degree};
    GpuPolyShardView dropped_coeff1{
        scratch.device_id,
        scratch.relin_rescale_dropped_coeff.data() + 2 * scratch.degree,
        scratch.base_q_size - 2,
        2,
        0,
        scratch.degree};
    {
        NvtxRange range("keyswitch.finalize_rescale_x2.intt_dropped0");
        kernel::launch_inverse_ntt_poly_shard(
            dropped_coeff0,
            as_const_shard(dropped_ntt0),
            *parameter_shard,
            scratch.degree);
    }
    {
        NvtxRange range("keyswitch.finalize_rescale_x2.intt_dropped1");
        kernel::launch_inverse_ntt_poly_shard(
            dropped_coeff1,
            as_const_shard(dropped_ntt1),
            *parameter_shard,
            scratch.degree);
    }

    const std::size_t destination_q_count = destination_level_info.q_count;
    // POSEIDON_OPT_FUSED_RESCALE: centered remainders once per component, then
    // each correction is generated inside its forward NTT (no correction pass).
    bool correction_fused = false;
    if (opt_flag(OptFlag::FusedRescale) && destination_q_count >= 2)
    {
        NvtxRange range("keyswitch.finalize_rescale_x2.fused_correction_ntt");
        GpuWide *remainders =
            reinterpret_cast<GpuWide *>(scratch.relin_rescale_correction.data());
        kernel::launch_reconstruct_q_last_two_centered_remainders(
            remainders,
            scratch.relin_rescale_dropped_coeff.data(),
            2,
            *parameter_shard,
            scratch.degree);
        correction_fused = kernel::launch_fused_rescale_correction_65536(
            nullptr, nullptr,
            scratch.relin_rescale_correction_ntt.data(),
            nullptr, remainders, 2, destination_q_count, *parameter_shard);
        if (correction_fused &&
            !kernel::launch_fused_rescale_correction_65536(
                nullptr, nullptr,
                scratch.relin_rescale_correction_ntt.data() + destination_q_count * scratch.degree,
                nullptr, remainders + scratch.degree, 2, destination_q_count, *parameter_shard))
        {
            throw std::logic_error("finalize_rescale_x2: fused correction applied to one component only");
        }
    }
    if (!correction_fused)
    {
        NvtxRange range("keyswitch.finalize_rescale_x2.build_correction");
        kernel::launch_build_q_last_two_rescale_correction_batch_fused(
            scratch.relin_rescale_correction.data(),
            scratch.relin_rescale_dropped_coeff.data(),
            2,
            destination_q_count,
            *parameter_shard,
            scratch.degree);
    }

    GpuPolyShardView correction_ntt0{
        scratch.device_id,
        scratch.relin_rescale_correction_ntt.data(),
        0,
        destination_q_count,
        0,
        scratch.degree};
    GpuPolyShardView correction_ntt1{
        scratch.device_id,
        scratch.relin_rescale_correction_ntt.data() +
            destination_q_count * scratch.degree,
        0,
        destination_q_count,
        0,
        scratch.degree};
    GpuConstPolyShardView correction0{
        scratch.device_id,
        scratch.relin_rescale_correction.data(),
        0,
        destination_q_count,
        0,
        scratch.degree};
    GpuConstPolyShardView correction1{
        scratch.device_id,
        scratch.relin_rescale_correction.data() +
            destination_q_count * scratch.degree,
        0,
        destination_q_count,
        0,
        scratch.degree};
    if (!correction_fused)
    {
    {
        NvtxRange range("keyswitch.finalize_rescale_x2.ntt_correction0");
        kernel::launch_forward_ntt_poly_shard(
            correction_ntt0,
            correction0,
            *parameter_shard,
            scratch.degree);
    }
    {
        NvtxRange range("keyswitch.finalize_rescale_x2.ntt_correction1");
        kernel::launch_forward_ntt_poly_shard(
            correction_ntt1,
            correction1,
            *parameter_shard,
            scratch.degree);
    }
    }

    {
        NvtxRange range("keyswitch.finalize_rescale_x2.apply_retained");
        kernel::launch_hybrid_apply_moddown_ntt_add_back_rescale_x2(
            destination_shard0,
            destination_shard1,
            as_const_shard(correction_ntt0),
            as_const_shard(correction_ntt1),
            scratch.accum_q0.data(),
            scratch.accum_q1.data(),
            converted_q0,
            converted_q1,
            *parameter_shard,
            scratch.degree,
            &add_source_full0,
            &add_source_full1);
    }
}

void validate_single_full_shard(
    const char *name,
    const GpuConstRNSPolyView &poly,
    std::size_t degree,
    std::size_t limb_count)
{
    if (poly.shards.size() != 1)
    {
        throw std::invalid_argument(std::string(name) + ": expected one shard");
    }

    const auto &shard = poly.shards.front();
    if (shard.limb_begin != 0 ||
        shard.limb_count != limb_count ||
        shard.coeff_begin != 0 ||
        shard.coeff_count != degree)
    {
        throw std::invalid_argument(
            std::string(name) + ": expected a full coefficient, full limb shard");
    }
}

void validate_single_full_shard(
    const char *name,
    const GpuRNSPolyView &poly,
    std::size_t degree,
    std::size_t limb_count)
{
    if (poly.shards.size() != 1)
    {
        throw std::invalid_argument(std::string(name) + ": expected one shard");
    }

    const auto &shard = poly.shards.front();
    if (shard.limb_begin != 0 ||
        shard.limb_count != limb_count ||
        shard.coeff_begin != 0 ||
        shard.coeff_count != degree)
    {
        throw std::invalid_argument(
            std::string(name) + ": expected a full coefficient, full limb shard");
    }
}

void validate_hybrid_relinearize_shape(
    const GpuCiphertextView &destination,
    const GpuConstCiphertextView &source,
    const GpuConstEvaluationKeyView &relin_keys,
    const GpuEvaluationKeyData &relin_key_data,
    const GpuLevelInfo &level_info)
{
    if (!(destination.meta.parms_id == source.meta.parms_id) ||
        !(source.meta.parms_id == level_info.parms_id))
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: parms_id mismatch");
    }
    if (!source.meta.is_ntt_form || !destination.meta.is_ntt_form)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: CKKS inputs must be in NTT form");
    }
    if (source.polys.size() != 3 || source.meta.component_count != 3)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: source must have three components");
    }
    if (destination.polys.size() != 2 || destination.meta.component_count != 2)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: destination must have two components");
    }
    if (source.meta.degree != destination.meta.degree ||
        source.meta.degree != level_info.degree ||
        source.meta.q_count != destination.meta.q_count ||
        source.meta.q_count != level_info.q_count ||
        source.meta.p_count != 0 ||
        destination.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: shape mismatch");
    }
    if (!(relin_keys.meta.key_parms_id == relin_key_data.meta.key_parms_id) ||
        relin_keys.storage_q_count != relin_key_data.meta.q_count ||
        relin_keys.meta.q_count != source.meta.q_count ||
        relin_keys.meta.key_count == 0 ||
        relin_keys.meta.decomposition_count == 0 ||
        relin_keys.meta.component_count < kSwitchKeyComponentCount)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: invalid relin key metadata");
    }
    if (relin_key_data.poly_metadata_.empty() ||
        relin_key_data.polys_.size() != relin_keys.polys.size())
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: invalid relin key layout");
    }

    for (std::size_t component = 0; component < source.polys.size(); ++component)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler source",
            source.polys[component],
            source.meta.degree,
            source.meta.q_count);
        if (!same_shard_placement(
                source.polys[0].shards.front(),
                source.polys[component].shards.front()))
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: source shard placement mismatch");
        }
    }

    for (std::size_t component = 0; component < destination.polys.size(); ++component)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler destination",
            destination.polys[component],
            destination.meta.degree,
            destination.meta.q_count);
        if (!same_shard_placement(
                destination.polys[component].shards.front(),
                source.polys[component].shards.front()))
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::relinearize_hybrid_ciphertext: destination/source shard placement mismatch");
        }
    }
}

void validate_hybrid_switch_key_shape(
    const GpuCiphertextView &destination,
    const GpuConstRNSPolyView &switch_poly_ntt,
    const GpuConstEvaluationKeyView &switch_keys,
    const GpuEvaluationKeyData &switch_key_data,
    std::size_t key_index,
    const GpuLevelInfo &level_info)
{
    if (!(destination.meta.parms_id == level_info.parms_id))
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: parms_id mismatch");
    }
    if (!destination.meta.is_ntt_form)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: destination must be in NTT form");
    }
    if (destination.polys.size() != 2 || destination.meta.component_count != 2)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: destination must have two components");
    }
    if (destination.meta.degree != level_info.degree ||
        destination.meta.q_count != level_info.q_count ||
        destination.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: destination shape mismatch");
    }
    if (switch_poly_ntt.shards.size() != 1)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: switch poly must have one shard");
    }
    validate_single_full_shard(
        "GpuKeySwitchHandler switch poly",
        switch_poly_ntt,
        destination.meta.degree,
        destination.meta.q_count);

    for (std::size_t component = 0; component < destination.polys.size(); ++component)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler switch destination",
            destination.polys[component],
            destination.meta.degree,
            destination.meta.q_count);
        if (!same_shard_placement(
                destination.polys[component].shards.front(),
                switch_poly_ntt.shards.front()))
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: destination/switch-poly shard placement mismatch");
        }
    }

    if (!(switch_keys.meta.key_parms_id == switch_key_data.meta.key_parms_id) ||
        switch_keys.storage_q_count != switch_key_data.meta.q_count ||
        switch_keys.meta.q_count != destination.meta.q_count ||
        switch_keys.meta.key_count <= key_index ||
        switch_keys.meta.decomposition_count == 0 ||
        switch_keys.meta.component_count < kSwitchKeyComponentCount)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: invalid key metadata");
    }
    if (switch_key_data.poly_metadata_.empty() ||
        switch_key_data.polys_.size() != switch_keys.polys.size())
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: invalid key layout");
    }
}

}  // namespace

struct GpuKeySwitchHandler::PersistentWorkspace
{
    HybridScratch relinearize;
    // Concurrent application lanes (streams other than the per-thread
    // default stream) each get their own relinearization scratch.
    std::map<cudaStream_t, std::unique_ptr<HybridScratch>> lane_relinearize;
    HybridScratch &relinearize_for_stream()
    {
        const cudaStream_t stream = gpu_execution_stream();
        if (stream == cudaStreamPerThread)
        {
            return relinearize;
        }
        auto &slot = lane_relinearize[stream];
        if (!slot)
        {
            slot = std::make_unique<HybridScratch>();
        }
        return *slot;
    }
    // [batch][limb][N] until keymul, then [component][batch][limb][N].
    DeviceVector<GpuWord> pair_c2_coeff, pair_weighted;
    DeviceVector<GpuWord> pair_modup_q, pair_modup_p;
    DeviceVector<GpuWord> pair_partial_q, pair_partial_p;
    DeviceVector<GpuWord> pair_accum_q, pair_accum_p, pair_p_coeff;
    DeviceVector<GpuWord> pair_converted_coeff, pair_converted_ntt;
    // Optional lifetime-packed alternative. Keep v1 allocations intact when
    // toggling, since an existing CUDA Graph may still reference their data.
    DeviceVector<GpuWord> pair_arena;

    // Persistent scratch for batched dnum=1 rotations (Conv / Shortcut).
    DeviceVector<GpuWord> rot_permuted_c1;
    DeviceVector<GpuWord> rot_c1_coeff;
    DeviceVector<GpuWord> rot_modup_p;
    DeviceVector<GpuWord> rot_accum_q;
    DeviceVector<GpuWord> rot_accum_p;
    DeviceVector<GpuWord> rot_p_coeff;
    DeviceVector<GpuWord> rot_converted_q;
};

GpuKeySwitchHandler::GpuKeySwitchHandler(const GpuParameterData &params)
    : params_(params),
      persistent_workspace_(new PersistentWorkspace())
{}

GpuKeySwitchHandler::~GpuKeySwitchHandler() = default;

std::size_t GpuKeySwitchHandler::retained_workspace_bytes(
    const rmm::mr::device_memory_resource *resource) const
{
    const auto &scratch = persistent_workspace_->relinearize;
    std::size_t bytes = 0;
    for (const auto *buffer : {
             &scratch.c2_intt, &scratch.modup_q, &scratch.modup_p,
             &scratch.accum_q0, &scratch.accum_q1, &scratch.accum_p0, &scratch.accum_p1,
             &scratch.fourstep_q0, &scratch.fourstep_q1,
             &scratch.fourstep_p0, &scratch.fourstep_p1,
             &scratch.relin_rescale_dropped_ntt, &scratch.relin_rescale_dropped_coeff,
             &scratch.relin_rescale_correction, &scratch.relin_rescale_correction_ntt})
        bytes += buffer->allocated_bytes(resource);
    const auto &pair = *persistent_workspace_;
    for (const auto *buffer : {
             &pair.pair_c2_coeff, &pair.pair_weighted,
             &pair.pair_modup_q, &pair.pair_modup_p,
             &pair.pair_partial_q, &pair.pair_partial_p,
             &pair.pair_accum_q, &pair.pair_accum_p, &pair.pair_p_coeff,
             &pair.pair_converted_coeff, &pair.pair_converted_ntt, &pair.pair_arena,
             &pair.rot_permuted_c1, &pair.rot_c1_coeff, &pair.rot_modup_p,
             &pair.rot_accum_q, &pair.rot_accum_p,
             &pair.rot_p_coeff, &pair.rot_converted_q})
        bytes += buffer->allocated_bytes(resource);
    return bytes;
}

void GpuKeySwitchHandler::hoist_decompose_modup_ntt(
    const GpuConstRNSPolyView &switch_poly_ntt,
    const GpuLevelInfo &level_info,
    GpuHoistedDecomposition &destination,
    GpuHybridKeySwitchWorkspace &workspace,
    const GpuWord *precomputed_source_intt_q,
    bool precomputed_source_preweighted) const
{
    NvtxRange range("double_hoist.decompose");
    validate_single_full_shard(
        "GpuKeySwitchHandler::hoist_decompose_modup_ntt",
        switch_poly_ntt,
        level_info.degree,
        level_info.q_count);
    const auto &source_shard = switch_poly_ntt.shards.front();
    const auto *parameter_shard =
        find_parameter_shard(level_info, source_shard);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::hoist_decompose_modup_ntt: no matching parameter shard");
    }

    const std::size_t q_count = level_info.q_count;
    const std::size_t p_count = parameter_shard->hybrid_base_p_count;
    if (p_count == 0 ||
        parameter_shard->hybrid_base_q_count != q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::hoist_decompose_modup_ntt: invalid HYBRID base");
    }
    const std::size_t dnum = (q_count + p_count - 1) / p_count;
    const std::size_t q_words = q_count * level_info.degree;
    const std::size_t p_words = p_count * level_info.degree;

    workspace.ensure_capacity(
        source_shard.device_id,
        level_info.degree,
        q_count,
        p_count);
    const bool shape_changed =
        destination.device_id != source_shard.device_id ||
        destination.degree != level_info.degree ||
        destination.q_count != q_count ||
        destination.p_count != p_count ||
        destination.dnum != dnum;
    const bool digit_capacity_insufficient =
        shape_changed ||
        destination.digits_q_ntt.size() < dnum * q_words ||
        destination.digits_p_ntt.size() < dnum * p_words;
    if (digit_capacity_insufficient)
    {
        destination.digits_q_ntt.allocate(
            dnum * q_words,
            source_shard.device_id);
        destination.digits_p_ntt.allocate(
            dnum * p_words,
            source_shard.device_id);
    }
    if (precomputed_source_intt_q == nullptr &&
        (shape_changed || destination.source_intt_q.size() < q_words))
    {
        destination.source_intt_q.allocate(
            q_words,
            source_shard.device_id);
    }
    destination.parms_id = level_info.parms_id;
    destination.device_id = source_shard.device_id;
    destination.degree = level_info.degree;
    destination.q_count = q_count;
    destination.p_count = p_count;
    destination.dnum = dnum;

    const GpuWord *source_intt_q = precomputed_source_intt_q;
    bool source_preweighted =
        source_intt_q != nullptr && precomputed_source_preweighted;
    if (source_intt_q == nullptr)
    {
        GpuPolyShardView intt_q;
        intt_q.device_id = source_shard.device_id;
        intt_q.ptr = destination.source_intt_q.data();
        intt_q.limb_begin = 0;
        intt_q.limb_count = q_count;
        intt_q.coeff_begin = 0;
        intt_q.coeff_count = level_info.degree;
        // POSEIDON_OPT_MODUP_FOLD: every digit below takes the generic ModUp.
        const bool qp_fourstep =
            use_double_hoist_p9_qp_fourstep(level_info.degree, p_count);
        const bool fuse_phase1 = qp_fourstep &&
            (use_p9_modup_fourstep_compact_preweight(level_info.degree, p_count) ||
             use_p9_modup_fourstep_phase1_fused(level_info.degree, p_count));
        const bool generic_modup =
            !fuse_phase1 &&
            !use_double_hoist_p9_modup_row_tiled8(level_info.degree, p_count) &&
            p_count <= 64;
        const GpuWord *table = generic_modup && kernel::modup_fold_applicable(level_info.degree)
            ? kernel::hybrid_q_preweighted_inv_degree_table(*parameter_shard)
            : nullptr;
        if (table != nullptr &&
            kernel::launch_inverse_ntt_poly_shard_scaled_65536(
                intt_q, source_shard, *parameter_shard, level_info.degree, table))
        {
            source_preweighted = true;
        }
        else
        {
        kernel::launch_inverse_ntt_poly_shard(
            intt_q,
            source_shard,
            *parameter_shard,
            level_info.degree);
        }
        source_intt_q = intt_q.ptr;
    }

    for (std::size_t digit = 0; digit < dnum; ++digit)
    {
        const std::size_t limb_begin = digit * p_count;
        const std::size_t limb_count =
            std::min(p_count, q_count - limb_begin);
        GpuWord *digit_q =
            destination.digits_q_ntt.data() + digit * q_words;
        GpuWord *digit_p =
            destination.digits_p_ntt.data() + digit * p_words;
        const bool qp_fourstep = use_double_hoist_p9_qp_fourstep(
            level_info.degree,
            p_count);
        const bool compact_preweight = qp_fourstep &&
            use_p9_modup_fourstep_compact_preweight(
                level_info.degree,
                p_count);
        const bool fuse_modup_phase1 = qp_fourstep &&
            (compact_preweight ||
            use_p9_modup_fourstep_phase1_fused(
                level_info.degree,
                p_count));
        GpuWord *modup_q = qp_fourstep && !fuse_modup_phase1
            ? workspace.permuted_digit_q.data()
            : digit_q;
        GpuWord *modup_p = qp_fourstep && !fuse_modup_phase1
            ? workspace.permuted_digit_p.data()
            : digit_p;

        if (fuse_modup_phase1)
        {
            const bool source_preweighted =
                compact_preweight && limb_count > 1;
            const unsigned int target_limb_tile = source_preweighted
                ? p9_modup_fourstep_grouped_targets()
                : 1;
            const GpuWord *modup_source = source_intt_q;
            if (source_preweighted)
            {
                NvtxRange preweight_range(
                    "double_hoist.decompose.modup.compact_preweight_p9");
                kernel::launch_hybrid_preweight_modup_source_p9(
                    workspace.permuted_digit_p.data(),
                    source_intt_q,
                    digit,
                    limb_begin,
                    limb_count,
                    *parameter_shard,
                    level_info.degree);
                modup_source = workspace.permuted_digit_p.data();
            }
            NvtxRange modup_range(
                source_preweighted
                    ? "double_hoist.decompose.modup_fourstep_phase1.compact_preweight_p9"
                    : "double_hoist.decompose.modup_fourstep_phase1.fused_p9");
            kernel::launch_hybrid_modup_p9_forward_ntt_qp_active_phase1_fourstep_65536(
                digit_q,
                digit_p,
                modup_source,
                digit,
                limb_begin,
                limb_count,
                *parameter_shard,
                level_info.degree,
                source_preweighted,
                target_limb_tile);
        }
        else if (use_double_hoist_p9_modup_row_tiled8(
                level_info.degree,
                p_count))
        {
            NvtxRange modup_range(
                "double_hoist.decompose.modup.p9.row_tiled8");
            kernel::launch_hybrid_modup_decomposition_row_tiled8(
                modup_q,
                modup_p,
                source_intt_q,
                digit,
                limb_begin,
                limb_count,
                *parameter_shard,
                level_info.degree);
        }
        else
        {
            NvtxRange modup_range(
                "double_hoist.decompose.modup.generic");
            kernel::launch_hybrid_modup_decomposition(
                modup_q,
                modup_p,
                source_intt_q,
                source_shard.ptr,
                digit,
                limb_begin,
                limb_count,
                *parameter_shard,
                level_info.degree,
                source_preweighted);
        }

        /*
         * launch_hybrid_modup_decomposition deliberately skips the Q limbs
         * which belong to this decomposition block: the monolithic
         * KeySwitch path reads those values directly from switch_poly_ntt.
         * A persistent hoisted digit must instead be self-contained because
         * later Galois permutations and pre-rotated KeyMult consume the full
         * [Q|P] digit. Fill the skipped, already-NTT Q interval from the
         * original switch polynomial before transforming the active limbs.
         *
         * Across all digits these contiguous copies cover Q exactly once.
         */
        const std::size_t copied_q_words =
            limb_count * level_info.degree;
        gpu_check_cuda(
            cudaMemcpyAsync(
                digit_q + limb_begin * level_info.degree,
                source_shard.ptr + limb_begin * level_info.degree,
                copied_q_words * sizeof(GpuWord),
                cudaMemcpyDeviceToDevice,
                gpu_execution_stream()),
            "double-hoist copy decomposition Q limbs");
        if (qp_fourstep)
        {
            NvtxRange ntt_range(
                "double_hoist.decompose.qp_forward_ntt.fourstep_p9");
            kernel::launch_forward_ntt_qp_active_fourstep_65536(
                digit_q,
                digit_p,
                modup_q,
                modup_p,
                limb_begin,
                limb_count,
                *parameter_shard,
                level_info.degree,
                fuse_modup_phase1);
        }
        else
        {
            NvtxRange ntt_range(
                "double_hoist.decompose.qp_forward_ntt.generic");
            kernel::launch_hybrid_forward_ntt_qp_active(
                digit_q,
                digit_p,
                limb_begin,
                limb_count,
                *parameter_shard,
                level_info.degree);
        }
    }
}

void GpuKeySwitchHandler::hoist_decompose_modup_ntt_batch(
    const GpuWord *source_ntt_batch,
    std::size_t source_ntt_batch_stride,
    const GpuWord *source_intt_batch,
    bool source_preweighted,
    std::size_t batch_count,
    const GpuLevelInfo &level_info,
    DeviceVector<GpuWord> &digits_q_ntt_batch,
    DeviceVector<GpuWord> &digits_p_ntt_batch,
    DeviceVector<GpuWord> &modup_q_batch,
    DeviceVector<GpuWord> &modup_p_batch,
    bool skip_self_q_copy) const
{
    if (batch_count == 0)
    {
        return;
    }
    NvtxRange range("double_hoist.decompose_batch");
    if (source_ntt_batch == nullptr || source_intt_batch == nullptr ||
        level_info.degree != 65536 || level_info.shards.empty())
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::hoist_decompose_modup_ntt_batch: invalid arguments");
    }
    int device_id = level_info.shards.front().device_id;
    if (level_info.shards.size() > 1)
    {
        gpu_check_cuda(cudaGetDevice(&device_id),
                       "hoist_decompose_modup_ntt_batch cudaGetDevice");
    }
    GpuConstPolyShardView probe{
        device_id, source_ntt_batch, 0, level_info.q_count, 0, level_info.degree};
    const auto *parameter_shard = find_parameter_shard(level_info, probe);
    if (parameter_shard == nullptr || parameter_shard->hybrid_base_p_count == 0 ||
        parameter_shard->hybrid_base_q_count != level_info.q_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::hoist_decompose_modup_ntt_batch: no matching parameter shard");
    }

    const std::size_t degree = level_info.degree;
    const std::size_t q_count = level_info.q_count;
    const std::size_t p_count = parameter_shard->hybrid_base_p_count;
    const std::size_t dnum = (q_count + p_count - 1) / p_count;
    const std::size_t q_words = q_count * degree;
    const std::size_t p_words = p_count * degree;
    const std::size_t total_digit_q = batch_count * dnum * q_words;
    const std::size_t total_digit_p = batch_count * dnum * p_words;
    const auto ensure_buf = [device_id](DeviceVector<GpuWord> &buf, std::size_t words) {
        if (buf.device_id() != device_id || buf.size() < words)
        {
            buf.allocate(words, device_id);
        }
    };
    if (!skip_self_q_copy || dnum > 1)
    {
        ensure_buf(digits_q_ntt_batch, total_digit_q);
    }
    ensure_buf(digits_p_ntt_batch, total_digit_p);
    ensure_buf(modup_p_batch, batch_count * p_words);
    if (dnum > 1)
    {
        ensure_buf(modup_q_batch, batch_count * q_words);
    }

    for (std::size_t digit = 0; digit < dnum; ++digit)
    {
        const std::size_t limb_begin = digit * p_count;
        const std::size_t limb_count = std::min(p_count, q_count - limb_begin);
        GpuWord *digit_q_base =
            (!skip_self_q_copy || dnum > 1)
                ? digits_q_ntt_batch.data() + digit * q_words
                : nullptr;
        GpuWord *digit_p_base = digits_p_ntt_batch.data() + digit * p_words;
        GpuWord *modup_q_ptr = limb_count < q_count ? modup_q_batch.data() : nullptr;
        GpuWord *modup_p_ptr = modup_p_batch.data();

        kernel::launch_hybrid_modup_decomposition_batch(
            modup_q_ptr,
            modup_p_ptr,
            source_intt_batch,
            digit,
            limb_begin,
            limb_count,
            batch_count,
            q_words,
            q_words,
            p_words,
            *parameter_shard,
            degree,
            source_preweighted);

        if (!skip_self_q_copy)
        {
            kernel::launch_copy_strided_q_limbs_batch(
                digit_q_base + limb_begin * degree,
                source_ntt_batch + limb_begin * degree,
                limb_count,
                degree,
                batch_count,
                dnum * q_words,
                source_ntt_batch_stride,
                device_id);
        }

        kernel::launch_forward_ntt_qp_active_batch_fourstep_65536(
            digit_q_base,
            digit_p_base,
            modup_q_ptr,
            modup_p_ptr,
            limb_begin,
            limb_count,
            batch_count,
            dnum * q_words,
            dnum * p_words,
            q_words,
            p_words,
            *parameter_shard,
            degree);
    }
}

void GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown(
    const GpuHoistedDecomposition &hoisted,
    const GpuWord *source_q0,
    const GpuWord *source_q1,
    const std::uint32_t *galois_elts,
    const std::size_t *key_indices,
    std::size_t batch_count,
    const GpuConstEvaluationKeyView &keys,
    const GpuEvaluationKeyData &key_storage,
    GpuQPCiphertextBuffer &destination,
    std::size_t destination_batch_begin,
    const GpuLevelInfo &level_info) const
{
    if (batch_count == 0)
    {
        return;
    }
    NvtxRange range("double_hoist.keymult_batch_no_moddown");
    if (!(hoisted.parms_id == level_info.parms_id) ||
        hoisted.degree != level_info.degree ||
        hoisted.q_count != level_info.q_count ||
        hoisted.p_count == 0 || hoisted.dnum == 0 ||
        hoisted.dnum > kernel::kMaxHoistedKeymulBatchDigits)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown: unsupported hoisted shape");
    }
    if (destination_batch_begin + batch_count > destination.batch_count ||
        destination.degree != hoisted.degree ||
        destination.q_count != hoisted.q_count ||
        destination.p_count != hoisted.p_count ||
        destination.device_id != hoisted.device_id)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown: destination shape mismatch");
    }
    if (keys.meta.q_count != hoisted.q_count ||
        keys.meta.p_count != hoisted.p_count ||
        keys.storage_q_count != key_storage.meta.q_count ||
        galois_elts == nullptr || key_indices == nullptr || source_q0 == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown: key/pointer mismatch");
    }

    GpuConstPolyShardView level_probe{
        hoisted.device_id, hoisted.digits_q_ntt.data(), 0, hoisted.q_count, 0, hoisted.degree};
    const auto *parameter_shard = find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown: no matching parameter shard");
    }

    const bool pre_rotated =
        keys.meta.galois_format == GpuGaloisKeyFormat::InversePreRotated;
    const std::size_t dnum = hoisted.dnum;

    for (std::size_t offset = 0;
         offset < batch_count;
         offset += kernel::kMaxDoubleHoistFusedBabySteps)
    {
        const std::size_t chunk = std::min(
            kernel::kMaxDoubleHoistFusedBabySteps,
            batch_count - offset);
        kernel::HoistedKeymulBatchArgs q_args{};
        kernel::HoistedKeymulBatchArgs p_args{};
        for (std::size_t b = 0; b < chunk; ++b)
        {
            const std::uint32_t galois_elt = galois_elts[offset + b];
            q_args.galois_elts[b] = galois_elt;
            p_args.galois_elts[b] = galois_elt;
            if (galois_elt == 0)
            {
                continue;
            }
            const std::size_t key_index = key_indices[offset + b];
            if (key_index >= keys.meta.key_count)
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown: key_index out of range");
            }
            if (pre_rotated &&
                (key_storage.galois_elts_by_key_index.size() <= key_index ||
                 key_storage.galois_elts_by_key_index[key_index] != galois_elt))
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::keyswitch_hoisted_batch_no_moddown: Galois element mismatch");
            }
            for (std::size_t d = 0; d < dnum; ++d)
            {
                const auto k0 = make_hybrid_key_component_view(
                    find_key_poly(keys, key_storage, key_index, d, 0), keys, key_storage);
                const auto k1 = make_hybrid_key_component_view(
                    find_key_poly(keys, key_storage, key_index, d, 1), keys, key_storage);
                q_args.key0[b * dnum + d] = k0.q_ptr;
                q_args.key1[b * dnum + d] = k1.q_ptr;
                p_args.key0[b * dnum + d] = k0.p_ptr;
                p_args.key1[b * dnum + d] = k1.p_ptr;
            }
        }
        kernel::launch_double_hoist_hoisted_keymul_batch(
            destination.q_component(destination_batch_begin + offset, 0),
            destination.p_component(destination_batch_begin + offset, 0),
            hoisted.digits_q_ntt.data(),
            hoisted.digits_p_ntt.data(),
            source_q0,
            source_q1,
            q_args,
            p_args,
            chunk,
            dnum,
            pre_rotated,
            *parameter_shard,
            hoisted.degree);
    }
}

void GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown(
    const GpuHoistedDecomposition &hoisted,
    const GpuWord *source_q0,
    const std::uint32_t *galois_elts,
    const std::size_t *key_indices,
    std::size_t batch_count,
    const GpuConstEvaluationKeyView &keys,
    const GpuEvaluationKeyData &key_storage,
    GpuQPCiphertextBuffer &destination,
    std::size_t destination_batch,
    const GpuLevelInfo &level_info) const
{
    if (batch_count == 0)
    {
        return;
    }
    NvtxRange range("double_hoist.keymult_hoisted_sum");
    if (!(hoisted.parms_id == level_info.parms_id) ||
        hoisted.degree != level_info.degree ||
        hoisted.q_count != level_info.q_count ||
        hoisted.p_count == 0 || hoisted.dnum == 0 ||
        hoisted.dnum > kernel::kMaxHoistedKeymulBatchDigits)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: hoisted shape mismatch");
    }
    if (destination_batch >= destination.batch_count ||
        destination.degree != hoisted.degree ||
        destination.q_count != hoisted.q_count ||
        destination.p_count != hoisted.p_count ||
        destination.device_id != hoisted.device_id)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: destination shape mismatch");
    }
    if (keys.meta.q_count != hoisted.q_count ||
        keys.meta.p_count != hoisted.p_count ||
        keys.storage_q_count != key_storage.meta.q_count ||
        galois_elts == nullptr || key_indices == nullptr || source_q0 == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: key/pointer mismatch");
    }

    GpuConstPolyShardView level_probe{
        hoisted.device_id, hoisted.digits_q_ntt.data(), 0, hoisted.q_count, 0, hoisted.degree};
    const auto *parameter_shard = find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: no matching parameter shard");
    }

    const bool pre_rotated =
        keys.meta.galois_format == GpuGaloisKeyFormat::InversePreRotated;
    const std::size_t dnum = hoisted.dnum;

    for (std::size_t offset = 0;
         offset < batch_count;
         offset += kernel::kMaxDoubleHoistFusedBabySteps)
    {
        const std::size_t chunk = std::min(
            kernel::kMaxDoubleHoistFusedBabySteps,
            batch_count - offset);
        kernel::HoistedKeymulBatchArgs q_args{};
        kernel::HoistedKeymulBatchArgs p_args{};
        for (std::size_t b = 0; b < chunk; ++b)
        {
            const std::uint32_t galois_elt = galois_elts[offset + b];
            if (galois_elt == 0)
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: zero step is not supported");
            }
            q_args.galois_elts[b] = galois_elt;
            p_args.galois_elts[b] = galois_elt;
            const std::size_t key_index = key_indices[offset + b];
            if (key_index >= keys.meta.key_count)
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: key_index out of range");
            }
            if (pre_rotated &&
                (key_storage.galois_elts_by_key_index.size() <= key_index ||
                 key_storage.galois_elts_by_key_index[key_index] != galois_elt))
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::keyswitch_hoisted_sum_no_moddown: Galois element mismatch");
            }
            for (std::size_t d = 0; d < dnum; ++d)
            {
                const auto k0 = make_hybrid_key_component_view(
                    find_key_poly(keys, key_storage, key_index, d, 0), keys, key_storage);
                const auto k1 = make_hybrid_key_component_view(
                    find_key_poly(keys, key_storage, key_index, d, 1), keys, key_storage);
                q_args.key0[b * dnum + d] = k0.q_ptr;
                q_args.key1[b * dnum + d] = k1.q_ptr;
                p_args.key0[b * dnum + d] = k0.p_ptr;
                p_args.key1[b * dnum + d] = k1.p_ptr;
            }
        }
        kernel::launch_double_hoist_hoisted_keymul_sum(
            destination.q_component(destination_batch, 0),
            destination.p_component(destination_batch, 0),
            destination.q_component(destination_batch, 1),
            destination.p_component(destination_batch, 1),
            hoisted.digits_q_ntt.data(),
            hoisted.digits_p_ntt.data(),
            source_q0,
            q_args,
            p_args,
            chunk,
            dnum,
            pre_rotated,
            offset == 0,
            *parameter_shard,
            hoisted.degree);
    }
}

void GpuKeySwitchHandler::keyswitch_multsum_no_moddown(
    const GpuHoistedDecomposition &hoisted,
    std::uint32_t galois_elt,
    const GpuConstEvaluationKeyView &keys,
    const GpuEvaluationKeyData &key_storage,
    std::size_t key_index,
    GpuQPCiphertextBuffer &destination,
    std::size_t destination_batch,
    bool initialize,
    const GpuLevelInfo &level_info,
    GpuHybridKeySwitchWorkspace &workspace,
    const GpuWord *lifted_c0_source_q) const
{
    NvtxRange range("double_hoist.keymult_no_moddown");
    if (!(hoisted.parms_id == level_info.parms_id) ||
        hoisted.degree != level_info.degree ||
        hoisted.q_count != level_info.q_count ||
        hoisted.p_count == 0 || hoisted.dnum == 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: hoisted shape mismatch");
    }
    if (destination_batch >= destination.batch_count ||
        destination.degree != hoisted.degree ||
        destination.q_count != hoisted.q_count ||
        destination.p_count != hoisted.p_count ||
        destination.device_id != hoisted.device_id)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: destination shape mismatch");
    }
    if (keys.meta.q_count != hoisted.q_count ||
        keys.meta.p_count != hoisted.p_count ||
        keys.storage_q_count != key_storage.meta.q_count ||
        key_index >= keys.meta.key_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: key metadata mismatch");
    }

    GpuConstPolyShardView level_probe;
    level_probe.device_id = hoisted.device_id;
    level_probe.ptr = hoisted.digits_q_ntt.data();
    level_probe.limb_begin = 0;
    level_probe.limb_count = hoisted.q_count;
    level_probe.coeff_begin = 0;
    level_probe.coeff_count = hoisted.degree;
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: no matching parameter shard");
    }
    workspace.ensure_capacity(
        hoisted.device_id,
        hoisted.degree,
        hoisted.q_count,
        hoisted.p_count);

    const std::size_t q_words = hoisted.q_count * hoisted.degree;
    const std::size_t p_words = hoisted.p_count * hoisted.degree;
    const bool inverse_pre_rotated =
        keys.meta.galois_format ==
        GpuGaloisKeyFormat::InversePreRotated;
    if (lifted_c0_source_q != nullptr && !inverse_pre_rotated)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: "
            "fused c0 requires inverse-pre-rotated keys");
    }
    if (inverse_pre_rotated &&
        (key_storage.galois_elts_by_key_index.size() <= key_index ||
         key_storage.galois_elts_by_key_index[key_index] != galois_elt))
    {
        std::string present;
        for (const auto element : key_storage.galois_elts_by_key_index)
            if (element != 0) present += " " + std::to_string(element);
        throw std::invalid_argument(
            "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: "
            "pre-rotated key/Galois-element mismatch (galois_elt=" +
            std::to_string(galois_elt) + " level q=" + std::to_string(level_info.q_count) +
            " key P=" + std::to_string(key_storage.meta.p_count) + " key elements:" + present + ")");
    }
    if (inverse_pre_rotated)
    {
        const std::size_t pointer_offset =
            key_index * key_storage.meta.decomposition_count;
        const std::size_t pointer_end =
            pointer_offset + hoisted.dnum;
        if (key_storage.galois_key_q0_ptrs.size() < pointer_end ||
            key_storage.galois_key_p0_ptrs.size() < pointer_end ||
            key_storage.galois_key_q1_ptrs.size() < pointer_end ||
            key_storage.galois_key_p1_ptrs.size() < pointer_end)
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::keyswitch_multsum_no_moddown: "
                "pre-rotated key pointer tables are incomplete");
        }
        kernel::launch_double_hoist_pre_rotated_keymul_batch(
            destination.q_component(destination_batch, 0),
            destination.p_component(destination_batch, 0),
            destination.q_component(destination_batch, 1),
            destination.p_component(destination_batch, 1),
            hoisted.digits_q_ntt.data(),
            hoisted.digits_p_ntt.data(),
            key_storage.galois_key_q0_ptrs.data() + pointer_offset,
            key_storage.galois_key_p0_ptrs.data() + pointer_offset,
            key_storage.galois_key_q1_ptrs.data() + pointer_offset,
            key_storage.galois_key_p1_ptrs.data() + pointer_offset,
            hoisted.dnum,
            galois_elt,
            initialize,
            lifted_c0_source_q,
            *parameter_shard,
            hoisted.degree);
        return;
    }
    for (std::size_t digit = 0; digit < hoisted.dnum; ++digit)
    {
        const GpuWord *digit_q =
            hoisted.digits_q_ntt.data() + digit * q_words;
        const GpuWord *digit_p =
            hoisted.digits_p_ntt.data() + digit * p_words;

        const GpuWord *active_digit_q = digit_q;
        const GpuWord *active_digit_p = digit_p;
        if (!inverse_pre_rotated)
        {
            GpuPolyShardView permuted_q{
                hoisted.device_id,
                workspace.permuted_digit_q.data(),
                0,
                hoisted.q_count,
                0,
                hoisted.degree};
            GpuConstPolyShardView digit_q_view{
                hoisted.device_id,
                digit_q,
                0,
                hoisted.q_count,
                0,
                hoisted.degree};
            kernel::launch_apply_galois_ntt_poly_shard(
                permuted_q,
                digit_q_view,
                galois_elt,
                hoisted.degree);

            GpuPolyShardView permuted_p{
                hoisted.device_id,
                workspace.permuted_digit_p.data(),
                hoisted.q_count,
                hoisted.p_count,
                0,
                hoisted.degree};
            GpuConstPolyShardView digit_p_view{
                hoisted.device_id,
                digit_p,
                hoisted.q_count,
                hoisted.p_count,
                0,
                hoisted.degree};
            kernel::launch_apply_galois_ntt_poly_shard(
                permuted_p,
                digit_p_view,
                galois_elt,
                hoisted.degree);
            active_digit_q = workspace.permuted_digit_q.data();
            active_digit_p = workspace.permuted_digit_p.data();
        }

        const auto &key0_poly = find_key_poly(
            keys,
            key_storage,
            key_index,
            digit,
            0);
        const auto &key1_poly = find_key_poly(
            keys,
            key_storage,
            key_index,
            digit,
            1);
        const auto key0 =
            make_hybrid_key_component_view(key0_poly, keys, key_storage);
        const auto key1 =
            make_hybrid_key_component_view(key1_poly, keys, key_storage);

        const std::size_t decomp_limb_begin = digit * hoisted.p_count;
        const std::size_t decomp_limb_count = std::min(
            hoisted.p_count,
            hoisted.q_count - decomp_limb_begin);
        if (inverse_pre_rotated)
        {
            kernel::launch_double_hoist_pre_rotated_keymul_digit(
                destination.q_component(destination_batch, 0),
                destination.p_component(destination_batch, 0),
                destination.q_component(destination_batch, 1),
                destination.p_component(destination_batch, 1),
                active_digit_q,
                active_digit_p,
                key0.q_ptr,
                key0.p_ptr,
                key1.q_ptr,
                key1.p_ptr,
                galois_elt,
                initialize && digit == 0,
                *parameter_shard,
                hoisted.degree);
        }
        else
        {
            kernel::launch_hybrid_multiply_accumulate_two_components(
                destination.q_component(destination_batch, 0),
                destination.p_component(destination_batch, 0),
                destination.q_component(destination_batch, 1),
                destination.p_component(destination_batch, 1),
                active_digit_q,
                active_digit_p,
                active_digit_q,
                key0.q_ptr,
                key0.p_ptr,
                key1.q_ptr,
                key1.p_ptr,
                *parameter_shard,
                hoisted.degree,
                decomp_limb_begin,
                decomp_limb_count,
                initialize && digit == 0);
        }
    }
}

void GpuKeySwitchHandler::moddown_qp_ciphertext_to_q(
    GpuQPCiphertextBuffer &source,
    std::size_t source_batch,
    GpuCiphertextData &destination,
    const GpuCiphertextMeta &destination_meta,
    const GpuLevelInfo &level_info,
    GpuHybridKeySwitchWorkspace &workspace,
    const GpuCiphertextData *add_source) const
{
    NvtxRange range("double_hoist.moddown");
    if (source_batch >= source.batch_count ||
        source.degree != level_info.degree ||
        source.q_count != level_info.q_count ||
        source.p_count == 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_to_q: source shape mismatch");
    }
    if (add_source != nullptr &&
        (add_source == &destination || add_source->empty() ||
         add_source->size() != 2 || !add_source->meta.is_ntt_form ||
         add_source->meta.degree != source.degree ||
         add_source->meta.q_count != source.q_count ||
         add_source->meta.p_count != 0 ||
         add_source->fields_.size() != 1 ||
         add_source->fields_.front().device_id != source.device_id))
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_to_q: invalid add_source");
    }
    GpuConstPolyShardView level_probe{
        source.device_id,
        source.q_component(source_batch, 0),
        0,
        source.q_count,
        0,
        source.degree};
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count != source.p_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_to_q: no matching parameter shard");
    }
    workspace.ensure_capacity(
        source.device_id,
        source.degree,
        source.q_count,
        source.p_count);

    const bool reusable =
        !destination.empty() &&
        destination.meta.degree == source.degree &&
        destination.meta.q_count == source.q_count &&
        destination.meta.p_count == 0 &&
        destination.meta.component_count == 2 &&
        destination.fields_.size() == 1 &&
        destination.fields_.front().device_id == source.device_id;
    if (!reusable)
    {
        destination = GpuCiphertextData::allocate_single_device(
            source.degree,
            source.q_count,
            2,
            source.device_id);
    }
    destination.meta = destination_meta;
    destination.meta.degree = source.degree;
    destination.meta.q_count = source.q_count;
    destination.meta.p_count = 0;
    destination.meta.component_count = 2;
    destination.meta.is_ntt_form = true;

    auto destination_view = destination.make_view();

    GpuPolyShardView p_coeff0{
        source.device_id,
        workspace.p_coeff0.data(),
        source.q_count,
        source.p_count,
        0,
        source.degree};
    GpuPolyShardView p_coeff1{
        source.device_id,
        workspace.p_coeff1.data(),
        source.q_count,
        source.p_count,
        0,
        source.degree};
    GpuConstPolyShardView p_ntt0{
        source.device_id,
        source.p_component(source_batch, 0),
        source.q_count,
        source.p_count,
        0,
        source.degree};
    GpuConstPolyShardView p_ntt1{
        source.device_id,
        source.p_component(source_batch, 1),
        source.q_count,
        source.p_count,
        0,
        source.degree};
    const bool p_preweighted = inverse_p_parts_for_p_to_q(
        p_coeff0, p_ntt0, p_coeff1, p_ntt1, *parameter_shard, source.degree);
    launch_double_hoist_p_to_q_forward_ntt(
        workspace.converted_q0.data(),
        workspace.converted_q1.data(),
        workspace.p_coeff0.data(),
        workspace.p_coeff1.data(),
        *parameter_shard,
        source.degree,
        p_preweighted);
    if (add_source != nullptr)
    {
        const auto add_view = add_source->make_const_view();
        kernel::launch_hybrid_apply_moddown_ntt_add_back(
            destination_view.polys[0].shards.front(),
            destination_view.polys[1].shards.front(),
            source.q_component(source_batch, 0),
            source.q_component(source_batch, 1),
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            *parameter_shard,
            source.degree,
            &add_view.polys[0].shards.front(),
            &add_view.polys[1].shards.front());
    }
    else
    {
        kernel::launch_hybrid_apply_moddown_ntt_out_of_place(
            destination_view.polys[0].shards.front().ptr,
            destination_view.polys[1].shards.front().ptr,
            source.q_component(source_batch, 0),
            source.q_component(source_batch, 1),
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            *parameter_shard,
            source.degree);
    }
}

void GpuKeySwitchHandler::moddown_qp_ciphertext_to_q_c2s_split(
    GpuQPCiphertextBuffer &source,
    std::size_t source_batch,
    const GpuCiphertextData &dft_result,
    const GpuPlaintextData &minus_i_plaintext,
    GpuCiphertextData &result_real,
    GpuCiphertextData &result_imag,
    const GpuLevelInfo &level_info,
    GpuHybridKeySwitchWorkspace &workspace) const
{
    NvtxRange range("double_hoist.moddown_c2s_split");
    if (source_batch >= source.batch_count ||
        source.degree != level_info.degree ||
        source.q_count != level_info.q_count ||
        source.p_count == 0 ||
        &result_real == &result_imag ||
        &result_real == &dft_result ||
        &result_imag == &dft_result)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_to_q_c2s_split: shape/alias mismatch");
    }
    GpuConstPolyShardView level_probe{
        source.device_id,
        source.q_component(source_batch, 0),
        0,
        source.q_count,
        0,
        source.degree};
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count != source.p_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_to_q_c2s_split: no matching parameter shard");
    }
    workspace.ensure_capacity(
        source.device_id,
        source.degree,
        source.q_count,
        source.p_count);

    const auto ensure_dest = [&](GpuCiphertextData &dst, double scale) {
        const bool reusable =
            !dst.empty() &&
            dst.meta.degree == source.degree &&
            dst.meta.q_count == source.q_count &&
            dst.meta.p_count == 0 &&
            dst.meta.component_count == 2 &&
            dst.fields_.size() == 1 &&
            dst.fields_.front().device_id == source.device_id &&
            dst.polys_.size() == 2 &&
            dst.polys_[0].shards.size() == 1 &&
            dst.polys_[1].shards.size() == 1;
        if (!reusable)
        {
            dst = GpuCiphertextData::allocate_single_device(
                source.degree,
                source.q_count,
                2,
                source.device_id);
        }
        dst.meta = dft_result.meta;
        dst.meta.degree = source.degree;
        dst.meta.q_count = source.q_count;
        dst.meta.p_count = 0;
        dst.meta.component_count = 2;
        dst.meta.is_ntt_form = true;
        dst.meta.scale = scale;
    };
    ensure_dest(result_real, dft_result.meta.scale);
    ensure_dest(result_imag, dft_result.meta.scale * minus_i_plaintext.meta.scale);

    GpuPolyShardView p_coeff0{
        source.device_id, workspace.p_coeff0.data(), source.q_count, source.p_count, 0, source.degree};
    GpuPolyShardView p_coeff1{
        source.device_id, workspace.p_coeff1.data(), source.q_count, source.p_count, 0, source.degree};
    GpuConstPolyShardView p_ntt0{
        source.device_id, source.p_component(source_batch, 0), source.q_count, source.p_count, 0, source.degree};
    GpuConstPolyShardView p_ntt1{
        source.device_id, source.p_component(source_batch, 1), source.q_count, source.p_count, 0, source.degree};
    const bool p_preweighted = inverse_p_parts_for_p_to_q(
        p_coeff0, p_ntt0, p_coeff1, p_ntt1, *parameter_shard, source.degree);
    launch_double_hoist_p_to_q_forward_ntt(
        workspace.converted_q0.data(),
        workspace.converted_q1.data(),
        workspace.p_coeff0.data(),
        workspace.p_coeff1.data(),
        *parameter_shard,
        source.degree,
        p_preweighted);

    auto real_view = result_real.make_view();
    auto imag_view = result_imag.make_view();
    const auto dft_view = dft_result.make_const_view();
    const auto minus_i_view = minus_i_plaintext.make_const_view();
    kernel::launch_hybrid_apply_moddown_ntt_c2s_split(
        real_view.polys[0].shards.front(),
        real_view.polys[1].shards.front(),
        imag_view.polys[0].shards.front(),
        imag_view.polys[1].shards.front(),
        dft_view.polys[0].shards.front(),
        dft_view.polys[1].shards.front(),
        minus_i_view.poly.shards.front(),
        source.q_component(source_batch, 0),
        source.q_component(source_batch, 1),
        workspace.converted_q0.data(),
        workspace.converted_q1.data(),
        *parameter_shard,
        source.degree);
}

bool GpuKeySwitchHandler::try_moddown_qp_ciphertext_to_q_rescale(
    GpuQPCiphertextBuffer &source,
    std::size_t source_batch,
    GpuCiphertextData &destination,
    const GpuCiphertextMeta &product_meta,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info,
    std::uint32_t drop_count,
    GpuHybridKeySwitchWorkspace &workspace) const
{
    if ((drop_count != 1 && drop_count != 2) ||
        source_batch >= source.batch_count ||
        source.degree != 65536 ||
        source.degree != source_level_info.degree ||
        source.degree != destination_level_info.degree ||
        source.q_count != source_level_info.q_count ||
        source.q_count <= drop_count ||
        destination_level_info.q_count + drop_count != source.q_count ||
        source.p_count == 0)
    {
        return false;
    }
    const char *joint_mode = std::getenv("POSEIDON_GPU_RELIN_RESCALE_MERGED");
    if (joint_mode != nullptr && std::string(joint_mode) == "0")
    {
        return false;
    }
    GpuConstPolyShardView level_probe{
        source.device_id,
        source.q_component(source_batch, 0),
        0,
        source.q_count,
        0,
        source.degree};
    const auto *parameter_shard =
        find_parameter_shard(source_level_info, level_probe);
    const std::size_t retained = destination_level_info.q_count;
    if (parameter_shard == nullptr ||
        parameter_shard->limb_begin != 0 ||
        parameter_shard->hybrid_base_q_count != source.q_count ||
        parameter_shard->hybrid_base_p_count != source.p_count ||
        parameter_shard->hybrid_inv_p_mod_q.size() < source.q_count ||
        parameter_shard->fourstep_intt_tables.data() == nullptr ||
        parameter_shard->fourstep_intt_tables.size() < source.q_count * source.degree ||
        parameter_shard->ntt_tables.size() < retained * source.degree)
    {
        return false;
    }
    if (drop_count == 1)
    {
        if (parameter_shard->q_last == 0 ||
            parameter_shard->half_q_last_mod_q.size() < retained ||
            parameter_shard->inv_q_last_mod_q.size() < retained)
        {
            return false;
        }
    }
    else
    {
        if (parameter_shard->q_last_two_product == 0 ||
            parameter_shard->q_last_two_product_mod_q.size() < retained ||
            parameter_shard->inv_q_last_two_product_mod_q.size() < retained)
        {
            return false;
        }
    }
    const double divisor = drop_count == 1
        ? static_cast<double>(parameter_shard->q_last)
        : static_cast<double>(parameter_shard->q_last_two_product);
    if (!(divisor > 0.0) || !std::isfinite(divisor))
    {
        return false;
    }
    const double out_scale = product_meta.scale / divisor;
    if (!(out_scale > 0.0) || !std::isfinite(out_scale))
    {
        return false;
    }

    NvtxRange range("double_hoist.moddown_rescale");
    workspace.ensure_capacity(
        source.device_id,
        source.degree,
        source.q_count,
        source.p_count);

    const bool reusable =
        !destination.empty() &&
        destination.meta.degree == source.degree &&
        destination.meta.q_count == retained &&
        destination.meta.p_count == 0 &&
        destination.meta.component_count == 2 &&
        destination.fields_.size() == 1 &&
        destination.fields_.front().device_id == source.device_id;
    if (!reusable)
    {
        destination = GpuCiphertextData::allocate_single_device(
            source.degree,
            retained,
            2,
            source.device_id);
    }
    destination.meta = product_meta;
    destination.meta.parms_id = destination_level_info.parms_id;
    destination.meta.degree = source.degree;
    destination.meta.q_count = retained;
    destination.meta.p_count = 0;
    destination.meta.component_count = 2;
    destination.meta.is_ntt_form = true;
    destination.meta.scale = out_scale;

    auto destination_view = destination.make_view();

    GpuPolyShardView p_coeff0{
        source.device_id, workspace.p_coeff0.data(), source.q_count, source.p_count, 0, source.degree};
    GpuPolyShardView p_coeff1{
        source.device_id, workspace.p_coeff1.data(), source.q_count, source.p_count, 0, source.degree};
    GpuConstPolyShardView p_ntt0{
        source.device_id, source.p_component(source_batch, 0), source.q_count, source.p_count, 0, source.degree};
    GpuConstPolyShardView p_ntt1{
        source.device_id, source.p_component(source_batch, 1), source.q_count, source.p_count, 0, source.degree};
    const bool p_preweighted = inverse_p_parts_for_p_to_q(
        p_coeff0, p_ntt0, p_coeff1, p_ntt1, *parameter_shard, source.degree);
    kernel::launch_hybrid_convert_p_to_q_coeff_lazy(
        workspace.converted_q0.data(),
        workspace.converted_q1.data(),
        workspace.p_coeff0.data(),
        workspace.p_coeff1.data(),
        *parameter_shard,
        source.degree,
        p_preweighted);

    GpuWord *tail0 = workspace.moddown_rescale_dropped_ntt.data();
    GpuWord *tail1 = tail0 + drop_count * source.degree;
    GpuWord *tail_coeff0 = workspace.moddown_rescale_dropped_coeff.data();
    GpuWord *tail_coeff1 = tail_coeff0 + drop_count * source.degree;

    if (drop_count == 1)
    {
        kernel::launch_hybrid_relin_rescale_x1_tail(
            tail0, tail1,
            source.q_component(source_batch, 0),
            source.q_component(source_batch, 1),
            nullptr, nullptr,
            *parameter_shard, source.degree, false);
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            tail_coeff0, tail_coeff1,
            tail0, tail1,
            source.q_count - 1, 1, *parameter_shard);
        kernel::launch_hybrid_relin_rescale_x1_merge_correction(
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            tail_coeff0, tail_coeff1,
            *parameter_shard, source.degree, false);
        kernel::launch_forward_ntt_two_components_inplace_fourstep_65536(
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            retained,
            *parameter_shard);
        kernel::launch_hybrid_relin_rescale_x1_apply(
            destination_view.polys[0].shards.front().ptr,
            destination_view.polys[1].shards.front().ptr,
            source.q_component(source_batch, 0),
            source.q_component(source_batch, 1),
            nullptr, nullptr,
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            *parameter_shard, source.degree, false);
    }
    else
    {
        kernel::launch_hybrid_relin_rescale_x2_tail(
            tail0, tail1,
            source.q_component(source_batch, 0),
            source.q_component(source_batch, 1),
            nullptr, nullptr,
            *parameter_shard, source.degree);
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            tail_coeff0, tail_coeff1,
            tail0, tail1,
            source.q_count - 2, 2, *parameter_shard);
        kernel::launch_hybrid_relin_rescale_x2_merge_correction(
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            tail_coeff0, tail_coeff1,
            *parameter_shard, source.degree);
        kernel::launch_forward_ntt_two_components_inplace_fourstep_65536(
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            retained,
            *parameter_shard);
        kernel::launch_hybrid_relin_rescale_x2_apply(
            destination_view.polys[0].shards.front().ptr,
            destination_view.polys[1].shards.front().ptr,
            source.q_component(source_batch, 0),
            source.q_component(source_batch, 1),
            nullptr, nullptr,
            workspace.converted_q0.data(),
            workspace.converted_q1.data(),
            *parameter_shard, source.degree);
    }
    return true;
}

void GpuKeySwitchHandler::moddown_qp_ciphertext_list_to_q(
    GpuQPCiphertextBuffer &source,
    std::size_t batch_count,
    std::vector<GpuCiphertextData> &destinations,
    const GpuCiphertextMeta &destination_meta,
    const GpuLevelInfo &level_info,
    GpuHybridKeySwitchWorkspace &workspace,
    DeviceVector<GpuWord> &batch_p_coeff,
    DeviceVector<GpuWord> &batch_converted_q) const
{
    if (batch_count == 0)
    {
        destinations.clear();
        return;
    }
    if (batch_count > source.batch_count ||
        source.degree != level_info.degree ||
        source.q_count != level_info.q_count ||
        source.p_count == 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_list_to_q: source shape mismatch");
    }
    GpuConstPolyShardView level_probe{
        source.device_id,
        source.q_component(0, 0),
        0,
        source.q_count,
        0,
        source.degree};
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count != source.p_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_list_to_q: no matching parameter shard");
    }

    destinations.resize(batch_count);
    const std::size_t total_limbs = source.q_count + source.p_count;
    const GpuWord *p_inverse =
        (batch_moddown_enabled() && opt_flag(OptFlag::PToQPreweight) &&
         source.degree == 65536 && source.p_count <= 64 &&
         parameter_shard->limb_begin == 0 &&
         parameter_shard->ntt_tables.size() >= total_limbs * 65536 &&
         parameter_shard->fourstep_intt_tables.size() >= total_limbs * 65536)
            ? kernel::hybrid_p_preweighted_inv_degree_table(*parameter_shard)
            : nullptr;

    if (p_inverse == nullptr)
    {
        for (std::size_t i = 0; i < batch_count; ++i)
        {
            moddown_qp_ciphertext_to_q(
                source, i, destinations[i], destination_meta, level_info, workspace);
        }
        return;
    }

    NvtxRange range("double_hoist.moddown_list_batch");
    for (std::size_t i = 0; i < batch_count; ++i)
    {
        auto &destination = destinations[i];
        const bool reusable =
            !destination.empty() &&
            destination.meta.degree == source.degree &&
            destination.meta.q_count == source.q_count &&
            destination.meta.p_count == 0 &&
            destination.meta.component_count == 2 &&
            destination.fields_.size() == 1 &&
            destination.fields_.front().device_id == source.device_id;
        if (!reusable)
        {
            destination = GpuCiphertextData::allocate_single_device(
                source.degree,
                source.q_count,
                2,
                source.device_id);
        }
        destination.meta = destination_meta;
        destination.meta.degree = source.degree;
        destination.meta.q_count = source.q_count;
        destination.meta.p_count = 0;
        destination.meta.component_count = 2;
        destination.meta.is_ntt_form = true;
    }

    constexpr std::size_t kMaxChunkCiphertexts = 16;
    const std::size_t max_chunk = std::min(batch_count, kMaxChunkCiphertexts);
    const std::size_t max_comp = 2 * max_chunk;
    const std::size_t p_component_words = source.p_count * source.degree;
    const std::size_t q_component_words = source.q_count * source.degree;
    if (batch_p_coeff.size() < max_comp * p_component_words ||
        batch_p_coeff.device_id() != source.device_id)
    {
        batch_p_coeff.allocate(max_comp * p_component_words, source.device_id);
    }
    if (batch_converted_q.size() < max_comp * q_component_words ||
        batch_converted_q.device_id() != source.device_id)
    {
        batch_converted_q.allocate(max_comp * q_component_words, source.device_id);
    }

    for (std::size_t offset = 0; offset < batch_count; offset += kMaxChunkCiphertexts)
    {
        const std::size_t chunk = std::min(kMaxChunkCiphertexts, batch_count - offset);
        const std::size_t comp_count = 2 * chunk;
        GpuPolyShardView p_coeff_view{
            source.device_id,
            batch_p_coeff.data(),
            source.q_count,
            source.p_count,
            0,
            source.degree};
        GpuConstPolyShardView p_ntt_view{
            source.device_id,
            source.p.data() + (2 * offset) * p_component_words,
            source.q_count,
            source.p_count,
            0,
            source.degree};
        kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
            p_coeff_view,
            p_ntt_view,
            *parameter_shard,
            source.degree,
            comp_count,
            p_component_words,
            p_component_words,
            p_inverse);
        kernel::launch_hybrid_convert_p_to_q_preweighted_batch(
            batch_converted_q.data(),
            batch_p_coeff.data(),
            comp_count,
            *parameter_shard,
            source.degree);
        kernel::BatchMutPolyPtrs32 dest_ptrs{};
        kernel::FusedModDownBatchArgs64 md_args{};
        for (std::size_t c = 0; c < chunk; ++c)
        {
            auto view = destinations[offset + c].make_view();
            dest_ptrs.ptrs[2 * c + 0] = view.polys[0].shards.front().ptr;
            dest_ptrs.ptrs[2 * c + 1] = view.polys[1].shards.front().ptr;
            md_args.dst[2 * c + 0] = dest_ptrs.ptrs[2 * c + 0];
            md_args.dst[2 * c + 1] = dest_ptrs.ptrs[2 * c + 1];
            md_args.accum_q[2 * c + 0] = source.q.data() + (2 * offset + 2 * c + 0) * q_component_words;
            md_args.accum_q[2 * c + 1] = source.q.data() + (2 * offset + 2 * c + 1) * q_component_words;
        }
        if (!kernel::launch_forward_ntt_moddown_batch_fourstep_65536(
                batch_converted_q.data(),
                batch_converted_q.data(),
                md_args,
                comp_count,
                false,
                false,
                *parameter_shard))
        {
            GpuPolyShardView conv_q_view{
                source.device_id,
                batch_converted_q.data(),
                0,
                source.q_count,
                0,
                source.degree};
            GpuConstPolyShardView conv_q_const_view{
                source.device_id,
                batch_converted_q.data(),
                0,
                source.q_count,
                0,
                source.degree};
            kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
                conv_q_view,
                conv_q_const_view,
                *parameter_shard,
                source.degree,
                comp_count);
            kernel::launch_hybrid_apply_moddown_ntt_multi_destinations(
                dest_ptrs,
                source.q.data(),
                2 * offset,
                batch_converted_q.data(),
                comp_count,
                *parameter_shard,
                source.degree);
        }
    }
}

void GpuKeySwitchHandler::moddown_qp_ciphertext_batch_to_q(
    GpuQPCiphertextBuffer &source,
    std::size_t batch_count,
    GpuQCiphertextBatchBuffer &destination,
    const GpuLevelInfo &level_info,
    DeviceVector<GpuWord> &p_coeff,
    DeviceVector<GpuWord> &converted_q) const
{
    NvtxRange range("double_hoist.moddown_batch");
    if (batch_count == 0 || batch_count > source.batch_count ||
        source.degree != level_info.degree ||
        source.q_count != level_info.q_count || source.p_count == 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_batch_to_q: "
            "source shape mismatch");
    }

    GpuConstPolyShardView level_probe{
        source.device_id,
        source.q_component(0, 0),
        0,
        source.q_count,
        0,
        source.degree};
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count != source.p_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_ciphertext_batch_to_q: "
            "no matching parameter shard");
    }

    destination.ensure_capacity(
        source.device_id,
        source.degree,
        source.q_count,
        batch_count);
    const std::size_t component_count = 2 * batch_count;
    const std::size_t p_component_words =
        source.p_count * source.degree;
    const std::size_t q_component_words =
        source.q_count * source.degree;
    const std::size_t p_words = component_count * p_component_words;
    const std::size_t q_words = component_count * q_component_words;
    if (p_coeff.size() < p_words ||
        p_coeff.device_id() != source.device_id)
    {
        p_coeff.allocate(p_words, source.device_id);
    }
    if (converted_q.size() < q_words ||
        converted_q.device_id() != source.device_id)
    {
        converted_q.allocate(q_words, source.device_id);
    }

    /*
     * Keep the parameter-selected NTT implementation. The tensor component
     * launcher requires setup-time TAM matrices which are intentionally not
     * mandatory for bootstrap parameters. We still stage all P INTTs before
     * the fused conversion/forward-NTT phase, instead of serializing a
     * complete ModDown pipeline per group.
     */
    const std::size_t total_limbs = source.q_count + source.p_count;
    if (batch_moddown_enabled() && opt_flag(OptFlag::PToQPreweight) &&
        source.degree == 65536 && source.p_count <= 64 &&
        component_count <= 64 && parameter_shard->limb_begin == 0 &&
        parameter_shard->ntt_tables.size() >= total_limbs * 65536 &&
        parameter_shard->fourstep_intt_tables.size() >= total_limbs * 65536)
    {
        if (const GpuWord *p_inverse =
                kernel::hybrid_p_preweighted_inv_degree_table(*parameter_shard))
        {
            GpuPolyShardView p_coeff_view{
                source.device_id,
                p_coeff.data(),
                source.q_count,
                source.p_count,
                0,
                source.degree};
            GpuConstPolyShardView p_ntt_view{
                source.device_id,
                source.p.data(),
                source.q_count,
                source.p_count,
                0,
                source.degree};
            kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
                p_coeff_view,
                p_ntt_view,
                *parameter_shard,
                source.degree,
                component_count,
                p_component_words,
                p_component_words,
                p_inverse);
            kernel::launch_hybrid_convert_p_to_q_preweighted_batch(
                converted_q.data(),
                p_coeff.data(),
                component_count,
                *parameter_shard,
                source.degree);
            kernel::FusedModDownBatchArgs64 md_args{};
            for (std::size_t c = 0; c < component_count; ++c)
            {
                md_args.dst[c] = destination.q.data() + c * q_component_words;
                md_args.accum_q[c] = source.q.data() + c * q_component_words;
            }
            if (!kernel::launch_forward_ntt_moddown_batch_fourstep_65536(
                    converted_q.data(),
                    converted_q.data(),
                    md_args,
                    component_count,
                    false,
                    false,
                    *parameter_shard))
            {
                GpuPolyShardView conv_q_view{
                    source.device_id,
                    converted_q.data(),
                    0,
                    source.q_count,
                    0,
                    source.degree};
                GpuConstPolyShardView conv_q_const_view{
                    source.device_id,
                    converted_q.data(),
                    0,
                    source.q_count,
                    0,
                    source.degree};
                kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
                    conv_q_view,
                    conv_q_const_view,
                    *parameter_shard,
                    source.degree,
                    component_count);
                kernel::launch_hybrid_apply_moddown_ntt_out_of_place_batch(
                    destination.q.data(),
                    source.q.data(),
                    converted_q.data(),
                    batch_count,
                    *parameter_shard,
                    source.degree);
            }
            return;
        }
    }

    bool p_preweighted = false;
    for (std::size_t component = 0;
         component < component_count;
         ++component)
    {
        const GpuPolyShardView p_coeff_component{
            source.device_id,
            p_coeff.data() + component * p_component_words,
            source.q_count,
            source.p_count,
            0,
            source.degree};
        const GpuConstPolyShardView p_ntt_component{
            source.device_id,
            source.p.data() + component * p_component_words,
            source.q_count,
            source.p_count,
            0,
            source.degree};
        const bool weighted = inverse_p_part_for_p_to_q(
            p_coeff_component,
            p_ntt_component,
            *parameter_shard,
            source.degree);
        if (component == 0)
        {
            p_preweighted = weighted;
        }
        else if (weighted != p_preweighted)
        {
            throw std::logic_error("batched ModDown: P->Q weight fold applied to some components only");
        }
    }

    /*
     * Preserve the existing two-component fusion: it combines P->Q basis
     * conversion with the first forward-NTT stage. Splitting that kernel just
     * to expose a larger batch increases global-memory traffic at N=16384.
     * The groups are still phase-scheduled (all INTTs first, then all fused
     * convert/NTTs, then one out-of-place apply).
     */
    for (std::size_t batch = 0; batch < batch_count; ++batch)
    {
        launch_double_hoist_p_to_q_forward_ntt(
            converted_q.data() +
                (batch * 2) * q_component_words,
            converted_q.data() +
                (batch * 2 + 1) * q_component_words,
            p_coeff.data() +
                (batch * 2) * p_component_words,
            p_coeff.data() +
                (batch * 2 + 1) * p_component_words,
            *parameter_shard,
            source.degree,
            p_preweighted);
    }

    kernel::launch_hybrid_apply_moddown_ntt_out_of_place_batch(
        destination.q.data(),
        source.q.data(),
        converted_q.data(),
        batch_count,
        *parameter_shard,
        source.degree);
}

void GpuKeySwitchHandler::moddown_qp_c1_groups_to_q(
    GpuQPCiphertextBuffer &source,
    const std::vector<std::uint32_t> &groups,
    std::size_t destination_batch_count,
    GpuQCiphertextBatchBuffer &destination,
    const GpuLevelInfo &level_info,
    DeviceVector<GpuWord> &p_coeff,
    DeviceVector<GpuWord> &converted_q) const
{
    NvtxRange range("double_hoist.moddown_c1_batch");
    const char *name = "GpuKeySwitchHandler::moddown_qp_c1_groups_to_q";
    if (groups.empty() ||
        groups.size() > kernel::kMaxSelectedModDownComponents ||
        destination_batch_count > source.batch_count ||
        source.degree != level_info.degree ||
        source.q_count != level_info.q_count || source.p_count == 0)
    {
        throw std::invalid_argument(std::string(name) + ": source shape mismatch");
    }
    for (const auto group : groups)
    {
        if (group >= destination_batch_count)
        {
            throw std::invalid_argument(std::string(name) + ": group out of range");
        }
    }
    GpuConstPolyShardView level_probe{
        source.device_id,
        source.q_component(0, 0),
        0,
        source.q_count,
        0,
        source.degree};
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count != source.p_count)
    {
        throw std::invalid_argument(std::string(name) + ": no matching parameter shard");
    }

    destination.ensure_capacity(
        source.device_id,
        source.degree,
        source.q_count,
        destination_batch_count);
    // The P->Q conversion kernels work on component pairs; an odd count is
    // padded with a copy of the last component whose result is not applied.
    const std::size_t count = groups.size();
    const std::size_t slots = count + (count & 1);
    const std::size_t p_component_words = source.p_count * source.degree;
    const std::size_t q_component_words = source.q_count * source.degree;
    if (p_coeff.size() < slots * p_component_words ||
        p_coeff.device_id() != source.device_id)
    {
        p_coeff.allocate(slots * p_component_words, source.device_id);
    }
    if (converted_q.size() < slots * q_component_words ||
        converted_q.device_id() != source.device_id)
    {
        converted_q.allocate(slots * q_component_words, source.device_id);
    }

    const std::size_t total_limbs = source.q_count + source.p_count;
    if (batch_moddown_enabled() && opt_flag(OptFlag::PToQPreweight) &&
        source.degree == 65536 && source.p_count <= 64 &&
        count <= 32 && parameter_shard->limb_begin == 0 &&
        parameter_shard->ntt_tables.size() >= total_limbs * 65536 &&
        parameter_shard->fourstep_intt_tables.size() >= total_limbs * 65536)
    {
        if (const GpuWord *p_inverse =
                kernel::hybrid_p_preweighted_inv_degree_table(*parameter_shard))
        {
            kernel::BatchConstPolyPtrs32 p_sources{};
            for (std::size_t slot = 0; slot < count; ++slot)
            {
                p_sources.ptrs[slot] = source.p_component(groups[slot], 1);
            }
            kernel::launch_inverse_ntt_multi_sources_fourstep_65536(
                p_coeff.data(),
                p_sources,
                source.q_count,
                source.p_count,
                count,
                *parameter_shard,
                p_inverse);
            kernel::launch_hybrid_convert_p_to_q_preweighted_batch(
                converted_q.data(),
                p_coeff.data(),
                count,
                *parameter_shard,
                source.degree);
            kernel::FusedModDownBatchArgs64 md_args{};
            for (std::size_t slot = 0; slot < count; ++slot)
            {
                const std::size_t comp_idx = static_cast<std::size_t>(groups[slot]) * 2 + 1;
                md_args.dst[slot] = destination.q.data() + comp_idx * q_component_words;
                md_args.accum_q[slot] = source.q.data() + comp_idx * q_component_words;
            }
            if (!kernel::launch_forward_ntt_moddown_batch_fourstep_65536(
                    converted_q.data(),
                    converted_q.data(),
                    md_args,
                    count,
                    false,
                    false,
                    *parameter_shard))
            {
                GpuPolyShardView conv_q_view{
                    source.device_id,
                    converted_q.data(),
                    0,
                    source.q_count,
                    0,
                    source.degree};
                GpuConstPolyShardView conv_q_const_view{
                    source.device_id,
                    converted_q.data(),
                    0,
                    source.q_count,
                    0,
                    source.degree};
                kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
                    conv_q_view,
                    conv_q_const_view,
                    *parameter_shard,
                    source.degree,
                    count);
                std::vector<std::uint32_t> component_indices(count);
                for (std::size_t slot = 0; slot < count; ++slot)
                {
                    component_indices[slot] = groups[slot] * 2 + 1;
                }
                kernel::launch_hybrid_apply_moddown_ntt_selected(
                    destination.q.data(),
                    source.q.data(),
                    converted_q.data(),
                    component_indices.data(),
                    count,
                    *parameter_shard,
                    source.degree);
            }
            return;
        }
    }

    bool p_preweighted = false;
    for (std::size_t slot = 0; slot < count; ++slot)
    {
        const GpuPolyShardView p_coeff_component{
            source.device_id,
            p_coeff.data() + slot * p_component_words,
            source.q_count,
            source.p_count,
            0,
            source.degree};
        const GpuConstPolyShardView p_ntt_component{
            source.device_id,
            source.p_component(groups[slot], 1),
            source.q_count,
            source.p_count,
            0,
            source.degree};
        const bool weighted = inverse_p_part_for_p_to_q(
            p_coeff_component,
            p_ntt_component,
            *parameter_shard,
            source.degree);
        if (slot == 0)
        {
            p_preweighted = weighted;
        }
        else if (weighted != p_preweighted)
        {
            throw std::logic_error("c1 ModDown: P->Q weight fold applied to some groups only");
        }
    }
    // POSEIDON_OPT_C1_NOPAD: convert the odd last group on its own instead of
    // padding it with a copy whose (discarded) conversion costs half a pair.
    std::size_t paired_slots = slots;
    if (slots != count && p_preweighted && opt_flag(OptFlag::C1GroupNoPad) &&
        kernel::launch_hybrid_convert_p_to_q_forward_ntt_single_preweighted(
            converted_q.data() + (count - 1) * q_component_words,
            p_coeff.data() + (count - 1) * p_component_words,
            *parameter_shard,
            source.degree))
    {
        paired_slots = count - 1;
    }
    else if (slots != count)
    {
        gpu_check_cuda(
            cudaMemcpyAsync(
                p_coeff.data() + count * p_component_words,
                p_coeff.data() + (count - 1) * p_component_words,
                p_component_words * sizeof(GpuWord),
                cudaMemcpyDeviceToDevice,
                gpu_execution_stream()),
            name);
    }
    for (std::size_t slot = 0; slot < paired_slots; slot += 2)
    {
        launch_double_hoist_p_to_q_forward_ntt(
            converted_q.data() + slot * q_component_words,
            converted_q.data() + (slot + 1) * q_component_words,
            p_coeff.data() + slot * p_component_words,
            p_coeff.data() + (slot + 1) * p_component_words,
            *parameter_shard,
            source.degree,
            p_preweighted);
    }

    std::vector<std::uint32_t> component_indices(count);
    for (std::size_t slot = 0; slot < count; ++slot)
    {
        component_indices[slot] = groups[slot] * 2 + 1;
    }
    kernel::launch_hybrid_apply_moddown_ntt_selected(
        destination.q.data(),
        source.q.data(),
        converted_q.data(),
        component_indices.data(),
        count,
        *parameter_shard,
        source.degree);
}

void GpuKeySwitchHandler::moddown_qp_groups_to_q(
    GpuQPCiphertextBuffer &source_groups,
    std::size_t group_count,
    DeviceVector<GpuWord> &reduced_p_ntt,
    GpuCiphertextData &destination,
    const GpuCiphertextMeta &destination_meta,
    const GpuLevelInfo &level_info,
    GpuHybridKeySwitchWorkspace &workspace) const
{
    NvtxRange range("double_hoist.moddown_grouped_outer");
    if (group_count == 0 || group_count > source_groups.batch_count ||
        source_groups.degree != level_info.degree ||
        source_groups.q_count != level_info.q_count ||
        source_groups.p_count == 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_groups_to_q: "
            "source shape mismatch");
    }
    GpuConstPolyShardView level_probe{
        source_groups.device_id,
        source_groups.q_component(0, 0),
        0,
        source_groups.q_count,
        0,
        source_groups.degree};
    const auto *parameter_shard =
        find_parameter_shard(level_info, level_probe);
    if (parameter_shard == nullptr ||
        parameter_shard->hybrid_base_p_count != source_groups.p_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::moddown_qp_groups_to_q: "
            "no matching parameter shard");
    }
    workspace.ensure_capacity(
        source_groups.device_id,
        source_groups.degree,
        source_groups.q_count,
        source_groups.p_count);

    const std::size_t p_component_words =
        source_groups.p_count * source_groups.degree;
    const std::size_t required_p_words = 2 * p_component_words;
    if (reduced_p_ntt.size() < required_p_words ||
        reduced_p_ntt.device_id() != source_groups.device_id)
    {
        reduced_p_ntt.allocate(
            required_p_words,
            source_groups.device_id);
    }
    kernel::launch_double_hoist_reduce_p_groups(
        reduced_p_ntt.data(),
        reduced_p_ntt.data() + p_component_words,
        source_groups.p.data(),
        group_count,
        *parameter_shard,
        source_groups.degree);

    const GpuPolyShardView p_coeff0{
        source_groups.device_id,
        workspace.p_coeff0.data(),
        source_groups.q_count,
        source_groups.p_count,
        0,
        source_groups.degree};
    const GpuPolyShardView p_coeff1{
        source_groups.device_id,
        workspace.p_coeff1.data(),
        source_groups.q_count,
        source_groups.p_count,
        0,
        source_groups.degree};
    const GpuConstPolyShardView p_ntt0{
        source_groups.device_id,
        reduced_p_ntt.data(),
        source_groups.q_count,
        source_groups.p_count,
        0,
        source_groups.degree};
    const GpuConstPolyShardView p_ntt1{
        source_groups.device_id,
        reduced_p_ntt.data() + p_component_words,
        source_groups.q_count,
        source_groups.p_count,
        0,
        source_groups.degree};
    const bool p_preweighted = inverse_p_parts_for_p_to_q(
        p_coeff0, p_ntt0, p_coeff1, p_ntt1, *parameter_shard, source_groups.degree);
    launch_double_hoist_p_to_q_forward_ntt(
        workspace.converted_q0.data(),
        workspace.converted_q1.data(),
        workspace.p_coeff0.data(),
        workspace.p_coeff1.data(),
        *parameter_shard,
        source_groups.degree,
        p_preweighted);

    const bool reusable =
        !destination.empty() &&
        destination.meta.degree == source_groups.degree &&
        destination.meta.q_count == source_groups.q_count &&
        destination.meta.p_count == 0 &&
        destination.meta.component_count == 2 &&
        destination.fields_.size() == 1 &&
        destination.fields_.front().device_id ==
            source_groups.device_id;
    if (!reusable)
    {
        destination = GpuCiphertextData::allocate_single_device(
            source_groups.degree,
            source_groups.q_count,
            2,
            source_groups.device_id);
    }
    destination.meta = destination_meta;
    destination.meta.degree = source_groups.degree;
    destination.meta.q_count = source_groups.q_count;
    destination.meta.p_count = 0;
    destination.meta.component_count = 2;
    destination.meta.is_ntt_form = true;
    auto destination_view = destination.make_view();
    kernel::launch_hybrid_apply_moddown_ntt_from_q_groups(
        destination_view.polys[0].shards.front().ptr,
        destination_view.polys[1].shards.front().ptr,
        source_groups.q.data(),
        workspace.converted_q0.data(),
        workspace.converted_q1.data(),
        group_count,
        *parameter_shard,
        source_groups.degree);
}

void GpuKeySwitchHandler::switch_key_hybrid_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstRNSPolyView &switch_poly_ntt,/*可以自由选择需要密钥切换的密文分量位置*/
    const GpuConstEvaluationKeyView &switch_keys_view,
    const GpuEvaluationKeyData &switch_keys_data,
    std::size_t key_index,/*可以自由选择密钥切换的密钥类型*/
    const GpuLevelInfo &level_info,
    std::shared_ptr<void> *workspace,
    const GpuConstRNSPolyView *add_source0) const
{
    switch_key_hybrid_ciphertext_impl(
        destination_view,
        switch_poly_ntt,
        switch_keys_view,
        switch_keys_data,
        key_index,
        level_info,
        add_source0,
        nullptr,
        nullptr,
        workspace);
}

void GpuKeySwitchHandler::switch_key_hybrid_ciphertext_impl(
    GpuCiphertextView &destination_view,
    const GpuConstRNSPolyView &switch_poly_ntt,
    const GpuConstEvaluationKeyView &switch_keys_view,
    const GpuEvaluationKeyData &switch_keys_data,
    std::size_t key_index,
    const GpuLevelInfo &level_info,
    const GpuConstRNSPolyView *add_source0,
    const GpuConstRNSPolyView *add_source1,
    const GpuLevelInfo *rescale_destination_level,
    std::shared_ptr<void> *workspace,
    bool double_moddown) const
{
    (void)params_;
    if (rescale_destination_level == nullptr)
    {
        validate_hybrid_switch_key_shape(
            destination_view,
            switch_poly_ntt,
            switch_keys_view,
            switch_keys_data,
            key_index,
            level_info);
    }
    else
    {
        const std::size_t q_drops =
            level_info.q_count > destination_view.meta.q_count
                ? level_info.q_count - destination_view.meta.q_count
                : 0;
        if (!(switch_poly_ntt.shards.size() == 1) ||
            !(destination_view.meta.parms_id ==
              rescale_destination_level->parms_id) ||
            destination_view.meta.degree != level_info.degree ||
            (q_drops != 1 && q_drops != 2) ||
            destination_view.meta.q_count !=
                rescale_destination_level->q_count ||
            destination_view.meta.p_count != 0 ||
            destination_view.polys.size() != 2 ||
            destination_view.meta.component_count != 2 ||
            switch_keys_view.meta.q_count != level_info.q_count ||
            switch_keys_view.storage_q_count != switch_keys_data.meta.q_count ||
            switch_keys_view.meta.key_count <= key_index ||
            switch_keys_view.meta.decomposition_count == 0 ||
            switch_keys_view.meta.component_count < kSwitchKeyComponentCount ||
            !(switch_keys_view.meta.key_parms_id ==
              switch_keys_data.meta.key_parms_id) ||
            switch_keys_data.poly_metadata_.empty())
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::switch_key_hybrid_ciphertext_rescale_x2: shape mismatch");
        }
        validate_single_full_shard(
            "GpuKeySwitchHandler switch poly rescale_x2",
            switch_poly_ntt,
            level_info.degree,
            level_info.q_count);
        for (const auto &poly : destination_view.polys)
        {
            validate_single_full_shard(
                "GpuKeySwitchHandler destination rescale_x2",
                poly,
                destination_view.meta.degree,
                destination_view.meta.q_count);
        }
        if (switch_keys_data.polys_.size() != switch_keys_view.polys.size())
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::switch_key_hybrid_ciphertext_rescale_x2: invalid key layout");
        }
    }

    const std::size_t base_q_size = level_info.q_count;
    const std::size_t base_p_size = switch_keys_view.meta.p_count;
    if (switch_keys_view.meta.q_count != base_q_size)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: active key Q prefix must match ciphertext q_count");
    }
    if (switch_keys_view.storage_q_count != switch_keys_data.meta.q_count ||
        switch_keys_view.storage_q_count < base_q_size)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: invalid full-key storage Q count");
    }
    if (base_p_size == 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: HYBRID requires key p limbs");
    }
    NvtxRange range(
        "keyswitch.hybrid.q" + std::to_string(base_q_size) +
        ".p" + std::to_string(base_p_size) +
        ".d" + std::to_string(
            (base_q_size + base_p_size - 1) / base_p_size));
    /* 计算dnum的分块数，向上取整，按base_p_size分块 */
    const std::size_t expected_decomposition_count =
        (base_q_size + base_p_size - 1) / base_p_size;
    if (switch_keys_view.meta.decomposition_count < expected_decomposition_count)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: key decomposition count is too small");
    }

    const int device_id = destination_view.polys[0].shards.front().device_id;
    /*
     * Relinearization repeatedly visits descending Q levels. Keep the largest
     * buffers alive and reinterpret only their active prefixes at lower
     * levels. The legacy path deliberately retains per-call allocation for
     * same-binary A/B measurements.
     */
    HybridScratch local_scratch;
    HybridScratch *scratch_ptr = nullptr;
    const bool persistent_relinearize =
        add_source0 != nullptr &&
        use_persistent_relinearize();
    if (workspace != nullptr)
    {
        if (!*workspace) *workspace = std::make_shared<HybridScratch>();
        auto owned = std::static_pointer_cast<HybridScratch>(*workspace);
        ensure_hybrid_scratch(*owned, device_id, destination_view.meta.degree,
                              base_q_size, base_p_size);
        scratch_ptr = owned.get();
    }
    else if (persistent_relinearize)
    {
        ensure_hybrid_scratch(
            persistent_workspace_->relinearize_for_stream(),
            device_id,
            destination_view.meta.degree,
            base_q_size,
            base_p_size);
        scratch_ptr = &persistent_workspace_->relinearize_for_stream();
    }
    else
    {
        local_scratch = allocate_hybrid_scratch(
            device_id,
            destination_view.meta.degree,
            base_q_size,
            base_p_size);
        scratch_ptr = &local_scratch;
    }
    HybridScratch &scratch = *scratch_ptr;
    /* 将待切换分量通过 INTT 从点值域转换到系数域 */
    inverse_ntt_switch_poly(
        scratch,
        switch_poly_ntt,
        level_info);

#if 0
    /* Retired all-dnum PAccum experiments. */
    if (use_paccum_final_tail())
    {
        NvtxRange paccum_range("keyswitch.paccum_final_tail");
        allocate_hybrid_paccum_all_dnum_scratch(
            scratch,
            expected_decomposition_count);

        std::vector<const GpuWord *> key0_ptrs(expected_decomposition_count);
        std::vector<const GpuWord *> key1_ptrs(expected_decomposition_count);
        const GpuParameterShard *paccum_parameter_shard = nullptr;

        for (std::size_t decomp_index = 0;
             decomp_index < expected_decomposition_count;
             ++decomp_index)
        {
            const std::size_t decomp_limb_begin = decomp_index * base_p_size;
            const std::size_t decomp_limb_count = std::min(
                base_p_size,
                base_q_size - decomp_limb_begin);

            const auto &key_component0 = find_key_poly(
                switch_keys_view,
                switch_keys_data,
                key_index,
                decomp_index,
                0);
            const auto &key_component1 = find_key_poly(
                switch_keys_view,
                switch_keys_data,
                key_index,
                decomp_index,
                1);

            validate_single_full_shard(
                "GpuKeySwitchHandler switch key c0",
                key_component0,
                switch_keys_view.meta.degree,
                switch_keys_view.meta.q_count + switch_keys_view.meta.p_count);
            validate_single_full_shard(
                "GpuKeySwitchHandler switch key c1",
                key_component1,
                switch_keys_view.meta.degree,
                switch_keys_view.meta.q_count + switch_keys_view.meta.p_count);

            const auto &key0_shard = key_component0.shards.front();
            const auto *parameter_shard =
                find_parameter_shard(level_info, key0_shard);
            if (parameter_shard == nullptr)
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: no matching final-tail parameter shard");
            }
            if (paccum_parameter_shard == nullptr)
            {
                paccum_parameter_shard = parameter_shard;
            }

            key0_ptrs[decomp_index] = key0_shard.ptr;
            key1_ptrs[decomp_index] =
                key_component1.shards.front().ptr;

            prepare_hybrid_decomposition_final_tail_block(
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                scratch,
                scratch.all_modup_q.data() +
                    decomp_index * scratch.q_word_count,
                scratch.all_modup_p.data() +
                    decomp_index * scratch.p_word_count,
                key_component0,
                key_component1,
                level_info);
        }

        scratch.key_qp0_by_dnum.copy_from_host(
            key0_ptrs.data(),
            key0_ptrs.size());
        scratch.key_qp1_by_dnum.copy_from_host(
            key1_ptrs.data(),
            key1_ptrs.size());

        if (paccum_parameter_shard == nullptr)
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: missing final-tail PAccum parameter shard");
        }

        {
            NvtxRange range(
                "keyswitch.paccum_final_tail.final_ntt_accumulate_all_dnum");
            kernel::launch_hybrid_final_ntt_paccum_all_dnum_two_components(
                scratch.accum_q0.data(),
                scratch.accum_p0.data(),
                scratch.accum_q1.data(),
                scratch.accum_p1.data(),
                scratch.all_modup_q.data(),
                scratch.all_modup_p.data(),
                switch_poly_ntt.shards.front().ptr,
                scratch.key_qp0_by_dnum.data(),
                scratch.key_qp1_by_dnum.data(),
                expected_decomposition_count,
                *paccum_parameter_shard,
                scratch.degree);
        }
    }
    else if (use_paccum_all_dnum())
    {
        NvtxRange paccum_range("keyswitch.paccum_all_dnum");
        allocate_hybrid_paccum_all_dnum_scratch(
            scratch,
            expected_decomposition_count);

        std::vector<const GpuWord *> key0_ptrs(expected_decomposition_count);
        std::vector<const GpuWord *> key1_ptrs(expected_decomposition_count);
        const GpuParameterShard *paccum_parameter_shard = nullptr;

        for (std::size_t decomp_index = 0;
             decomp_index < expected_decomposition_count;
             ++decomp_index)
        {
            const std::size_t decomp_limb_begin = decomp_index * base_p_size;
            const std::size_t decomp_limb_count = std::min(
                base_p_size,
                base_q_size - decomp_limb_begin);

            const auto &key_component0 = find_key_poly(
                switch_keys_view,
                switch_keys_data,
                key_index,
                decomp_index,
                0);
            const auto &key_component1 = find_key_poly(
                switch_keys_view,
                switch_keys_data,
                key_index,
                decomp_index,
                1);

            validate_single_full_shard(
                "GpuKeySwitchHandler switch key c0",
                key_component0,
                switch_keys_view.meta.degree,
                switch_keys_view.meta.q_count + switch_keys_view.meta.p_count);
            validate_single_full_shard(
                "GpuKeySwitchHandler switch key c1",
                key_component1,
                switch_keys_view.meta.degree,
                switch_keys_view.meta.q_count + switch_keys_view.meta.p_count);

            const auto &key0_shard = key_component0.shards.front();
            const auto *parameter_shard =
                find_parameter_shard(level_info, key0_shard);
            if (parameter_shard == nullptr)
            {
                throw std::invalid_argument(
                    "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: no matching parameter shard");
            }
            if (paccum_parameter_shard == nullptr)
            {
                paccum_parameter_shard = parameter_shard;
            }

            key0_ptrs[decomp_index] = key0_shard.ptr;
            key1_ptrs[decomp_index] =
                key_component1.shards.front().ptr;

            prepare_hybrid_decomposition_ntt_block(
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                scratch,
                scratch.all_modup_q.data() +
                    decomp_index * scratch.q_word_count,
                scratch.all_modup_p.data() +
                    decomp_index * scratch.p_word_count,
                switch_poly_ntt,
                key_component0,
                key_component1,
                level_info);
        }

        scratch.key_qp0_by_dnum.copy_from_host(
            key0_ptrs.data(),
            key0_ptrs.size());
        scratch.key_qp1_by_dnum.copy_from_host(
            key1_ptrs.data(),
            key1_ptrs.size());

        if (paccum_parameter_shard == nullptr)
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::switch_key_hybrid_ciphertext: missing PAccum parameter shard");
        }

        {
            NvtxRange range("keyswitch.paccum.accumulate_all_dnum");
            kernel::launch_hybrid_paccum_all_dnum_two_components(
                scratch.accum_q0.data(),
                scratch.accum_p0.data(),
                scratch.accum_q1.data(),
                scratch.accum_p1.data(),
                scratch.all_modup_q.data(),
                scratch.all_modup_p.data(),
                switch_poly_ntt.shards.front().ptr,
                scratch.key_qp0_by_dnum.data(),
                scratch.key_qp1_by_dnum.data(),
                expected_decomposition_count,
                *paccum_parameter_shard,
                scratch.degree);
        }
    }
    else
#endif
    {
        const bool fuse_decomp_q = use_fused_decomp_q();
        const bool fuse_modup_ntt_head = use_fused_modup_ntt_head();
        const bool bconv_row_tiled = use_bconv_row_tiled();
        const bool bconv_row_tiled8 = use_bconv_row_tiled8();
        /* 分块循环：每个 dnum 分块做 ModUp + NTT + 密钥乘加累加 */
        for (std::size_t decomp_index = 0;
             decomp_index < expected_decomposition_count;
             ++decomp_index)
        {
            /* 计算在dnum块中的起始位置，因为是按照p_size进行分块的，所以现在在块内循环，块index*块大小可以定位起始地址位置*/
            const std::size_t decomp_limb_begin = decomp_index * base_p_size;
            const std::size_t decomp_limb_count = std::min(
                base_p_size,
                base_q_size - decomp_limb_begin);

            /* find_key_poly主要用来从已经上传到 GPU 里，找到某一个具体的 key 多项式 */
            /* 主要原因是 CPU 侧的密钥是分层的：key index + dnum 分块 + ksk0/ksk1 分量 */
            const auto &key_component0 = find_key_poly(
                switch_keys_view,
                switch_keys_data,
                key_index,
                decomp_index,
                0);
            const auto &key_component1 = find_key_poly(
                switch_keys_view,
                switch_keys_data,
                key_index,
                decomp_index,
                1);

            validate_single_full_shard(
                "GpuKeySwitchHandler switch key c0",
                key_component0,
                switch_keys_data.meta.degree,
                switch_keys_data.meta.q_count + switch_keys_data.meta.p_count);
            validate_single_full_shard(
                "GpuKeySwitchHandler switch key c1",
                key_component1,
                switch_keys_data.meta.degree,
                switch_keys_data.meta.q_count + switch_keys_data.meta.p_count);

            const auto key_component0_level =
                make_hybrid_key_component_view(
                    key_component0,
                    switch_keys_view,
                    switch_keys_data);
            const auto key_component1_level =
                make_hybrid_key_component_view(
                    key_component1,
                    switch_keys_view,
                    switch_keys_data);

            /* 处理每一个 dnum 分块的函数，负责模升+NTT+乘密钥累加*/
            process_hybrid_decomposition_block(
                decomp_index,
                decomp_limb_begin,
                decomp_limb_count,
                scratch,
                switch_poly_ntt,
                key_component0_level,
                key_component1_level,
                level_info,
                fuse_decomp_q,
                fuse_modup_ntt_head,
                bconv_row_tiled,
                bconv_row_tiled8);
        }
    }

    /* INTT 模降 NTT 和原密文分量求和 */
    if (rescale_destination_level == nullptr)
    {
        finalize_hybrid_relinearize(
            destination_view,
            scratch,
            level_info,
            add_source0,
            add_source1);
    }
    else if (rescale_destination_level->q_count + 1 == level_info.q_count)
    {
        finalize_hybrid_relinearize_rescale_x1(
            destination_view,
            scratch,
            level_info,
            *rescale_destination_level,
            add_source0,
            add_source1,
            double_moddown);
    }
    else
    {
        finalize_hybrid_relinearize_rescale_x2(
            destination_view,
            scratch,
            level_info,
            *rescale_destination_level,
            add_source0,
            add_source1);
    }
}

void GpuKeySwitchHandler::relinearize_hybrid_ciphertext(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &source_view,
    const GpuConstEvaluationKeyView &relin_keys_view,
    const GpuEvaluationKeyData &relin_keys_data,
    const GpuLevelInfo &level_info) const
{
    validate_hybrid_relinearize_shape(
        destination_view,
        source_view,
        relin_keys_view,
        relin_keys_data,
        level_info);

    if (!use_persistent_relinearize())
    {
        /*
         * Legacy A/B path: two synchronous D2D copies followed by a fresh
         * KeySwitch scratch allocation.
         */
        copy_initial_components(destination_view, source_view);
        switch_key_hybrid_ciphertext(
            destination_view,
            source_view.polys[2],
            relin_keys_view,
            relin_keys_data,
            kRelinKeyPower2Index,
            level_info);
        return;
    }

    /*
     * Out-of-place finalize: the ModDown kernel reads source c0/c1 directly
     * and writes source + switched(c2) to the destination. No synchronous
     * pre-copy is needed.
     */
    switch_key_hybrid_ciphertext_impl(
        destination_view,
        source_view.polys[2],
        relin_keys_view,
        relin_keys_data,
        kRelinKeyPower2Index,
        level_info,
        &source_view.polys[0],
        &source_view.polys[1]);
}

bool GpuKeySwitchHandler::try_relinearize_hybrid_ciphertext_pair(
    GpuCiphertextView &destination0,
    GpuCiphertextView &destination1,
    const GpuConstCiphertextView &source0,
    const GpuConstCiphertextView &source1,
    const GpuConstEvaluationKeyView &relin_keys_view,
    const GpuEvaluationKeyData &relin_keys_data,
    const GpuLevelInfo &level_info) const
{
    // Read at each eager call/capture; a captured graph freezes this choice.
    const char *raw = std::getenv("POSEIDON_GPU_RELIN_PAIR");
    if (raw == nullptr || std::string(raw) != "1") return false;
    const auto n = level_info.degree;
    const auto q = level_info.q_count;
    const auto p = relin_keys_view.meta.p_count;
    if (n != 65536 || q == 0 || p == 0 || p > 64 ||
        !(source0.meta.parms_id == source1.meta.parms_id)) return false;

    validate_hybrid_relinearize_shape(destination0, source0, relin_keys_view, relin_keys_data, level_info);
    validate_hybrid_relinearize_shape(destination1, source1, relin_keys_view, relin_keys_data, level_info);
    const auto &c20 = source0.polys[2].shards.front();
    const auto &c21 = source1.polys[2].shards.front();
    if (c20.device_id != c21.device_id) return false;
    const auto *parameters = find_parameter_shard(level_info, c20);
    if (parameters == nullptr || parameters->hybrid_base_q_count != q ||
        parameters->hybrid_base_p_count != p) return false;
    const auto q_words = checked_mul(q, n, "pair Q size overflow");
    const auto p_words = checked_mul(p, n, "pair P size overflow");
    const auto bytes = checked_mul(q_words, sizeof(GpuWord), "pair shard size overflow");
    const auto overlaps = [bytes](const GpuWord *a, const GpuWord *b) {
        const auto x = reinterpret_cast<std::uintptr_t>(a);
        const auto y = reinterpret_cast<std::uintptr_t>(b);
        return x <= y ? y - x < bytes : x - y < bytes;
    };
    const GpuCiphertextView *outputs[] = {&destination0, &destination1};
    const GpuConstCiphertextView *inputs[] = {&source0, &source1};
    // All return-false conditions precede allocation, cache initialization,
    // kernels and writes. Exceptions after this preflight never fall back.
    for (const auto *out : outputs)
        for (const auto &out_poly : out->polys)
            for (const auto *in : inputs)
                for (const auto &in_poly : in->polys)
                    if (overlaps(out_poly.shards.front().ptr, in_poly.shards.front().ptr)) return false;
    const GpuWord *output_ptrs[] = {
        destination0.polys[0].shards.front().ptr, destination0.polys[1].shards.front().ptr,
        destination1.polys[0].shards.front().ptr, destination1.polys[1].shards.front().ptr};
    for (std::size_t i = 0; i < 4; ++i)
        for (std::size_t j = i + 1; j < 4; ++j)
            if (overlaps(output_ptrs[i], output_ptrs[j])) return false;

    kernel::validate_hybrid_relinearize_pair_parameters(*parameters, n);
    const auto digits = (q + p - 1) / p;
    if (relin_keys_view.meta.decomposition_count < digits ||
        relin_keys_view.storage_q_count < q ||
        relin_keys_data.meta.p_count != p || relin_keys_data.meta.degree != n)
        throw std::invalid_argument("relinearize pair: invalid key metadata");
    std::vector<HybridKeyComponentView> key0, key1;
    key0.reserve(digits);
    key1.reserve(digits);
    for (std::size_t digit = 0; digit < digits; ++digit)
    {
        key0.push_back(make_hybrid_key_component_view(
            find_key_poly(relin_keys_view, relin_keys_data, kRelinKeyPower2Index, digit, 0),
            relin_keys_view, relin_keys_data));
        key1.push_back(make_hybrid_key_component_view(
            find_key_poly(relin_keys_view, relin_keys_data, kRelinKeyPower2Index, digit, 1),
            relin_keys_view, relin_keys_data));
        if (key0.back().device_id != c20.device_id || key1.back().device_id != c20.device_id)
            throw std::invalid_argument("relinearize pair: key device mismatch");
    }

    auto &s = *persistent_workspace_;
    gpu_check_cuda(cudaSetDevice(c20.device_id), "pair workspace cudaSetDevice");
    const auto ensure = [&](DeviceVector<GpuWord> &buffer, std::size_t words) {
        if (buffer.size() >= words && buffer.device_id() == c20.device_id) return;
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "pair workspace capture status");
        if (status != cudaStreamCaptureStatusNone)
            throw std::logic_error("relinearize pair: warm up workspace before graph capture");
        buffer.allocate(words, c20.device_id);
    };
    const auto q2 = checked_mul(2, q_words, "pair Q scratch overflow");
    const auto p2 = checked_mul(2, p_words, "pair P scratch overflow");
    const auto q4 = checked_mul(4, q_words, "pair Q scratch overflow");
    const auto p4 = checked_mul(4, p_words, "pair P scratch overflow");
    const char *arena_raw = std::getenv("POSEIDON_GPU_RELIN_PAIR_ARENA");
    const bool compact_arena = arena_raw != nullptr && std::string(arena_raw) == "1";
    GpuWord *c2_coeff, *weighted, *modup_q, *modup_p, *partial_q, *partial_p;
    GpuWord *accum_q, *accum_p, *p_coeff, *converted_coeff, *converted_ntt;
    if (compact_arena)
    {
        const auto a_words = std::max(q2, p4);
        const auto c_words = std::max(p4, q4);
        std::size_t arena_words = 0;
        for (const auto length : {a_words, q4, c_words, p2, p2, q4})
        {
            if (length > std::numeric_limits<std::size_t>::max() - arena_words)
                throw std::overflow_error("pair arena size overflow");
            arena_words += length;
        }
        (void)checked_mul(arena_words, sizeof(GpuWord), "pair arena byte size overflow");
        ensure(s.pair_arena, arena_words);
        GpuWord *a = s.pair_arena.data();
        GpuWord *b = a + a_words;
        GpuWord *c = b + q4;
        GpuWord *d = c + c_words;
        GpuWord *e = d + p2;
        GpuWord *f = e + p2;
        // A: c2 coefficients die after all digits, before P INTT writes.
        // B: disjoint ModUp/NTT-phase1 Q halves die before P->Q conversion.
        // C: P accumulators die after P INTT, before final Q NTT writes.
        // D: each digit's weights die before QP phase1 writes partial P.
        // E/F remain ModUp P / accumulated Q throughout the digit loop.
        c2_coeff = p_coeff = a;
        modup_q = converted_coeff = b;
        partial_q = b + q2;
        accum_p = converted_ntt = c;
        weighted = partial_p = d;
        modup_p = e;
        accum_q = f;
    }
    else
    {
        ensure(s.pair_c2_coeff, q2);
        ensure(s.pair_weighted, p2);
        ensure(s.pair_modup_q, q2);
        ensure(s.pair_modup_p, p2);
        ensure(s.pair_partial_q, q2);
        ensure(s.pair_partial_p, p2);
        ensure(s.pair_accum_q, q4);
        ensure(s.pair_accum_p, p4);
        ensure(s.pair_p_coeff, p4);
        ensure(s.pair_converted_coeff, q4);
        ensure(s.pair_converted_ntt, q4);
        c2_coeff = s.pair_c2_coeff.data();
        weighted = s.pair_weighted.data();
        modup_q = s.pair_modup_q.data();
        modup_p = s.pair_modup_p.data();
        partial_q = s.pair_partial_q.data();
        partial_p = s.pair_partial_p.data();
        accum_q = s.pair_accum_q.data();
        accum_p = s.pair_accum_p.data();
        p_coeff = s.pair_p_coeff.data();
        converted_coeff = s.pair_converted_coeff.data();
        converted_ntt = s.pair_converted_ntt.data();
    }
    if (parameters->opt_p_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size())
    {
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "pair table capture status");
        if (status != cudaStreamCaptureStatusNone)
            throw std::logic_error("relinearize pair: warm up P weights before graph capture");
    }
    const auto *p_inverse = kernel::hybrid_p_preweighted_inv_degree_table(*parameters);
    if (!p_inverse) throw std::logic_error("relinearize pair: P weight table unavailable");
    const GpuWord *q_inverse = nullptr;
    if (kernel::modup_fold_applicable(n))
    {
        cudaStreamCaptureStatus q_status = cudaStreamCaptureStatusNone;
        if (parameters->opt_q_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size())
        {
            gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &q_status),
                           "pair Q table capture status");
        }
        if (q_status == cudaStreamCaptureStatusNone)
        {
            q_inverse = kernel::hybrid_q_preweighted_inv_degree_table(*parameters);
        }
    }

    NvtxRange range(compact_arena ? "keyswitch.hybrid.relinearize_pair.arena" :
                                   "keyswitch.hybrid.relinearize_pair");
    kernel::launch_inverse_ntt_two_components_fourstep_65536(
        c2_coeff, c2_coeff + q_words,
        c20.ptr, c21.ptr, 0, q, *parameters, q_inverse);
    for (std::size_t digit = 0; digit < digits; ++digit)
    {
        const auto begin = digit * p;
        const auto count = std::min(p, q - begin);
        kernel::launch_hybrid_modup_decomposition_pair(
            modup_q, modup_p, weighted,
            c2_coeff, digit, begin, count, *parameters, n, q_inverse != nullptr);
        kernel::launch_forward_ntt_qp_active_fourstep_mul_accumulate_two_components_65536(
            partial_q, partial_p,
            modup_q, modup_p,
            accum_q, accum_p,
            accum_q + q2, accum_p + p2,
            c20.ptr, key0[digit].q_ptr, key0[digit].p_ptr,
            key1[digit].q_ptr, key1[digit].p_ptr,
            begin, count, digit == 0, *parameters, n, false, 2, c21.ptr);
    }
    // Batch all 4 P components ([component=0..1][batch=0..1]) into one 4-step INTT.
    GpuPolyShardView p_coeff_view{c20.device_id, p_coeff, q, p, 0, n};
    GpuConstPolyShardView accum_p_view{c20.device_id, accum_p, q, p, 0, n};
    kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
        p_coeff_view, accum_p_view, *parameters, n, 4, p_words, p_words, p_inverse);
    kernel::launch_hybrid_convert_p_to_q_preweighted_batch4(
        converted_coeff, p_coeff, *parameters, n);
    kernel::FusedModDownBatchArgs64 pair_md_args{};
    pair_md_args.dst[0] = destination0.polys[0].shards.front().ptr;
    pair_md_args.dst[1] = destination1.polys[0].shards.front().ptr;
    pair_md_args.dst[2] = destination0.polys[1].shards.front().ptr;
    pair_md_args.dst[3] = destination1.polys[1].shards.front().ptr;
    pair_md_args.add_q[0] = source0.polys[0].shards.front().ptr;
    pair_md_args.add_q[1] = source1.polys[0].shards.front().ptr;
    pair_md_args.add_q[2] = source0.polys[1].shards.front().ptr;
    pair_md_args.add_q[3] = source1.polys[1].shards.front().ptr;
    for (std::size_t z = 0; z < 4; ++z)
    {
        pair_md_args.accum_q[z] = accum_q + z * q_words;
    }
    if (!kernel::launch_forward_ntt_moddown_batch_fourstep_65536(
            converted_ntt,
            converted_coeff,
            pair_md_args,
            4,
            true,
            false,
            *parameters))
    {
        GpuPolyShardView converted;
        converted.device_id = c20.device_id;
        converted.ptr = converted_ntt;
        converted.limb_count = q;
        converted.coeff_count = n;
        GpuConstPolyShardView coeff;
        coeff.device_id = c20.device_id;
        coeff.ptr = converted_coeff;
        coeff.limb_count = q;
        coeff.coeff_count = n;
        kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(converted, coeff, *parameters, n, 4);
        kernel::launch_hybrid_relinearize_pair_addback(
            destination0.polys[0].shards.front().ptr, destination0.polys[1].shards.front().ptr,
            destination1.polys[0].shards.front().ptr, destination1.polys[1].shards.front().ptr,
            source0.polys[0].shards.front().ptr, source0.polys[1].shards.front().ptr,
            source1.polys[0].shards.front().ptr, source1.polys[1].shards.front().ptr,
            accum_q, converted_ntt, *parameters, n);
    }
    return true;
}

bool GpuKeySwitchHandler::try_relinearize_hybrid_ciphertext_rescale_pair(
    GpuCiphertextView &destination0,
    GpuCiphertextView &destination1,
    const GpuConstCiphertextView &source0,
    const GpuConstCiphertextView &source1,
    const GpuConstEvaluationKeyView &relin_keys_view,
    const GpuEvaluationKeyData &relin_keys_data,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info,
    std::uint32_t drop_count,
    PairRelinPostOp post_op,
    const GpuWord *plain_ptr,
    const GpuConstCiphertextView *extra0,
    const GpuConstCiphertextView *extra1) const
{
    const char *raw = std::getenv("POSEIDON_GPU_RELIN_PAIR");
    if (raw == nullptr || std::string(raw) != "1" || !opt_flag(OptFlag::RelinRescalePair))
        return false;
    if (drop_count != 1 && drop_count != 2) return false;
    const auto n = source_level_info.degree;
    const auto q = source_level_info.q_count;
    const auto p = relin_keys_view.meta.p_count;
    if (n != 65536 || destination_level_info.degree != n ||
        q < drop_count + 1 || destination_level_info.q_count + drop_count != q ||
        p == 0 || p > 64 ||
        !(source0.meta.parms_id == source_level_info.parms_id) ||
        !(source1.meta.parms_id == source_level_info.parms_id) ||
        !(destination0.meta.parms_id == destination_level_info.parms_id) ||
        !(destination1.meta.parms_id == destination_level_info.parms_id))
        return false;

    const auto retained = destination_level_info.q_count;
    const auto valid_source = [&](const GpuConstCiphertextView &src) {
        if (!src.meta.is_ntt_form || src.meta.p_count != 0 || src.meta.degree != n ||
            src.meta.q_count != q || src.meta.component_count != 3 || src.polys.size() != 3)
            return false;
        for (const auto &poly : src.polys) {
            if (poly.shards.size() != 1) return false;
            const auto &sh = poly.shards.front();
            if (sh.limb_begin != 0 || sh.limb_count != q || sh.coeff_begin != 0 ||
                sh.coeff_count != n || sh.ptr == nullptr || sh.device_id != src.polys[0].shards.front().device_id)
                return false;
        }
        return true;
    };
    const auto valid_dest = [&](const GpuCiphertextView &dst, int dev) {
        if (!dst.meta.is_ntt_form || dst.meta.p_count != 0 || dst.meta.degree != n ||
            dst.meta.q_count != retained || dst.meta.component_count != 2 || dst.polys.size() != 2)
            return false;
        for (const auto &poly : dst.polys) {
            if (poly.shards.size() != 1) return false;
            const auto &sh = poly.shards.front();
            if (sh.device_id != dev || sh.limb_begin != 0 || sh.limb_count != retained ||
                sh.coeff_begin != 0 || sh.coeff_count != n || sh.ptr == nullptr)
                return false;
        }
        return true;
    };
    const auto valid_extra = [&](const GpuConstCiphertextView *ext, int dev) {
        if (ext == nullptr || !ext->meta.is_ntt_form || ext->meta.p_count != 0 ||
            ext->meta.degree != n || ext->meta.q_count < q ||
            ext->meta.component_count != 2 || ext->polys.size() != 2)
            return false;
        for (const auto &poly : ext->polys) {
            if (poly.shards.size() != 1) return false;
            const auto &sh = poly.shards.front();
            if (sh.device_id != dev || sh.limb_begin != 0 || sh.limb_count < q ||
                sh.coeff_begin != 0 || sh.coeff_count != n || sh.ptr == nullptr)
                return false;
        }
        return true;
    };
    if (!valid_source(source0) || !valid_source(source1)) return false;
    const auto &c20 = source0.polys[2].shards.front();
    const auto &c21 = source1.polys[2].shards.front();
    if (c20.device_id != c21.device_id) return false;
    if (!valid_dest(destination0, c20.device_id) || !valid_dest(destination1, c20.device_id))
        return false;
    const bool needs_extra =
        post_op == PairRelinPostOp::DoubleSubCipher ||
        post_op == PairRelinPostOp::DoubleSubCipherPlain;
    if (needs_extra &&
        (!valid_extra(extra0, c20.device_id) || !valid_extra(extra1, c20.device_id)))
        return false;
    if (post_op == PairRelinPostOp::DoubleSubCipherPlain && plain_ptr == nullptr)
        return false;

    const auto *parameters = find_parameter_shard(source_level_info, c20);
    if (parameters == nullptr || parameters->hybrid_base_q_count != q ||
        parameters->hybrid_base_p_count != p || parameters->limb_begin != 0 ||
        parameters->hybrid_inv_p_mod_q.size() < q)
        return false;
    if (drop_count == 1) {
        if (parameters->q_last == 0 ||
            parameters->half_q_last_mod_q.size() < retained ||
            parameters->inv_q_last_mod_q.size() < retained)
            return false;
    } else {
        if (parameters->q_last_two_product == 0 ||
            parameters->q_last_two_product_mod_q.size() < retained ||
            parameters->inv_q_last_two_product_mod_q.size() < retained)
            return false;
    }
    const auto digits = (q + p - 1) / p;
    if (!(relin_keys_view.meta.key_parms_id == relin_keys_data.meta.key_parms_id) ||
        relin_keys_view.storage_q_count != relin_keys_data.meta.q_count ||
        relin_keys_view.meta.q_count != q ||
        relin_keys_view.meta.key_count == 0 ||
        relin_keys_view.meta.decomposition_count < digits ||
        relin_keys_view.storage_q_count < q ||
        relin_keys_view.meta.component_count < kSwitchKeyComponentCount ||
        relin_keys_data.meta.p_count != p || relin_keys_data.meta.degree != n ||
        relin_keys_data.poly_metadata_.empty() ||
        relin_keys_data.polys_.size() != relin_keys_view.polys.size())
        return false;

    const auto q_words = checked_mul(q, n, "pair rr Q size overflow");
    const auto p_words = checked_mul(p, n, "pair rr P size overflow");
    const auto retained_words = checked_mul(retained, n, "pair rr retained size overflow");
    const auto in_bytes = checked_mul(q_words, sizeof(GpuWord), "pair rr in bytes overflow");
    const auto out_bytes = checked_mul(retained_words, sizeof(GpuWord), "pair rr out bytes overflow");
    const auto overlap_range = [](const GpuWord *a, std::size_t ab, const GpuWord *b, std::size_t bb) {
        if (a == nullptr || b == nullptr) return false;
        const auto x = reinterpret_cast<std::uintptr_t>(a);
        const auto y = reinterpret_cast<std::uintptr_t>(b);
        return x <= y ? y - x < ab : x - y < bb;
    };
    const GpuWord *output_ptrs[] = {
        destination0.polys[0].shards.front().ptr, destination0.polys[1].shards.front().ptr,
        destination1.polys[0].shards.front().ptr, destination1.polys[1].shards.front().ptr};
    for (std::size_t i = 0; i < 4; ++i)
        for (std::size_t j = i + 1; j < 4; ++j)
            if (overlap_range(output_ptrs[i], out_bytes, output_ptrs[j], out_bytes)) return false;
    const GpuConstCiphertextView *inputs[] = {&source0, &source1};
    for (std::size_t i = 0; i < 4; ++i) {
        for (const auto *in : inputs)
            for (const auto &in_poly : in->polys)
                if (overlap_range(output_ptrs[i], out_bytes, in_poly.shards.front().ptr, in_bytes))
                    return false;
        if (plain_ptr != nullptr && overlap_range(output_ptrs[i], out_bytes, plain_ptr, in_bytes))
            return false;
        if (needs_extra) {
            for (const auto *ext : {extra0, extra1})
                for (const auto &ext_poly : ext->polys)
                    if (overlap_range(output_ptrs[i], out_bytes, ext_poly.shards.front().ptr, in_bytes))
                        return false;
        }
    }

    kernel::validate_hybrid_relinearize_pair_parameters(*parameters, n);
    std::vector<HybridKeyComponentView> key0, key1;
    key0.reserve(digits);
    key1.reserve(digits);
    for (std::size_t digit = 0; digit < digits; ++digit) {
        key0.push_back(make_hybrid_key_component_view(
            find_key_poly(relin_keys_view, relin_keys_data, kRelinKeyPower2Index, digit, 0),
            relin_keys_view, relin_keys_data));
        key1.push_back(make_hybrid_key_component_view(
            find_key_poly(relin_keys_view, relin_keys_data, kRelinKeyPower2Index, digit, 1),
            relin_keys_view, relin_keys_data));
        if (key0.back().device_id != c20.device_id || key1.back().device_id != c20.device_id)
            throw std::invalid_argument("relinearize rescale pair: key device mismatch");
    }

    auto &s = *persistent_workspace_;
    gpu_check_cuda(cudaSetDevice(c20.device_id), "pair rr workspace cudaSetDevice");
    const auto ensure = [&](DeviceVector<GpuWord> &buffer, std::size_t words) {
        if (buffer.size() >= words && buffer.device_id() == c20.device_id) return;
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "pair rr workspace capture status");
        if (status != cudaStreamCaptureStatusNone)
            throw std::logic_error("relinearize rescale pair: warm up workspace before graph capture");
        buffer.allocate(words, c20.device_id);
    };
    const auto q2 = checked_mul(2, q_words, "pair rr Q scratch overflow");
    const auto p2 = checked_mul(2, p_words, "pair rr P scratch overflow");
    const auto q4 = checked_mul(4, q_words, "pair rr Q scratch overflow");
    const auto p4 = checked_mul(4, p_words, "pair rr P scratch overflow");
    const auto drop_words = checked_mul(drop_count, n, "pair rr drop scratch overflow");
    const auto tail_pair_words = checked_mul(8, drop_words, "pair rr tail scratch overflow");
    const char *arena_raw = std::getenv("POSEIDON_GPU_RELIN_PAIR_ARENA");
    const bool compact_arena = arena_raw != nullptr && std::string(arena_raw) == "1";
    GpuWord *c2_coeff, *weighted, *modup_q, *modup_p, *partial_q, *partial_p;
    GpuWord *accum_q, *accum_p, *p_coeff, *converted_coeff, *converted_ntt;
    GpuWord *tail_ntt, *tail_coeff;
    if (compact_arena) {
        const auto a_words = std::max({q2, p4, tail_pair_words});
        const auto c_words = std::max(p4, q4);
        std::size_t arena_words = 0;
        for (const auto length : {a_words, q4, c_words, p2, p2, q4}) {
            if (length > std::numeric_limits<std::size_t>::max() - arena_words)
                throw std::overflow_error("pair rr arena size overflow");
            arena_words += length;
        }
        (void)checked_mul(arena_words, sizeof(GpuWord), "pair rr arena byte size overflow");
        ensure(s.pair_arena, arena_words);
        GpuWord *a = s.pair_arena.data();
        GpuWord *b = a + a_words;
        GpuWord *c = b + q4;
        GpuWord *d = c + c_words;
        GpuWord *e = d + p2;
        GpuWord *f = e + p2;
        c2_coeff = p_coeff = a;
        tail_ntt = a;
        tail_coeff = a + 4 * drop_words;
        modup_q = converted_coeff = b;
        partial_q = b + q2;
        accum_p = converted_ntt = c;
        weighted = partial_p = d;
        modup_p = e;
        accum_q = f;
    } else {
        ensure(s.pair_c2_coeff, std::max(q2, 4 * drop_words));
        ensure(s.pair_weighted, p2);
        ensure(s.pair_modup_q, q2);
        ensure(s.pair_modup_p, p2);
        ensure(s.pair_partial_q, q2);
        ensure(s.pair_partial_p, p2);
        ensure(s.pair_accum_q, q4);
        ensure(s.pair_accum_p, p4);
        ensure(s.pair_p_coeff, std::max(p4, 4 * drop_words));
        ensure(s.pair_converted_coeff, q4);
        ensure(s.pair_converted_ntt, q4);
        c2_coeff = s.pair_c2_coeff.data();
        tail_ntt = s.pair_c2_coeff.data();
        weighted = s.pair_weighted.data();
        modup_q = s.pair_modup_q.data();
        modup_p = s.pair_modup_p.data();
        partial_q = s.pair_partial_q.data();
        partial_p = s.pair_partial_p.data();
        accum_q = s.pair_accum_q.data();
        accum_p = s.pair_accum_p.data();
        p_coeff = s.pair_p_coeff.data();
        tail_coeff = s.pair_p_coeff.data();
        converted_coeff = s.pair_converted_coeff.data();
        converted_ntt = s.pair_converted_ntt.data();
    }
    if (parameters->opt_p_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size()) {
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "pair rr table capture status");
        if (status != cudaStreamCaptureStatusNone)
            throw std::logic_error("relinearize rescale pair: warm up P weights before graph capture");
    }
    const auto *p_inverse = kernel::hybrid_p_preweighted_inv_degree_table(*parameters);
    if (!p_inverse) throw std::logic_error("relinearize rescale pair: P weight table unavailable");
    const GpuWord *q_inverse = nullptr;
    if (kernel::modup_fold_applicable(n)) {
        cudaStreamCaptureStatus q_status = cudaStreamCaptureStatusNone;
        if (parameters->opt_q_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size())
            gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &q_status),
                           "pair rr Q table capture status");
        if (q_status == cudaStreamCaptureStatusNone)
            q_inverse = kernel::hybrid_q_preweighted_inv_degree_table(*parameters);
    }

    NvtxRange range("keyswitch.hybrid.relinearize_rescale_pair");
    kernel::launch_inverse_ntt_two_components_fourstep_65536(
        c2_coeff, c2_coeff + q_words,
        c20.ptr, c21.ptr, 0, q, *parameters, q_inverse);
    for (std::size_t digit = 0; digit < digits; ++digit) {
        const auto begin = digit * p;
        const auto count = std::min(p, q - begin);
        kernel::launch_hybrid_modup_decomposition_pair(
            modup_q, modup_p, weighted,
            c2_coeff, digit, begin, count, *parameters, n, q_inverse != nullptr);
        kernel::launch_forward_ntt_qp_active_fourstep_mul_accumulate_two_components_65536(
            partial_q, partial_p,
            modup_q, modup_p,
            accum_q, accum_p,
            accum_q + q2, accum_p + p2,
            c20.ptr, key0[digit].q_ptr, key0[digit].p_ptr,
            key1[digit].q_ptr, key1[digit].p_ptr,
            begin, count, digit == 0, *parameters, n, false, 2, c21.ptr);
    }
    GpuPolyShardView p_coeff_view{c20.device_id, p_coeff, q, p, 0, n};
    GpuConstPolyShardView accum_p_view{c20.device_id, accum_p, q, p, 0, n};
    kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
        p_coeff_view, accum_p_view, *parameters, n, 4, p_words, p_words, p_inverse);
    kernel::launch_hybrid_convert_p_to_q_preweighted_batch4(
        converted_coeff, p_coeff, *parameters, n);

    const GpuWord *extra00 = needs_extra ? extra0->polys[0].shards.front().ptr : nullptr;
    const GpuWord *extra01 = needs_extra ? extra0->polys[1].shards.front().ptr : nullptr;
    const GpuWord *extra10 = needs_extra ? extra1->polys[0].shards.front().ptr : nullptr;
    const GpuWord *extra11 = needs_extra ? extra1->polys[1].shards.front().ptr : nullptr;
    const int op_code = static_cast<int>(post_op);

    kernel::launch_hybrid_relin_rescale_pair_tail(
        tail_ntt, accum_q,
        source0.polys[0].shards.front().ptr, source0.polys[1].shards.front().ptr,
        source1.polys[0].shards.front().ptr, source1.polys[1].shards.front().ptr,
        plain_ptr, extra00, extra01, extra10, extra11,
        drop_count, op_code, *parameters, n);
    GpuPolyShardView tail_coeff_view{c20.device_id, tail_coeff, q - drop_count, drop_count, 0, n};
    GpuConstPolyShardView tail_ntt_view{c20.device_id, tail_ntt, q - drop_count, drop_count, 0, n};
    kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
        tail_coeff_view, tail_ntt_view, *parameters, n, 4, drop_words, drop_words);
    kernel::RelinRescaleBatchArgs4 pair_rr_args{};
    pair_rr_args.dst[0] = destination0.polys[0].shards.front().ptr;
    pair_rr_args.dst[1] = destination1.polys[0].shards.front().ptr;
    pair_rr_args.dst[2] = destination0.polys[1].shards.front().ptr;
    pair_rr_args.dst[3] = destination1.polys[1].shards.front().ptr;
    pair_rr_args.source[0] = source0.polys[0].shards.front().ptr;
    pair_rr_args.source[1] = source1.polys[0].shards.front().ptr;
    pair_rr_args.source[2] = source0.polys[1].shards.front().ptr;
    pair_rr_args.source[3] = source1.polys[1].shards.front().ptr;
    pair_rr_args.extra[0] = extra00;
    pair_rr_args.extra[1] = extra10;
    pair_rr_args.extra[2] = extra01;
    pair_rr_args.extra[3] = extra11;
    pair_rr_args.plain = plain_ptr;
    for (std::size_t z = 0; z < 4; ++z)
    {
        pair_rr_args.r_coeff[z] = converted_coeff + z * q_words;
        pair_rr_args.tail_coeff[z] = tail_coeff + z * drop_words;
        pair_rr_args.accum_q[z] = accum_q + z * q_words;
    }
    if (!kernel::launch_fused_relin_rescale_batch_65536(
            pair_rr_args,
            tail_ntt,
            converted_ntt,
            4,
            drop_count,
            op_code,
            *parameters))
    {
        kernel::launch_hybrid_relin_rescale_pair_merge_correction(
            converted_ntt, converted_coeff, tail_coeff,
            drop_count, op_code, *parameters, n);
        GpuPolyShardView corr_ntt_view{c20.device_id, converted_coeff, 0, retained, 0, n};
        GpuConstPolyShardView merged_view{c20.device_id, converted_ntt, 0, retained, 0, n};
        kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
            corr_ntt_view, merged_view, *parameters, n, 4);
        kernel::launch_hybrid_relin_rescale_pair_apply(
            destination0.polys[0].shards.front().ptr, destination0.polys[1].shards.front().ptr,
            destination1.polys[0].shards.front().ptr, destination1.polys[1].shards.front().ptr,
            accum_q,
            source0.polys[0].shards.front().ptr, source0.polys[1].shards.front().ptr,
            source1.polys[0].shards.front().ptr, source1.polys[1].shards.front().ptr,
            plain_ptr, extra00, extra01, extra10, extra11,
            converted_coeff, drop_count, op_code, *parameters, n);
    }
    return true;
}

bool GpuKeySwitchHandler::try_relinearize_hybrid_ciphertext_rescale_postop(
    GpuCiphertextView &destination,
    const GpuConstCiphertextView &source,
    const GpuConstEvaluationKeyView &relin_keys_view,
    const GpuEvaluationKeyData &relin_keys_data,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info,
    std::uint32_t drop_count,
    PairRelinPostOp post_op,
    const GpuWord *plain_ptr,
    const GpuConstCiphertextView *extra) const
{
    if (!opt_flag(OptFlag::RelinRescalePair) || !opt_flag(OptFlag::FusedRelinRescale))
        return false;
    if (drop_count != 1 && drop_count != 2)
        return false;
    const auto n = source_level_info.degree;
    const auto q = source_level_info.q_count;
    const auto p = relin_keys_view.meta.p_count;
    if (n != 65536 || q <= drop_count || p == 0 || p > 64)
        return false;
    const auto retained = q - drop_count;
    if (destination_level_info.degree != n || destination_level_info.q_count != retained)
        return false;

    if (!(source.meta.parms_id == source_level_info.parms_id) || !source.meta.is_ntt_form ||
        source.polys.size() != 3 || source.meta.component_count != 3 ||
        source.meta.degree != n || source.meta.q_count != q || source.meta.p_count != 0)
        return false;
    const int dev = source.polys[0].shards.empty() ? -1 : source.polys[0].shards.front().device_id;
    if (dev < 0)
        return false;
    for (const auto &poly : source.polys) {
        if (poly.shards.size() != 1) return false;
        const auto &sh = poly.shards.front();
        if (sh.device_id != dev || sh.limb_begin != 0 || sh.limb_count != q ||
            sh.coeff_begin != 0 || sh.coeff_count != n || sh.ptr == nullptr)
            return false;
    }
    if (!(destination.meta.parms_id == destination_level_info.parms_id) ||
        !destination.meta.is_ntt_form || destination.polys.size() != 2 ||
        destination.meta.component_count != 2 || destination.meta.degree != n ||
        destination.meta.q_count != retained || destination.meta.p_count != 0)
        return false;
    for (const auto &poly : destination.polys) {
        if (poly.shards.size() != 1) return false;
        const auto &sh = poly.shards.front();
        if (sh.device_id != dev || sh.limb_begin != 0 || sh.limb_count != retained ||
            sh.coeff_begin != 0 || sh.coeff_count != n || sh.ptr == nullptr)
            return false;
    }

    const bool needs_extra =
        post_op == PairRelinPostOp::DoubleSubCipher ||
        post_op == PairRelinPostOp::DoubleSubCipherPlain;
    if (needs_extra) {
        if (extra == nullptr || !extra->meta.is_ntt_form || extra->polys.size() != 2 ||
            extra->meta.component_count != 2 || extra->meta.degree != n ||
            extra->meta.q_count < q || extra->meta.p_count != 0)
            return false;
        for (const auto &poly : extra->polys) {
            if (poly.shards.size() != 1) return false;
            const auto &sh = poly.shards.front();
            if (sh.device_id != dev || sh.limb_begin != 0 || sh.limb_count < q ||
                sh.coeff_begin != 0 || sh.coeff_count != n || sh.ptr == nullptr)
                return false;
        }
    }
    if (post_op == PairRelinPostOp::DoubleSubCipherPlain && plain_ptr == nullptr)
        return false;

    const auto &c2 = source.polys[2].shards.front();
    const auto *parameters = find_parameter_shard(source_level_info, c2);
    if (parameters == nullptr || parameters->hybrid_base_q_count != q ||
        parameters->hybrid_base_p_count != p || parameters->limb_begin != 0 ||
        parameters->hybrid_inv_p_mod_q.size() < q ||
        parameters->rns_primes.size() < q + p ||
        parameters->rns_modulus_constants.size() < q + p ||
        parameters->ntt_tables.size() < (q + p) * n ||
        parameters->fourstep_intt_tables.data() == nullptr ||
        parameters->fourstep_intt_tables.size() < (q + p) * n)
        return false;
    if (drop_count == 1) {
        if (parameters->q_last == 0 ||
            parameters->half_q_last_mod_q.size() < retained ||
            parameters->inv_q_last_mod_q.size() < retained)
            return false;
    } else {
        if (parameters->q_last_two_product == 0 ||
            parameters->inv_q_last_mod_q_second_last == 0 ||
            parameters->q_last_two_product_mod_q.size() < retained ||
            parameters->inv_q_last_two_product_mod_q.size() < retained)
            return false;
    }
    const auto digits = (q + p - 1) / p;
    if (!(relin_keys_view.meta.key_parms_id == relin_keys_data.meta.key_parms_id) ||
        relin_keys_view.storage_q_count != relin_keys_data.meta.q_count ||
        relin_keys_view.meta.q_count != q ||
        relin_keys_view.meta.key_count == 0 ||
        relin_keys_view.meta.decomposition_count < digits ||
        relin_keys_view.storage_q_count < q ||
        relin_keys_view.meta.component_count < kSwitchKeyComponentCount ||
        relin_keys_data.meta.p_count != p || relin_keys_data.meta.degree != n ||
        relin_keys_data.poly_metadata_.empty() ||
        relin_keys_data.polys_.size() != relin_keys_view.polys.size())
        return false;

    const auto q_words = checked_mul(q, n, "single rr Q size overflow");
    const auto retained_words = checked_mul(retained, n, "single rr retained size overflow");
    const auto in_bytes = checked_mul(q_words, sizeof(GpuWord), "single rr in bytes overflow");
    const auto out_bytes = checked_mul(retained_words, sizeof(GpuWord), "single rr out bytes overflow");
    const auto overlap_range = [](const GpuWord *a, std::size_t ab, const GpuWord *b, std::size_t bb) {
        if (a == nullptr || b == nullptr) return false;
        const auto x = reinterpret_cast<std::uintptr_t>(a);
        const auto y = reinterpret_cast<std::uintptr_t>(b);
        return x <= y ? y - x < ab : x - y < bb;
    };
    GpuWord *out0 = destination.polys[0].shards.front().ptr;
    GpuWord *out1 = destination.polys[1].shards.front().ptr;
    if (overlap_range(out0, out_bytes, out1, out_bytes))
        return false;
    for (const auto *out_ptr : {out0, out1}) {
        for (const auto &in_poly : source.polys)
            if (overlap_range(out_ptr, out_bytes, in_poly.shards.front().ptr, in_bytes))
                return false;
        if (plain_ptr != nullptr && overlap_range(out_ptr, out_bytes, plain_ptr, in_bytes))
            return false;
        if (needs_extra) {
            for (const auto &ext_poly : extra->polys)
                if (overlap_range(out_ptr, out_bytes, ext_poly.shards.front().ptr, in_bytes))
                    return false;
        }
    }

    kernel::validate_hybrid_relinearize_pair_parameters(*parameters, n);
    std::vector<HybridKeyComponentView> key0, key1;
    key0.reserve(digits);
    key1.reserve(digits);
    for (std::size_t digit = 0; digit < digits; ++digit) {
        key0.push_back(make_hybrid_key_component_view(
            find_key_poly(relin_keys_view, relin_keys_data, kRelinKeyPower2Index, digit, 0),
            relin_keys_view, relin_keys_data));
        key1.push_back(make_hybrid_key_component_view(
            find_key_poly(relin_keys_view, relin_keys_data, kRelinKeyPower2Index, digit, 1),
            relin_keys_view, relin_keys_data));
        if (key0.back().device_id != dev || key1.back().device_id != dev)
            throw std::invalid_argument("relinearize rescale postop: key device mismatch");
    }

    gpu_check_cuda(cudaSetDevice(dev), "single rr workspace cudaSetDevice");
    HybridScratch &scratch = persistent_workspace_->relinearize;
    ensure_hybrid_scratch(scratch, dev, n, q, p);
    if (drop_count == 1)
        ensure_hybrid_relin_rescale_x1_scratch(scratch);
    else
        ensure_hybrid_relin_rescale_x2_scratch(scratch);

    NvtxRange range("keyswitch.hybrid.relinearize_rescale_postop");
    inverse_ntt_switch_poly(scratch, source.polys[2], source_level_info);

    const bool fuse_decomp_q = use_fused_decomp_q();
    const bool fuse_modup_ntt_head = use_fused_modup_ntt_head();
    const bool bconv_row_tiled = use_bconv_row_tiled();
    const bool bconv_row_tiled8 = use_bconv_row_tiled8();
    for (std::size_t digit = 0; digit < digits; ++digit) {
        const std::size_t begin = digit * p;
        const std::size_t count = std::min(p, q - begin);
        process_hybrid_decomposition_block(
            digit, begin, count, scratch, source.polys[2],
            key0[digit], key1[digit], source_level_info,
            fuse_decomp_q, fuse_modup_ntt_head, bconv_row_tiled, bconv_row_tiled8);
    }

    auto p0 = make_scratch_p_view(scratch.accum_p0.data(), scratch);
    auto p1 = make_scratch_p_view(scratch.accum_p1.data(), scratch);
    const bool use_p_out_of_place =
        scratch.fourstep_p0.size() >= scratch.p_word_count &&
        scratch.fourstep_p1.size() >= scratch.p_word_count;
    auto p_dst0 = use_p_out_of_place ? make_scratch_p_view(scratch.fourstep_p0.data(), scratch) : p0;
    auto p_dst1 = use_p_out_of_place ? make_scratch_p_view(scratch.fourstep_p1.data(), scratch) : p1;
    bool folded = false;
    if (p_to_q_fold_table(p_dst0, *parameters, n)) {
        folded = inverse_p_parts_for_p_to_q(
            p_dst0, as_const_shard(p0), p_dst1, as_const_shard(p1), *parameters, n);
    } else if (use_p_out_of_place) {
        kernel::launch_inverse_ntt_two_components_fourstep_65536(
            p_dst0.ptr, p_dst1.ptr, p0.ptr, p1.ptr, q, p, *parameters);
    } else {
        kernel::launch_inverse_ntt_poly_shard(p_dst0, as_const_shard(p0), *parameters, n);
        kernel::launch_inverse_ntt_poly_shard(p_dst1, as_const_shard(p1), *parameters, n);
    }
    kernel::launch_hybrid_convert_p_to_q_coeff_lazy(
        scratch.c2_intt.data(), scratch.modup_q.data(),
        p_dst0.ptr, p_dst1.ptr, *parameters, n, folded);

    const GpuWord *src0 = source.polys[0].shards.front().ptr;
    const GpuWord *src1 = source.polys[1].shards.front().ptr;
    const GpuWord *ext0 = needs_extra ? extra->polys[0].shards.front().ptr : nullptr;
    const GpuWord *ext1 = needs_extra ? extra->polys[1].shards.front().ptr : nullptr;
    const int op_code = static_cast<int>(post_op);
    const std::size_t drop_words = static_cast<std::size_t>(drop_count) * n;
    GpuWord *tail_ntt0 = scratch.relin_rescale_dropped_ntt.data();
    GpuWord *tail_ntt1 = tail_ntt0 + drop_words;
    GpuWord *tail_coeff0 = scratch.relin_rescale_dropped_coeff.data();
    GpuWord *tail_coeff1 = tail_coeff0 + drop_words;

    kernel::launch_hybrid_relin_rescale_single_tail(
        tail_ntt0,
        scratch.accum_q0.data(), scratch.accum_q1.data(),
        src0, src1, plain_ptr, ext0, ext1,
        drop_count, op_code, *parameters, n);
    kernel::launch_inverse_ntt_two_components_fourstep_65536(
        tail_coeff0, tail_coeff1, tail_ntt0, tail_ntt1,
        retained, drop_count, *parameters);

    kernel::RelinRescaleBatchArgs4 rr_args{};
    rr_args.dst[0] = out0;
    rr_args.dst[1] = out1;
    rr_args.source[0] = src0;
    rr_args.source[1] = src1;
    rr_args.extra[0] = ext0;
    rr_args.extra[1] = ext1;
    rr_args.plain = plain_ptr;
    rr_args.r_coeff[0] = scratch.c2_intt.data();
    rr_args.r_coeff[1] = scratch.modup_q.data();
    rr_args.tail_coeff[0] = tail_coeff0;
    rr_args.tail_coeff[1] = tail_coeff1;
    rr_args.accum_q[0] = scratch.accum_q0.data();
    rr_args.accum_q[1] = scratch.accum_q1.data();
    if (!kernel::launch_fused_relin_rescale_batch_65536(
            rr_args,
            scratch.relin_rescale_dropped_ntt.data(),
            scratch.relin_rescale_correction_ntt.data(),
            2,
            drop_count,
            op_code,
            *parameters))
    {
        throw std::logic_error(
            "GpuKeySwitchHandler::try_relinearize_hybrid_ciphertext_rescale_postop: fused batch unexpectedly rejected");
    }
    return true;
}

void GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x1(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &source_view,
    const GpuConstEvaluationKeyView &relin_keys_view,
    const GpuEvaluationKeyData &relin_keys_data,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info,
    bool double_moddown) const
{
    if (!(source_view.meta.parms_id == source_level_info.parms_id) ||
        !(destination_view.meta.parms_id == destination_level_info.parms_id) ||
        !source_view.meta.is_ntt_form ||
        !destination_view.meta.is_ntt_form ||
        source_view.polys.size() != 3 ||
        source_view.meta.component_count != 3 ||
        destination_view.polys.size() != 2 ||
        destination_view.meta.component_count != 2 ||
        source_view.meta.degree != destination_view.meta.degree ||
        source_view.meta.degree != source_level_info.degree ||
        source_view.meta.degree != destination_level_info.degree ||
        source_view.meta.q_count != source_level_info.q_count ||
        destination_view.meta.q_count != destination_level_info.q_count ||
        destination_view.meta.q_count + 1 != source_view.meta.q_count ||
        source_view.meta.p_count != 0 ||
        destination_view.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x1: shape mismatch");
    }
    if (!(relin_keys_view.meta.key_parms_id ==
          relin_keys_data.meta.key_parms_id) ||
        relin_keys_view.storage_q_count != relin_keys_data.meta.q_count ||
        relin_keys_view.meta.q_count != source_view.meta.q_count ||
        relin_keys_view.meta.key_count == 0 ||
        relin_keys_view.meta.decomposition_count == 0 ||
        relin_keys_view.meta.component_count < kSwitchKeyComponentCount ||
        relin_keys_data.poly_metadata_.empty() ||
        relin_keys_data.polys_.size() != relin_keys_view.polys.size())
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x1: invalid relin key metadata");
    }
    for (std::size_t component = 0; component < source_view.polys.size();
         ++component)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler relin-rescale_x1 source",
            source_view.polys[component],
            source_view.meta.degree,
            source_view.meta.q_count);
        if (!same_shard_placement(
                source_view.polys[0].shards.front(),
                source_view.polys[component].shards.front()))
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x1: source shard placement mismatch");
        }
    }
    for (const auto &poly : destination_view.polys)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler relin-rescale_x1 destination",
            poly,
            destination_view.meta.degree,
            destination_view.meta.q_count);
    }

    switch_key_hybrid_ciphertext_impl(
        destination_view,
        source_view.polys[2],
        relin_keys_view,
        relin_keys_data,
        kRelinKeyPower2Index,
        source_level_info,
        &source_view.polys[0],
        &source_view.polys[1],
        &destination_level_info,
        nullptr,
        double_moddown);
}

void GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x2(
    GpuCiphertextView &destination_view,
    const GpuConstCiphertextView &source_view,
    const GpuConstEvaluationKeyView &relin_keys_view,
    const GpuEvaluationKeyData &relin_keys_data,
    const GpuLevelInfo &source_level_info,
    const GpuLevelInfo &destination_level_info) const
{
    if (!(source_view.meta.parms_id == source_level_info.parms_id) ||
        !(destination_view.meta.parms_id ==
          destination_level_info.parms_id) ||
        !source_view.meta.is_ntt_form ||
        !destination_view.meta.is_ntt_form ||
        source_view.polys.size() != 3 ||
        source_view.meta.component_count != 3 ||
        destination_view.polys.size() != 2 ||
        destination_view.meta.component_count != 2 ||
        source_view.meta.degree != destination_view.meta.degree ||
        source_view.meta.degree != source_level_info.degree ||
        source_view.meta.degree != destination_level_info.degree ||
        source_view.meta.q_count != source_level_info.q_count ||
        destination_view.meta.q_count != destination_level_info.q_count ||
        destination_view.meta.q_count + 2 != source_view.meta.q_count ||
        source_view.meta.p_count != 0 ||
        destination_view.meta.p_count != 0)
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x2: shape mismatch");
    }
    if (!(relin_keys_view.meta.key_parms_id ==
          relin_keys_data.meta.key_parms_id) ||
        relin_keys_view.storage_q_count != relin_keys_data.meta.q_count ||
        relin_keys_view.meta.q_count != source_view.meta.q_count ||
        relin_keys_view.meta.key_count == 0 ||
        relin_keys_view.meta.decomposition_count == 0 ||
        relin_keys_view.meta.component_count < kSwitchKeyComponentCount ||
        relin_keys_data.poly_metadata_.empty() ||
        relin_keys_data.polys_.size() != relin_keys_view.polys.size())
    {
        throw std::invalid_argument(
            "GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x2: invalid relin key metadata");
    }
    for (std::size_t component = 0; component < source_view.polys.size();
         ++component)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler relin-rescale source",
            source_view.polys[component],
            source_view.meta.degree,
            source_view.meta.q_count);
        if (!same_shard_placement(
                source_view.polys[0].shards.front(),
                source_view.polys[component].shards.front()))
        {
            throw std::invalid_argument(
                "GpuKeySwitchHandler::relinearize_hybrid_ciphertext_rescale_x2: source shard placement mismatch");
        }
    }
    for (const auto &poly : destination_view.polys)
    {
        validate_single_full_shard(
            "GpuKeySwitchHandler relin-rescale destination",
            poly,
            destination_view.meta.degree,
            destination_view.meta.q_count);
    }

    switch_key_hybrid_ciphertext_impl(
        destination_view,
        source_view.polys[2],
        relin_keys_view,
        relin_keys_data,
        kRelinKeyPower2Index,
        source_level_info,
        &source_view.polys[0],
        &source_view.polys[1],
        &destination_level_info);
}

bool GpuKeySwitchHandler::try_rotate_dnum1_batch(
    const std::vector<GpuCiphertextView> &destinations,
    const std::vector<GpuConstCiphertextView> &sources,
    const std::vector<const GpuConstCiphertextView *> *add_sources,
    const std::vector<std::uint32_t> &galois_elts,
    const std::vector<std::size_t> &key_indices,
    bool shared_key,
    const GpuConstEvaluationKeyView &galois_keys_view,
    const GpuEvaluationKeyData &galois_keys_data,
    const GpuLevelInfo &level_info) const
{
    const std::size_t total_count = sources.size();
    if (total_count == 0)
    {
        return true;
    }
    if (!conv_batch_rotate_enabled() ||
        !opt_flag(OptFlag::ModupPreweight) ||
        !opt_flag(OptFlag::PToQPreweight) ||
        destinations.size() != total_count ||
        galois_elts.size() != total_count ||
        key_indices.size() != total_count ||
        (add_sources != nullptr && add_sources->size() != total_count))
    {
        return false;
    }
    if (galois_keys_data.meta.galois_format != GpuGaloisKeyFormat::Standard)
    {
        return false;
    }

    const std::size_t n = level_info.degree;
    const std::size_t q = level_info.q_count;
    if (n != 65536 || q == 0)
    {
        return false;
    }

    const auto valid_const_ct = [&](const GpuConstCiphertextView &ct, int expected_dev) {
        if (!(ct.meta.parms_id == level_info.parms_id) ||
            !ct.meta.is_ntt_form || ct.polys.size() != 2 ||
            ct.meta.component_count != 2 || ct.meta.degree != n ||
            ct.meta.q_count != q || ct.meta.p_count != 0)
        {
            return false;
        }
        for (const auto &poly : ct.polys)
        {
            if (poly.shards.size() != 1)
            {
                return false;
            }
            const auto &sh = poly.shards.front();
            if (sh.ptr == nullptr || sh.device_id != expected_dev ||
                sh.limb_begin != 0 || sh.limb_count != q ||
                sh.coeff_begin != 0 || sh.coeff_count != n)
            {
                return false;
            }
        }
        return true;
    };

    const auto valid_mut_ct = [&](const GpuCiphertextView &ct, int expected_dev) {
        if (!(ct.meta.parms_id == level_info.parms_id) ||
            !ct.meta.is_ntt_form || ct.polys.size() != 2 ||
            ct.meta.component_count != 2 || ct.meta.degree != n ||
            ct.meta.q_count != q || ct.meta.p_count != 0)
        {
            return false;
        }
        for (const auto &poly : ct.polys)
        {
            if (poly.shards.size() != 1)
            {
                return false;
            }
            const auto &sh = poly.shards.front();
            if (sh.ptr == nullptr || sh.device_id != expected_dev ||
                sh.limb_begin != 0 || sh.limb_count != q ||
                sh.coeff_begin != 0 || sh.coeff_count != n)
            {
                return false;
            }
        }
        return true;
    };

    if (sources[0].polys.empty() || sources[0].polys[0].shards.empty())
    {
        return false;
    }
    const auto &first_shard = sources[0].polys[0].shards.front();
    const int device_id = first_shard.device_id;
    const auto *parameters = find_parameter_shard(level_info, first_shard);
    if (parameters == nullptr ||
        parameters->limb_begin != 0 ||
        parameters->hybrid_base_q_count != q ||
        parameters->hybrid_base_p_count < q ||
        parameters->hybrid_base_p_count > 64 ||
        parameters->hybrid_decomp_count != 1 ||
        parameters->hybrid_inv_p_mod_q.size() < q)
    {
        return false;
    }
    const std::size_t p = parameters->hybrid_base_p_count;
    const std::size_t total_limbs = q + p;
    if (parameters->ntt_tables.size() < total_limbs * n ||
        parameters->fourstep_intt_tables.size() < total_limbs * n ||
        parameters->inv_degree_modulo.size() < total_limbs)
    {
        return false;
    }

    if (!(galois_keys_view.meta.key_parms_id == galois_keys_data.meta.key_parms_id) ||
        galois_keys_view.storage_q_count != galois_keys_data.meta.q_count ||
        galois_keys_view.meta.q_count != q ||
        galois_keys_view.meta.decomposition_count < 1 ||
        galois_keys_view.storage_q_count < q ||
        galois_keys_view.meta.component_count < kSwitchKeyComponentCount ||
        galois_keys_data.meta.p_count != p ||
        galois_keys_data.meta.degree != n ||
        galois_keys_data.poly_metadata_.empty() ||
        galois_keys_data.polys_.size() != galois_keys_view.polys.size())
    {
        return false;
    }

    for (std::size_t i = 0; i < total_count; ++i)
    {
        if (!valid_const_ct(sources[i], device_id) ||
            !valid_mut_ct(destinations[i], device_id) ||
            key_indices[i] >= galois_keys_view.meta.key_count)
        {
            return false;
        }
        if (shared_key && key_indices[i] != key_indices[0])
        {
            return false;
        }
        const std::uint32_t elt = galois_elts[i];
        if ((elt & 1U) == 0U || elt >= 2U * n)
        {
            return false;
        }
        const GpuWord *dst0 = destinations[i].polys[0].shards.front().ptr;
        const GpuWord *dst1 = destinations[i].polys[1].shards.front().ptr;
        const GpuWord *src0 = sources[i].polys[0].shards.front().ptr;
        if (dst0 == dst1 || dst0 == src0 || dst1 == src0)
        {
            return false;
        }
        if (add_sources != nullptr)
        {
            const auto *add_ct = (*add_sources)[i];
            if (add_ct == nullptr || !valid_const_ct(*add_ct, device_id))
            {
                return false;
            }
            const GpuWord *add0 = add_ct->polys[0].shards.front().ptr;
            const GpuWord *add1 = add_ct->polys[1].shards.front().ptr;
            if (add0 == dst1 || add1 == dst0)
            {
                return false;
            }
        }
    }

    kernel::validate_hybrid_relinearize_pair_parameters(*parameters, n);
    std::vector<HybridKeyComponentView> keys0(total_count), keys1(total_count);
    for (std::size_t i = 0; i < (shared_key ? std::size_t{1} : total_count); ++i)
    {
        keys0[i] = make_hybrid_key_component_view(
            find_key_poly(galois_keys_view, galois_keys_data, key_indices[i], 0, 0),
            galois_keys_view,
            galois_keys_data);
        keys1[i] = make_hybrid_key_component_view(
            find_key_poly(galois_keys_view, galois_keys_data, key_indices[i], 0, 1),
            galois_keys_view,
            galois_keys_data);
        if (keys0[i].device_id != device_id || keys1[i].device_id != device_id)
        {
            return false;
        }
    }

    gpu_check_cuda(cudaSetDevice(device_id), "batch rotate dnum1 cudaSetDevice");
    if ((q > 1 && parameters->opt_q_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size()) ||
        parameters->opt_p_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size())
    {
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "batch rotate table capture status");
        if (status != cudaStreamCaptureStatusNone)
        {
            throw std::logic_error("batch rotate dnum1: warm up preweight tables before graph capture");
        }
    }
    const GpuWord *q_inverse =
        q > 1 ? kernel::hybrid_q_preweighted_inv_degree_table(*parameters) : nullptr;
    if (q > 1 && q_inverse == nullptr)
    {
        return false;
    }
    const GpuWord *p_inverse = kernel::hybrid_p_preweighted_inv_degree_table(*parameters);
    if (p_inverse == nullptr)
    {
        return false;
    }

    auto &s = *persistent_workspace_;
    const auto ensure = [&](DeviceVector<GpuWord> &buffer, std::size_t words) {
        if (buffer.size() >= words && buffer.device_id() == device_id)
        {
            return;
        }
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "batch rotate workspace capture status");
        if (status != cudaStreamCaptureStatusNone)
        {
            throw std::logic_error("batch rotate dnum1: warm up workspace before graph capture");
        }
        buffer.allocate(words, device_id);
    };

    const std::size_t max_chunk = std::min(total_count, kernel::kMaxBatchKeySwitchItems);
    const std::size_t q_words = q * n;
    const std::size_t p_words = p * n;
    ensure(s.rot_permuted_c1, max_chunk * q_words);
    ensure(s.rot_c1_coeff, max_chunk * q_words);
    ensure(s.rot_modup_p, max_chunk * p_words);
    ensure(s.rot_accum_q, 2 * max_chunk * q_words);
    ensure(s.rot_accum_p, 2 * max_chunk * p_words);
    ensure(s.rot_p_coeff, 2 * max_chunk * p_words);
    ensure(s.rot_converted_q, 2 * max_chunk * q_words);

    NvtxRange range("keyswitch.hybrid.rotate_dnum1_batch");
    for (std::size_t offset = 0; offset < total_count; offset += kernel::kMaxBatchKeySwitchItems)
    {
        const std::size_t chunk = std::min(kernel::kMaxBatchKeySwitchItems, total_count - offset);
        kernel::BatchRotateDnum1Args args{};
        for (std::size_t b = 0; b < chunk; ++b)
        {
            const std::size_t idx = offset + b;
            args.dst_c0[b] = destinations[idx].polys[0].shards.front().ptr;
            args.dst_c1[b] = destinations[idx].polys[1].shards.front().ptr;
            args.src_c0[b] = sources[idx].polys[0].shards.front().ptr;
            args.src_c1[b] = sources[idx].polys[1].shards.front().ptr;
            args.galois_elts[b] = galois_elts[idx];
            if (add_sources != nullptr)
            {
                args.add_c0[b] = (*add_sources)[idx]->polys[0].shards.front().ptr;
                args.add_c1[b] = (*add_sources)[idx]->polys[1].shards.front().ptr;
            }
            if (!shared_key)
            {
                args.key_q0[b] = keys0[idx].q_ptr;
                args.key_p0[b] = keys0[idx].p_ptr;
                args.key_q1[b] = keys1[idx].q_ptr;
                args.key_p1[b] = keys1[idx].p_ptr;
            }
        }

        kernel::launch_batch_apply_galois_ntt_65536(
            s.rot_permuted_c1.data(), args, chunk, q, device_id);

        GpuPolyShardView c1_coeff_view{device_id, s.rot_c1_coeff.data(), 0, q, 0, n};
        GpuConstPolyShardView perm_c1_view{device_id, s.rot_permuted_c1.data(), 0, q, 0, n};
        kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
            c1_coeff_view, perm_c1_view, *parameters, n, chunk, q_words, q_words, q_inverse);

        kernel::launch_hybrid_modup_p_only_preweighted_batch_65536(
            s.rot_modup_p.data(), s.rot_c1_coeff.data(), chunk, *parameters);

        GpuPolyShardView modup_p_view{device_id, s.rot_modup_p.data(), q, p, 0, n};
        GpuConstPolyShardView modup_p_const_view{device_id, s.rot_modup_p.data(), q, p, 0, n};
        kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
            modup_p_view, modup_p_const_view, *parameters, n, chunk);

        if (shared_key)
        {
            kernel::launch_batch_dnum1_keymul_shared_key_65536(
                s.rot_accum_q.data(),
                s.rot_accum_p.data(),
                s.rot_permuted_c1.data(),
                s.rot_modup_p.data(),
                keys0[0].q_ptr,
                keys0[0].p_ptr,
                keys1[0].q_ptr,
                keys1[0].p_ptr,
                chunk,
                *parameters);
        }
        else
        {
            kernel::launch_batch_dnum1_keymul_distinct_keys_65536(
                s.rot_accum_q.data(),
                s.rot_accum_p.data(),
                s.rot_permuted_c1.data(),
                s.rot_modup_p.data(),
                args,
                chunk,
                *parameters);
        }

        const std::size_t comp_count = 2 * chunk;
        GpuPolyShardView p_coeff_view{device_id, s.rot_p_coeff.data(), q, p, 0, n};
        GpuConstPolyShardView accum_p_view{device_id, s.rot_accum_p.data(), q, p, 0, n};
        kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
            p_coeff_view, accum_p_view, *parameters, n, comp_count, p_words, p_words, p_inverse);

        kernel::launch_hybrid_convert_p_to_q_preweighted_batch(
            s.rot_converted_q.data(), s.rot_p_coeff.data(), comp_count, *parameters, n);

        kernel::FusedModDownBatchArgs64 rot_md_args{};
        const bool has_add = (add_sources != nullptr);
        for (std::size_t b = 0; b < chunk; ++b)
        {
            const std::size_t z0 = 2 * b + 0;
            const std::size_t z1 = 2 * b + 1;
            rot_md_args.dst[z0] = args.dst_c0[b];
            rot_md_args.dst[z1] = args.dst_c1[b];
            rot_md_args.accum_q[z0] = s.rot_accum_q.data() + z0 * q_words;
            rot_md_args.accum_q[z1] = s.rot_accum_q.data() + z1 * q_words;
            rot_md_args.galois_src[z0] = args.src_c0[b];
            rot_md_args.galois_elts[z0] = args.galois_elts[b];
            if (has_add)
            {
                rot_md_args.add_q[z0] = args.add_c0[b];
                rot_md_args.add_q[z1] = args.add_c1[b];
            }
        }
        if (!kernel::launch_forward_ntt_moddown_batch_fourstep_65536(
                s.rot_converted_q.data(),
                s.rot_converted_q.data(),
                rot_md_args,
                comp_count,
                has_add,
                true,
                *parameters))
        {
            GpuPolyShardView conv_q_view{device_id, s.rot_converted_q.data(), 0, q, 0, n};
            GpuConstPolyShardView conv_q_const_view{device_id, s.rot_converted_q.data(), 0, q, 0, n};
            kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
                conv_q_view, conv_q_const_view, *parameters, n, comp_count);

            kernel::launch_batch_dnum1_apply_moddown_65536(
                args,
                s.rot_accum_q.data(),
                s.rot_converted_q.data(),
                chunk,
                add_sources != nullptr,
                *parameters);
        }
    }
    return true;
}

bool GpuKeySwitchHandler::try_rotate_dnum1_distinct_sum(
    GpuCiphertextView &destination,
    const GpuConstCiphertextView *identity_source,
    const std::vector<GpuConstCiphertextView> &sources,
    const std::vector<std::uint32_t> &galois_elts,
    const std::vector<std::size_t> &key_indices,
    const GpuConstEvaluationKeyView &galois_keys_view,
    const GpuEvaluationKeyData &galois_keys_data,
    const GpuLevelInfo &level_info) const
{
    const std::size_t batch_count = sources.size();
    if (!conv_batch_rotate_enabled() ||
        !opt_flag(OptFlag::ModupPreweight) ||
        !opt_flag(OptFlag::PToQPreweight) ||
        batch_count == 0 || batch_count > kernel::kMaxBatchKeySwitchItems ||
        galois_elts.size() != batch_count ||
        key_indices.size() != batch_count)
    {
        return false;
    }
    if (galois_keys_data.meta.galois_format != GpuGaloisKeyFormat::Standard)
    {
        return false;
    }

    const std::size_t n = level_info.degree;
    const std::size_t q = level_info.q_count;
    if (n != 65536 || q == 0)
    {
        return false;
    }

    const auto valid_const_ct = [&](const GpuConstCiphertextView &ct, int expected_dev) {
        if (!(ct.meta.parms_id == level_info.parms_id) ||
            !ct.meta.is_ntt_form || ct.polys.size() != 2 ||
            ct.meta.component_count != 2 || ct.meta.degree != n ||
            ct.meta.q_count != q || ct.meta.p_count != 0)
        {
            return false;
        }
        for (const auto &poly : ct.polys)
        {
            if (poly.shards.size() != 1)
            {
                return false;
            }
            const auto &sh = poly.shards.front();
            if (sh.ptr == nullptr || sh.device_id != expected_dev ||
                sh.limb_begin != 0 || sh.limb_count != q ||
                sh.coeff_begin != 0 || sh.coeff_count != n)
            {
                return false;
            }
        }
        return true;
    };

    if (!(destination.meta.parms_id == level_info.parms_id) ||
        !destination.meta.is_ntt_form || destination.polys.size() != 2 ||
        destination.meta.component_count != 2 || destination.meta.degree != n ||
        destination.meta.q_count != q || destination.meta.p_count != 0 ||
        destination.polys[0].shards.size() != 1 ||
        destination.polys[1].shards.size() != 1)
    {
        return false;
    }
    const auto &dst_sh0 = destination.polys[0].shards.front();
    const auto &dst_sh1 = destination.polys[1].shards.front();
    const int device_id = dst_sh0.device_id;
    if (dst_sh0.ptr == nullptr || dst_sh1.ptr == nullptr ||
        dst_sh0.ptr == dst_sh1.ptr || dst_sh1.device_id != device_id ||
        dst_sh0.limb_begin != 0 || dst_sh0.limb_count != q ||
        dst_sh0.coeff_begin != 0 || dst_sh0.coeff_count != n ||
        dst_sh1.limb_begin != 0 || dst_sh1.limb_count != q ||
        dst_sh1.coeff_begin != 0 || dst_sh1.coeff_count != n)
    {
        return false;
    }

    if (identity_source != nullptr)
    {
        if (!valid_const_ct(*identity_source, device_id))
        {
            return false;
        }
        const GpuWord *id0 = identity_source->polys[0].shards.front().ptr;
        const GpuWord *id1 = identity_source->polys[1].shards.front().ptr;
        if (id0 == dst_sh1.ptr || id1 == dst_sh0.ptr)
        {
            return false;
        }
    }

    const GpuConstPolyShardView probe{device_id, dst_sh0.ptr, 0, q, 0, n};
    const auto *parameters = find_parameter_shard(level_info, probe);
    if (parameters == nullptr ||
        parameters->limb_begin != 0 ||
        parameters->hybrid_base_q_count != q ||
        parameters->hybrid_base_p_count < q ||
        parameters->hybrid_base_p_count > 64 ||
        parameters->hybrid_decomp_count != 1 ||
        parameters->hybrid_inv_p_mod_q.size() < q)
    {
        return false;
    }
    const std::size_t p = parameters->hybrid_base_p_count;
    const std::size_t total_limbs = q + p;
    if (parameters->ntt_tables.size() < total_limbs * n ||
        parameters->fourstep_intt_tables.size() < total_limbs * n ||
        parameters->inv_degree_modulo.size() < total_limbs)
    {
        return false;
    }

    if (!(galois_keys_view.meta.key_parms_id == galois_keys_data.meta.key_parms_id) ||
        galois_keys_view.storage_q_count != galois_keys_data.meta.q_count ||
        galois_keys_view.meta.q_count != q ||
        galois_keys_view.meta.decomposition_count < 1 ||
        galois_keys_view.storage_q_count < q ||
        galois_keys_view.meta.component_count < kSwitchKeyComponentCount ||
        galois_keys_data.meta.p_count != p ||
        galois_keys_data.meta.degree != n ||
        galois_keys_data.poly_metadata_.empty() ||
        galois_keys_data.polys_.size() != galois_keys_view.polys.size())
    {
        return false;
    }

    kernel::BatchRotateDnum1Args args{};
    for (std::size_t b = 0; b < batch_count; ++b)
    {
        if (!valid_const_ct(sources[b], device_id) ||
            key_indices[b] >= galois_keys_view.meta.key_count)
        {
            return false;
        }
        const std::uint32_t elt = galois_elts[b];
        if ((elt & 1U) == 0U || elt >= 2U * n)
        {
            return false;
        }
        const GpuWord *src0 = sources[b].polys[0].shards.front().ptr;
        const GpuWord *src1 = sources[b].polys[1].shards.front().ptr;
        if (src0 == dst_sh0.ptr || src0 == dst_sh1.ptr)
        {
            return false;
        }
        const auto k0 = make_hybrid_key_component_view(
            find_key_poly(galois_keys_view, galois_keys_data, key_indices[b], 0, 0),
            galois_keys_view,
            galois_keys_data);
        const auto k1 = make_hybrid_key_component_view(
            find_key_poly(galois_keys_view, galois_keys_data, key_indices[b], 0, 1),
            galois_keys_view,
            galois_keys_data);
        if (k0.device_id != device_id || k1.device_id != device_id)
        {
            return false;
        }
        args.src_c0[b] = src0;
        args.src_c1[b] = src1;
        args.galois_elts[b] = elt;
        args.key_q0[b] = k0.q_ptr;
        args.key_p0[b] = k0.p_ptr;
        args.key_q1[b] = k1.q_ptr;
        args.key_p1[b] = k1.p_ptr;
    }

    kernel::validate_hybrid_relinearize_pair_parameters(*parameters, n);
    gpu_check_cuda(cudaSetDevice(device_id), "batch rotate sum cudaSetDevice");
    if ((q > 1 && parameters->opt_q_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size()) ||
        parameters->opt_p_preweighted_inv_degree.size() != parameters->inv_degree_modulo.size())
    {
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "batch rotate sum table capture status");
        if (status != cudaStreamCaptureStatusNone)
        {
            throw std::logic_error("batch rotate sum: warm up preweight tables before graph capture");
        }
    }
    const GpuWord *q_inverse =
        q > 1 ? kernel::hybrid_q_preweighted_inv_degree_table(*parameters) : nullptr;
    if (q > 1 && q_inverse == nullptr)
    {
        return false;
    }
    const GpuWord *p_inverse = kernel::hybrid_p_preweighted_inv_degree_table(*parameters);
    if (p_inverse == nullptr)
    {
        return false;
    }

    auto &s = *persistent_workspace_;
    const auto ensure = [&](DeviceVector<GpuWord> &buffer, std::size_t words) {
        if (buffer.size() >= words && buffer.device_id() == device_id)
        {
            return;
        }
        cudaStreamCaptureStatus status;
        gpu_check_cuda(cudaStreamIsCapturing(gpu_execution_stream(), &status), "batch rotate sum workspace capture status");
        if (status != cudaStreamCaptureStatusNone)
        {
            throw std::logic_error("batch rotate sum: warm up workspace before graph capture");
        }
        buffer.allocate(words, device_id);
    };

    const std::size_t q_words = q * n;
    const std::size_t p_words = p * n;
    ensure(s.rot_permuted_c1, batch_count * q_words);
    ensure(s.rot_c1_coeff, batch_count * q_words);
    ensure(s.rot_modup_p, batch_count * p_words);
    ensure(s.rot_accum_q, 2 * q_words);
    ensure(s.rot_accum_p, 2 * p_words);
    ensure(s.rot_p_coeff, 2 * p_words);
    ensure(s.rot_converted_q, 2 * q_words);

    NvtxRange range("keyswitch.hybrid.rotate_dnum1_sum");
    kernel::launch_batch_apply_galois_ntt_65536(
        s.rot_permuted_c1.data(), args, batch_count, q, device_id);

    GpuPolyShardView c1_coeff_view{device_id, s.rot_c1_coeff.data(), 0, q, 0, n};
    GpuConstPolyShardView perm_c1_view{device_id, s.rot_permuted_c1.data(), 0, q, 0, n};
    kernel::launch_inverse_ntt_poly_shard_batch_fourstep_65536(
        c1_coeff_view, perm_c1_view, *parameters, n, batch_count, q_words, q_words, q_inverse);

    kernel::launch_hybrid_modup_p_only_preweighted_batch_65536(
        s.rot_modup_p.data(), s.rot_c1_coeff.data(), batch_count, *parameters);

    GpuPolyShardView modup_p_view{device_id, s.rot_modup_p.data(), q, p, 0, n};
    GpuConstPolyShardView modup_p_const_view{device_id, s.rot_modup_p.data(), q, p, 0, n};
    kernel::launch_forward_ntt_poly_shard_batch_fourstep_65536(
        modup_p_view, modup_p_const_view, *parameters, n, batch_count);

    kernel::launch_batch_dnum1_keymul_sum_lazy_moddown_65536(
        s.rot_accum_q.data(),
        s.rot_accum_p.data(),
        s.rot_permuted_c1.data(),
        s.rot_modup_p.data(),
        args,
        batch_count,
        *parameters);

    kernel::launch_inverse_ntt_two_components_fourstep_65536(
        s.rot_p_coeff.data(),
        s.rot_p_coeff.data() + p_words,
        s.rot_accum_p.data(),
        s.rot_accum_p.data() + p_words,
        q,
        p,
        *parameters,
        p_inverse);

    kernel::launch_hybrid_convert_p_to_q_preweighted_batch(
        s.rot_converted_q.data(), s.rot_p_coeff.data(), 2, *parameters, n);

    kernel::launch_forward_ntt_two_components_inplace_fourstep_65536(
        s.rot_converted_q.data(), s.rot_converted_q.data() + q_words, q, *parameters);

    const GpuWord *id0 = identity_source != nullptr
        ? identity_source->polys[0].shards.front().ptr
        : nullptr;
    const GpuWord *id1 = identity_source != nullptr
        ? identity_source->polys[1].shards.front().ptr
        : nullptr;
    kernel::launch_batch_dnum1_apply_moddown_sum_65536(
        dst_sh0.ptr,
        dst_sh1.ptr,
        id0,
        id1,
        args,
        s.rot_accum_q.data(),
        s.rot_converted_q.data(),
        batch_count,
        *parameters);
    return true;
}

}  // namespace gpu
}  // namespace poseidon
