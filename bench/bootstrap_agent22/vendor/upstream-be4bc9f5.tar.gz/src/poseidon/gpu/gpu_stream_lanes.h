#pragma once

// Fork/join of independent GPU work over several CUDA streams (A800
// catch-up, 2026-11-14). Lane 0 is the caller's stream; the other lanes use
// non-blocking streams that are created once and reused. Work is still issued
// from one host thread in its original order; only the stream it runs on
// changes, so results are unchanged. Library code that keeps scratch between
// calls selects it by gpu_execution_stream() (rescale, relinearization).
//
// Lanes are only opened from the per-thread default stream: a GpuStreamLanes
// constructed inside another lane has one lane, so nesting cannot reuse a
// stream that an enclosing fork still owns.

#include "poseidon/gpu/gpu_memory.h"

#include <cstddef>
#include <optional>
#include <vector>

namespace poseidon
{
namespace gpu
{

class GpuStreamLanes
{
public:
    explicit GpuStreamLanes(std::size_t requested)
        : lanes_(requested < 1 ? 1 : requested)
    {
        if (gpu_execution_stream() != cudaStreamPerThread)
        {
            lanes_ = 1;
        }
        if (lanes_ == 1)
        {
            return;
        }
        auto &pool = shared_pool();
        while (pool.streams.size() + 1 < lanes_)
        {
            cudaStream_t stream = nullptr;
            gpu_check_cuda(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking),
                           "GpuStreamLanes stream create");
            pool.streams.push_back(stream);
        }
        while (pool.events.size() < lanes_)
        {
            cudaEvent_t event = nullptr;
            gpu_check_cuda(cudaEventCreateWithFlags(&event, cudaEventDisableTiming),
                           "GpuStreamLanes event create");
            pool.events.push_back(event);
        }
        main_ = gpu_execution_stream();
        gpu_check_cuda(cudaEventRecord(pool.events[0], main_), "GpuStreamLanes fork record");
        for (std::size_t lane = 1; lane < lanes_; ++lane)
        {
            gpu_check_cuda(cudaStreamWaitEvent(pool.streams[lane - 1], pool.events[0], 0),
                           "GpuStreamLanes fork wait");
        }
    }

    GpuStreamLanes(const GpuStreamLanes &) = delete;
    GpuStreamLanes &operator=(const GpuStreamLanes &) = delete;

    ~GpuStreamLanes()
    {
        try
        {
            join();
        }
        catch (...)
        {
        }
    }

    std::size_t count() const { return lanes_; }

    cudaStream_t stream(std::size_t lane) const
    {
        const std::size_t index = lane % lanes_;
        return index == 0 ? (main_ ? main_ : gpu_execution_stream())
                          : shared_pool().streams[index - 1];
    }

    // Makes the caller's stream wait for every lane. Idempotent.
    void join()
    {
        if (lanes_ == 1 || joined_)
        {
            return;
        }
        joined_ = true;
        auto &pool = shared_pool();
        for (std::size_t lane = 1; lane < lanes_; ++lane)
        {
            gpu_check_cuda(cudaEventRecord(pool.events[lane], pool.streams[lane - 1]),
                           "GpuStreamLanes join record");
            gpu_check_cuda(cudaStreamWaitEvent(main_, pool.events[lane], 0),
                           "GpuStreamLanes join wait");
        }
    }

private:
    struct Pool
    {
        std::vector<cudaStream_t> streams;
        std::vector<cudaEvent_t> events;
    };
    static Pool &shared_pool()
    {
        static Pool pool;
        return pool;
    }

    std::size_t lanes_;
    cudaStream_t main_ = nullptr;
    bool joined_ = false;
};

// Runs the enclosing scope's GPU work on one lane (no-op for lane 0 or a
// single-lane fork). Declare it before the scope's temporaries so they are
// released on the same stream.
class GpuLaneScope
{
public:
    GpuLaneScope(const GpuStreamLanes &lanes, std::size_t lane)
    {
        if (lanes.count() > 1 && lane % lanes.count() != 0)
        {
            scope_.emplace(lanes.stream(lane));
        }
    }

private:
    std::optional<ScopedGpuExecutionStream> scope_;
};

}  // namespace gpu
}  // namespace poseidon
