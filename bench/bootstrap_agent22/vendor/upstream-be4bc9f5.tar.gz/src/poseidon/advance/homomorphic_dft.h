#pragma once

#include "homomorphic_linear_transform.h"
#include <cmath>
#include <complex>
#include <map>
#include <vector>

namespace poseidon
{
typedef int LinearType;
const LinearType encode = 0;
const LinearType decode = 1;

std::vector<std::complex<double>> get_roots_float64(int nth_root);

std::tuple<std::vector<std::vector<std::complex<double>>>,
           std::vector<std::vector<std::complex<double>>>,
           std::vector<std::vector<std::complex<double>>>>
ifft_plain_vec(uint32_t log_n, uint32_t dslots, std::vector<std::complex<double>> roots,
               std::vector<int> pow5);

std::tuple<std::vector<std::vector<std::complex<double>>>,
           std::vector<std::vector<std::complex<double>>>,
           std::vector<std::vector<std::complex<double>>>>
fft_plain_vec(uint32_t log_n, uint32_t dslots, std::vector<std::complex<double>> roots,
              std::vector<int> pow5);

void slice_bit_reverse_in_place(std::vector<std::complex<double>> &slice, int n);
void add_to_diag_matrix(std::map<int, std::vector<std::complex<double>>> &diag_mat, int index,
                        const std::vector<std::complex<double>> &vec);
std::vector<std::complex<double>> add(const std::vector<std::complex<double>> &a,
                                      const std::vector<std::complex<double>> &b);
std::vector<std::complex<double>> mul(const std::vector<std::complex<double>> &a,
                                      const std::vector<std::complex<double>> &b);
std::vector<std::complex<double>> rotate(const std::vector<std::complex<double>> &x, int n);
std::map<int, std::vector<std::complex<double>>>
gen_fft_diag_matrix(uint32_t log_l, uint32_t fft_level, std::vector<std::complex<double>> a,
                    std::vector<std::complex<double>> b, std::vector<std::complex<double>> c,
                    LinearType lt_type, bool bit_reversed);

std::map<int, std::vector<std::complex<double>>> multiply_fft_matrix_with_next_fft_level(
    const std::map<int, std::vector<std::complex<double>>> &vec, uint32_t log_l, uint32_t n,
    uint32_t next_level, std::vector<std::complex<double>> a, std::vector<std::complex<double>> b,
    std::vector<std::complex<double>> c, LinearType lt_type, bool bit_reversed);
std::map<int, std::vector<std::complex<double>>> gen_repack_matrix(uint32_t log_l,
                                                                   bool bit_reversed);

class HomomorphicDFTMatrixLiteral
{
public:
    HomomorphicDFTMatrixLiteral(LinearType type, uint32_t log_n, uint32_t log_slots,
                                uint32_t level_start, std::vector<uint32_t> levels,
                                bool repack_imag_to_real = false, double scaling = 1.0,
                                bool bit_reversed = false, uint32_t log_bsgs_ratio = 0,
                                std::vector<uint32_t> layer_groups = {},
                                uint32_t direct_layer_threshold = 0);

    POSEIDON_NODISCARD LinearType get_type() const;
    POSEIDON_NODISCARD uint32_t get_log_n() const;
    POSEIDON_NODISCARD uint32_t get_log_slots() const;
    POSEIDON_NODISCARD uint32_t get_level_start() const;
    POSEIDON_NODISCARD const std::vector<uint32_t> &get_levels() const;
    POSEIDON_NODISCARD bool get_repack_imag_to_real() const;
    POSEIDON_NODISCARD double get_scaling() const;
    POSEIDON_NODISCARD bool get_bit_reversed() const;
    POSEIDON_NODISCARD uint32_t get_log_bsgs_ratio() const;
    std::vector<std::map<int, std::vector<std::complex<double>>>> gen_matrices();
    void create(LinearMatrixGroup &mat_group, CKKSEncoder &encoder, uint32_t step);
    // Input weights are folded into the first matrix's columns, so
    // applying a plaintext mask does not require a separate multiply/rescale.
    void create(LinearMatrixGroup &mat_group, CKKSEncoder &encoder, uint32_t step,
                const std::vector<double> &input_weights);

    /**
     * @brief Encode every DFT matrix at one logical CKKS scale and plan each
     * physical suffix drop with the GS min_scale/2 rule.
     */
    void create_dynamic(
        LinearMatrixGroup &mat_group,
        CKKSEncoder &encoder,
        double input_scale,
        double plaintext_scale,
        double min_scale,
        double value_normalization = 1.0);

private:
    LinearType type_;
    uint32_t log_n_;
    uint32_t log_slots_;
    uint32_t level_start_;
    std::vector<uint32_t> levels_;
    bool repack_imag_to_real_;
    double scaling_;
    bool bit_reversed_;
    uint32_t log_bsgs_ratio_;
    std::vector<uint32_t> layer_groups_;
    uint32_t direct_layer_threshold_;
    uint32_t get_depth(bool actual);
};

}  // namespace poseidon
