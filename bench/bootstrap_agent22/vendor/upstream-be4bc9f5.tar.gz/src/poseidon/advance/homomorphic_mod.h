#pragma once

#include "polynomial_evaluation.h"
#include "poseidon/advance/util/chebyshev_interpolation.h"
#include "poseidon/advance/util/cosine_approx.h"
#include "poseidon/basics/util/common.h"
#include "poseidon/poseidon_context.h"
#include <utility>

namespace poseidon
{
int optimal_split(int log_degree);
int optimal_split_optimized(int log_degree);
bool is_not_negligible(complex<double> c);
pair<bool, bool> is_odd_or_even_polynomial(Polynomial &coeffs);

class EvalModPoly
{
public:
    EvalModPoly(const PoseidonContext &context, SineType type, double scaling_factor,
                uint32_t level_start, uint32_t log_message_ratio, uint32_t double_angle, uint32_t k,
                uint32_t arcsine_degree, uint32_t sine_degree);

    inline static complex<double> sin_2pi_x(const complex<double> &x)
    {
        return sin(6.283185307179586 * x);
    }

    inline SineType type() const { return this->type_; }

    inline double k() const { return this->k_; }

    inline double q_div() const { return this->q_div_; }

    inline int level_start() const { return this->level_start_; }

    inline double scaling_factor() const { return this->scaling_factor_; }

    inline uint32_t message_ratio() const { return 1 << this->log_message_ratio_; }

    inline uint32_t double_angle() const { return this->double_angle_; }

    inline double q_diff() const { return this->q_diff_; }

    inline double sc_fac() const { return this->sc_fac_; }

    inline double sqrt_2pi() const { return this->sqrt_2pi_; }

    inline double sine_poly_a() const { return sine_poly_a_; }
    inline double sine_poly_b() const { return sine_poly_b_; }
    inline const Polynomial &sine_poly() const { return this->sine_poly_; }

    /**
     * Keep Chebyshev coefficients T_0 through T_max_degree. This is an
     * explicit experimental approximation change, not a level/scale change.
     */
    void truncate_sine_polynomial(uint32_t max_degree)
    {
        auto &coefficients = sine_poly_.data();
        const std::size_t requested_size =
            static_cast<std::size_t>(max_degree) + 1;
        if (coefficients.size() > requested_size)
        {
            coefficients.resize(requested_size);
        }
        sine_poly_.max_degree() = static_cast<int>(
            coefficients.empty() ? 0 : coefficients.size() - 1);
    }

    /**
     * Replace the discrete-cosine coefficients with an exact fixed-degree
     * Chebyshev interpolation of the same phase-shifted base function.
     * This experimental source preserves the current double-angle semantics
     * but is not a Remez/minimax fit.
     */
    void refit_discrete_cosine_fixed_degree(uint32_t degree);

    inline const Polynomial &arcsine_poly() const { return this->arcsine_poly_; }

    // Experimental coefficient replacement for the current CosDiscrete fit.
    // Supply UNSCALED Chebyshev coefficients in the existing normalized basis
    // (input to EvalMod is (t-1/4)/K). The coefficient count must stay unchanged.
    // Applies sqrt_2pi internally and enables every nonzero parity, including
    // odd terms that the legacy CosDiscrete evaluator skipped.
    void set_cosine_coefficients(const std::vector<double> &coefficients);

    // Keep the generated coefficients unchanged, but evaluate all of them.
    // Opt-in: the legacy constructor's even-only behavior is preserved.
    void enable_full_cosine_coefficients();

    void set_level_start(uint32_t level) { level_start_ = level; }

private:
    SineType type_;
    double scaling_factor_;
    uint32_t level_start_;
    uint32_t log_message_ratio_;
    uint32_t double_angle_;
    double k_;
    double q_div_;
    double q_diff_;
    double sc_fac_;
    double sqrt_2pi_;

    Polynomial sine_poly_;
    Polynomial arcsine_poly_;

    double sine_poly_a_;
    double sine_poly_b_;
};

}  // namespace poseidon
