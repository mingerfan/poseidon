cmake_minimum_required(VERSION 3.12)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_C_STANDARD 99)

# CMake modules
include(CMakePushCheckState)
include(CheckCXXSourceCompiles)
include(GNUInstallDirs)

# Extra modules
list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_LIST_DIR}/cmake)
include(PoseidonMacros)

#select COMPILER
option(CROSS_COMPILE_ARRCH64 "Compile with aarch64" OFF)
message(STATUS "CROSS_COMPILE_ARRCH64: ${CROSS_COMPILE_ARRCH64}")
if(CROSS_COMPILE_ARRCH64)
    SET(CMAKE_C_COMPILER /data/gcc-arm-11.2/bin/aarch64-none-linux-gnu-gcc)
    SET(CMAKE_CXX_COMPILER /data/gcc-arm-11.2/bin/aarch64-none-linux-gnu-g++)
    if(NOT GMP_ROOT)
        set(GMP_ROOT "/data/gmp-arm/gmp-6.3.0-install" CACHE PATH
            "GMP installation prefix")
    endif()
endif ()

project(Poseidon VERSION 1.0.0 LANGUAGES CXX C)

find_package(GMP REQUIRED MODULE)

# 根据ASAN的值来设置编译器标志
option(ASAN "Enable AddressSanitizer" OFF)  
if(ASAN)
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -fsanitize=address -fsanitize-recover=address -fno-stack-protector -fno-omit-frame-pointer")
    message(STATUS "AddressSanitizer enabled.") 
else()
    message(STATUS "AddressSanitizer disabled.")
endif()

# [option] CMAKE_BUILD_TYPE (default: "Release")
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE "Release" CACHE STRING "Build type" FORCE)
    set_property(CACHE CMAKE_BUILD_TYPE PROPERTY
            STRINGS "Release" "Debug" "MinSizeRel" "RelWithDebInfo")
endif()
message(STATUS "Build type (CMAKE_BUILD_TYPE): ${CMAKE_BUILD_TYPE}")

# Always build position-independent-code
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Make the install target depend on the all target (required by vcpkg)
set(CMAKE_SKIP_INSTALL_ALL_DEPENDENCY OFF)

set(POSEIDON_USE_CXX17_OPTION_STR "Use C++17")
option(POSEIDON_USE_CXX17 ${POSEIDON_USE_CXX17_OPTION_STR} ON)
message(STATUS "POSEIDON_USE_CXX17: ${POSEIDON_USE_CXX17}")

SET(CMAKE_C_FLAGS_RELEASE "${CMAKE_C_FLAGS_RELEASE} -O3 -DNDEBUG -fPIC -pthread ")
SET(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS_RELEASE} -O3 -DNDEBUG -fPIC -pthread ")
SET (CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -fopenmp")

set(CMAKE_THREAD_PREFER_PTHREAD TRUE)
set(THREADS_PREFER_PTHREAD_FLAG TRUE)

message("-- Install Path: ${CMAKE_INSTALL_PREFIX}")
set(CMAKE_INSTALL_RPATH "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_LIBDIR}")
set(CMAKE_INSTALL_RPATH_USE_LINK_PATH TRUE)

# Source Tree
set(POSEIDON_INCLUDES_DIR ${CMAKE_CURRENT_LIST_DIR})
set(POSEIDON_CONFIG_H_IN_FILENAME ${POSEIDON_INCLUDES_DIR}/src/poseidon/util/config.h.in)

# Build tree
set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/${OUTLIB_PATH})
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/${OUTLIB_PATH})
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/bin)
set(POSEIDON_CONFIG_FILENAME ${CMAKE_CURRENT_BINARY_DIR}/cmake/POSEIDONConfig.cmake)
set(POSEIDON_CONFIG_H_FILENAME ${CMAKE_CURRENT_BINARY_DIR}/poseidon/util/config.h)
set(POSEIDON_THIRDPARTY_DIR ${CMAKE_CURRENT_BINARY_DIR}/thirdparty)
include_directories(${CMAKE_CURRENT_BINARY_DIR})

# Install
set(POSEIDON_CONFIG_INSTALL_DIR ${CMAKE_INSTALL_LIBDIR}/cmake)
set(POSEIDON_INCLUDES_INSTALL_DIR ${CMAKE_INSTALL_INCLUDEDIR})

#########################
# External dependencies #
#########################

# 目前只添加了zstd和zlib两个压缩库
# [option] POSEIDON_BUILD_DEPS (default: OFF)
# Download and build missing dependencies, throw error if disabled.
set(POSEIDON_BUILD_DEPS_OPTION_STR "Automatically download and build unmet dependencies")
option(POSEIDON_BUILD_DEPS ${POSEIDON_BUILD_DEPS_OPTION_STR} ON)
message(STATUS "POSEIDON_BUILD_DEPS: ${POSEIDON_BUILD_DEPS}")

if(POSEIDON_BUILD_DEPS)
    include(FetchContent)
    mark_as_advanced(FETCHCONTENT_BASE_DIR)
    mark_as_advanced(FETCHCONTENT_FULLY_DISCONNECTED)
    mark_as_advanced(FETCHCONTENT_UPDATES_DISCONNECTED)
    mark_as_advanced(FETCHCONTENT_QUIET)
endif()

# [option] POSEIDON_USE_ZLIB (default: ON)
set(POSEIDON_USE_ZLIB_OPTION_STR "Use ZLIB for compressed serialization")
option(POSEIDON_USE_ZLIB ${POSEIDON_USE_ZLIB_OPTION_STR} ON)
message(STATUS "POSEIDON_USE_ZLIB: ${POSEIDON_USE_ZLIB}")

if(POSEIDON_USE_ZLIB)
    if(POSEIDON_BUILD_DEPS)
        message(STATUS "ZLIB: download ...")
        poseidon_fetch_thirdparty_content(ExternalZLIB)
        set(zlib "zlibstatic")
    else()
        find_package(ZLIB 1)
        if(NOT ZLIB_FOUND)
            message(FATAL_ERROR "ZLIB: not found")
        else()
            message(STATUS "ZLIB: found")
        endif()
        set(zlib "ZLIB::ZLIB")
    endif()
endif()

# [option] POSEIDON_USE_ZSTD (default: ON)
set(POSEIDON_USE_ZSTD_OPTION_STR "Use Zstandard for compressed serialization")
option(POSEIDON_USE_ZSTD ${POSEIDON_USE_ZSTD_OPTION_STR} ON)
message(STATUS "POSEIDON_USE_ZSTD: ${POSEIDON_USE_ZSTD}")

if(POSEIDON_USE_ZSTD)
    if(POSEIDON_BUILD_DEPS)
        message(STATUS "Zstandard: download ...")
        poseidon_fetch_thirdparty_content(ExternalZSTD)
        set(zstd_static "libzstd_static")
    else()
        find_package(zstd CONFIG)
        if(NOT zstd_FOUND)
            message(FATAL_ERROR "Zstandard: not found")
        else()
            if(TARGET zstd::libzstd_static)
                set(zstd_static "zstd::libzstd_static")
            elseif(TARGET libzstd)
                get_target_property(libzstd_type libzstd TYPE)
                if(libzstd_type STREQUAL "STATIC_LIBRARY")
                    set(zstd_static "libzstd")
                    message(STATUS "Zstandard: found")
                else()
                    message(FATAL_ERROR "Zstandard: must be static")
                endif()
            elseif(TARGET zstd::libzstd_shared)
                message(FATAL_ERROR "Zstandard: must be static")
            else()
                message(FATAL_ERROR "Zstandard: not found")
            endif()
        endif()
    endif()
endif()

# [option] POSEIDON_USE_MSGSL (default: ON)
set(POSEIDON_USE_MSGSL_OPTION_STR "Use Microsoft GSL")
option(POSEIDON_USE_MSGSL ${POSEIDON_USE_MSGSL_OPTION_STR} ON)
message(STATUS "POSEIDON_USE_MSGSL: ${POSEIDON_USE_MSGSL}")

if(POSEIDON_USE_MSGSL)
    if(POSEIDON_BUILD_DEPS)
        message(STATUS "Microsoft GSL: download ...")
        poseidon_fetch_thirdparty_content(ExternalMSGSL)
    else()
        find_package(Microsoft.GSL 4 CONFIG)
        if(NOT Microsoft.GSL_FOUND)
            message(FATAL_ERROR "Microsoft GSL: not found")
        else()
            message(STATUS "Microsoft GSL: found")
        endif()
    endif()
endif()

# [option] POSEIDON_USE_INTEL_HEXL (default: OFF)
set(POSEIDON_USE_INTEL_HEXL_OPTION_STR "Use Intel HEXL library")
option(POSEIDON_USE_INTEL_HEXL ${POSEIDON_USE_INTEL_HEXL_OPTION_STR} OFF)
message(STATUS "POSEIDON_USE_INTEL_HEXL: ${POSEIDON_USE_INTEL_HEXL}")

if(POSEIDON_USE_INTEL_HEXL)
    if(POSEIDON_BUILD_DEPS)
        message(STATUS "Intel HEXL: download ...")
        poseidon_fetch_thirdparty_content(ExternalIntelHEXL)
    else()
        find_package(HEXL 1.2.6)
        if (NOT TARGET HEXL::hexl)
            message(FATAL_ERROR "Intel HEXL: not found")
        endif()
    endif()
endif()

# [option] POSEIDON_USE_OPENMP (default: OFF)
option(POSEIDON_USE_OPENMP "Enable OpenMP for POSEIDON" OFF)
message(STATUS "POSEIDON_USE_OPENMP: ${POSEIDON_USE_OPENMP}")
if(POSEIDON_USE_OPENMP)
    SET(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -fopenmp")
    find_package(OpenMP REQUIRED)
    if(OpenMP_CXX_FOUND)
        set(USING_OPENMP ON)
    endif()
endif()


# [option] POSEIDON_USE_SPDLOG (default: ON)
option(POSEIDON_USE_SPDLOG "Enable spdlog for POSEIDON" ON)
message(STATUS "POSEIDON_USE_SPDLOG: ${POSEIDON_USE_SPDLOG}")
if(POSEIDON_USE_SPDLOG)
    if(POSEIDON_BUILD_DEPS)
        message(STATUS "spdlog: download ...")
        poseidon_fetch_thirdparty_content(ExternalSpdlog)
    else()
        find_package(spdlog REQUIRED)
        # RMM also uses these packages from a child directory and requires
        # global imported targets. Promote them where find_package created them.
        foreach(_logging_target IN ITEMS
                spdlog::spdlog spdlog::spdlog_header_only
                fmt::fmt fmt::fmt-header-only)
            if(TARGET ${_logging_target})
                get_target_property(_logging_imported ${_logging_target} IMPORTED)
                get_target_property(_logging_alias ${_logging_target} ALIASED_TARGET)
                if(_logging_imported AND NOT _logging_alias)
                    set_target_properties(${_logging_target}
                        PROPERTIES IMPORTED_GLOBAL TRUE)
                endif()
            endif()
        endforeach()
        unset(_logging_target)
        unset(_logging_imported)
        unset(_logging_alias)
    endif()
endif()

# Create the config file
configure_file(${POSEIDON_CONFIG_H_IN_FILENAME} ${POSEIDON_CONFIG_H_FILENAME})
install(
        FILES ${POSEIDON_CONFIG_H_FILENAME}
        DESTINATION ${POSEIDON_INCLUDES_INSTALL_DIR}/poseidon/util)

# [option] POSEIDON_USE_HARDWARE (default: OFF)
# If you turn on POSEIDON_USE_HARDWARE, you need to install poseidon_hardware first.
option(POSEIDON_USE_HARDWARE OFF)
message(STATUS "POSEIDON_USE_HARDWARE: ${POSEIDON_USE_HARDWARE}")
if(POSEIDON_USE_HARDWARE)
    set(USING_HARDWARE ON)
endif()
add_subdirectory(src/poseidon)

# [option] POSEIDON_BUILD_EXAMPLES (default: ON)
option(POSEIDON_BUILD_EXAMPLES "Build examples for POSEIDON" ON)
message(STATUS "POSEIDON_BUILD_EXAMPLES: ${POSEIDON_BUILD_EXAMPLES}")
if(POSEIDON_BUILD_EXAMPLES)
    add_subdirectory(examples/bfv)
    add_subdirectory(examples/bgv)
    add_subdirectory(examples/ckks)
endif()

# [option] POSEIDON_BUILD_BENCH (default: OFF)
option(POSEIDON_BUILD_BENCH "Build examples for POSEIDON" OFF)
message(STATUS "POSEIDON_BUILD_BENCH: ${POSEIDON_BUILD_BENCH}")
if(POSEIDON_BUILD_BENCH)
    add_subdirectory(bench)
endif()

add_library(poseidon_shared SHARED ${POSEIDON_SOURCE_FILES})    
target_include_directories(poseidon_shared PUBLIC ${POSEIDON_INCLUDES_DIR}/src)
target_link_libraries(poseidon_shared PUBLIC GMP::gmpxx)
if(POSEIDON_USE_HARDWARE)    
    target_link_libraries(poseidon_shared PUBLIC poseidon_hardware)
endif()

if(POSEIDON_USE_MSGSL)
    if(POSEIDON_BUILD_DEPS)
        target_include_directories(poseidon_shared PUBLIC $<BUILD_INTERFACE:${msgsl_SOURCE_DIR}/include>)
    else()
        target_link_libraries(poseidon_shared PUBLIC Microsoft.GSL::GSL)
    endif()
endif()

if(POSEIDON_USE_ZLIB)
    target_link_libraries(poseidon_shared PRIVATE ${zlib})
    target_include_directories(poseidon_shared PRIVATE $<BUILD_INTERFACE:${zlib_SOURCE_DIR}>)
    target_include_directories(poseidon_shared PRIVATE $<BUILD_INTERFACE:$<TARGET_PROPERTY:${zlib},BINARY_DIR>>)
endif()

if(POSEIDON_USE_ZSTD)
    target_include_directories(poseidon_shared PRIVATE $<BUILD_INTERFACE:${zstd_SOURCE_DIR}/lib>)
    target_include_directories(poseidon_shared PRIVATE $<BUILD_INTERFACE:${zstd_SOURCE_DIR}/lib/common>)
    target_link_libraries(poseidon_shared PRIVATE ${zstd_static})
endif()

if(POSEIDON_BUILD_DEPS)
    # MSGSL
    if(POSEIDON_USE_MSGSL)
        install(
            DIRECTORY ${msgsl_SOURCE_DIR}/include/gsl
            DESTINATION ${POSEIDON_INCLUDES_INSTALL_DIR})
    endif()
endif()

if(POSEIDON_USE_INTEL_HEXL)
    target_link_libraries(poseidon_shared PRIVATE HEXL::hexl)
    target_compile_options(poseidon_shared PRIVATE $<TARGET_PROPERTY:HEXL::hexl,INTERFACE_COMPILE_OPTIONS>)
    get_target_property(HEXL_INTERFACE_LINK_OPTIONS HEXL::hexl INTERFACE_LINK_OPTIONS)
    if (NOT "${HEXL_INTERFACE_LINK_OPTIONS}" STREQUAL "HEXL_INTERFACE_LINK_OPTIONS-NOTFOUND")
        target_link_libraries(poseidon_shared INTERFACE ${HEXL_INTERFACE_LINK_OPTIONS})
    endif()

    # Install shared HEXL library to installation directory
    install(DIRECTORY ${CMAKE_LIBRARY_OUTPUT_DIRECTORY}
            DESTINATION ${CMAKE_INSTALL_PREFIX}/${CMAKE_LIBRARY_PREFIX}
            FILES_MATCHING PATTERN "*hexl*"
    )
endif()

if(POSEIDON_USE_OPENMP)
    target_link_libraries(poseidon_shared PRIVATE OpenMP::OpenMP_CXX)
    target_compile_definitions(poseidon_shared PRIVATE POSEIDON_USE_OPENMP)
endif()

if(POSEIDON_USE_SPDLOG)
    if(POSEIDON_BUILD_DEPS)
        target_include_directories(poseidon_shared PUBLIC $<BUILD_INTERFACE:${spdlog_SOURCE_DIR}/include>)
    else()
        target_link_libraries(poseidon_shared PUBLIC spdlog::spdlog)
    endif()
endif()

# [option] POSEIDON_BUILD_CKKS_RUNTIME_API (default: OFF)
option(POSEIDON_BUILD_CKKS_RUNTIME_API
    "Build the optional CKKS Runtime CPU/GPU Api integration" OFF)
message(STATUS "POSEIDON_BUILD_CKKS_RUNTIME_API: ${POSEIDON_BUILD_CKKS_RUNTIME_API}")
option(POSEIDON_BUILD_GPU "Build the standalone Poseidon GPU library" OFF)
option(POSEIDON_BUILD_RESNET20_S2C_FIRST
    "Build the self-contained S2C-first ResNet20 application" OFF)
option(POSEIDON_BUILD_LLAMA31_CERIUM_SOURCE15
    "Build the source15 Cerium-based Llama 3.1-8B API benchmark" OFF)

set(POSEIDON_CKKS_RUNTIME_SOURCE_DIR
    "${CMAKE_CURRENT_SOURCE_DIR}/third_party/ckks-runtime" CACHE PATH
    "Path to the CKKS Runtime source tree")

if(POSEIDON_BUILD_CKKS_RUNTIME_API)
    if(NOT EXISTS "${POSEIDON_CKKS_RUNTIME_SOURCE_DIR}/CMakeLists.txt")
        message(FATAL_ERROR
            "CKKS Runtime CMakeLists.txt was not found at "
            "${POSEIDON_CKKS_RUNTIME_SOURCE_DIR}.\n"
            "Initialize the bundled Runtime with:\n"
            "  git submodule update --init third_party/ckks-runtime\n"
            "or set POSEIDON_CKKS_RUNTIME_SOURCE_DIR to another checkout.")
    endif()

    add_subdirectory(
        "${POSEIDON_CKKS_RUNTIME_SOURCE_DIR}"
        "${CMAKE_CURRENT_BINARY_DIR}/ckks-runtime"
        EXCLUDE_FROM_ALL)

    option(POSEIDON_BUILD_CKKS_RUNTIME_TESTS
        "Build CKKS Runtime Api integration tests" ON)
    message(STATUS
        "POSEIDON_BUILD_CKKS_RUNTIME_TESTS: ${POSEIDON_BUILD_CKKS_RUNTIME_TESTS}")
    option(POSEIDON_BUILD_CKKS_RUNTIME_GPU_TESTS
        "Build CKKS Runtime GPU Api tests that require a CUDA device" OFF)
    message(STATUS
        "POSEIDON_BUILD_CKKS_RUNTIME_GPU_TESTS: ${POSEIDON_BUILD_CKKS_RUNTIME_GPU_TESTS}")
    option(POSEIDON_BUILD_CKKS_RUNTIME_MPI
        "Enable MPI mode in PoseidonCpuApi" OFF)
    message(STATUS
        "POSEIDON_BUILD_CKKS_RUNTIME_MPI: ${POSEIDON_BUILD_CKKS_RUNTIME_MPI}")
    option(POSEIDON_BUILD_CKKS_RUNTIME_GPU_NCCL
        "Enable the optional MPI/NCCL GPU communication backend" OFF)
    message(STATUS
        "POSEIDON_BUILD_CKKS_RUNTIME_GPU_NCCL: ${POSEIDON_BUILD_CKKS_RUNTIME_GPU_NCCL}")
    if(POSEIDON_BUILD_CKKS_RUNTIME_TESTS)
        enable_testing()
    endif()

endif()

if(POSEIDON_BUILD_CKKS_RUNTIME_API OR POSEIDON_BUILD_GPU OR
   POSEIDON_BUILD_RESNET20_S2C_FIRST OR POSEIDON_BUILD_LLAMA31_CERIUM_SOURCE15)
    enable_language(CUDA)
    set(CMAKE_CUDA_STANDARD 17)
    set(CMAKE_CUDA_STANDARD_REQUIRED ON)
    if(NOT CMAKE_CUDA_ARCHITECTURES)
        set(CMAKE_CUDA_ARCHITECTURES 75 CACHE STRING
            "CUDA architectures for the Poseidon GPU library" FORCE)
    endif()

    add_subdirectory(src/poseidon/gpu)
endif()

if(POSEIDON_BUILD_CKKS_RUNTIME_API)
    add_subdirectory(src/poseidon/runtime_api)
endif()

if(POSEIDON_BUILD_RESNET20_S2C_FIRST)
    enable_testing()
    add_subdirectory(bench/resnet20_s2c_first)
endif()

if(POSEIDON_BUILD_LLAMA31_CERIUM_SOURCE15)
    add_subdirectory(bench/llama31_cerium_source15)
endif()

install(
        TARGETS poseidon_shared
        LIBRARY DESTINATION lib
        ARCHIVE DESTINATION lib
        PUBLIC_HEADER DESTINATION include
)
