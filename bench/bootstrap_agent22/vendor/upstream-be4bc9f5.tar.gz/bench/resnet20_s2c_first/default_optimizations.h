#pragma once

// Default-on optimizations of the hand-written ResNet20 application.
//
// The GPU library keeps every POSEIDON_OPT_* switch off by default, so other
// workloads are unaffected. This application turns on the configuration that
// was measured best for it: each variable is set here only when it is unset,
// so an explicit value (including 0, as `run_optimized.sh off` sets) wins.
//
// Since the 2026-11-15 merge with the superopt line both cards default to
// run_optimized.sh a800 / 4090: main's switches #1-8, EvalMod pair, the
// superopt kernels (coalesced NTT phase 2, fused ModDown, paired/joint
// relin-rescale, uint2 base conversion, unified P=9 paths, fused baby
// groups, shared-memory baby tiles: 4 items on sm_80, 2 on sm_89) and the
// real-only Boot. Convolution/ReLU streams stay at 1: the paired and batched
// key-switch scratch is not per stream (relu_precision.cpp also falls back to
// one stream whenever POSEIDON_RELU_RELIN_RESCALE=1).
// A800, 2026-11-15 (Q49 fixture / Q43 fixture): main 1205.4 ms; merged with
// these defaults see background/ResNet20优化汇总与superopt融合分析-20261115.md.
//
// The kernel switches are bit-identical rewrites and are defaulted with any
// schedule. CUDA Graph is defaulted only for clean timing
// (POSEIDON_S2C_CUPTI=0) with the built-in single-device schedule; with a
// POSEIDON_S2C_SCHEDULE file the real-only Boot is not defaulted, because it
// does not combine with a two-device EvalMod split.

#include <cuda_runtime_api.h>

#include <cstdlib>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

namespace poseidon::benchmark::s2c_first
{

inline void apply_default_optimizations()
{
    const auto unset = [](const char *name) {
        const char *value = std::getenv(name);
        return value == nullptr || *value == '\0';
    };
    int major = 0, minor = 0;
    if (cudaDeviceGetAttribute(&major, cudaDevAttrComputeCapabilityMajor, 0) != cudaSuccess ||
        cudaDeviceGetAttribute(&minor, cudaDevAttrComputeCapabilityMinor, 0) != cudaSuccess)
    {
        cudaGetLastError();
        major = minor = 0;
    }
    const bool rtx4090_profile = major == 8 && minor == 9;
    const bool default_schedule = unset("POSEIDON_S2C_SCHEDULE");
    const char *cupti = std::getenv("POSEIDON_S2C_CUPTI");
    const bool clean_timing = cupti != nullptr && std::string(cupti) == "0";

    std::vector<std::pair<const char *, const char *>> defaults = {
        {"POSEIDON_OPT_INPLACE_INTT", "1"},
        {"POSEIDON_OPT_MODUP_PW", "1"},
        {"POSEIDON_OPT_PTOQ_PW", "1"},
        {"POSEIDON_OPT_LAZY_PMAC", "1"},
        {"POSEIDON_OPT_SHOUP_NTT", "1"},
        {"POSEIDON_OPT_C1_NOPAD", "1"},
        {"POSEIDON_OPT_FUSED_RESCALE", "1"},
        {"POSEIDON_OPT_MODUP_FOLD", "1"},
        {"POSEIDON_OPT_EVALMOD_PAIR", "1"},
        // superopt kernels (run_optimized.sh a800 / 4090)
        {"POSEIDON_OPT_COALESCED_NTT2", "1"},
        {"POSEIDON_OPT_FUSED_MODDOWN", "2"},
        {"POSEIDON_OPT_LAZY_BABY", "1"},
        {"POSEIDON_OPT_MODUP_TILE", "8"},
        {"POSEIDON_OPT_PTOQ_TILE", "8"},
        {"POSEIDON_OPT_PTOQ_DUAL_TILE", "6"},
        {"POSEIDON_OPT_FUSED_BABY8", "1"},
        {"POSEIDON_SHARED_BABY_MAC", "2"},
        {"POSEIDON_OPT_SHARED_BABY_ITEMS", rtx4090_profile ? "2" : "4"},
        {"POSEIDON_SKIP_GIANT_Q_COPY", "1"},
        {"POSEIDON_OPT_RELIN_RESCALE_X1", "1"},
        {"POSEIDON_OPT_RELIN_RESCALE_PAIR", "1"},
        {"POSEIDON_OPT_FUSED_RELIN_RESCALE", "1"},
        {"POSEIDON_OPT_VEC_BCONV", "1"},
        {"POSEIDON_OPT_UNIFY_P9", "1"},
        {"POSEIDON_GPU_RELIN_PAIR", "1"},
        {"POSEIDON_GPU_RELIN_PAIR_ARENA", "1"},
        {"POSEIDON_RELU_RELIN_RESCALE", "1"},
        {"POSEIDON_GPU_RELIN_RESCALE_MERGED", "1"},
    };
    if (default_schedule)
    {
        defaults.push_back({"POSEIDON_OPT_BOOT_REAL_ONLY", "1"});
        if (clean_timing)
            defaults.push_back({"POSEIDON_S2C_CUDA_GRAPH", "1"});
    }

    std::string applied;
    for (const auto &[name, value] : defaults)
    {
        if (!unset(name))
            continue;
        setenv(name, value, 0);
        applied += (applied.empty() ? "" : ",") + std::string(name) + "=" + value;
    }
    std::cout << "DEFAULT_OPTIMIZATIONS profile=" << (rtx4090_profile ? "4090" : "a800")
              << " compute_capability=" << major << '.' << minor
              << " default_schedule=" << (default_schedule ? "true" : "false")
              << " clean_timing=" << (clean_timing ? "true" : "false")
              << " applied=" << (applied.empty() ? "none" : applied) << '\n';
}

}  // namespace poseidon::benchmark::s2c_first
