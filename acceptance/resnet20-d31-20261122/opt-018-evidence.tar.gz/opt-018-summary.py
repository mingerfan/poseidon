import csv, glob, re, statistics
for mode in ('off','on'):
    rows=[]
    for path in sorted(glob.glob('opt-018-'+mode+'-[1-5].log')):
        text=open(path).read()
        wall=float(re.search(r'ONLINE_TIMING .*?wall_ms=([\d.]+)',text)[1])
        gpu=float(re.search(r'GPU_ACTIVITY_TIMING gpu_total_ms=([\d.]+)',text)[1])
        cts=float(re.search(r'GPU_STAGE_DETAIL name=cts_rotation gpu_union_ms=([\d.]+)',text)[1])
        err=float(re.search(r'NETWORK .*?max_logit_error=([\deE.+-]+)',text)[1])
        kernels=sum(int(m) for m in re.findall(r'GPU_STAGE_DETAIL .*? kernels=(\d+)',text))
        with open(path[:-4]+'-memory.csv') as f: peak=max(float(r[1]) for r in csv.reader(f) if len(r)>1)
        rows.append((wall,gpu,cts,kernels,peak,err))
    print(mode,'count',len(rows),'rows',rows)
    for i,name in enumerate(('wall_ms','gpu_ms','cts_ms','kernels','peak_mib','error')):
        vals=[r[i] for r in rows]; print(name,'median',statistics.median(vals),'min',min(vals),'max',max(vals))
