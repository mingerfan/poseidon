#!/usr/bin/env bash
set -u
root=/root/resnet20-d31-perf-20261120.4aP2lX
pid=$(cat "$root/opt-021-driver.pid")
while kill -0 "$pid" 2>/dev/null && [ ! -e "$root/opt-021-bv-probe.log" ]; do sleep 5; done
kill -0 "$pid" 2>/dev/null || exit 0
nvidia-smi --query-gpu=timestamp,memory.used,utilization.gpu --format=csv,noheader,nounits -lms 200 > "$root/opt-021-probe-memory.csv" 2>&1 & monitor=$!
trap 'kill "$monitor" 2>/dev/null || true' EXIT
while kill -0 "$pid" 2>/dev/null && ! grep -q PROBES_PASSED "$root/opt-021-driver.log"; do sleep 1; done
