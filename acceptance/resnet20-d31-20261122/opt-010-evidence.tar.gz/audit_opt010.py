import csv
import json
import math
import re
from pathlib import Path

root = Path('/root/resnet20-d31-perf-20261120.4aP2lX')
with (root / 'opt-008-results-reference.csv').open(newline='', encoding='utf-8-sig') as f:
    reference = {int(row['image']): row for row in csv.DictReader(f)}
assert set(reference) == set(range(1000)), 'invalid frozen reference'
seen = {}
for name in ('opt-010-correctness-0-88.log', 'opt-010-correctness-88-912.log'):
    for line in (root / name).read_text().splitlines():
        if not line.startswith('NETWORK image='):
            continue
        fields = dict(re.findall(r'(\w+)=([^ ]+)', line))
        image = int(fields['image'])
        assert image in reference and image not in seen, f'unexpected/duplicate image {image}'
        prior = reference[image]
        level = re.search(r'\bL(\d+)\b', line)
        error, scale = float(fields['max_logit_error']), float(fields['scale'])
        assert fields['result'] == 'PASS' and int(fields['activations']) == 19
        assert level and int(level.group(1)) == 2 and math.isfinite(scale) and scale > 0
        assert int(fields['plain']) == int(prior['frozen_d31_prediction'])
        assert int(fields['predicted']) == int(prior['frozen_d31_prediction'])
        assert int(fields['label']) == int(prior['label'])
        assert math.isfinite(error) and error < 0.01
        seen[image] = error
assert set(seen) == set(reference), f'missing samples: {len(set(reference) - set(seen))}'
summary = {'images': len(seen), 'gpu_matches_frozen_d31': len(seen),
           'max_logit_error': max(seen.values()),
           'd31_matches_labels': sum(int(row['frozen_d31_prediction']) == int(row['label']) for row in reference.values()),
           'd31_matches_exact_relu': sum(int(row['frozen_d31_prediction']) == int(row['exact_relu_prediction']) for row in reference.values())}
(root / 'opt-010-audit.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
