#!/usr/bin/env bash
set -uo pipefail
root=/root/resnet20-d31-perf-20261120.4aP2lX
while kill -0 623028 2>/dev/null || kill -0 623029 2>/dev/null; do sleep 10; done
grep -qx OPT010_AB_COMPLETE "$root/opt-010-driver.log" || { echo PRIOR_AB_INCOMPLETE; exit 1; }
grep -Eq '^(OPT010_CORRECTNESS_COMPLETE|PERFORMANCE_GATE_FAILED)$' "$root/opt-010-correctness-driver.log" || { echo PRIOR_VALIDATION_INCOMPLETE; exit 1; }
cd "$root/source" || exit 1
git worktree add -b work/resnet20-fused-d31-lazy-accumulate "$root/opt011-worktree" f3f720db4cdf57f227849ec2e20a04e70fe2c977 || exit 1
cp "$root/opt011-input/gpu_wide_bv_opt011.cu" "$root/opt011-worktree/src/poseidon/gpu/gpu_wide_bv.cu" || exit 1
cp "$root/opt011-input/gpu_wide_bv_opt011.h" "$root/opt011-worktree/src/poseidon/gpu/gpu_wide_bv.h" || exit 1
base=/root/resnet20-a800-20261117.KgGe5I
cd "$root/opt011-worktree" || exit 1
git diff --check || exit 1
git diff > "$root/opt-011.patch"
sha256sum src/poseidon/gpu/gpu_wide_bv.cu src/poseidon/gpu/gpu_wide_bv.h > "$root/opt-011-source.sha256"
"$base/cmake-new/bin/cmake" -S . -B "$root/build-opt011" -DCMAKE_BUILD_TYPE=Release -DCMAKE_POSITION_INDEPENDENT_CODE=ON -DCMAKE_CUDA_ARCHITECTURES=80 -DPOSEIDON_BUILD_EXAMPLES=OFF -DPOSEIDON_BUILD_GPU=ON -DPOSEIDON_BUILD_RESNET20_S2C_FIRST=ON -DPOSEIDON_USE_ZLIB=OFF -DPOSEIDON_USE_ZSTD=OFF -DPOSEIDON_USE_MSGSL=OFF -DSPDLOG_FMT_EXTERNAL_HO=OFF -DFETCHCONTENT_SOURCE_DIR_SPDLOG="$PWD/third_party/spdlog" -DGMP_INCLUDE_DIR="$base/deps/usr/include/x86_64-linux-gnu" -DGMPXX_INCLUDE_DIR="$base/deps/usr/include" -DGMP_LIBRARY="$base/deps/usr/lib/x86_64-linux-gnu/libgmp.so" -DGMPXX_LIBRARY="$base/deps/usr/lib/x86_64-linux-gnu/libgmpxx.so" > "$root/opt-011-configure.log" 2>&1 || { echo CONFIG_FAILED; exit 1; }
"$base/cmake-new/bin/cmake" --build "$root/build-opt011" --target resnet20_wide_functional functional_wide_ntt_probe functional_wide_bv_probe -j 4 > "$root/opt-011-build.log" 2>&1 || { echo BUILD_FAILED; exit 1; }
sha256sum "$root/build-opt011/bin/resnet20_wide_functional" > "$root/opt-011-binary.sha256"
export CUDA_VISIBLE_DEVICES=0 POSEIDON_WIDE_NTT_FUSED=1 POSEIDON_WIDE_NTT_TILE=1024 POSEIDON_WIDE_POOL_GIB=60 POSEIDON_WIDE_FULL_KEYS=1 POSEIDON_WIDE_HOIST_DIGITS=1 POSEIDON_WIDE_HOIST_KEYCACHE=1 POSEIDON_CTS_LOG_BSGS_RATIO=1 POSEIDON_WIDE_FAST_LIFT=1 POSEIDON_WIDE_FUSED_ACCUMULATE=1 POSEIDON_WIDE_NTT_PAIR=1 POSEIDON_WIDE_INTT_PAIR=1 POSEIDON_WIDE_LAZY_ACCUMULATE=1
timeout 900 "$root/build-opt011/bin/functional_wide_ntt_probe" 31 > "$root/opt-011-probe.log" 2>&1 || { echo PROBE_FAILED; exit 1; }
timeout 900 "$root/build-opt011/bin/functional_wide_bv_probe" 31 > "$root/opt-011-bv-probe.log" 2>&1 || { echo BV_PROBE_FAILED; exit 1; }
echo PROBES_PASSED
for entry in off-1 on-1 on-2 off-2 off-3 on-3 on-4 off-4 off-5 on-5; do
 mode=${entry%-*}
 if [ "$mode" = on ]; then export POSEIDON_WIDE_LAZY_ACCUMULATE=1; else unset POSEIDON_WIDE_LAZY_ACCUMULATE; fi
 nvidia-smi --query-gpu=timestamp,memory.used,utilization.gpu --format=csv,noheader,nounits -lms 200 > "$root/opt-011-$entry-memory.csv" 2>&1 & monitor=$!
 timeout 900 "$root/build-opt011/bin/resnet20_wide_functional" 31 0 "$PWD/trident-functional/resnet20/functional_params" --benchmark > "$root/opt-011-$entry.log" 2>&1
 status=$?
 kill "$monitor" 2>/dev/null || true
 wait "$monitor" 2>/dev/null || true
 echo "OPT011_RUN=$entry STATUS=$status"
 [ "$status" -eq 0 ] || exit "$status"
done
echo OPT011_AB_COMPLETE
