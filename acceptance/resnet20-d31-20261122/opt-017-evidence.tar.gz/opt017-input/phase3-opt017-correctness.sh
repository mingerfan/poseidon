#!/usr/bin/env bash
set -uo pipefail
root=/root/resnet20-d31-perf-20261120.4aP2lX
pid=${1:?A/B driver PID required}
while kill -0 "$pid" 2>/dev/null; do sleep 10; done
grep -qx OPT017_AB_COMPLETE "$root/opt-017-driver.log" || { echo AB_INCOMPLETE; exit 1; }
cd "$root" || exit 1
python3 - <<'PY' || { echo PERFORMANCE_GATE_FAILED; exit 1; }
import glob, re, statistics
v={}
for mode in ('off','on'):
    files=glob.glob('opt-017-'+mode+'-[1-5].log')
    assert len(files)==5
    v[mode]=[float(re.search(r'ONLINE_TIMING .*?wall_ms=([\d.]+)',open(p).read())[1]) for p in files]
print('WALL_MS',v,flush=True)
assert max(v['on']) < min(v['off']) and statistics.median(v['on']) < .99*statistics.median(v['off'])
PY
cd "$root/opt017-worktree" || exit 1
sha256sum -c "$root/opt-017-source.sha256" || exit 1
sha256sum -c "$root/opt-017-binary.sha256" || exit 1
export CUDA_VISIBLE_DEVICES=0 POSEIDON_WIDE_NTT_FUSED=1 POSEIDON_WIDE_NTT_TILE=1024 POSEIDON_WIDE_POOL_GIB=60 POSEIDON_WIDE_FULL_KEYS=1 POSEIDON_WIDE_HOIST_DIGITS=1 POSEIDON_WIDE_HOIST_KEYCACHE=1 POSEIDON_CTS_LOG_BSGS_RATIO=1 POSEIDON_WIDE_FAST_LIFT=1 POSEIDON_WIDE_FUSED_ACCUMULATE=1 POSEIDON_WIDE_NTT_PAIR=1 POSEIDON_WIDE_INTT_PAIR=1 POSEIDON_WIDE_NTT_TRIPLE=1 POSEIDON_WIDE_INTT_TRIPLE=1 POSEIDON_WIDE_NTT_KEYACC=1 POSEIDON_WIDE_NTT_FIVE=1
for batch in 0:88 88:912; do
 start=${batch%:*}; count=${batch#*:}; logfile="$root/opt-017-correctness-$start-$count.log"
 [ ! -e "$logfile" ] || { echo REFUSING_OVERWRITE; exit 1; }
 timeout 7200 "$root/build-opt017/bin/resnet20_wide_functional" 31 "$start" "$PWD/trident-functional/resnet20/functional_params" "--batch=$count" > "$logfile" 2>&1
 status=$?
 echo "BATCH=$batch STATUS=$status RECORDS=$(grep -c '^NETWORK image=' "$logfile")"
 [ "$status" -eq 0 ] || exit "$status"
done
echo OPT017_CORRECTNESS_COMPLETE
